/* Racha estilo Duolingo: chip en la barra superior, hoja "Tu racha" con calendario y avisos. */
(function () {
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);
  const DIAS = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'];
  const DIA_ES = { lunes: 'Lun', martes: 'Mar', miercoles: 'Mié', jueves: 'Jue', viernes: 'Vie', sabado: 'Sáb', domingo: 'Dom' };
  const HORA_AVISO_PENDIENTE = 18;
  const LOCALES = { es: 'es-CO', en: 'en-US', de: 'de-DE' };

  let estado = null;
  let hoja = null;
  let enCurso = null;
  let anioVista = null;
  const calendarios = {};
  let cargandoAnio = false;

  const llaveEvento = () => {
    const usuario = window.__nutriamigoUser;
    return `nutriamigo_racha_evento_${usuario ? usuario.id : 'x'}`;
  };

  function leerUltimoEvento() {
    try {
      const v = localStorage.getItem(llaveEvento());
      return v === null ? null : parseInt(v, 10);
    } catch (e) {
      return null;
    }
  }

  function guardarUltimoEvento(id) {
    try { localStorage.setItem(llaveEvento(), String(id)); } catch (e) { /* almacenamiento no disponible */ }
  }

  function aUTC(fecha) {
    const [a, m, d] = fecha.split('-').map(Number);
    return Date.UTC(a, m - 1, d);
  }

  function sumar(fecha, n) {
    return new Date(aUTC(fecha) + n * 86400000).toISOString().slice(0, 10);
  }

  function indiceDia(fecha) {
    return (new Date(aUTC(fecha)).getUTCDay() + 6) % 7;
  }

  function pintarChip() {
    document.querySelectorAll('[data-user-streak]').forEach((el) => { el.textContent = estado.racha; });
    document.querySelectorAll('[data-streak-prot]').forEach((el) => { el.textContent = estado.protectores; });
    const etiqueta = t('racha.chipEtiqueta', 'Racha: {n} días, {p} protectores de racha')
      .replace('{n}', estado.racha).replace('{p}', estado.protectores);
    document.querySelectorAll('[data-streak-chip]').forEach((el) => el.setAttribute('aria-label', etiqueta));
  }

  function avisosNuevos(nuevoEstado) {
    const ultimo = leerUltimoEvento();
    const maxId = nuevoEstado.eventos.reduce((m, e) => Math.max(m, e.id), 0);
    if (ultimo === null) { guardarUltimoEvento(maxId); return; }
    const nuevos = nuevoEstado.eventos.filter((e) => e.id > ultimo);
    nuevos.forEach((e) => {
      if (e.tipo === 'accion') {
        const n = nuevoEstado.racha;
        const texto = n === 1
          ? t('racha.toastUno', '¡Racha de 1 día!')
          : t('racha.toastVarios', '¡Racha de {n} días!').replace('{n}', n);
        window.mostrarAviso(`🔥 ${texto}`, 'exito');
      } else if (e.tipo === 'protector_ganado') {
        window.mostrarAviso(t('racha.toastProtectorGanado', '🧊 Ganaste un protector de racha'), 'exito');
      } else if (e.tipo === 'protector_usado') {
        window.mostrarAviso(t('racha.toastProtectorUsado', '🧊 Un protector salvó tu racha'), 'info');
      } else if (e.tipo === 'protector_regalo') {
        window.mostrarAviso(t('racha.toastProtectorRegalo', '🎁 Recibiste tu protector de racha del mes'), 'info');
      } else if (e.tipo === 'perdida') {
        window.mostrarAviso(t('racha.toastPerdida', 'Tu racha volvió a 0. ¡Empieza de nuevo hoy, tú puedes!'), 'info', 7000);
      }
    });
    if (maxId > ultimo) guardarUltimoEvento(maxId);
  }

  function pintarBanner() {
    const principal = document.querySelector('.app-main');
    const previo = document.getElementById('rachaPendiente');
    const mostrar = document.body.classList.contains('page-dashboard')
      && estado.racha > 0 && !estado.hoyCumplido && new Date().getHours() >= HORA_AVISO_PENDIENTE;
    if (!mostrar) { if (previo) previo.remove(); return; }
    if (previo) {
      previo.textContent = `🔥 ${t('racha.pendiente', 'Hoy te falta una acción para mantener tu racha')}`;
      return;
    }
    if (!principal) return;
    const el = document.createElement('div');
    el.id = 'rachaPendiente';
    el.className = 'racha-pendiente';
    el.setAttribute('role', 'status');
    el.textContent = `🔥 ${t('racha.pendiente', 'Hoy te falta una acción para mantener tu racha')}`;
    const saludo = principal.querySelector('.greeting-row');
    if (saludo) saludo.after(el); else principal.prepend(el);
  }

  function localeActual() {
    const idioma = window.NutriIdioma && window.NutriIdioma.get ? window.NutriIdioma.get() : 'es';
    return LOCALES[idioma] || LOCALES.es;
  }

  function dosDigitos(n) { return String(n).padStart(2, '0'); }

  function celdaCalendario(fecha, datosAnio) {
    const marca = datosAnio.dias[fecha];
    const estadoDia = fecha > estado.hoy ? 'futuro'
      : marca === 'congelado' ? 'congelado'
      : marca === 'accion' ? 'accion' : 'sin';
    const icono = { accion: '🔥', congelado: '🧊', sin: '', futuro: '' }[estadoDia];
    const nombre = {
      accion: t('racha.diaAccion', 'con actividad'),
      congelado: t('racha.diaCongelado', 'cubierto con un protector'),
      sin: t('racha.diaSin', 'sin actividad'),
      futuro: ''
    }[estadoDia];
    const etiqueta = nombre ? `${fecha}: ${nombre}` : fecha;
    const clases = `racha-dia racha-dia-${estadoDia}${fecha === estado.hoy ? ' racha-dia-hoy' : ''}`;
    return `<div class="${clases}" role="listitem" aria-label="${etiqueta}"><span aria-hidden="true">${icono}</span></div>`;
  }

  /* Un mes: encabezado con el nombre, letras de los días y las celdas (la semana empieza el lunes). */
  function mesHtml(anio, mes, datosAnio, cabecera) {
    const nombre = new Intl.DateTimeFormat(localeActual(), { month: 'long', timeZone: 'UTC' }).format(new Date(Date.UTC(anio, mes - 1, 1)));
    const primero = `${anio}-${dosDigitos(mes)}-01`;
    const vacias = indiceDia(primero);
    const total = new Date(Date.UTC(anio, mes, 0)).getUTCDate();
    let celdas = '<div class="racha-dia racha-dia-vacio" aria-hidden="true"></div>'.repeat(vacias);
    for (let d = 1; d <= total; d += 1) celdas += celdaCalendario(`${anio}-${dosDigitos(mes)}-${dosDigitos(d)}`, datosAnio);
    return `<section class="racha-mes"><h5>${nombre}</h5><div class="racha-calendario racha-calendario-mini" role="list">${cabecera}${celdas}</div></section>`;
  }

  function calendarioAnualHtml() {
    const datos = calendarios[anioVista];
    if (!datos) return `<p class="racha-explica" role="status">${t('racha.cargandoCalendario', 'Cargando calendario…')}</p>`;
    const cabecera = DIAS.map((d) => `<div class="racha-cab" aria-hidden="true">${t('dia.' + d, DIA_ES[d]).slice(0, 1)}</div>`).join('');
    let meses = '';
    for (let m = 1; m <= 12; m += 1) meses += mesHtml(anioVista, m, datos, cabecera);
    const anterior = anioVista <= datos.primerAnio ? 'disabled' : '';
    const siguiente = anioVista >= datos.ultimoAnio ? 'disabled' : '';
    const resumen = t('racha.diasEnAnio', '{n} días con actividad en {a}').replace('{n}', datos.diasConActividad).replace('{a}', anioVista);
    return `
      <div class="racha-anio-nav">
        <button type="button" class="btn btn-ghost" data-racha-anio="-1" aria-label="${t('racha.anioAnterior', 'Año anterior')}" ${anterior}>‹</button>
        <strong aria-live="polite">${anioVista}</strong>
        <button type="button" class="btn btn-ghost" data-racha-anio="1" aria-label="${t('racha.anioSiguiente', 'Año siguiente')}" ${siguiente}>›</button>
      </div>
      <p class="racha-proximo">${resumen}</p>
      <div class="racha-anio">${meses}</div>
      <p class="racha-leyenda">🔥 ${t('racha.diaAccion', 'con actividad')} · 🧊 ${t('racha.diaCongelado', 'cubierto con un protector')}</p>`;
  }

  async function cargarAnio(anio) {
    anioVista = anio;
    if (calendarios[anio]) { pintarHoja(); return; }
    cargandoAnio = true;
    pintarHoja();
    try {
      calendarios[anio] = await window.api.get(`./api/streak/calendario?anio=${anio}`, { silencioso: true });
    } catch (err) {
      console.error('No se pudo cargar el calendario de la racha', err);
    } finally {
      cargandoAnio = false;
      pintarHoja();
    }
  }

  function contenidoHoja() {
    const vacio = estado.racha === 0
      ? `<p class="racha-vacio">${t('racha.vacio', 'Empieza hoy: marca una comida, una rutina o registra tu peso')}</p>` : '';
    const proximo = t('racha.proximo', 'Te faltan {n} días para ganar un protector').replace('{n}', estado.proximoProtectorEn);

    return `
      <h3 id="rachaTitulo">${t('racha.titulo', 'Tu racha')}</h3>
      <div class="racha-resumen">
        <div><strong>🔥 ${estado.racha}</strong><span>${t('racha.dias', 'días de racha')}</span></div>
        <div><strong>🧊 ${estado.protectores}/${estado.cap}</strong><span>${t('racha.protectores', 'Protectores de racha')}</span></div>
        <div><strong>🏆 ${estado.mejor}</strong><span>${t('racha.mejor', 'Mejor racha')}</span></div>
      </div>
      ${vacio}
      <p class="racha-proximo">${proximo}</p>
      <h4>${t('racha.calendarioCompleto', 'Calendario completo')}</h4>
      ${cargandoAnio && !calendarios[anioVista] ? `<p class="racha-explica" role="status">${t('racha.cargandoCalendario', 'Cargando calendario…')}</p>` : calendarioAnualHtml()}
      <p class="racha-explica">${t('racha.comoFunciona', 'Tu racha sube 1 cada día que marcas una comida, marcas una rutina o registras tu peso. Un protector 🧊 cubre un día sin actividad para que no pierdas la racha. Ganas uno cada 7 días.')}</p>
      <button type="button" class="btn btn-ghost" data-racha-cerrar>${t('racha.cerrar', 'Cerrar')}</button>`;
  }

  function pintarHoja() {
    if (!hoja) return;
    const cuerpo = hoja.querySelector('.modal');
    const asa = cuerpo.querySelector(':scope > .sheet-handle');
    cuerpo.innerHTML = contenidoHoja();
    if (asa) cuerpo.prepend(asa);
    hoja.querySelector('[data-racha-cerrar]').addEventListener('click', () => { hoja.hidden = true; });
    hoja.querySelectorAll('[data-racha-anio]').forEach((b) => {
      b.addEventListener('click', () => cargarAnio(anioVista + Number(b.dataset.rachaAnio)));
    });
  }

  function abrirHoja() {
    if (!estado) return;
    if (!hoja) {
      hoja = document.createElement('div');
      hoja.className = 'modal-overlay';
      hoja.id = 'rachaHoja';
      hoja.hidden = true;
      hoja.innerHTML = '<div class="modal racha-modal" role="dialog" aria-modal="true" aria-labelledby="rachaTitulo"></div>';
      document.body.appendChild(hoja);
    }
    anioVista = Number(estado.hoy.slice(0, 4));
    delete calendarios[anioVista];
    hoja.hidden = false;
    cargarAnio(anioVista);
  }

  function aplicar(nuevoEstado) {
    avisosNuevos(nuevoEstado);
    estado = nuevoEstado;
    pintarChip();
    pintarBanner();
    if (hoja && !hoja.hidden) pintarHoja();
  }

  async function refrescar() {
    if (enCurso) return enCurso;
    enCurso = (async () => {
      try {
        aplicar(await window.api.get('./api/streak', { silencioso: true }));
      } catch (err) {
        if (err.status !== 401 && err.status !== 404) console.error('No se pudo cargar la racha', err);
      } finally {
        enCurso = null;
      }
    })();
    return enCurso;
  }

  window.NutriRacha = { refrescar, abrir: abrirHoja };

  document.addEventListener('click', (e) => {
    const chip = e.target.closest && e.target.closest('[data-streak-chip]');
    if (chip) abrirHoja();
  });
  document.addEventListener('nutriamigo:user-ready', (e) => { if (e.detail) refrescar(); });
  document.addEventListener('nutriamigo:lang-changed', () => { if (estado) { pintarChip(); pintarBanner(); pintarHoja(); } });
})();
