(function () {
  const $ = (id) => document.getElementById(id);
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);

  function mostrar(texto) {
    $('mensaje').textContent = texto;
    $('mensaje').hidden = !texto;
  }

  document.addEventListener('DOMContentLoaded', () => {
    $('gsForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      mostrar('');
      const pass = $('gsPass').value;
      if (pass.length < 8) { mostrar(t('err.contrasena_corta', 'La contraseña debe tener al menos 8 caracteres')); return; }
      if (pass !== $('gsPass2').value) { mostrar(t('err.contrasenas_no_coinciden', 'Las contraseñas no coinciden')); return; }
      const boton = e.target.querySelector('button[type="submit"]');
      boton.disabled = true;
      try {
        const datos = await window.api.post('./auth/google-simulado', {
          nombre: $('gsNombre').value.trim(),
          email: $('gsCorreo').value.trim(),
          password: pass,
          confirmar: $('gsPass2').value
        }, { silencioso: true });
        window.location.href = `.${datos.siguiente}`;
      } catch (err) {
        mostrar(err.message || t('err.interno', 'Error interno'));
      } finally {
        boton.disabled = false;
      }
    });

    document.querySelectorAll('[data-mostrar]').forEach(chk => {
      chk.addEventListener('change', () => {
        chk.dataset.mostrar.split(',').forEach(id => { $(id).type = chk.checked ? 'text' : 'password'; });
      });
    });

    window.api.get('./api/me', { silencioso: true }).then((yo) => {
      if (yo.role === 'admin') $('pieAdmin').hidden = false;
    }).catch(() => { /* sin sesión: no pasa nada */ });
  });
})();
