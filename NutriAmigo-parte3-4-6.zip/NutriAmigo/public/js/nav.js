/* Barra superior (escritorio y tableta) y barra inferior (celular) de las páginas internas */
(function () {
  const LOGROS_DISPONIBLES = false; // la página de logros llega en una parte posterior

  const ICONOS = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    food: '<path d="M7 3v8a2 2 0 0 0 2 2v8"/><path d="M5 3v6"/><path d="M11 3v6"/><path d="M17 21V3c-2 2-3 5-3 8h3"/>',
    dumbbell: '<path d="M6 8v8M3 10v4M18 8v8M21 10v4M6 12h12"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M17 14c2.5 0 4 1.8 4 4.5"/>',
    more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>'
  };

  const DESTINOS = [
    { href: './dashboard.html', largo: ['appnav.inicio', 'Inicio'], corto: ['bnav.inicio', 'Inicio'], icono: 'home' },
    { href: './alimentacion.html', largo: ['appnav.alimentacion', 'Alimentación'], corto: ['bnav.alimentacion', 'Comidas'], icono: 'food' },
    { href: './entrenamiento.html', largo: ['appnav.entrenamiento', 'Entrenamiento'], corto: ['bnav.entrenamiento', 'Entreno'], icono: 'dumbbell' },
    { href: './comunidad.html', largo: ['appnav.comunidad', 'Comunidad'], corto: ['bnav.comunidad', 'Comunidad'], icono: 'users' }
  ];

  const pagina = (window.location.pathname.split('/').pop() || 'index.html');
  const esActiva = (href) => href.replace('./', '') === pagina;

  const svg = (nombre) => `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONOS[nombre]}</svg>`;

  function enlacesSuperiores() {
    const base = DESTINOS.map(d =>
      `<a href="${d.href}"${esActiva(d.href) ? ' class="active" aria-current="page"' : ''} data-i18n="${d.largo[0]}">${d.largo[1]}</a>`
    );
    if (LOGROS_DISPONIBLES) {
      base.splice(3, 0, `<a href="./logros.html"${esActiva('./logros.html') ? ' class="active" aria-current="page"' : ''} data-i18n="appnav.logros">Logros</a>`);
    }
    base.push(`<a href="./premium.html"${esActiva('./premium.html') ? ' class="active" aria-current="page"' : ''} data-free-only data-i18n="appnav.premium">Premium</a>`);
    return base.join('');
  }

  function construirCabecera() {
    return `
    <div class="app-header-inner">
      <a href="./dashboard.html" class="app-brand"><img src="./assets/logo.png" alt="">NutriAmigo</a>
      <nav class="app-nav" aria-label="Navegación principal" data-i18n-aria="nav.principal">${enlacesSuperiores()}</nav>
      <button type="button" class="streak-chip" data-streak-chip aria-haspopup="dialog"><span aria-hidden="true">🔥</span><b data-user-streak>0</b><span class="streak-prot" aria-hidden="true">🧊<b data-streak-prot>0</b></span></button>
      <span class="plan-badge" data-plan-badge data-i18n="plan.gratis">Gratis</span>
      <div class="app-profile">
        <button class="app-profile-btn" id="profileBtn" type="button" aria-haspopup="dialog" aria-label="Mi perfil" data-i18n-aria="nav.perfil">
          <span class="avatar-wrap"><span class="app-avatar" data-user-avatar>--</span><span class="rank-badge" data-rank-badge data-premium-only hidden></span></span>
        </button>
        <div class="app-profile-menu" id="profileMenu">
          <div class="app-profile-card" role="dialog" aria-label="Mi perfil" data-i18n-aria="nav.perfil">
            <div class="app-profile-card-header">
              <span class="avatar-wrap"><span class="app-avatar" data-user-avatar>--</span><span class="rank-badge" data-rank-badge data-premium-only hidden></span></span>
              <div>
                <strong data-user-name>...</strong>
                <span><span data-user-streak>0</span> <span data-i18n="racha.dias">días de racha</span></span>
              </div>
            </div>
            <a href="./premium.html" data-free-only data-i18n="profile.membresia">Membresía Premium</a>
            <a href="./premium.html" data-premium-only hidden data-i18n="profile.gestionar">Gestionar suscripción</a>
            <button type="button" id="settingsBtn" data-i18n="profile.configuracion">Configuración</button>
            <button type="button" id="logoutBtn" data-i18n="profile.cerrarSesion">Cerrar sesión</button>
          </div>
        </div>
      </div>
    </div>`;
  }

  function construirBarraInferior() {
    const items = DESTINOS.map(d => `
      <a class="bn-item" href="${d.href}"${esActiva(d.href) ? ' aria-current="page"' : ''}>
        <span class="bn-icon">${svg(d.icono)}</span><span class="bn-label" data-i18n="${d.corto[0]}">${d.corto[1]}</span>
      </a>`).join('');
    return `${items}
      <button type="button" class="bn-item" id="moreBtn" aria-haspopup="dialog" aria-expanded="false" aria-controls="moreSheet">
        <span class="bn-icon">${svg('more')}</span><span class="bn-label" data-i18n="bnav.mas">Más</span>
      </button>`;
  }

  function construirHojaMas() {
    return `
    <div class="modal more-sheet" role="dialog" aria-modal="true" aria-labelledby="moreTitle">
      <h3 id="moreTitle" data-i18n="bnav.mas">Más</h3>
      <ul class="more-list">
        <li${LOGROS_DISPONIBLES ? '' : ' hidden'}><a href="./logros.html" data-i18n="appnav.logros">Logros</a></li>
        <li><button type="button" id="moreSettings" data-i18n="profile.configuracion">Configuración</button></li>
        <li data-free-only><a href="./premium.html" data-i18n="appnav.premium">Premium</a></li>
        <li data-premium-only hidden><a href="./premium.html" data-i18n="profile.gestionar">Gestionar suscripción</a></li>
      </ul>
      <div class="more-block">
        <span class="more-label" data-i18n="settings.idioma">Idioma</span>
        <div class="pill-group" id="moreLang">
          <button type="button" class="pill" data-lang="es">Español</button>
          <button type="button" class="pill" data-lang="en">English</button>
          <button type="button" class="pill" data-lang="de">Deutsch</button>
        </div>
      </div>
      <div class="more-block">
        <span class="more-label" data-i18n="settings.tema">Tema</span>
        <div class="pill-group" id="moreTema">
          <button type="button" class="pill" data-tema="claro" data-i18n="tema.claro">Claro</button>
          <button type="button" class="pill" data-tema="dark" data-i18n="tema.oscuro">Oscuro</button>
          <button type="button" class="pill" data-tema="auto" data-i18n="tema.auto">Automático</button>
        </div>
      </div>
      <button type="button" class="more-logout" id="moreLogout" data-i18n="profile.cerrarSesion">Cerrar sesión</button>
    </div>`;
  }

  const cabecera = document.getElementById('appHeader');
  if (!cabecera) return;
  cabecera.innerHTML = construirCabecera();

  const barra = document.createElement('nav');
  barra.className = 'bottom-nav';
  barra.setAttribute('aria-label', 'Navegación principal');
  barra.setAttribute('data-i18n-aria', 'nav.principal');
  barra.innerHTML = construirBarraInferior();
  document.body.appendChild(barra);

  const hoja = document.createElement('div');
  hoja.className = 'modal-overlay more-overlay';
  hoja.id = 'moreSheet';
  hoja.hidden = true;
  hoja.innerHTML = construirHojaMas();
  document.body.appendChild(hoja);
  document.body.classList.add('has-bottom-nav');

  const botonMas = document.getElementById('moreBtn');

  function marcarActivos() {
    const idioma = window.NutriIdioma ? window.NutriIdioma.get() : 'es';
    const tema = window.NutriTema ? window.NutriTema.get() : 'claro';
    hoja.querySelectorAll('#moreLang .pill').forEach(b => b.classList.toggle('active', b.dataset.lang === idioma));
    hoja.querySelectorAll('#moreTema .pill').forEach(b => b.classList.toggle('active', b.dataset.tema === tema));
  }

  botonMas.addEventListener('click', () => {
    marcarActivos();
    hoja.hidden = false;
    botonMas.setAttribute('aria-expanded', 'true');
  });

  hoja.addEventListener('nutriamigo:modal-cerrado', () => botonMas.setAttribute('aria-expanded', 'false'));

  hoja.querySelectorAll('#moreLang .pill').forEach(b => b.addEventListener('click', () => {
    if (window.NutriIdioma) window.NutriIdioma.set(b.dataset.lang);
    marcarActivos();
  }));
  hoja.querySelectorAll('#moreTema .pill').forEach(b => b.addEventListener('click', () => {
    if (window.NutriTema) window.NutriTema.set(b.dataset.tema);
    marcarActivos();
  }));

  document.getElementById('moreSettings').addEventListener('click', () => {
    hoja.hidden = true;
    const ajustes = document.getElementById('settingsBtn');
    if (ajustes) ajustes.click();
  });
  document.getElementById('moreLogout').addEventListener('click', () => {
    const salir = document.getElementById('logoutBtn');
    if (salir) salir.click();
  });

  document.addEventListener('nutriamigo:user-ready', (e) => {
    if (!e.detail) document.body.classList.add('no-session');
  });
})();
