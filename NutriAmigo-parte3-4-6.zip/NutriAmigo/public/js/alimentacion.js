let mealsData = null;
let diaActivo = diaDeHoy();
let proteinasElegidas = [];
let restriccionesTexto = '';
let biometria = {};
let completionsHoy = [];

const PROTEINAS_EXCLUSIVAS = ['vegetariano', 'vegano'];

function objetivoDePlan() {
  return biometria.objetivo || 'mantener';
}

/* Aplica las reglas de exclusividad de los botones dentro del modal:
   marcar vegano/vegetariano desmarca y deshabilita las demás, y viceversa. */
function actualizarExclusividadProteinas() {
  const botones = Array.from(document.querySelectorAll('#proteinasGroup .pill'));
  const marcadas = botones.filter(b => b.classList.contains('active')).map(b => b.dataset.proteina);
  const hayExclusiva = marcadas.some(v => PROTEINAS_EXCLUSIVAS.includes(v));
  const hayCombinable = marcadas.some(v => !PROTEINAS_EXCLUSIVAS.includes(v));

  botones.forEach(b => {
    if (b.classList.contains('active')) { b.disabled = false; return; } // lo ya marcado siempre se puede desmarcar
    const esExclusiva = PROTEINAS_EXCLUSIVAS.includes(b.dataset.proteina);
    if (hayExclusiva) {
      b.disabled = true; // ya hay vegano/vegetariano marcado: nada más se puede combinar
    } else if (hayCombinable) {
      b.disabled = esExclusiva; // hay pollo/pescado/carne marcados: solo se bloquean las exclusivas
    } else {
      b.disabled = false;
    }
  });
}

function renderResumen() {
  const el = document.getElementById('planSummary');
  const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
  if (!biometria.peso) {
    el.innerHTML = `${t('plan.sinDatos', 'Aún no has completado tus datos.')} <a href="./onboarding.html" style="color:var(--green-600);font-weight:600;">${t('plan.completalosAqui', 'Complétalos aquí')}</a> ${t('plan.paraPlanCalculado', 'para un plan calculado para ti.')}`;
    return;
  }
  const genero = biometria.sexo === 'hombre' ? t('plan.hombre', 'hombre') : t('plan.mujer', 'mujer');
  el.innerHTML = `${t('plan.calculadoPara', 'Plan calculado para:')} <b>${genero}</b>, <b>${biometria.peso} kg</b>, <b>${biometria.estatura} cm</b>, ${t('plan.actividad', 'actividad')} <b>${labelActividad(biometria.actividad)}</b>, ${t('plan.objetivo', 'objetivo')} <b>${labelObjetivo(objetivoDePlan())}</b>.`;
}

function renderTabs() {
  const wrap = document.getElementById('weekTabs');
  wrap.innerHTML = DIAS.map(d =>
    `<button class="week-tab ${d === diaActivo ? 'active' : ''}" data-dia="${d}">${labelDia(d, false)}</button>`
  ).join('');
  wrap.querySelectorAll('.week-tab').forEach(btn => {
    btn.addEventListener('click', () => { diaActivo = btn.dataset.dia; renderTabs(); renderDay(); });
  });
}

function renderDay() {
  const wrap = document.getElementById('daySlots');
  const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
  const dia = mealsData[objetivoDePlan()][diaActivo];
  const proteinaHoy = resolverProteinaDelDia(proteinasElegidas, diaActivo);
  const nota = restriccionesTexto
    ? `<div class="slot-card" style="grid-column:1/-1;background:var(--green-50);">
         <h4>${t('plan.tenEnCuenta', 'Ten en cuenta')}</h4>
         <div class="slot-option">${escapeHtml(restriccionesTexto)}</div>
       </div>`
    : '';

  wrap.innerHTML = nota + Object.keys(SLOT_LABEL).map(slot => {
    const itemKey = `alimentacion-${diaActivo}-${slot}`;
    const esHoy = diaActivo === diaDeHoy();
    const hecho = esHoy && completionsHoy.includes(itemKey);
    return `
    <div class="slot-card">
      <div class="slot-card-header">
        <h4>${labelSlot(slot)}</h4>
        <button type="button" class="done-toggle ${hecho ? 'done' : ''}" data-item-key="${itemKey}"${esHoy ? '' : ` disabled title="${t('plan.soloHoy', 'Solo se puede marcar hoy')}"`}>${hecho ? t('plan.hechoHoy', '✓ Hecho hoy') : t('plan.yaLoHice', 'Ya lo hice')}</button>
      </div>
      ${dia[slot].map((opcion, i) => `
        <div class="slot-option"><b>${t('plan.opcion', 'Opción')} ${i + 1}</b>${mostrarOpcionComida(opcion, proteinaHoy)}</div>
      `).join('')}
    </div>
  `;
  }).join('');

  wrap.querySelectorAll('.done-toggle').forEach(btn => {
    btn.addEventListener('click', () => marcarCompletado(btn.dataset.itemKey));
  });
}

async function marcarCompletado(itemKey) {
  try {
    const data = await api.post('./api/completions', { itemKey });
    if (data.completado) completionsHoy.push(itemKey);
    else completionsHoy = completionsHoy.filter(k => k !== itemKey);
  } catch (err) {
    console.error('No se pudo registrar como completado', err);
  }
  renderDay();
}

async function cargarCompletions() {
  try {
    completionsHoy = await api.get('./api/completions');
  } catch (err) {
    console.error('No se pudieron cargar tus tareas completadas', err);
  }
}

function descargarPDF() {
  document.getElementById('printableBody').innerHTML = construirHtmlComidas(objetivoDePlan(), proteinasElegidas, restriccionesTexto);
  window.print();
}

async function cargarBiometria() {
  try {
    biometria = (await api.get('./api/biometrics')) || {};
  } catch (err) {
    console.error('No se pudieron cargar tus datos base', err);
    biometria = biometria || {};
  }
}

async function cargarPreferencias() {
  try {
    const prefs = await api.get('./api/preferences', { silencioso: true });
    if (prefs) {
      proteinasElegidas = prefs.proteinas || [];
      restriccionesTexto = prefs.restriccionesTexto || '';
      document.querySelectorAll('#proteinasGroup .pill').forEach(b => {
        b.classList.toggle('active', proteinasElegidas.includes(b.dataset.proteina));
      });
      actualizarExclusividadProteinas();
      document.getElementById('restriccionesTexto').value = restriccionesTexto;
    }
  } catch (err) {
    console.error('No se pudieron cargar tus preferencias', err);
  }
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  mealsData = MEALS_DATA;

  renderTabs();
  renderDay();

  document.addEventListener('nutriamigo:lang-changed', () => {
    renderResumen();
    renderTabs();
    renderDay();
  });

  document.getElementById('downloadMealsBtn').addEventListener('click', descargarPDF);

  const modal = document.getElementById('personalizeModal');
  document.getElementById('personalizeBtn').addEventListener('click', () => {
    if (!user.isPremium) { window.location.href = './premium.html'; return; }
    modal.hidden = false;
  });
  document.getElementById('closeModalBtn').addEventListener('click', () => { modal.hidden = true; });

  document.querySelectorAll('#proteinasGroup .pill').forEach(b => {
    b.addEventListener('click', () => {
      b.classList.toggle('active');
      actualizarExclusividadProteinas();
    });
  });

  document.getElementById('personalizeForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    proteinasElegidas = Array.from(document.querySelectorAll('#proteinasGroup .pill.active')).map(b => b.dataset.proteina);
    restriccionesTexto = document.getElementById('restriccionesTexto').value.trim();

    try {
      await api.post('./api/preferences', { proteinas: proteinasElegidas, restriccionesTexto });
    } catch (err) {
      console.error('No se pudieron guardar las preferencias', err);
      return;
    }

    modal.hidden = true;
    renderDay();
  });

  (async () => {
    try {
      await cargarBiometria();
      await cargarPreferencias();
      await cargarCompletions();
    } catch (err) {
      console.error('No se pudieron cargar tus datos guardados', err);
    }
    renderResumen();
    renderDay();
  })();
});
