const DIAS = ['lunes','martes','miercoles','jueves','viernes','sabado','domingo'];
function diaDeHoy() {
  return DIAS[(new Date().getDay() + 6) % 7];
}
/* Fecha local del navegador 'YYYY-MM-DD' (nunca UTC). */
function fechaLocal(d) {
  const f = d || new Date();
  const mes = String(f.getMonth() + 1).padStart(2, '0');
  const dia = String(f.getDate()).padStart(2, '0');
  return `${f.getFullYear()}-${mes}-${dia}`;
}
function hoyLocal() {
  return fechaLocal(new Date());
}
const DIA_LABEL = { lunes:'Lun', martes:'Mar', miercoles:'Mié', jueves:'Jue', viernes:'Vie', sabado:'Sáb', domingo:'Dom' };
const DIA_LABEL_LARGO = { lunes:'Lunes', martes:'Martes', miercoles:'Miércoles', jueves:'Jueves', viernes:'Viernes', sabado:'Sábado', domingo:'Domingo' };
const SLOT_LABEL = { desayuno:'Desayuno', almuerzo:'Almuerzo', media_tarde:'Media tarde', cena:'Cena' };
const OBJETIVO_LABEL = { definir: 'Definir', mantener: 'Mantener', volumen: 'Subir de peso' };
const ENFOQUE_LABEL = { piernas: 'piernas', brazos: 'brazos', espalda: 'espalda', cuerpo_completo: 'cuerpo completo' };
const ACTIVIDAD_LABEL = { sedentario: 'sedentario', ligero: 'ligero', moderado: 'moderado', activo: 'activo', muy_activo: 'muy activo' };

/* Devuelve el idioma activo ('es' por defecto si i18n.js aún no cargó). */
function idiomaActivo() {
  return window.NutriIdioma ? window.NutriIdioma.get() : 'es';
}

/* Traduce un texto de comida (data/meals.js) al idioma activo, si existe
   traducción en data/meals.i18n.js. Si no, devuelve el texto en español. */
function traducirComida(texto) {
  const lang = idiomaActivo();
  if (lang === 'es' || typeof MEALS_TRANSLATIONS === 'undefined') return texto;
  return (MEALS_TRANSLATIONS[lang] && MEALS_TRANSLATIONS[lang][texto]) || texto;
}

/* Traduce un texto de entrenamiento (data/workouts.js) al idioma activo. */
function traducirEntrenamiento(texto) {
  const lang = idiomaActivo();
  if (lang === 'es' || typeof WORKOUTS_TRANSLATIONS === 'undefined') return texto;
  return (WORKOUTS_TRANSLATIONS[lang] && WORKOUTS_TRANSLATIONS[lang][texto]) || texto;
}

/* Etiquetas (día, franja, objetivo, actividad, enfoque) traducidas según
   el idioma activo, reutilizando el diccionario de js/i18n.js. */
function labelDia(dia, largo) {
  const es = largo ? DIA_LABEL_LARGO[dia] : DIA_LABEL[dia];
  return window.NutriIdioma ? window.NutriIdioma.t((largo ? 'diaLargo.' : 'dia.') + dia, es) : es;
}
function labelSlot(slot) {
  return window.NutriIdioma ? window.NutriIdioma.t('slot.' + slot, SLOT_LABEL[slot]) : SLOT_LABEL[slot];
}
function labelObjetivo(objetivo) {
  const clave = { definir: 'objetivo.definir', mantener: 'objetivo.mantener', volumen: 'objetivo.volumen' }[objetivo];
  return window.NutriIdioma && clave ? window.NutriIdioma.t(clave, OBJETIVO_LABEL[objetivo] || objetivo) : (OBJETIVO_LABEL[objetivo] || objetivo);
}
function labelActividad(actividad) {
  const clave = { sedentario: 'actividad.sedentario', ligero: 'actividad.ligero', moderado: 'actividad.moderado', activo: 'actividad.activo', muy_activo: 'actividad.muyActivo' }[actividad];
  return window.NutriIdioma && clave ? window.NutriIdioma.t(clave, ACTIVIDAD_LABEL[actividad] || actividad) : (ACTIVIDAD_LABEL[actividad] || actividad);
}
function labelEnfoque(enfoque) {
  const clave = { piernas: 'enfoque.piernas', brazos: 'enfoque.brazos', espalda: 'enfoque.espalda', cuerpo_completo: 'enfoque.cuerpoCompleto' }[enfoque];
  return window.NutriIdioma && clave ? window.NutriIdioma.t(clave, ENFOQUE_LABEL[enfoque] || enfoque) : (ENFOQUE_LABEL[enfoque] || enfoque);
}

/* Escapa HTML para evitar XSS al insertar texto libre del usuario (restricciones) */
function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[ch]));
}

/* Sustitución de proteína (versión en español) — comportamiento original. */
function aplicarProteinaEs(texto, tipoProteina) {
  let t = texto;
  if (tipoProteina === 'vegano') {
    t = t.replace(/Pechuga de pollo|Pollo desmechado|Pollo al curry/gi, 'Tofu a la plancha')
         .replace(/Carne de res magra|Carne magra|Carne asada|Filete de pescado|Pescado al horno|Pescado a la plancha/gi, 'Garbanzos guisados')
         .replace(/[Hh]uevos?/g, 'Tofu revuelto')
         .replace(/[Qq]ueso fresco|[Qq]ueso/g, 'queso vegetal')
         .replace(/[Ll]eche/g, 'leche vegetal')
         .replace(/[Aa]tún/g, 'garbanzos');
  } else if (tipoProteina === 'vegetariano') {
    t = t.replace(/Pechuga de pollo|Pollo desmechado|Pollo al curry/gi, 'Garbanzos guisados')
         .replace(/Carne de res magra|Carne magra|Carne asada|Filete de pescado|Pescado al horno|Pescado a la plancha|[Aa]tún/gi, 'Lentejas con vegetales');
  } else if (tipoProteina === 'pollo') {
    t = t.replace(/Carne de res magra|Carne magra|Carne asada|Filete de pescado|Pescado al horno|Pescado a la plancha/gi, 'Pechuga de pollo a la plancha');
  } else if (tipoProteina === 'pescado') {
    t = t.replace(/Pechuga de pollo|Carne de res magra|Carne magra|Carne asada/gi, 'Filete de pescado a la plancha');
  } else if (tipoProteina === 'carne') {
    t = t.replace(/Pechuga de pollo|Filete de pescado/gi, 'Carne de res magra a la plancha');
  }
  return t;
}

/* Misma sustitución, aplicada sobre el texto ya traducido a inglés o alemán,
   usando los mismos términos que usamos al traducir data/meals.js. */
function aplicarProteinaEn(texto, tipoProteina) {
  let t = texto;
  if (tipoProteina === 'vegano') {
    t = t.replace(/(?:Grilled )?chicken breast|shredded chicken|chicken curry/gi, 'Grilled tofu')
         .replace(/(?:Grilled )?lean beef|grilled beef|fish fillet|baked fish|grilled fish/gi, 'Stewed chickpeas')
         .replace(/\beggs?\b/gi, 'scrambled tofu')
         .replace(/fresh cheese|\bcheese\b/gi, 'plant-based cheese')
         .replace(/\bmilk\b/gi, 'plant milk')
         .replace(/\btuna\b/gi, 'chickpeas');
  } else if (tipoProteina === 'vegetariano') {
    t = t.replace(/(?:Grilled )?chicken breast|shredded chicken|chicken curry/gi, 'Stewed chickpeas')
         .replace(/(?:Grilled )?lean beef|grilled beef|fish fillet|baked fish|grilled fish|\btuna\b/gi, 'Lentils with vegetables');
  } else if (tipoProteina === 'pollo') {
    t = t.replace(/(?:Grilled )?lean beef|grilled beef|fish fillet|baked fish|grilled fish/gi, 'Grilled chicken breast');
  } else if (tipoProteina === 'pescado') {
    t = t.replace(/(?:Grilled )?chicken breast|(?:Grilled )?lean beef|grilled beef/gi, 'Grilled fish fillet');
  } else if (tipoProteina === 'carne') {
    t = t.replace(/(?:Grilled )?chicken breast|fish fillet/gi, 'Grilled lean beef');
  }
  return t;
}

function aplicarProteinaDe(texto, tipoProteina) {
  let t = texto;
  if (tipoProteina === 'vegano') {
    t = t.replace(/(?:Gegrillte )?Hähnchenbrust|gezupftes? Hähnchen|Hähnchen-Curry/gi, 'Gebratener Tofu')
         .replace(/(?:Gegrilltes )?mageres Rindfleisch|gegrilltes Rindfleisch|Fischfilet|Ofenfisch|gegrillter Fisch/gi, 'Geschmorte Kichererbsen')
         .replace(/\bEiern?\b|\bEi\b/gi, 'Tofu-Rührei')
         .replace(/Frischkäse|\bKäse\b/gi, 'pflanzlicher Käse')
         .replace(/\bMilch\b/gi, 'Pflanzenmilch')
         .replace(/\bThunfisch\b/gi, 'Kichererbsen');
  } else if (tipoProteina === 'vegetariano') {
    t = t.replace(/(?:Gegrillte )?Hähnchenbrust|gezupftes? Hähnchen|Hähnchen-Curry/gi, 'Geschmorte Kichererbsen')
         .replace(/(?:Gegrilltes )?mageres Rindfleisch|gegrilltes Rindfleisch|Fischfilet|Ofenfisch|gegrillter Fisch|\bThunfisch\b/gi, 'Linsen mit Gemüse');
  } else if (tipoProteina === 'pollo') {
    t = t.replace(/(?:Gegrilltes )?mageres Rindfleisch|gegrilltes Rindfleisch|Fischfilet|Ofenfisch|gegrillter Fisch/gi, 'Gegrillte Hähnchenbrust');
  } else if (tipoProteina === 'pescado') {
    t = t.replace(/(?:Gegrillte )?Hähnchenbrust|(?:Gegrilltes )?mageres Rindfleisch|gegrilltes Rindfleisch/gi, 'Gegrilltes Fischfilet');
  } else if (tipoProteina === 'carne') {
    t = t.replace(/(?:Gegrillte )?Hähnchenbrust|Fischfilet/gi, 'Gegrilltes mageres Rindfleisch');
  }
  return t;
}

/* Traduce la opción de comida y aplica la sustitución de proteína en el
   idioma correspondiente. Esta es la función que deben usar las páginas. */
/* Calculadora de porciones caseras: en vez de reescribir las 83 comidas con
   datos estructurados de gramaje (cambio enorme que rompería las traducciones
   y la sustitución de proteína, que dependen del texto exacto), se detectan
   los ingredientes principales por palabra clave y se agrega su equivalente
   en medida casera al texto ya mostrado — funciona en los 3 idiomas. */
const MEDIDAS_CASERAS = {
  es: [
    [/pechuga de pollo/i, '≈ 1 pechuga mediana'],
    [/pollo desmechado|pollo al curry/i, '≈ 1 taza'],
    [/filete de pescado|pescado a la plancha|pescado al horno/i, '≈ 1 filete mediano'],
    [/carne de res magra|carne magra|carne asada/i, '≈ 1 trozo del tamaño de tu palma'],
    [/atún/i, '≈ 1 lata pequeña'],
    [/queso fresco|queso/i, '≈ 2 dedos de ancho'],
    [/\barroz\b/i, '≈ 1 puño cerrado cocido'],
    [/avena/i, '≈ 1/2 taza en seco'],
    [/lentejas|garbanzos/i, '≈ 1/2 taza cocidos'],
    [/\bpapa\b/i, '≈ 1 papa mediana'],
    [/aguacate/i, '≈ 1/4 de aguacate mediano'],
    [/almendras|nueces|frutos secos/i, '≈ un puñado']
  ],
  en: [
    [/chicken breast/i, '≈ 1 medium breast'],
    [/shredded chicken|chicken curry/i, '≈ 1 cup'],
    [/fish fillet|grilled fish|baked fish/i, '≈ 1 medium fillet'],
    [/lean beef|grilled beef/i, '≈ 1 piece the size of your palm'],
    [/\btuna\b/i, '≈ 1 small can'],
    [/cheese/i, '≈ 2 finger-widths'],
    [/\brice\b/i, '≈ 1 closed fist, cooked'],
    [/\boats?\b/i, '≈ 1/2 cup dry'],
    [/lentils|chickpeas/i, '≈ 1/2 cup cooked'],
    [/\bpotato/i, '≈ 1 medium potato'],
    [/avocado/i, '≈ 1/4 medium avocado'],
    [/almonds|walnuts|\bnuts\b/i, '≈ a handful']
  ],
  de: [
    [/hähnchenbrust/i, '≈ 1 mittlere Brust'],
    [/gezupftes? hähnchen|hähnchen-curry/i, '≈ 1 Tasse'],
    [/fischfilet|gegrillter fisch|ofenfisch/i, '≈ 1 mittleres Filet'],
    [/mageres rindfleisch|gegrilltes rindfleisch/i, '≈ 1 Stück, handflächengroß'],
    [/thunfisch/i, '≈ 1 kleine Dose'],
    [/käse/i, '≈ 2 Fingerbreiten'],
    [/\breis\b/i, '≈ 1 geschlossene Faust, gekocht'],
    [/hafer/i, '≈ 1/2 Tasse ungekocht'],
    [/linsen|kichererbsen/i, '≈ 1/2 Tasse gekocht'],
    [/kartoffel/i, '≈ 1 mittlere Kartoffel'],
    [/avocado/i, '≈ 1/4 mittlere Avocado'],
    [/mandeln|walnüssen|nüsse/i, '≈ eine Handvoll']
  ]
};

function agregarMedidaCasera(textoMostrado) {
  const lang = idiomaActivo();
  const reglas = MEDIDAS_CASERAS[lang] || MEDIDAS_CASERAS.es;
  const encontradas = [];
  for (const [regex, hint] of reglas) {
    if (regex.test(textoMostrado) && !encontradas.includes(hint)) {
      encontradas.push(hint);
      if (encontradas.length === 2) break; // máximo 2 pistas para no saturar el texto
    }
  }
  return encontradas.length ? `${textoMostrado} (${encontradas.join(' · ')})` : textoMostrado;
}

function mostrarOpcionComida(opcion, tipoProteina) {
  const lang = idiomaActivo();
  let texto;
  if (lang === 'en') texto = aplicarProteinaEn(traducirComida(opcion), tipoProteina);
  else if (lang === 'de') texto = aplicarProteinaDe(traducirComida(opcion), tipoProteina);
  else texto = aplicarProteinaEs(opcion, tipoProteina);
  return agregarMedidaCasera(texto);
}

/* Decide qué proteína (de las elegidas por el usuario) aplica a un día
   concreto de la semana, alternando entre ellas para que el plan no se
   sienta repetitivo. Con una sola elegida (o vegano/vegetariano, que son
   excluyentes), esa misma proteína aplica todos los días. */
function resolverProteinaDelDia(proteinas, dia) {
  if (!proteinas || !proteinas.length) return '';
  if (proteinas.length === 1) return proteinas[0];
  const idx = DIAS.indexOf(dia);
  return proteinas[idx % proteinas.length];
}

const PROTEINA_CLAVE_LABEL = { pollo: 'proteina.pollo', pescado: 'proteina.pescado', carne: 'proteina.carne', vegetariano: 'proteina.vegetariano', vegano: 'proteina.vegano' };
const PROTEINA_LABEL_ES = { pollo: 'Pollo', pescado: 'Pescado', carne: 'Carne de res', vegetariano: 'Vegetariano', vegano: 'Vegano' };
function labelProteina(p) {
  return window.NutriIdioma ? window.NutriIdioma.t(PROTEINA_CLAVE_LABEL[p], PROTEINA_LABEL_ES[p] || p) : (PROTEINA_LABEL_ES[p] || p);
}

/* Se mantiene por compatibilidad (llamadas existentes en español). */
function aplicarProteina(texto, tipoProteina) {
  return aplicarProteinaEs(texto, tipoProteina);
}

function aplicarEnfoque(texto, enfoqueMuscular) {
  if (!enfoqueMuscular || enfoqueMuscular === 'cuerpo_completo') return texto;
  if (/Fuerza|Strength|Kraft|Accesorios|Accessory|Zusatzübungen|Enfoque muscular|Muscle focus|Muskelfokus/i.test(texto)) {
    const lang = idiomaActivo();
    const prefijo = window.NutriIdioma ? window.NutriIdioma.t('plan.enfoqueTexto', 'Fuerza — enfoque en') : 'Fuerza — enfoque en';
    return `${prefijo} ${labelEnfoque(enfoqueMuscular)}`;
  }
  return texto;
}

function aplicarActividad(texto, actividad) {
  const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
  if (actividad === 'sedentario') return `${texto}${t('plan.actEmpiezaSuave', ' (empieza suave: reduce a la mitad las series si es tu primera semana)')}`;
  if (actividad === 'ligero') return `${texto}${t('plan.actIntensidadModerada', ' (intensidad moderada, sube el peso o el ritmo cada 2 semanas)')}`;
  if (actividad === 'activo' || actividad === 'muy_activo') return `${texto}${t('plan.actExigeMas', ' (puedes exigir más: agrega una serie extra o acorta los descansos)')}`;
  return texto;
}

function construirHtmlComidas(objetivo, proteinas, restriccionesTexto) {
  const plan = MEALS_DATA[objetivo] || MEALS_DATA.mantener;
  const t = window.NutriIdioma ? window.NutriIdioma.t : (k, es) => es;
  const listaProteinas = Array.isArray(proteinas) ? proteinas : (proteinas ? [proteinas] : []); // compatibilidad con el formato anterior (string único)
  let html = `<h3>${t('plan.pdfAlimTitulo', 'Plan de alimentación — Objetivo:')} ${labelObjetivo(objetivo)}</h3>`;
  if (listaProteinas.length) html += `<p><b>${t('plan.pdfProteinas', 'Proteínas elegidas:')}</b> ${listaProteinas.map(labelProteina).join(', ')}</p>`;
  if (restriccionesTexto) html += `<p><b>${t('plan.pdfRestricciones', 'Restricciones:')}</b> ${escapeHtml(restriccionesTexto)}</p>`;

  DIAS.forEach(d => {
    const proteinaDia = resolverProteinaDelDia(listaProteinas, d);
    html += `<h4>${labelDia(d, true)}</h4><ul>`;
    Object.keys(SLOT_LABEL).forEach(slot => {
      const opciones = plan[d][slot].map(o => mostrarOpcionComida(o, proteinaDia));
      html += `<li><b>${labelSlot(slot)}:</b> ${opciones.join(t('plan.o', ' — o — '))}</li>`;
    });
    html += `</ul>`;
  });
  return html;
}

/* ---------- Entrenamiento (Parte 6): ayudas compartidas por la página, el PDF y el panel ---------- */
function trEnt(clave, es, vars) {
  let texto = window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es;
  Object.keys(vars || {}).forEach(k => { texto = texto.split('{' + k + '}').join(String(vars[k])); });
  return texto;
}

function nombreEjercicio(id) {
  const ej = window.GeneradorRutinas.ejercicioPorId(id);
  const idioma = idiomaActivo();
  return ej ? (ej.nombre[idioma] || ej.nombre.es) : id;
}

function nivelPorActividad(actividad) {
  if (actividad === 'moderado') return 'intermedio';
  if (actividad === 'activo' || actividad === 'muy_activo') return 'avanzado';
  return 'principiante';
}

/* Perfil para el generador. Sin Premium: rutina estándar (3 días, cuerpo completo, casa). */
function perfilDeEntrenamiento(datos, prefs, esPremium, semanaNumero, userId) {
  const p = esPremium && prefs ? prefs : {};
  return {
    objetivo: datos.objetivo,
    edad: datos.edad,
    frecuencia: p.frecuenciaSemanal || 3,
    distanciaKm: p.distanciaKm || null,
    enfoque: p.enfoqueMuscular && p.enfoqueMuscular !== 'cuerpo_completo' ? p.enfoqueMuscular : null,
    nivel: p.nivel || nivelPorActividad(datos.actividad),
    lugar: p.lugar || 'casa',
    semanaNumero: semanaNumero || 1,
    semilla: userId || 1
  };
}

function textoCantidad(it) {
  if (it.unidad === 'min') {
    const base = `${it.minutos} ${trEnt('ent.min', 'min')}`;
    return it.km ? `${base} · ${it.km} ${trEnt('ent.km', 'km')}` : base;
  }
  if (it.unidad === 'seg') return `${it.series} × ${it.segundos} ${trEnt('ent.seg', 's')}`;
  return `${it.series} × ${it.repeticiones} ${trEnt('ent.rep', 'rep')}`;
}

function nombreSesion(sesion) {
  return trEnt(`ent.sesion.${sesion.nombreClave}`, sesion.nombreClave);
}

function construirHtmlEntrenamiento(semana) {
  let html = `<h3>${escapeHtml(trEnt('plan.pdfEntrTitulo', 'Plan de entrenamiento — Objetivo:'))} ${escapeHtml(labelObjetivo(semana.perfil.objetivo))}</h3>`;
  html += `<p>${escapeHtml(trEnt('ent.pdfSemana', 'Semana {n} · {e} días de entrenamiento', { n: semana.semanaNumero, e: semana.resumen.diasEntrenamiento }))}</p>`;
  if (semana.perfil.enfoque) html += `<p><b>${escapeHtml(trEnt('plan.pdfEnfoque', 'Enfoque muscular:'))}</b> ${escapeHtml(labelEnfoque(semana.perfil.enfoque))}</p>`;
  if (semana.resumen.kmSemana) html += `<p>${escapeHtml(trEnt('ent.metaKm', 'Meta de la semana: {meta} km', { meta: semana.resumen.kmSemana }))}</p>`;
  if (semana.avisos.includes('supervisionMenor')) html += `<p>${escapeHtml(trEnt('ent.supervision', 'Entrena con la supervisión de un adulto.'))}</p>`;

  semana.dias.forEach(d => {
    html += `<h4>${escapeHtml(trEnt('ent.pdfDia', '{dia}: {nombre}', { dia: labelDia(d.dia, true), nombre: nombreSesion(d) }))} (${d.duracionMin} ${escapeHtml(trEnt('ent.min', 'min'))})</h4><ul>`;
    d.principal.forEach(it => { html += `<li>${escapeHtml(nombreEjercicio(it.id))} — ${escapeHtml(textoCantidad(it))}</li>`; });
    if (d.cardio) html += `<li>${escapeHtml(nombreEjercicio(d.cardio.id))} — ${escapeHtml(textoCantidad(d.cardio))}</li>`;
    html += `</ul>`;
  });
  return html;
}
