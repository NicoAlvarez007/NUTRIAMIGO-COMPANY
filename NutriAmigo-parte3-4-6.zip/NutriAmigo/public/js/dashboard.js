function formatearFechaCorta(fechaStr) {
  const [y, m, d] = fechaStr.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('es-CO', { day: '2-digit', month: 'short' });
}

function formatearMesCorto(fechaStr) {
  const [y, m] = fechaStr.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('es-CO', { month: 'short', year: '2-digit' });
}

function filtrarPorVista(entries, vista) {
  const ordenadas = [...entries].sort((a, b) => a.fecha.localeCompare(b.fecha));
  const hoy = new Date();

  if (vista === 'semana') {
    const limite = new Date(hoy); limite.setDate(limite.getDate() - 7);
    const limiteStr = fechaLocal(limite);
    return ordenadas.filter(e => e.fecha >= limiteStr)
      .map(e => ({ fecha: e.fecha, peso: e.peso, label: formatearFechaCorta(e.fecha) }));
  }

  if (vista === 'mes') {
    const limite = new Date(hoy); limite.setDate(limite.getDate() - 30);
    const limiteStr = fechaLocal(limite);
    const porDia = {};
    ordenadas.filter(e => e.fecha >= limiteStr).forEach(e => { porDia[e.fecha] = e.peso; });
    return Object.keys(porDia).sort().map(fecha => ({ fecha, peso: porDia[fecha], label: formatearFechaCorta(fecha) }));
  }

  const limite = new Date(hoy); limite.setFullYear(limite.getFullYear() - 1);
  const limiteStr = fechaLocal(limite);
  const porMes = {};
  ordenadas.filter(e => e.fecha >= limiteStr).forEach(e => {
    const mesKey = e.fecha.slice(0, 7);
    (porMes[mesKey] = porMes[mesKey] || []).push(e.peso);
  });
  return Object.keys(porMes).sort().map(mesKey => {
    const pesos = porMes[mesKey];
    const promedio = Math.round((pesos.reduce((a, b) => a + b, 0) / pesos.length) * 10) / 10;
    return { fecha: `${mesKey}-01`, peso: promedio, label: formatearMesCorto(`${mesKey}-01`) };
  });
}

const GRAFICAS = new Map();
let observadorAncho = null;

function colorCss(nombre, respaldo) {
  const valor = getComputedStyle(document.documentElement).getPropertyValue(nombre).trim();
  return valor || respaldo;
}

function dibujarSerieLinea(canvas, empty, entries, formatearValor) {
  if (!entries.length) {
    GRAFICAS.delete(canvas);
    canvas.style.display = 'none';
    empty.style.display = 'block';
    return;
  }
  canvas.style.display = 'block';
  empty.style.display = 'none';
  GRAFICAS.set(canvas, { entries, formatearValor, ancho: 0 });
  pintarGrafica(canvas, true);

  if (!observadorAncho && 'ResizeObserver' in window) {
    observadorAncho = new ResizeObserver(() => GRAFICAS.forEach((_, c) => pintarGrafica(c, false)));
  }
  if (observadorAncho) observadorAncho.observe(canvas.parentElement);
}

function pintarGrafica(canvas, forzar) {
  const datos = GRAFICAS.get(canvas);
  if (!datos) return;

  canvas.style.width = '100%';
  const w = Math.floor(canvas.getBoundingClientRect().width) || 320;
  if (!forzar && w === datos.ancho) return;
  datos.ancho = w;

  const h = Math.round(Math.min(240, Math.max(160, w * 0.42)));
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.height = h + 'px';

  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const colorLinea = colorCss('--line', '#d9ede1');
  const colorTrazo = colorCss('--green-500', '#34c281');
  const colorPunto = colorCss('--green-600', '#279d68');
  const colorTexto = colorCss('--text', '#263029');
  const colorSuave = colorCss('--text-soft', '#5c6b62');
  const fuente = getComputedStyle(document.body).fontFamily || 'sans-serif';

  const entries = datos.entries;
  const pad = 32;
  const valores = entries.map(e => e.valor);
  const min = Math.min(...valores) - 1;
  const max = Math.max(...valores) + 1;
  const range = max - min || 1;
  const stepX = entries.length > 1 ? (w - pad * 2) / (entries.length - 1) : 0;
  const salto = stepX > 0 ? Math.max(1, Math.ceil(46 / stepX)) : 1;

  const points = entries.map((e, i) => ({
    x: entries.length > 1 ? pad + stepX * i : w / 2,
    y: h - pad - ((e.valor - min) / range) * (h - pad * 2)
  }));

  ctx.lineWidth = 1;
  ctx.strokeStyle = colorLinea;
  ctx.beginPath();
  ctx.moveTo(pad, h - pad);
  ctx.lineTo(w - pad, h - pad);
  ctx.stroke();

  ctx.strokeStyle = colorTrazo;
  ctx.lineWidth = 2.5;
  ctx.lineJoin = 'round';
  ctx.beginPath();
  points.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
  ctx.stroke();

  ctx.textAlign = 'center';
  points.forEach((p, i) => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = colorPunto;
    ctx.fill();

    const visible = i % salto === 0 || i === points.length - 1 && salto === 1;
    if (!visible) return;

    ctx.fillStyle = colorTexto;
    ctx.font = `600 11px ${fuente}`;
    ctx.fillText(datos.formatearValor(entries[i].valor), p.x, p.y - 12);

    ctx.fillStyle = colorSuave;
    ctx.font = `500 10px ${fuente}`;
    ctx.fillText(entries[i].label, p.x, h - pad + 16);
  });
}

new MutationObserver(() => GRAFICAS.forEach((_, c) => pintarGrafica(c, true)))
  .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

function drawWeightChart(entries) {
  const canvas = document.getElementById('progressChart');
  const empty = document.getElementById('progressEmpty');
  dibujarSerieLinea(canvas, empty, entries.map(e => ({ ...e, valor: e.peso })), v => v + ' kg');
}

/* Gráfica histórica de IMC: reutiliza el mismo motor de dibujo que la de
   peso, pero calculando el IMC de cada registro con la estatura actual. */
function calcularSerieIMC(entriesFiltradas, estatura) {
  if (!estatura) return [];
  return entriesFiltradas.map(e => {
    const imc = calcularIMC({ peso: e.peso, estatura });
    return { fecha: e.fecha, label: e.label, imc: Math.round(imc * 10) / 10 };
  });
}

function drawImcChart(entries) {
  const canvas = document.getElementById('imcChart');
  const empty = document.getElementById('imcChartEmpty');
  if (!canvas || !empty) return; // por si la página aún no tiene el bloque de IMC
  dibujarSerieLinea(canvas, empty, entries.map(e => ({ ...e, valor: e.imc })), v => v.toFixed(1));
}

let ultimoResultado = null;

async function cargarMetaCalorica() {
  try {
    const data = await api.get('./api/biometrics');
    const resultsGrid = document.getElementById('resultsGrid');
    const noBioCard = document.getElementById('noBioCard');

    if (!data) { resultsGrid.style.display = 'none'; noBioCard.style.display = 'block'; return; }

    estaturaActual = data.estatura || null;
    redibujarGraficas();

    const imc = calcularIMC(data);
    const kcal = calcularMetaCalorica(data);
    const macros = calcularMacros(kcal, data.objetivo);

    if (imc && kcal && macros) {
      ultimoResultado = { imc, kcal, macros, datos: data };
      resultsGrid.style.display = 'grid';
      noBioCard.style.display = 'none';
      document.getElementById('imcValue').textContent = imc.toFixed(1);
      document.getElementById('imcTag').textContent = categoriaIMC(imc);
      const sugerencia = sugerirObjetivo(imc);
      document.getElementById('aiSuggestionValue').textContent = sugerencia ? sugerencia.titulo : '—';
      document.getElementById('kcalValue').textContent = kcal.toLocaleString('es-CO') + ' kcal';
      document.getElementById('macroProteina').textContent = `${macros.proteina.gramos} g (${macros.proteina.pct}%)`;
      document.getElementById('macroCarbs').textContent = `${macros.carbohidratos.gramos} g (${macros.carbohidratos.pct}%)`;
      document.getElementById('macroGrasas').textContent = `${macros.grasas.gramos} g (${macros.grasas.pct}%)`;
    }
    if (data.nombre) {
      document.querySelectorAll('[data-user-name]').forEach(el => {
        el.textContent = `${data.nombre} ${data.apellido || ''}`.trim();
      });
    }
  } catch (err) {
    console.error('No se pudo cargar tu meta calórica', err);
  }
}

async function descargarResumenPDF() {
  if (!ultimoResultado) { mostrarAviso(window.NutriIdioma ? window.NutriIdioma.t('dash.completaDatos', 'Completa tus datos primero desde Configuración, en el menú de tu perfil.') : 'Completa tus datos primero desde Configuración, en el menú de tu perfil.', 'info'); return; }
  const { imc, kcal, macros, datos } = ultimoResultado;

  let prefs = null;
  try {
    prefs = await api.get('./api/preferences', { silencioso: true });
  } catch (err) {
    console.error('No se pudieron cargar tus preferencias para el PDF', err);
  }
  const proteinas = (prefs && prefs.proteinas) || [];
  const restriccionesTexto = (prefs && prefs.restriccionesTexto) || '';
  let semanaDelPlan = 1;
  try {
    semanaDelPlan = (await api.get('./api/entrenamiento/semana', { silencioso: true })).semanaNumero;
  } catch (err) {
    console.error('No se pudo calcular la semana del plan para el PDF', err);
  }

  document.getElementById('printableBody').innerHTML = `
    <h3>Tus datos</h3>
    <ul>
      ${datos.nombre ? `<li>Nombre: ${escapeHtml(datos.nombre)} ${escapeHtml(datos.apellido || '')}</li>` : ''}
      ${datos.correo ? `<li>Correo: ${escapeHtml(datos.correo)}</li>` : ''}
      <li>Peso: ${escapeHtml(datos.peso)} kg — Estatura: ${escapeHtml(datos.estatura)} cm</li>
      <li>Género: ${datos.sexo === 'hombre' ? 'Hombre' : 'Mujer'} — Edad: ${escapeHtml(datos.edad)}</li>
      <li>Nivel de actividad: ${escapeHtml(datos.actividad)}</li>
      <li>Objetivo: ${escapeHtml(datos.objetivo)}</li>
    </ul>
    <h3>Resultado</h3>
    <ul>
      <li>Índice de masa corporal: ${imc.toFixed(1)} (${categoriaIMC(imc)})</li>
      <li>Meta calórica diaria: ${kcal} kcal</li>
      <li>Proteína: ${macros.proteina.gramos} g (${macros.proteina.pct}%)</li>
      <li>Carbohidratos: ${macros.carbohidratos.gramos} g (${macros.carbohidratos.pct}%)</li>
      <li>Grasas: ${macros.grasas.gramos} g (${macros.grasas.pct}%)</li>
    </ul>
    ${construirHtmlComidas(datos.objetivo, proteinas, restriccionesTexto)}
    ${construirHtmlEntrenamiento(window.GeneradorRutinas.generarSemana(perfilDeEntrenamiento(datos, prefs, !!(window.__nutriamigoUser && window.__nutriamigoUser.isPremium), semanaDelPlan, window.__nutriamigoUser && window.__nutriamigoUser.id)))}
  `;
  window.print();
}

function exportarProgresoCSV() {
  if (!entriesCache.length) { mostrarAviso(window.NutriIdioma ? window.NutriIdioma.t('dash.sinRegistros', 'Aún no tienes registros de peso para exportar.') : 'Aún no tienes registros de peso para exportar.', 'info'); return; }

  const filas = ['Fecha,Peso (kg)'];
  [...entriesCache].sort((a, b) => a.fecha.localeCompare(b.fecha)).forEach(e => {
    filas.push(`${e.fecha},${e.peso}`);
  });

  const csv = '\uFEFF' + filas.join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'historial-peso-nutriamigo.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

let entriesCache = [];
let vistaActual = 'semana';
let estaturaActual = null;

function redibujarGraficas() {
  const filtradas = filtrarPorVista(entriesCache, vistaActual);
  drawWeightChart(filtradas);
  drawImcChart(calcularSerieIMC(filtradas, estaturaActual));
}

async function cargarProgreso() {
  try {
    entriesCache = await api.get('./api/progress');
    redibujarGraficas();
  } catch (err) {
    console.error('No se pudo cargar tu progreso', err);
  }
}

let vasosAguaActual = 0;
let kmRecorridosActual = 0;
let guardarDailyLogTimeout = null;

async function cargarDailyLog() {
  try {
    const data = await api.get('./api/daily-log');
    vasosAguaActual = data.vasos_agua || 0;
    kmRecorridosActual = data.km_recorridos || 0;
    document.getElementById('waterCount').textContent = vasosAguaActual;
    document.getElementById('kmInput').value = data.km_recorridos || '';
  } catch (err) {
    console.error('No se pudo cargar tu registro diario', err);
  }
}

/* Guarda el registro diario con un pequeño debounce para no perder cambios
   de agua/km si el usuario nunca presiona "Guardar registro de hoy". */
function guardarDailyLogDebounced() {
  if (guardarDailyLogTimeout) clearTimeout(guardarDailyLogTimeout);
  guardarDailyLogTimeout = setTimeout(async () => {
    try {
      await api.post('./api/daily-log', { vasosAgua: vasosAguaActual, kmRecorridos: kmRecorridosActual });
    } catch (err) {
      console.error('No se pudo guardar tu registro diario', err);
    }
  }, 400);
}

const LOGROS = [
  { id: 'racha3', icono: '🔥', nombre: '3 días de racha', check: (d) => d.streak >= 3 },
  { id: 'racha7', icono: '🏆', nombre: '7 días de racha', check: (d) => d.streak >= 7 },
  { id: 'primerPeso', icono: '⚖️', nombre: 'Primer registro de peso', check: (d) => d.totalProgreso >= 1 },
  { id: 'constanciaPeso', icono: '📈', nombre: '5 registros de peso', check: (d) => d.totalProgreso >= 5 },
  { id: 'cumplidor', icono: '✅', nombre: '10 tareas completadas', check: (d) => d.totalCompletions >= 10 },
  { id: 'premium', icono: '💎', nombre: 'Miembro Premium', check: (d) => d.isPremium }
];

function renderLogros(datos) {
  const grid = document.getElementById('achievementsGrid');
  grid.innerHTML = LOGROS.map(l => {
    const desbloqueado = l.check(datos);
    return `<div class="achievement-badge ${desbloqueado ? 'unlocked' : ''}">
      <span class="achievement-icon">${l.icono}</span>
      <span class="achievement-name">${l.nombre}</span>
    </div>`;
  }).join('');
}

async function cargarLogros(usuario) {
  try {
    const progreso = await api.get('./api/progress');
    renderLogros({
      streak: usuario.streak || 0,
      totalProgreso: progreso.length,
      totalCompletions: usuario.totalCompletions || 0,
      isPremium: usuario.isPremium
    });
  } catch (err) {
    console.error('No se pudieron cargar los logros', err);
  }
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const usuario = e.detail;
  cargarProgreso();
  cargarMetaCalorica();
  cargarDailyLog();
  cargarLogros(usuario);
  document.getElementById('downloadSummaryBtn').addEventListener('click', descargarResumenPDF);
  document.getElementById('exportProgressBtn').addEventListener('click', exportarProgresoCSV);

  document.getElementById('waterPlusBtn').addEventListener('click', () => {
    vasosAguaActual++;
    document.getElementById('waterCount').textContent = vasosAguaActual;
    guardarDailyLogDebounced();
  });
  document.getElementById('waterMinusBtn').addEventListener('click', () => {
    vasosAguaActual = Math.max(0, vasosAguaActual - 1);
    document.getElementById('waterCount').textContent = vasosAguaActual;
    guardarDailyLogDebounced();
  });
  document.getElementById('saveDailyLogBtn').addEventListener('click', async () => {
    const km = parseFloat(document.getElementById('kmInput').value) || 0;
    kmRecorridosActual = km;
    try {
      await api.post('./api/daily-log', { vasosAgua: vasosAguaActual, kmRecorridos: km });
    } catch (err) {
      console.error('No se pudo guardar tu registro diario', err);
    }
  });

  document.querySelectorAll('#progressViewTabs .week-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      vistaActual = btn.dataset.vista;
      document.querySelectorAll('#progressViewTabs .week-tab').forEach(b => b.classList.toggle('active', b === btn));
      redibujarGraficas();
    });
  });

  document.getElementById('progressForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = document.getElementById('progressPeso');
    const peso = parseFloat(input.value);
    if (!peso) return;

    try {
      await api.post('./api/progress', { peso });
    } catch (err) {
      console.error('No se pudo guardar el registro de peso', err);
      return;
    }
    input.value = '';
    await cargarProgreso();

    try {
      const bio = await api.get('./api/biometrics');
      if (bio && bio.peso && Math.abs(bio.peso - peso) >= 1) {
        await api.post('./api/biometrics', { ...bio, peso });
        cargarMetaCalorica();

        const user = window.__nutriamigoUser;
        if (!user || user.avisarActualizacionPlan !== false) {
          const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
          const plantilla = t('dash.planActualizado', 'Actualizamos tu plan: tu peso pasó de {de} kg a {a} kg.');
          mostrarAviso(plantilla.replace('{de}', bio.peso).replace('{a}', peso), 'info');
        }
      }
    } catch (err) {
      console.error('No se pudo comparar tu peso con el plan actual', err);
    }
  });

  document.getElementById('clearProgressBtn').addEventListener('click', async () => {
    try {
      await api.delete('./api/progress');
    } catch (err) {
      console.error('No se pudo borrar el historial', err);
    }
    cargarProgreso();
  });
});
