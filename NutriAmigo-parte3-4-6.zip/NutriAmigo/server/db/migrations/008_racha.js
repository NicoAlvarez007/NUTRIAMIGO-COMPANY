/* Racha estilo Duolingo: reconstruye streaks conservando lo que ya había y crea streak_events. */
function up(db) {
  const columnas = db.prepare('PRAGMA table_info(streaks)').all().map((c) => c.name);

  if (!columnas.includes('racha')) {
    db.exec('ALTER TABLE streaks RENAME TO streaks_anterior');
    db.exec(`
CREATE TABLE streaks (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  racha INTEGER NOT NULL DEFAULT 0,
  mejor INTEGER NOT NULL DEFAULT 0,
  ultimo_dia TEXT,
  protectores INTEGER NOT NULL DEFAULT 0,
  regalo_mes TEXT,
  congelados TEXT NOT NULL DEFAULT '[]'
);
INSERT INTO streaks (user_id, racha, mejor, ultimo_dia)
  SELECT user_id, current_streak, current_streak, last_active_date FROM streaks_anterior;
DROP TABLE streaks_anterior;
`);
  }

  db.exec(`
CREATE TABLE IF NOT EXISTS streak_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  fecha TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('accion','protector_usado','protector_ganado','protector_regalo','perdida','ajuste_admin')),
  detalle TEXT
);
CREATE INDEX IF NOT EXISTS idx_streak_events_usuario ON streak_events(user_id, id);
`);
}

module.exports = { up };
