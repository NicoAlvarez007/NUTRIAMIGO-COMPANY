/* Zona horaria de cada persona y fecha simulada (solo la usa el administrador). */
function up(db) {
  const existentes = new Set(db.prepare('PRAGMA table_info(users)').all().map((c) => c.name));
  if (!existentes.has('tz')) db.exec('ALTER TABLE users ADD COLUMN tz TEXT');
  if (!existentes.has('sim_date')) db.exec('ALTER TABLE users ADD COLUMN sim_date TEXT');
}

module.exports = { up };
