/* completions ya tiene la llave única (user_id, item_key, fecha); solo falta la hora de creación. */
function up(db) {
  const existentes = new Set(db.prepare('PRAGMA table_info(completions)').all().map((c) => c.name));
  if (!existentes.has('creado_en')) db.exec('ALTER TABLE completions ADD COLUMN creado_en TEXT');
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_completions_unica ON completions(user_id, item_key, fecha)');
}

module.exports = { up };
