const os = require('os');
const path = require('path');
const http = require('http');
const express = require('express');
const session = require('express-session');
const { Passport } = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const { Server } = require('socket.io');

const { cargarConfig } = require('./config');
const { abrir } = require('./db');
const { crearConsultas } = require('./db/queries');
const { crearStore } = require('./lib/sesionSqlite');
const { MENSAJES } = require('./lib/validadores');
const { tzValida } = require('./lib/fechas');
const { iniciarSockets } = require('./sockets');
const { crearHelmet, sinCache, proteccionCsrf, bloquearRutasSospechosas } = require('./middleware/seguridad');
const { crearLimites } = require('./middleware/limites');
const { crearRutasAuth } = require('./routes/auth');
const { crearRutasPerfil } = require('./routes/perfil');
const { crearRutasProgreso } = require('./routes/progreso');
const { crearRutasEntrenamiento } = require('./routes/entrenamiento');
const { crearRutasPlan } = require('./routes/plan');
const { crearRutasComunidad } = require('./routes/comunidad');
const { crearRutasAmigos } = require('./routes/amigos');
const { crearRutasAdmin } = require('./routes/admin');
const { requireAdminPagina } = require('./middleware/cuentas');
const { asegurarAdministrador } = require('./lib/administrador');

const CARPETA_PUBLICA = path.join(__dirname, '..', 'public');

function direccionesDeRed() {
  const direcciones = [];
  for (const interfaces of Object.values(os.networkInterfaces())) {
    for (const i of interfaces || []) {
      if (i.family === 'IPv4' && !i.internal) direcciones.push(i.address);
    }
  }
  return direcciones;
}

function mostrarDirecciones(puerto) {
  const redes = direccionesDeRed();
  console.log('\n✅ NutriAmigo está funcionando');
  console.log(`   En este computador:  http://localhost:${puerto}`);
  if (redes.length === 0) {
    console.log('   Desde tu celular (misma red Wi-Fi):  no se encontró una red local activa');
  }
  redes.forEach((ip, i) => {
    const etiqueta = i === 0 ? 'Desde tu celular (misma red Wi-Fi):' : '                                    ';
    console.log(`   ${etiqueta}  http://${ip}:${puerto}`);
  });
  console.log('');
}

/* `reloj` solo sirve para las pruebas: permite fijar qué hora es en el servidor. */
function crearServidor(opciones = {}) {
  const { reloj = () => new Date(), ...opcionesConfig } = opciones;
  const config = cargarConfig(opcionesConfig);
  const db = abrir(config.RUTA_DB, { copiarAntigua: config.NODE_ENV !== 'test' });
  const q = crearConsultas(db);
  const limites = crearLimites();

  const app = express();
  const server = http.createServer(app);
  const io = new Server(server);
  const store = crearStore(session, db);
  const passport = new Passport();

  app.disable('x-powered-by');
  app.use(crearHelmet(config));
  app.use(bloquearRutasSospechosas);

  const sesion = session({
    name: 'nutriamigo.sid',
    secret: config.SESSION_SECRET,
    store,
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: config.COOKIE_SECURE,
      maxAge: 30 * 24 * 60 * 60 * 1000
    }
  });
  const pasaporteInicio = passport.initialize();
  const pasaporteSesion = passport.session();

  /* La página del panel y la versión Química solo se sirven al administrador. */
  app.use(['/admin.html', '/quimica'], sesion, pasaporteInicio, pasaporteSesion, requireAdminPagina);
  app.use(express.static(CARPETA_PUBLICA, { dotfiles: 'ignore' }));

  app.use('/api', sinCache, limites.general);
  app.use('/auth', limites.autenticacion);
  app.use(proteccionCsrf);
  app.use(express.json({ limit: '100kb' }));

  app.use(sesion);
  app.use(pasaporteInicio);
  app.use(pasaporteSesion);

  /* Instante actual y zona horaria: el navegador la manda en X-Timezone y el servidor la valida. */
  app.use((req, res, next) => {
    req.ahora = reloj();
    const tz = req.get('X-Timezone');
    if (req.user && tz && tz !== req.user.tz && tzValida(tz)) {
      q.setZonaHoraria(req.user.id, tz);
      req.user.tz = tz;
    }
    next();
  });

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser((id, done) => done(null, q.getUserById(id) || false));

  if (config.GOOGLE_CONFIGURADO) {
    passport.use(new GoogleStrategy({
      clientID: config.GOOGLE_CLIENT_ID,
      clientSecret: config.GOOGLE_CLIENT_SECRET,
      callbackURL: config.GOOGLE_CALLBACK_URL
    }, (accessToken, refreshToken, profile, done) => {
      const usuario = q.findOrCreateUser({
        googleId: profile.id,
        name: profile.displayName,
        email: profile.emails?.[0]?.value || null,
        avatar: profile.photos?.[0]?.value || null
      });
      done(null, usuario);
    }));
  } else if (config.NODE_ENV !== 'test') {
    const aviso = config.GOOGLE_SIMULADO
      ? 'se usa el inicio de sesión de Google simulado en este computador.'
      : 'el inicio de sesión con Google no funcionará hasta configurarlos.';
    console.warn(`\nℹ️  Sin GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET en server/.env: ${aviso}\n`);
  }

  if (config.NODE_ENV === 'test') {
    /* Solo existe en las pruebas automáticas: crea un usuario y abre su sesión. */
    app.post('/__test/login', (req, res, next) => {
      const cuerpo = req.body || {};
      const correo = typeof cuerpo.email === 'string' ? cuerpo.email : 'prueba@nutriamigo.test';
      const usuario = q.findOrCreateUser({
        googleId: `prueba:${correo}`,
        name: typeof cuerpo.name === 'string' ? cuerpo.name : 'Usuario de prueba',
        email: correo,
        avatar: null
      });
      req.login(usuario, (err) => {
        if (err) return next(err);
        return res.json({ ok: true, id: usuario.id });
      });
    });
  }

  app.use('/auth', crearRutasAuth({ config, q, passport }));
  app.use('/api', crearRutasPerfil({ q, config }));
  app.use('/api', crearRutasProgreso({ q }));
  app.use('/api', crearRutasEntrenamiento({ q }));
  app.use('/api', crearRutasPlan({ q, config, db }));
  app.use('/api', crearRutasAdmin({ q, config, db }));
  app.use('/api', crearRutasComunidad({ q, limites }));
  app.use('/api', crearRutasAmigos({ q, limites }));

  app.use('/api', (req, res) => {
    res.status(404).json({ error: MENSAJES.no_encontrado, code: 'no_encontrado' });
  });
  app.use((req, res) => {
    res.status(404).type('text/plain').send('No encontrado');
  });

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err && err.type === 'entity.parse.failed') {
      return res.status(400).json({ error: MENSAJES.json_invalido, code: 'json_invalido' });
    }
    if (err && err.type === 'entity.too.large') {
      return res.status(413).json({ error: MENSAJES.cuerpo_grande, code: 'cuerpo_grande' });
    }
    console.error('Error no controlado:', err);
    try { q.auditar(req.user && req.user.id, 'error_500', `${req.method} ${req.path}: ${err && err.message}`); } catch (e) { /* sin registro */ }
    if (res.headersSent) return undefined;
    return res.status(500).json({ error: MENSAJES.interno, code: 'interno' });
  });

  io.engine.use(sesion);
  io.engine.use(pasaporteInicio);
  io.engine.use(pasaporteSesion);
  iniciarSockets(io, q);

  async function iniciar() {
    await asegurarAdministrador(q, config);
    return new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(config.PORT, '0.0.0.0', () => {
        server.removeListener('error', reject);
        const puerto = server.address().port;
        if (config.NODE_ENV !== 'test') mostrarDirecciones(puerto);
        resolve({ puerto });
      });
    });
  }

  function detener() {
    return new Promise((resolve) => {
      store.cerrar();
      io.close(() => {
        try { db.close(); } catch (e) { /* ya estaba cerrada */ }
        resolve();
      });
    });
  }

  return { app, server, io, db, q, config, iniciar, detener };
}

if (require.main === module) {
  let servidor;
  try {
    servidor = crearServidor();
  } catch (err) {
    console.error(`\n❌ No se pudo iniciar NutriAmigo: ${err.message}\n`);
    process.exit(1);
  }
  servidor.iniciar().catch((err) => {
    const mensaje = err.code === 'EADDRINUSE'
      ? `El puerto ${servidor.config.PORT} ya está en uso. Cierra el otro programa o cambia PORT en server/.env.`
      : err.message;
    console.error(`\n❌ No se pudo iniciar NutriAmigo: ${mensaje}\n`);
    process.exit(1);
  });
}

module.exports = { crearServidor, direccionesDeRed };
