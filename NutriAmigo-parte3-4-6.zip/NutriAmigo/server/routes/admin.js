const express = require('express');
const path = require('path');
const requireAuth = require('../middleware/requireAuth');
const { requireAdmin } = require('../middleware/cuentas');
const { responderCodigo, validarCuerpo, validarParametroId } = require('../middleware/validar');
const {
  validarMotivo, validarFuncion, validarFechaAdmin, validarAjusteProtector, validarRachaFija, validarSimulacionDias, FUNCIONES
} = require('../lib/validadores');
const { ejecutarEscenarios } = require('../lib/escenariosRacha');
const { hashPassword, contrasenaTemporal } = require('../lib/passwords');
const { hoy, sumarDias, fechaValida } = require('../lib/fechas');

function crearRutasAdmin({ q, config, db }) {
  const router = express.Router();
  router.use('/admin', requireAuth, requireAdmin);

  const rutaId = validarParametroId('id');

  function usuarioObjetivo(req, res) {
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.ids.id);
    if (!u) responderCodigo(res, 404, 'no_encontrado');
    return u || null;
  }

  router.get('/admin/estado', (req, res) => {
    res.json(q.estadoServidor({
      rutaDb: config.RUTA_DB,
      carpetaUploads: path.join(__dirname, '..', 'uploads'),
      version: require('../package.json').version
    }));
  });

  router.get('/admin/usuarios', (req, res) => {
    const texto = typeof req.query.q === 'string' ? req.query.q.slice(0, 80) : '';
    const pagina = Math.max(1, parseInt(req.query.pagina, 10) || 1);
    res.json(q.listarUsuarios({ q: texto, pagina }));
  });

  router.get('/admin/usuarios/:id', rutaId, (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (u) res.json(q.detalleUsuario(u.id));
  });

  router.post('/admin/usuarios/:id/suspender', rutaId, validarCuerpo(validarMotivo), (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (!u) return undefined;
    if (u.role === 'admin') return responderCodigo(res, 400, 'accion_no_permitida');
    q.suspender(u.id, req.datos.motivo);
    q.auditar(req.user.id, 'usuario_suspendido', `id=${u.id}; motivo=${req.datos.motivo}`);
    return res.json({ ok: true });
  });

  router.post('/admin/usuarios/:id/reactivar', rutaId, (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (!u) return;
    q.reactivar(u.id);
    q.auditar(req.user.id, 'usuario_reactivado', `id=${u.id}`);
    res.json({ ok: true });
  });

  router.post('/admin/usuarios/:id/restablecer-contrasena', rutaId, async (req, res, next) => {
    try {
      const u = usuarioObjetivo(req, res);
      if (!u) return undefined;
      if (u.role === 'admin' && u.id !== req.user.id) return responderCodigo(res, 400, 'accion_no_permitida');
      const temporal = contrasenaTemporal();
      q.guardarContrasena(u.id, await hashPassword(temporal));
      q.limpiarIntentos([`cta:${(u.email || u.username || '').toLowerCase()}`, `pwd:${u.id}`]);
      q.auditar(req.user.id, 'contrasena_restablecida', `id=${u.id}`);
      return res.json({ ok: true, temporal });
    } catch (err) {
      return next(err);
    }
  });

  router.delete('/admin/usuarios/:id', rutaId, (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (!u) return undefined;
    if (u.role === 'admin') return responderCodigo(res, 400, 'accion_no_permitida');
    q.deleteAccount(u.id);
    q.auditar(req.user.id, 'usuario_eliminado', `id=${u.id}`);
    return res.json({ ok: true });
  });

  router.get('/admin/funciones', (req, res) => {
    res.json(q.obtenerFunciones());
  });

  router.post('/admin/funciones/:clave', validarCuerpo(validarFuncion), (req, res) => {
    const clave = req.params.clave;
    if (!FUNCIONES.includes(clave)) return responderCodigo(res, 404, 'no_encontrado');
    q.cambiarFuncion(clave, req.datos.activo);
    q.auditar(req.user.id, 'funcion_cambiada', `${clave}=${req.datos.activo ? 1 : 0}`);
    return res.json(q.obtenerFunciones());
  });

  router.get('/admin/fecha', (req, res) => {
    res.json({ simulada: req.user.sim_date || null, hoy: hoy(req) });
  });

  router.post('/admin/fecha', validarCuerpo(validarFechaAdmin), (req, res) => {
    const d = req.datos;
    let nueva = null;
    if (d.fecha) nueva = d.fecha;
    else if (d.sumarDias !== undefined) nueva = sumarDias(hoy(req), d.sumarDias);
    if (nueva && !fechaValida(nueva)) return responderCodigo(res, 400, 'fecha_invalida');
    q.fijarFechaSimulada(req.user.id, nueva);
    q.auditar(req.user.id, 'fecha_simulada', nueva || 'quitada');
    return res.json({ simulada: nueva });
  });

  /* ---- Racha (Parte 4): todo se aplica solo a la cuenta del administrador ---- */
  router.get('/admin/racha', (req, res) => {
    res.json(q.racha.estado(req.user.id, hoy(req)));
  });

  router.post('/admin/racha/protector', validarCuerpo(validarAjusteProtector), (req, res) => {
    const fecha = hoy(req);
    const estado = req.datos.accion === 'dar' ? q.racha.darProtector(req.user.id, fecha) : q.racha.quitarProtector(req.user.id, fecha);
    q.auditar(req.user.id, 'racha_protector', req.datos.accion);
    res.json(estado);
  });

  router.post('/admin/racha/fijar', validarCuerpo(validarRachaFija), (req, res) => {
    q.auditar(req.user.id, 'racha_fijar', String(req.datos.racha));
    res.json(q.racha.ponerRacha(req.user.id, req.datos.racha, hoy(req)));
  });

  router.post('/admin/racha/reiniciar', (req, res) => {
    q.auditar(req.user.id, 'racha_reiniciar', null);
    res.json(q.racha.ponerRacha(req.user.id, 0, hoy(req)));
  });

  /* Simula N días seguidos con una acción cada día y deja la fecha simulada en el día siguiente. */
  router.post('/admin/racha/simular', validarCuerpo(validarSimulacionDias), (req, res) => {
    let fecha = hoy(req);
    for (let i = 0; i < req.datos.dias; i += 1) {
      q.racha.registrarAccion(req.user.id, 'comida', fecha);
      fecha = sumarDias(fecha, 1);
    }
    q.fijarFechaSimulada(req.user.id, fecha);
    q.auditar(req.user.id, 'racha_simular', String(req.datos.dias));
    res.json({ simulada: fecha, estado: q.racha.estado(req.user.id, fecha) });
  });

  router.post('/admin/reiniciar-dia', (req, res) => {
    q.auditar(req.user.id, 'reiniciar_dia', hoy(req));
    res.json(q.racha.reiniciarDia(req.user.id, hoy(req)));
  });

  router.get('/admin/racha/escenarios', (req, res) => {
    res.json(ejecutarEscenarios());
  });

  return router;
}

module.exports = { crearRutasAdmin };
