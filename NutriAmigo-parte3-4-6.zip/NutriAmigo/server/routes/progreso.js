const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { validarCuerpo, responderCodigo } = require('../middleware/validar');
const { validarProgreso, validarRegistroDiario, validarCompletion, validarReinicio, detalleItemKey } = require('../lib/validadores');
const { hoy, diaSemana, inicioSemana, sumarDias } = require('../lib/fechas');

function crearRutasProgreso({ q }) {
  const router = express.Router();
  router.use(requireAuth);

  router.get('/progress', (req, res) => {
    res.json(q.getProgress(req.user.id));
  });

  router.post('/progress', validarCuerpo(validarProgreso), (req, res) => {
    const fecha = hoy(req);
    const lista = q.addProgress(req.user.id, req.datos.peso, fecha);
    q.racha.registrarAccion(req.user.id, 'peso', fecha);
    res.json(lista);
  });

  router.delete('/progress', (req, res) => {
    q.clearProgress(req.user.id);
    res.json({ ok: true });
  });

  router.get('/daily-log', (req, res) => {
    res.json(q.getDailyLog(req.user.id, hoy(req)));
  });

  router.post('/daily-log', validarCuerpo(validarRegistroDiario), (req, res) => {
    const fecha = hoy(req);
    const actual = q.getDailyLog(req.user.id, fecha);
    const vasosAgua = req.datos.vasosAgua !== undefined ? req.datos.vasosAgua : actual.vasos_agua;
    const kmRecorridos = req.datos.kmRecorridos !== undefined ? req.datos.kmRecorridos : actual.km_recorridos;
    res.json(q.guardarDailyLog(req.user.id, fecha, vasosAgua, kmRecorridos));
  });

  /* Marcas de hoy (lista de itemKey). El parámetro ?fecha=hoy es el único valor aceptado. */
  router.get('/completions', (req, res) => {
    res.json(q.getCompletions(req.user.id, hoy(req)));
  });

  /* Marcas de la semana en curso (lunes a domingo), solo lectura para los demás días. */
  router.get('/completions/semana', (req, res) => {
    const fecha = hoy(req);
    const desde = inicioSemana(fecha);
    res.json({ hoy: fecha, desde, hasta: sumarDias(desde, 6), marcas: q.getCompletionsRango(req.user.id, desde, sumarDias(desde, 6)) });
  });

  /* "Reiniciar": borra las marcas de hoy (todas, o solo las de entrenamiento o alimentación). */
  router.post('/completions/reiniciar', validarCuerpo(validarReinicio), (req, res) => {
    const fecha = hoy(req);
    const borradas = q.reiniciarCompletions(req.user.id, fecha, req.datos.tipo);
    res.json({ ok: true, borradas, completions: q.getCompletions(req.user.id, fecha) });
  });

  /* La fecha es siempre la de hoy del servidor; el cliente nunca la envía.
     `marcar: true` deja la marca puesta (lo usa "Entrenar ahora"); sin él, alterna. */
  router.post('/completions', validarCuerpo(validarCompletion), (req, res) => {
    const fecha = hoy(req);
    const { itemKey, marcar } = req.datos;
    const { dia, tipo } = detalleItemKey(itemKey);
    if (dia !== diaSemana(fecha)) return responderCodigo(res, 409, 'dia_no_es_hoy', 'itemKey');

    const resultado = marcar ? q.marcarCompletion(req.user.id, itemKey, fecha) : q.toggleCompletion(req.user.id, itemKey, fecha);
    if (resultado.completado) q.racha.registrarAccion(req.user.id, tipo, fecha);
    return res.json({ completado: resultado.completado, racha: q.racha.estado(req.user.id, fecha) });
  });

  return router;
}

module.exports = { crearRutasProgreso };
