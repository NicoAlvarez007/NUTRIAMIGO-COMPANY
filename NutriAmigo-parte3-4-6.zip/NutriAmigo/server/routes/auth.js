const express = require('express');
const { responderCodigo, validarCuerpo } = require('../middleware/validar');
const { MENSAJES, validarRegistro, validarLogin, validarGoogleSimulado } = require('../lib/validadores');
const { hashPassword, verificarPassword, verificacionFalsa } = require('../lib/passwords');

function esErrorUnico(err) {
  return !!(err && String(err.code || '').startsWith('SQLITE_CONSTRAINT'));
}

function crearRutasAuth({ config, q, passport }) {
  const router = express.Router();

  function requiereGoogle(req, res, next) {
    if (config.GOOGLE_CONFIGURADO) return next();
    return responderCodigo(res, 503, 'google_no_configurado');
  }

  function destino(usuario) {
    if (usuario.suspended) return '/suspendida.html';
    return q.getBiometrics(usuario.id) ? '/dashboard.html' : '/onboarding.html';
  }

  function abrirSesion(req, usuario) {
    return new Promise((resolve, reject) => {
      req.login(usuario, (err) => (err ? reject(err) : resolve()));
    });
  }

  function bloqueada(res, minutos) {
    return res.status(429).json({ error: MENSAJES.cuenta_bloqueada, code: 'cuenta_bloqueada', minutos });
  }

  router.post('/registro', validarCuerpo(validarRegistro), async (req, res, next) => {
    try {
      const { email, password } = req.datos;
      if (q.buscarPorEmail(email)) return responderCodigo(res, 409, 'correo_existente', 'email');

      let usuario;
      try {
        usuario = q.crearUsuarioConContrasena({ email, hash: await hashPassword(password) });
      } catch (err) {
        if (esErrorUnico(err)) return responderCodigo(res, 409, 'correo_existente', 'email');
        throw err;
      }
      await abrirSesion(req, usuario);
      q.auditar(usuario.id, 'registro', 'password');
      return res.status(201).json({ ok: true, siguiente: '/onboarding.html' });
    } catch (err) {
      return next(err);
    }
  });

  router.post('/login', validarCuerpo(validarLogin), async (req, res, next) => {
    try {
      const { identificador, password } = req.datos;
      const claves = [`cta:${identificador}`, `ip:${req.ip}`];
      const minutos = q.minutosDeBloqueo(claves);
      if (minutos) return bloqueada(res, minutos);

      const usuario = identificador.includes('@') ? q.buscarPorEmail(identificador) : q.buscarPorUsername(identificador);
      const valida = usuario && usuario.password_hash
        ? await verificarPassword(password, usuario.password_hash)
        : await verificacionFalsa(password);

      if (!valida) {
        if (q.registrarFallo(claves)) return bloqueada(res, q.minutosDeBloqueo(claves));
        return responderCodigo(res, 401, 'credenciales_invalidas');
      }

      q.limpiarIntentos(claves);
      await abrirSesion(req, usuario);
      q.auditar(usuario.id, 'login', usuario.role === 'admin' ? 'admin' : null);
      return res.json({ ok: true, siguiente: destino(usuario), suspendida: !!usuario.suspended });
    } catch (err) {
      return next(err);
    }
  });

  router.get('/google', (req, res, next) => {
    if (config.GOOGLE_CONFIGURADO) {
      return passport.authenticate('google', { scope: ['profile', 'email'] })(req, res, next);
    }
    if (config.GOOGLE_SIMULADO) return res.redirect('/google-simulado.html');
    return responderCodigo(res, 503, 'google_no_configurado');
  });

  router.get('/google/callback', requiereGoogle,
    passport.authenticate('google', { failureRedirect: '/acceso.html?error=google' }),
    (req, res) => {
      q.auditar(req.user.id, 'login', 'google');
      res.redirect(destino(req.user));
    });

  /* Google simulado (solo cuando no hay credenciales reales y la configuración lo permite). */
  router.post('/google-simulado', validarCuerpo(validarGoogleSimulado), async (req, res, next) => {
    try {
      if (!config.GOOGLE_SIMULADO) return responderCodigo(res, 404, 'no_encontrado');
      const { nombre, email, password } = req.datos;
      const claves = [`cta:${email}`, `ip:${req.ip}`];
      const minutos = q.minutosDeBloqueo(claves);
      if (minutos) return bloqueada(res, minutos);

      let usuario = q.buscarPorEmail(email);
      if (usuario && usuario.role === 'admin') return responderCodigo(res, 403, 'sin_permiso');

      /* La contraseña es obligatoria: se crea con la cuenta, y quien ya tenía una debe escribirla
         (así nadie entra a una cuenta ajena solo con saber su correo). */
      if (usuario && usuario.password_hash) {
        if (!(await verificarPassword(password, usuario.password_hash))) {
          if (q.registrarFallo(claves)) return bloqueada(res, q.minutosDeBloqueo(claves));
          return responderCodigo(res, 401, 'credenciales_invalidas');
        }
        q.limpiarIntentos(claves);
      } else {
        if (!usuario) {
          try {
            usuario = q.findOrCreateUser({ googleId: null, name: nombre, email, avatar: null });
          } catch (err) {
            if (!esErrorUnico(err)) throw err;
            usuario = q.buscarPorEmail(email);
          }
        }
        if (usuario.password_hash) return responderCodigo(res, 409, 'correo_existente', 'email');
        q.guardarContrasena(usuario.id, await hashPassword(password));
      }
      await abrirSesion(req, usuario);
      q.auditar(usuario.id, 'login', 'google_simulado');
      return res.json({ ok: true, siguiente: destino(usuario) });
    } catch (err) {
      return next(err);
    }
  });

  router.post('/logout', (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      return res.json({ ok: true });
    });
  });

  return router;
}

module.exports = { crearRutasAuth };
