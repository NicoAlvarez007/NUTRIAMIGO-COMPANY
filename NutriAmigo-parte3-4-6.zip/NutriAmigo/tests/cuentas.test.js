const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { iniciarServidor } = require('./ayudas');
const { hoy, diaDeSemana } = require('../server/lib/fechas');
const { hashPassword, verificarPassword } = require('../server/lib/passwords');

const ENV = { ADMIN_USER: 'administrador', ADMIN_PASSWORD: 'clave-admin-prueba', GOOGLE_SIMULADO: 'true' };
const DATOS = { nombre: 'Ana', apellido: 'Pérez', peso: 60, estatura: 165, sexo: 'mujer', actividad: 'ligero', objetivo: 'mantener' };
const ADULTO = { nombre: 'Marta Pérez', parentesco: 'madre', contacto: '3101234567', acepta: true };

async function conServidor(t) {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  return s;
}

async function entrarAdmin(s) {
  const c = s.cliente();
  const r = await c.post('/auth/login', { identificador: 'administrador', password: 'clave-admin-prueba' });
  assert.equal(r.status, 200);
  return c;
}

test('hash scrypt: formato esperado y verificación', async () => {
  const h = await hashPassword('clave-segura-1');
  assert.match(h, /^scrypt\$16384\$8\$1\$[0-9a-f]{32}\$[0-9a-f]{128}$/);
  assert.equal(await verificarPassword('clave-segura-1', h), true);
  assert.equal(await verificarPassword('otra', h), false);
  assert.equal(await verificarPassword('x', 'basura'), false);
});

test('registro: correcto, contraseña corta y correo repetido con otras mayúsculas', async (t) => {
  const s = await conServidor(t);
  const corta = await s.cliente().post('/auth/registro', { email: 'corta@prueba.com', password: '1234567' });
  assert.equal(corta.status, 400);
  assert.equal(corta.datos.code, 'contrasena_corta');

  const c = s.cliente();
  const ok = await c.post('/auth/registro', { email: 'Ana@Prueba.com', password: 'clave-segura-1' });
  assert.equal(ok.status, 201);
  assert.equal(ok.datos.siguiente, '/onboarding.html');
  assert.equal((await c.get('/api/me')).datos.email, 'ana@prueba.com');

  const repetido = await s.cliente().post('/auth/registro', { email: 'ANA@prueba.COM', password: 'clave-segura-1' });
  assert.equal(repetido.status, 409);
  assert.equal(repetido.datos.code, 'correo_existente');
});

test('login: mismo mensaje en ambos fallos y acepta correo o usuario', async (t) => {
  const s = await conServidor(t);
  await s.cliente().post('/auth/registro', { email: 'login@prueba.com', password: 'clave-segura-2' });
  const mala = await s.cliente().post('/auth/login', { identificador: 'login@prueba.com', password: 'incorrecta' });
  const noExiste = await s.cliente().post('/auth/login', { identificador: 'nadie@prueba.com', password: 'incorrecta' });
  assert.equal(mala.status, 401);
  assert.deepEqual(mala.datos, noExiste.datos);
  assert.equal(mala.datos.code, 'credenciales_invalidas');
  assert.equal((await s.cliente().post('/auth/login', { identificador: 'LOGIN@prueba.com', password: 'clave-segura-2' })).status, 200);
});

test('login: 5 fallos seguidos bloquean 15 minutos y el bloqueo expira', async (t) => {
  const s = await conServidor(t);
  await s.cliente().post('/auth/registro', { email: 'bloqueo@prueba.com', password: 'clave-segura-3' });
  let ultimo;
  for (let i = 0; i < 5; i += 1) ultimo = await s.cliente().post('/auth/login', { identificador: 'bloqueo@prueba.com', password: `mala${i}` });
  assert.equal(ultimo.status, 429);
  assert.equal(ultimo.datos.code, 'cuenta_bloqueada');
  assert.ok(ultimo.datos.minutos >= 1 && ultimo.datos.minutos <= 15);

  s.servidor.db.prepare('UPDATE login_attempts SET bloqueado_hasta = 1').run();
  const libre = await s.cliente().post('/auth/login', { identificador: 'bloqueo@prueba.com', password: 'clave-segura-3' });
  assert.equal(libre.status, 200);
});

test('la contraseña nunca aparece en texto ni en /api/me', async (t) => {
  const s = await conServidor(t);
  const c = s.cliente();
  await c.post('/auth/registro', { email: 'hash@prueba.com', password: 'clave-segura-4' });
  const yo = await c.get('/api/me');
  const texto = JSON.stringify(yo.datos);
  assert.ok(!texto.includes('clave-segura-4') && !texto.includes('scrypt$') && !texto.includes('password_hash'));
  const filas = JSON.stringify(s.servidor.db.prepare('SELECT * FROM users').all());
  assert.ok(!filas.includes('clave-segura-4'));
  assert.match(s.servidor.db.prepare('SELECT password_hash FROM users WHERE email = ?').get('hash@prueba.com').password_hash,
    /^scrypt\$16384\$8\$1\$[0-9a-f]{32}\$[0-9a-f]{128}$/);
});

test('Google simulado: la contraseña es obligatoria, se confirma y protege cuentas existentes', async (t) => {
  const s = await conServidor(t);
  await s.cliente().post('/auth/registro', { email: 'existente@prueba.com', password: 'clave-segura-5' });
  const contar = () => s.servidor.db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  const antes = contar();

  // sin contraseña, corta o sin confirmar: se rechaza y no se crea nada
  const sinClave = await s.cliente().post('/auth/google-simulado', { nombre: 'Nuevo', email: 'nuevo@prueba.com' });
  assert.equal(sinClave.status, 400);
  assert.equal(sinClave.datos.code, 'contrasena_corta');
  const corta = await s.cliente().post('/auth/google-simulado', { nombre: 'Nuevo', email: 'nuevo@prueba.com', password: '1234', confirmar: '1234' });
  assert.equal(corta.datos.code, 'contrasena_corta');
  const distinta = await s.cliente().post('/auth/google-simulado', { nombre: 'Nuevo', email: 'nuevo@prueba.com', password: 'clave-nueva-55', confirmar: 'clave-nueva-56' });
  assert.equal(distinta.status, 400);
  assert.equal(distinta.datos.code, 'contrasenas_no_coinciden');
  assert.equal(contar(), antes);

  // cuenta nueva: se crea con contraseña y luego se puede entrar con correo y contraseña
  const c = s.cliente();
  const ok = await c.post('/auth/google-simulado', { nombre: 'Nuevo', email: 'nuevo@prueba.com', password: 'clave-nueva-55', confirmar: 'clave-nueva-55' });
  assert.equal(ok.status, 200);
  assert.equal(contar(), antes + 1);
  const yo = (await c.get('/api/me')).datos;
  assert.equal(yo.authProvider, 'google');
  assert.equal(yo.hasPassword, true);
  assert.equal((await s.cliente().post('/auth/login', { identificador: 'nuevo@prueba.com', password: 'clave-nueva-55' })).status, 200);

  // cuenta existente: exige SU contraseña; con una equivocada no entra y no se duplica
  const mala = await s.cliente().post('/auth/google-simulado', { nombre: 'Otro', email: 'EXISTENTE@prueba.com', password: 'clave-equivocada', confirmar: 'clave-equivocada' });
  assert.equal(mala.status, 401);
  const buena = await s.cliente().post('/auth/google-simulado', { nombre: 'Otro', email: 'EXISTENTE@prueba.com', password: 'clave-segura-5', confirmar: 'clave-segura-5' });
  assert.equal(buena.status, 200);
  assert.equal(contar(), antes + 1);
});

test('Google simulado: una cuenta antigua sin contraseña debe crear una al entrar', async (t) => {
  const s = await conServidor(t);
  s.servidor.q.findOrCreateUser({ googleId: null, name: 'Antigua', email: 'antigua@prueba.com', avatar: null });
  const c = s.cliente();
  const r = await c.post('/auth/google-simulado', { nombre: 'Antigua', email: 'antigua@prueba.com', password: 'clave-nueva-77', confirmar: 'clave-nueva-77' });
  assert.equal(r.status, 200);
  assert.equal((await c.get('/api/me')).datos.hasPassword, true);
  assert.equal((await s.cliente().post('/auth/login', { identificador: 'antigua@prueba.com', password: 'clave-nueva-77' })).status, 200);
});

test('Google simulado desactivado cuando la configuración no lo permite', async (t) => {
  const s = await iniciarServidor({ env: { GOOGLE_SIMULADO: 'false' } });
  t.after(() => s.detener());
  const r = await s.cliente().post('/auth/google-simulado', { nombre: 'X', email: 'x@prueba.com' });
  assert.equal(r.status, 404);
});

test('menores: <15 rechazado, 16 sin autorización 400, con autorización se guarda', async (t) => {
  const s = await conServidor(t);
  const c = s.cliente();
  await c.post('/auth/registro', { email: 'menor@prueba.com', password: 'clave-segura-6' });

  assert.equal((await c.post('/api/biometrics', { ...DATOS, edad: 14 })).status, 400);
  const sin = await c.post('/api/biometrics', { ...DATOS, edad: 16 });
  assert.equal(sin.status, 400);
  assert.equal(sin.datos.code, 'consentimiento_requerido');
  assert.equal((await c.post('/api/biometrics', { ...DATOS, edad: 16, consentimiento: { ...ADULTO, acepta: false } })).status, 400);
  assert.equal((await c.post('/api/biometrics', { ...DATOS, edad: 16, objetivo: 'definir', consentimiento: ADULTO })).datos.code, 'objetivo_no_permitido_menor');

  const ok = await c.post('/api/biometrics', { ...DATOS, edad: 16, consentimiento: ADULTO });
  assert.equal(ok.status, 200);
  assert.equal(ok.datos.correo, 'menor@prueba.com');
  const fila = s.servidor.db.prepare('SELECT * FROM guardian_consents').get();
  assert.equal(fila.nombre, 'Marta Pérez');
  assert.ok(fila.aceptado_en);
  assert.equal((await c.post('/api/biometrics', { ...DATOS, edad: 16, peso: 62 })).status, 200);
});

test('volver a entrar con la misma cuenta no vuelve a pedir el registro de datos', async (t) => {
  const s = await conServidor(t);
  const c = s.cliente();
  await c.post('/auth/registro', { email: 'vuelve@prueba.com', password: 'clave-segura-7' });
  assert.equal((await c.get('/api/me')).datos.hasBiometrics, false);
  assert.equal((await c.post('/api/biometrics', { ...DATOS, edad: 30 })).status, 200);
  await c.post('/auth/logout');

  const otra = s.cliente();
  const login = await otra.post('/auth/login', { identificador: 'vuelve@prueba.com', password: 'clave-segura-7' });
  assert.equal(login.datos.siguiente, '/dashboard.html');
  assert.equal((await otra.get('/api/me')).datos.hasBiometrics, true);
});

test('administrador: creado desde .env; los demás reciben 404 en la página y 403 en la API', async (t) => {
  const s = await conServidor(t);
  assert.equal(s.servidor.db.prepare("SELECT username FROM users WHERE role = 'admin'").get().username, 'administrador');

  const usuario = s.cliente();
  await usuario.post('/auth/registro', { email: 'normal@prueba.com', password: 'clave-segura-8' });
  assert.equal((await usuario.get('/admin.html')).status, 404);
  assert.equal((await usuario.get('/api/admin/estado')).status, 403);
  assert.equal((await s.cliente().get('/admin.html')).status, 404);
  assert.equal((await s.cliente().get('/api/admin/estado')).status, 401);

  const admin = await entrarAdmin(s);
  assert.equal((await admin.get('/admin.html')).status, 200);
  assert.equal((await admin.get('/api/admin/estado')).status, 200);
  assert.equal((await admin.get('/api/me')).datos.role, 'admin');
  assert.equal((await admin.get('/api/me')).datos.isPremium, true);
});

test('administrador: la contraseña del .env se actualiza al reiniciar', async (t) => {
  const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), 'nutriamigo-admin-'));
  t.after(() => fs.rmSync(carpeta, { recursive: true, force: true }));
  const rutaDb = path.join(carpeta, 'admin.db');

  const a = await iniciarServidor({ rutaDb, env: ENV });
  assert.equal((await a.cliente().post('/auth/login', { identificador: 'administrador', password: 'clave-admin-prueba' })).status, 200);
  await a.detener();

  const b = await iniciarServidor({ rutaDb, env: { ...ENV, ADMIN_PASSWORD: 'otra-clave-admin' } });
  t.after(() => b.detener());
  assert.equal((await b.cliente().post('/auth/login', { identificador: 'administrador', password: 'otra-clave-admin' })).status, 200);
  assert.equal((await b.cliente().post('/auth/login', { identificador: 'administrador', password: 'clave-admin-prueba' })).status, 401);
});

test('suspensión: el usuario ve el motivo y no puede usar la comunidad; reactivar la restaura', async (t) => {
  const s = await conServidor(t);
  const usuario = s.cliente();
  await usuario.post('/auth/registro', { email: 'susp@prueba.com', password: 'clave-segura-9' });
  const id = (await usuario.get('/api/me')).datos.id;
  const admin = await entrarAdmin(s);

  assert.equal((await admin.post(`/api/admin/usuarios/${id}/suspender`, {})).status, 400);
  assert.equal((await admin.post(`/api/admin/usuarios/${id}/suspender`, { motivo: 'Spam' })).status, 200);
  const yo = (await usuario.get('/api/me')).datos;
  assert.equal(yo.suspended, true);
  assert.equal(yo.suspendedReason, 'Spam');
  assert.equal((await usuario.get('/api/reels')).datos.code, 'cuenta_suspendida');
  assert.equal((await usuario.post('/api/reels', { texto: 'hola' })).status, 403);

  const login = await s.cliente().post('/auth/login', { identificador: 'susp@prueba.com', password: 'clave-segura-9' });
  assert.equal(login.datos.siguiente, '/suspendida.html');

  await admin.post(`/api/admin/usuarios/${id}/reactivar`, {});
  assert.equal((await usuario.get('/api/reels')).status, 200);
});

test('administrador: restablecer contraseña, buscar y eliminar usuarios', async (t) => {
  const s = await conServidor(t);
  const usuario = s.cliente();
  await usuario.post('/auth/registro', { email: 'borrar@prueba.com', password: 'clave-segura-10' });
  const id = (await usuario.get('/api/me')).datos.id;
  const admin = await entrarAdmin(s);

  const lista = await admin.get('/api/admin/usuarios?q=borrar');
  assert.equal(lista.datos.total, 1);
  assert.ok(!JSON.stringify(lista.datos).includes('scrypt'));

  const reset = await admin.post(`/api/admin/usuarios/${id}/restablecer-contrasena`, {});
  assert.ok(reset.datos.temporal.length >= 8);
  assert.equal((await s.cliente().post('/auth/login', { identificador: 'borrar@prueba.com', password: reset.datos.temporal })).status, 200);
  assert.equal((await s.cliente().post('/auth/login', { identificador: 'borrar@prueba.com', password: 'clave-segura-10' })).status, 401);

  const adminId = (await admin.get('/api/me')).datos.id;
  assert.equal((await admin.delete(`/api/admin/usuarios/${adminId}`)).status, 400);
  assert.equal((await admin.delete(`/api/admin/usuarios/${id}`)).status, 200);
  assert.equal((await usuario.get('/api/me')).status, 401);
  assert.ok(s.servidor.db.prepare("SELECT COUNT(*) AS n FROM audit_log WHERE accion = 'usuario_eliminado'").get().n >= 1);
});

test('interruptores de funciones: una función apagada responde 403 y se refleja en /api/me', async (t) => {
  const s = await conServidor(t);
  const usuario = s.cliente();
  await usuario.post('/auth/registro', { email: 'flags@prueba.com', password: 'clave-segura-11' });
  const admin = await entrarAdmin(s);

  assert.equal((await admin.post('/api/admin/funciones/reels', { activo: false })).datos.reels, false);
  assert.equal((await admin.post('/api/admin/funciones/inexistente', { activo: false })).status, 404);
  assert.equal((await admin.post('/api/admin/funciones/chat', { activo: 'no' })).status, 400);
  assert.equal((await usuario.get('/api/reels')).datos.code, 'funcion_desactivada');
  assert.equal((await usuario.get('/api/friends')).status, 200);
  assert.equal((await usuario.get('/api/me')).datos.features.reels, false);
  await admin.post('/api/admin/funciones/reels', { activo: true });
  assert.equal((await usuario.get('/api/reels')).status, 200);
});

test('fecha simulada: cambia para el administrador y no para los demás', async (t) => {
  const s = await conServidor(t);
  const otro = s.cliente();
  await otro.post('/auth/registro', { email: 'fecha@prueba.com', password: 'clave-segura-12' });
  const admin = await entrarAdmin(s);

  assert.equal((await admin.post('/api/admin/fecha', { fecha: '2030-05-20' })).datos.simulada, '2030-05-20');
  assert.equal((await admin.post('/api/admin/fecha', { fecha: '2026-02-30' })).status, 400);
  const yoAdmin = (await admin.get('/api/me')).datos;
  assert.equal(yoAdmin.today, '2030-05-20');
  assert.equal(yoAdmin.simDate, '2030-05-20');
  const yoOtro = (await otro.get('/api/me')).datos;
  assert.notEqual(yoOtro.today, '2030-05-20');
  assert.equal(yoOtro.simDate, null);

  const filaAdmin = s.servidor.db.prepare("SELECT * FROM users WHERE role = 'admin'").get();
  const filaOtro = s.servidor.db.prepare('SELECT * FROM users WHERE email = ?').get('fecha@prueba.com');
  assert.equal(hoy({ user: filaAdmin }), '2030-05-20');
  assert.notEqual(hoy({ user: { ...filaOtro, sim_date: '2030-05-20' } }), '2030-05-20');

  assert.equal((await admin.post('/api/admin/fecha', { sumarDias: 1 })).datos.simulada, '2030-05-21');
  await admin.post('/api/completions', { itemKey: `entrenamiento-${diaDeSemana('2030-05-21')}` });
  assert.equal(s.servidor.db.prepare('SELECT fecha FROM completions WHERE user_id = ?').get(filaAdmin.id).fecha, '2030-05-21');
  assert.equal((await admin.post('/api/admin/fecha', { reset: true })).datos.simulada, null);
});
