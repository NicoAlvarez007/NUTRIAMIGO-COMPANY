const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const Database = require('better-sqlite3');
const { abrir } = require('../server/db');
const { migrar } = require('../server/db/migrate');

const ESQUEMA_ORIGINAL = `
CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, google_id TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  email TEXT, avatar TEXT, is_premium INTEGER NOT NULL DEFAULT 0, perfil_publico INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL);
CREATE TABLE progress (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, fecha TEXT NOT NULL, peso REAL NOT NULL);
CREATE TABLE streaks (user_id INTEGER PRIMARY KEY, current_streak INTEGER NOT NULL DEFAULT 0, last_active_date TEXT);
CREATE TABLE biometrics (user_id INTEGER PRIMARY KEY, nombre TEXT, apellido TEXT, correo TEXT, peso REAL, estatura REAL, sexo TEXT, edad INTEGER, actividad TEXT, objetivo TEXT);
CREATE TABLE preferences (user_id INTEGER PRIMARY KEY, restricciones_texto TEXT, frecuencia_semanal INTEGER, distancia_km REAL, enfoque_muscular TEXT);
CREATE TABLE preferencias_proteinas (user_id INTEGER NOT NULL, proteina TEXT NOT NULL, PRIMARY KEY (user_id, proteina));
CREATE TABLE reels (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, autor TEXT NOT NULL, texto TEXT NOT NULL, imagen_url TEXT, upvotes INTEGER NOT NULL DEFAULT 0, downvotes INTEGER NOT NULL DEFAULT 0, likes INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE reel_votes (reel_id INTEGER NOT NULL, user_id INTEGER NOT NULL, tipo TEXT NOT NULL, PRIMARY KEY (reel_id, user_id, tipo));
CREATE TABLE friends (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, nombre TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE friend_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, friend_id INTEGER NOT NULL, autor TEXT NOT NULL, texto TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE daily_logs (user_id INTEGER NOT NULL, fecha TEXT NOT NULL, vasos_agua INTEGER NOT NULL DEFAULT 0, km_recorridos REAL NOT NULL DEFAULT 0, PRIMARY KEY (user_id, fecha));
CREATE TABLE completions (user_id INTEGER NOT NULL, item_key TEXT NOT NULL, fecha TEXT NOT NULL, PRIMARY KEY (user_id, item_key, fecha));
`;

function carpetaTemporal(t) {
  const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), 'nutriamigo-mig-'));
  t.after(() => fs.rmSync(carpeta, { recursive: true, force: true }));
  return carpeta;
}

test('dos arranques seguidos no duplican ni fallan', (t) => {
  const ruta = path.join(carpetaTemporal(t), 'a.db');
  const db1 = abrir(ruta, { copiarAntigua: false });
  const versiones = db1.prepare('SELECT version FROM schema_migrations ORDER BY version').all().map((f) => f.version);
  assert.deepEqual(versiones, [1, 2, 3, 4, 5, 6, 7, 8, 9]);
  db1.close();

  const db2 = abrir(ruta, { copiarAntigua: false });
  assert.equal(db2.prepare('SELECT COUNT(*) AS n FROM schema_migrations').get().n, 9);
  assert.deepEqual(migrar(db2), []);
  assert.equal(db2.pragma('foreign_keys', { simple: true }), 1);
  assert.equal(String(db2.pragma('journal_mode', { simple: true })).toLowerCase(), 'wal');
  db2.close();
});

test('una base antigua se migra sin perder filas', (t) => {
  const ruta = path.join(carpetaTemporal(t), 'antigua.db');
  const vieja = new Database(ruta);
  vieja.exec(ESQUEMA_ORIGINAL);
  vieja.prepare("INSERT INTO users (google_id, name, email, created_at) VALUES ('g1', 'Ana', 'a@a.co', '2026-01-01')").run();
  vieja.prepare("INSERT INTO progress (user_id, fecha, peso) VALUES (1, '2026-01-02', 70.5)").run();
  vieja.prepare("INSERT INTO biometrics (user_id, nombre, peso) VALUES (1, 'Ana', 70.5)").run();
  vieja.prepare("INSERT INTO completions (user_id, item_key, fecha) VALUES (1, 'entrenamiento-lunes', '2026-01-02')").run();
  vieja.prepare("INSERT INTO streaks (user_id, current_streak, last_active_date) VALUES (1, 5, '2026-01-02')").run();
  vieja.close();

  const db = abrir(ruta, { copiarAntigua: false });
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM users').get().n, 1);
  assert.equal(db.prepare('SELECT peso FROM progress').get().peso, 70.5);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM completions').get().n, 1);
  const columnas = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  for (const c of ['avisar_actualizacion_plan', 'recordar_agua', 'recordar_entreno']) assert.ok(columnas.includes(c), c);
  assert.equal(db.prepare('SELECT avisar_actualizacion_plan AS v FROM users').get().v, 1);
  const racha = db.prepare('SELECT racha, mejor, ultimo_dia, protectores, congelados FROM streaks WHERE user_id = 1').get();
  assert.deepEqual({ ...racha }, { racha: 5, mejor: 5, ultimo_dia: '2026-01-02', protectores: 0, congelados: '[]' });
  assert.ok(db.prepare("SELECT name FROM sqlite_master WHERE name = 'streak_events'").get());
  for (const c of ['tz', 'sim_date']) assert.ok(columnas.includes(c), c);
  assert.ok(db.prepare('PRAGMA table_info(completions)').all().some((c) => c.name === 'creado_en'));
  assert.ok(db.prepare("SELECT name FROM sqlite_master WHERE name = 'sessions'").get());
  assert.ok(db.prepare("SELECT name FROM sqlite_master WHERE name = 'idx_progress_usuario_fecha'").get());
  db.close();
});

test('una migración que falla se revierte completa', (t) => {
  const carpeta = carpetaTemporal(t);
  const migraciones = path.join(carpeta, 'm');
  fs.mkdirSync(migraciones);
  fs.writeFileSync(path.join(migraciones, '001_ok.js'), "exports.up = (db) => db.exec('CREATE TABLE a (x INTEGER)');");
  fs.writeFileSync(path.join(migraciones, '002_mala.js'),
    "exports.up = (db) => { db.exec('CREATE TABLE b (x INTEGER)'); throw new Error('boom'); };");
  const db = new Database(path.join(carpeta, 'x.db'));
  assert.throws(() => migrar(db, migraciones), /002_mala/);
  assert.ok(db.prepare("SELECT name FROM sqlite_master WHERE name = 'a'").get());
  assert.equal(db.prepare("SELECT name FROM sqlite_master WHERE name = 'b'").get(), undefined);
  assert.deepEqual(db.prepare('SELECT version FROM schema_migrations').all().map((f) => f.version), [1]);
  db.close();
});

test('copia automática de backend/nutriamigo.db a server/data', (t) => {
  const { copiarBaseAntigua } = require('../server/db');
  const carpeta = carpetaTemporal(t);
  const destino = path.join(carpeta, 'nueva.db');
  assert.equal(copiarBaseAntigua(destino), fs.existsSync(path.join(__dirname, '..', 'backend', 'nutriamigo.db')));
});
