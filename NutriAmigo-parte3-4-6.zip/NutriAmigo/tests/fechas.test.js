const test = require('node:test');
const assert = require('node:assert/strict');
const f = require('../server/lib/fechas');

test('hoy(req): a las 19:30 en Colombia sigue siendo el mismo día (no UTC)', () => {
  const req = { user: { tz: 'America/Bogota' }, ahora: new Date('2026-10-02T00:30:00Z') };
  assert.equal(f.hoy(req), '2026-10-01');
  assert.equal(f.hoy({ ahora: new Date('2026-10-02T00:30:00Z') }), '2026-10-01');
});

test('hoy(req): respeta la zona de la persona y cambia de día a la medianoche local', () => {
  const ahora = new Date('2026-10-02T04:59:00Z');
  assert.equal(f.hoy({ user: { tz: 'America/Bogota' }, ahora }), '2026-10-01');
  assert.equal(f.hoy({ user: { tz: 'America/Bogota' }, ahora: new Date('2026-10-02T05:00:00Z') }), '2026-10-02');
  assert.equal(f.hoy({ user: { tz: 'Europe/Berlin' }, ahora }), '2026-10-02');
  assert.equal(f.hoy({ user: { tz: 'zona/inventada' }, ahora }), '2026-10-01');
});

test('hoy(req): solo el administrador puede usar fecha simulada', () => {
  const ahora = new Date('2026-10-02T12:00:00Z');
  assert.equal(f.hoy({ user: { role: 'admin', sim_date: '2026-12-25' }, ahora }), '2026-12-25');
  assert.equal(f.hoy({ user: { role: 'user', sim_date: '2026-12-25' }, ahora }), '2026-10-02');
  assert.equal(f.hoy({ user: { sim_date: '2026-12-25' }, ahora }), '2026-10-02');
  assert.equal(f.hoy({ user: { role: 'admin', sim_date: 'no-es-fecha' }, ahora }), '2026-10-02');
});

test('aritmética de fechas sin hora', () => {
  assert.equal(f.sumarDias('2026-02-27', 3), '2026-03-02');
  assert.equal(f.sumarDias('2026-03-08', 1), '2026-03-09');
  assert.equal(f.sumarDias('2026-01-01', -1), '2025-12-31');
  assert.equal(f.diferenciaDias('2026-03-01', '2026-03-10'), 9);
  assert.equal(f.diferenciaDias('2026-03-10', '2026-03-01'), -9);
  assert.equal(f.mesDe('2026-10-01'), '2026-10');
  assert.equal(f.diaSemana('2026-10-01'), 'jueves');
  assert.equal(f.diaSemana('2026-10-04'), 'domingo');
  assert.equal(f.diaSemana('2026-10-05'), 'lunes');
  assert.equal(f.inicioSemana('2026-10-04'), '2026-09-28');
});

test('validación de fechas y zonas', () => {
  assert.equal(f.esFechaValida('2026-02-30'), false);
  assert.equal(f.esFechaValida('2026-10-01'), true);
  assert.equal(f.esFechaValida(null), false);
  assert.equal(f.tzValida('America/Bogota'), true);
  assert.equal(f.tzValida('nada'), false);
  assert.equal(f.tzValida(''), false);
});
