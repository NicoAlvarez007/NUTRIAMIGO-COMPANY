const test = require('node:test');
const assert = require('node:assert/strict');
const { nuevoEntorno, ejecutarEscenarios } = require('../server/lib/escenariosRacha');
const { sumarDias } = require('../server/lib/fechas');

const D0 = '2026-03-01';
const dia = (n) => sumarDias(D0, n);

test('primera acción de la vida: racha 1 y último día hoy', () => {
  const { racha, userId } = nuevoEntorno();
  assert.equal(racha.estado(userId, D0).racha, 0);
  const r = racha.registrarAccion(userId, 'comida', D0);
  assert.equal(r.sumoDia, true);
  assert.equal(r.estado.racha, 1);
  assert.equal(r.estado.ultimoDia, D0);
  assert.equal(r.estado.hoyCumplido, true);
});

test('varias acciones el mismo día cuentan una sola vez', () => {
  const { racha, userId } = nuevoEntorno();
  racha.registrarAccion(userId, 'comida', D0);
  assert.equal(racha.registrarAccion(userId, 'rutina', D0).sumoDia, false);
  assert.equal(racha.registrarAccion(userId, 'peso', D0).estado.racha, 1);
});

test('tipo de acción no válido se rechaza (agua y km no cuentan)', () => {
  const { racha, userId } = nuevoEntorno();
  assert.throws(() => racha.registrarAccion(userId, 'agua', D0));
  assert.throws(() => racha.registrarAccion(userId, 'km', D0));
  assert.equal(racha.estado(userId, D0).racha, 0);
});

test('5 días sin entrar con 1 protector: se gasta uno, el segundo día se pierde y no resta más', () => {
  const { racha, userId, db } = nuevoEntorno();
  racha.registrarAccion(userId, 'comida', D0);
  racha.registrarAccion(userId, 'comida', dia(1));
  racha.darProtector(userId, dia(1));
  const e = racha.estado(userId, dia(7));
  assert.equal(e.racha, 0);
  assert.equal(e.protectores, 0);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM streak_events WHERE tipo = 'protector_usado'").get().n, 1);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM streak_events WHERE tipo = 'perdida'").get().n, 1);
  assert.equal(racha.estado(userId, dia(8)).racha, 0);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM streak_events WHERE tipo = 'perdida'").get().n, 1);
});

test('con 2 protectores y 2 días perdidos la racha se conserva y quedan 0', () => {
  const { racha, userId } = nuevoEntorno();
  racha.registrarAccion(userId, 'comida', D0);
  racha.darProtector(userId, D0);
  racha.darProtector(userId, D0);
  const e = racha.registrarAccion(userId, 'comida', dia(3)).estado;
  assert.equal(e.racha, 2);
  assert.equal(e.protectores, 0);
  assert.deepEqual(e.congelados, [dia(1), dia(2)]);
});

test('consultar varias veces no gasta protectores dos veces', () => {
  const { racha, userId } = nuevoEntorno();
  racha.registrarAccion(userId, 'comida', D0);
  racha.darProtector(userId, D0);
  racha.darProtector(userId, D0);
  racha.estado(userId, dia(2));
  racha.estado(userId, dia(2));
  assert.equal(racha.estado(userId, dia(2)).protectores, 1);
});

test('el día de hoy nunca se considera perdido', () => {
  const { racha, userId } = nuevoEntorno();
  racha.registrarAccion(userId, 'comida', D0);
  const e = racha.estado(userId, dia(1));
  assert.equal(e.racha, 1);
  assert.equal(e.hoyCumplido, false);
});

test('7 días seguidos dan 1 protector; el tope gratuito es 2 y el Premium 3', () => {
  const gratis = nuevoEntorno();
  for (let i = 0; i < 21; i += 1) gratis.racha.registrarAccion(gratis.userId, 'comida', dia(i));
  const eg = gratis.racha.estado(gratis.userId, dia(20));
  assert.equal(eg.racha, 21);
  assert.equal(eg.protectores, 2);
  assert.equal(eg.cap, 2);

  const premium = nuevoEntorno(true);
  premium.racha.estado(premium.userId, dia(0));
  for (let i = 0; i < 21; i += 1) premium.racha.registrarAccion(premium.userId, 'comida', dia(i));
  const ep = premium.racha.estado(premium.userId, dia(20));
  assert.equal(ep.cap, 3);
  assert.equal(ep.protectores, 3);
});

test('regalo mensual Premium: una sola vez por mes', () => {
  const { racha, userId } = nuevoEntorno(true);
  assert.equal(racha.estado(userId, '2026-03-10').protectores, 1);
  assert.equal(racha.estado(userId, '2026-03-20').protectores, 1);
  assert.equal(racha.estado(userId, '2026-04-02').protectores, 2);
  assert.equal(racha.estado(userId, '2026-04-02').protectores, 2);
});

test('quien deja de ser Premium con más protectores del tope baja a 2', () => {
  const { racha, userId, db } = nuevoEntorno(true);
  racha.estado(userId, '2026-03-10');
  racha.darProtector(userId, '2026-03-10');
  racha.darProtector(userId, '2026-03-10');
  assert.equal(racha.estado(userId, '2026-03-10').protectores, 3);
  db.prepare('UPDATE users SET is_premium = 0 WHERE id = ?').run(userId);
  assert.equal(racha.estado(userId, '2026-03-10').protectores, 2);
});

test('fecha simulada hacia atrás no corrompe la racha ni suma', () => {
  const { racha, userId } = nuevoEntorno();
  racha.registrarAccion(userId, 'comida', dia(5));
  racha.registrarAccion(userId, 'comida', dia(6));
  const atras = racha.registrarAccion(userId, 'comida', dia(2));
  assert.equal(atras.sumoDia, false);
  assert.equal(atras.estado.hoyCumplido, true);
  assert.equal(atras.estado.racha, 2);
  assert.equal(atras.estado.ultimoDia, dia(6));
  assert.equal(racha.estado(userId, dia(2)).racha, 2);
});

test('herramientas de administrador: poner racha, quitar protector, reiniciar día', () => {
  const { racha, userId, db } = nuevoEntorno();
  let e = racha.ponerRacha(userId, 9, D0);
  assert.equal(e.racha, 9);
  assert.equal(e.hoyCumplido, false);
  assert.equal(racha.estado(userId, D0).racha, 9);
  racha.darProtector(userId, D0);
  assert.equal(racha.quitarProtector(userId, D0).protectores, 0);
  assert.equal(racha.quitarProtector(userId, D0).protectores, 0);

  racha.registrarAccion(userId, 'comida', D0);
  db.prepare("INSERT INTO completions (user_id, item_key, fecha) VALUES (?, 'entrenamiento-domingo', ?)").run(userId, D0);
  db.prepare('INSERT INTO daily_logs (user_id, fecha, vasos_agua) VALUES (?, ?, 4)').run(userId, D0);
  e = racha.reiniciarDia(userId, D0);
  assert.equal(e.racha, 9);
  assert.equal(e.hoyCumplido, false);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM completions').get().n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM daily_logs').get().n, 0);
  assert.equal(racha.ponerRacha(userId, 0, D0).racha, 0);
});

test('estado: calendario, próximo protector y eventos recientes', () => {
  const { racha, userId } = nuevoEntorno();
  for (let i = 0; i < 3; i += 1) racha.registrarAccion(userId, 'comida', dia(i));
  const e = racha.estado(userId, dia(2));
  assert.equal(e.proximoProtectorEn, 4);
  assert.deepEqual(e.dias, [dia(0), dia(1), dia(2)]);
  assert.equal(e.mejor, 3);
  assert.ok(e.eventos.length >= 3);
});

test('prueba guiada: todos los escenarios dan el resultado esperado', () => {
  const resultados = ejecutarEscenarios();
  console.log('\n| Escenario | Esperado | Obtenido | Resultado |\n|---|---|---|---|');
  resultados.forEach((r) => console.log(`| ${r.titulo} | ${r.esperado} | ${r.obtenido} | ${r.ok ? 'OK' : 'FALLA'} |`));
  assert.equal(resultados.length, 5);
  resultados.forEach((r) => assert.equal(r.ok, true, r.titulo));
});
