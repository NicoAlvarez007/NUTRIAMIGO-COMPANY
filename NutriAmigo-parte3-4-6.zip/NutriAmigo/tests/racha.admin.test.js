const test = require('node:test');
const assert = require('node:assert/strict');
const { iniciarServidor } = require('./ayudas');
const { ejecutarEscenarios } = require('../server/lib/escenariosRacha');
const v = require('../server/lib/validadores');

const ENV = { ADMIN_USER: 'administrador', ADMIN_PASSWORD: 'clave-admin-prueba', GOOGLE_SIMULADO: 'true' };

async function entrarAdmin(t) {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = s.cliente();
  const r = await c.post('/auth/login', { identificador: 'administrador', password: 'clave-admin-prueba' });
  assert.equal(r.status, 200);
  return { s, c };
}

test('validadores del panel de racha', () => {
  assert.equal(v.validarAjusteProtector({ accion: 'dar' }).ok, true);
  assert.equal(v.validarAjusteProtector({ accion: 'regalar' }).ok, false);
  assert.equal(v.validarRachaFija({ racha: 8 }).ok, true);
  assert.equal(v.validarRachaFija({ racha: -1 }).ok, false);
  assert.equal(v.validarRachaFija({ racha: 'ocho' }).ok, false);
  assert.equal(v.validarSimulacionDias({ dias: 7 }).ok, true);
  assert.equal(v.validarSimulacionDias({ dias: 0 }).ok, false);
  assert.equal(v.validarSimulacionDias({ dias: 61 }).ok, false);
});

test('la prueba guiada de la racha da todos los escenarios correctos', () => {
  const lista = ejecutarEscenarios();
  assert.ok(lista.length >= 5);
  lista.forEach((e) => assert.equal(e.ok, true, `${e.titulo}: ${e.obtenido}`));
});

test('panel: un usuario normal no puede usar las herramientas de racha', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = s.cliente();
  await c.post('/__test/login', {});
  assert.equal((await c.get('/api/admin/racha')).status, 403);
  assert.equal((await c.post('/api/admin/racha/simular', { dias: 3 })).status, 403);
  assert.equal((await s.cliente().get('/api/admin/racha')).status, 401);
});

test('panel: simular 7 días con actividad deja racha 7 y un protector; el día siguiente suma 8', async (t) => {
  const { c } = await entrarAdmin(t);
  const sim = await c.post('/api/admin/racha/simular', { dias: 7 });
  assert.equal(sim.status, 200);
  assert.equal(sim.datos.estado.racha, 7);
  assert.equal(sim.datos.estado.protectores, 1);
  assert.ok(sim.datos.simulada);
  const octavo = await c.post('/api/admin/racha/simular', { dias: 1 });
  assert.equal(octavo.datos.estado.racha, 8);
});

test('panel: avanzar la fecha sin actividad pierde la racha; con un protector se conserva', async (t) => {
  const { c } = await entrarAdmin(t);
  await c.post('/api/admin/racha/fijar', { racha: 5 });
  await c.post('/api/admin/fecha', { sumarDias: 3 });
  assert.equal((await c.get('/api/admin/racha')).datos.racha, 0);

  await c.post('/api/admin/racha/fijar', { racha: 5 });
  await c.post('/api/admin/racha/protector', { accion: 'dar' });
  await c.post('/api/admin/fecha', { sumarDias: 2 });
  const e = (await c.get('/api/admin/racha')).datos;
  assert.equal(e.racha, 5);
  assert.equal(e.protectores, 0);
});

test('panel: protector, fijar, reiniciar racha y reiniciar el día', async (t) => {
  const { c } = await entrarAdmin(t);
  assert.equal((await c.post('/api/admin/racha/protector', { accion: 'dar' })).datos.protectores, 1);
  assert.equal((await c.post('/api/admin/racha/protector', { accion: 'quitar' })).datos.protectores, 0);
  assert.equal((await c.post('/api/admin/racha/fijar', { racha: 12 })).datos.racha, 12);
  assert.equal((await c.post('/api/admin/racha/fijar', { racha: -4 })).status, 400);
  assert.equal((await c.post('/api/admin/racha/reiniciar', {})).datos.racha, 0);
  assert.equal((await c.post('/api/admin/reiniciar-dia', {})).status, 200);
  assert.equal((await c.get('/api/admin/racha/escenarios')).datos.every((e) => e.ok), true);
});

test('calendario anual de la racha: días con actividad, protectores y rango de años', async (t) => {
  const { s, c } = await entrarAdmin(t);
  await c.post('/api/admin/fecha', { fecha: '2027-03-10' });
  await c.post('/api/admin/racha/simular', { dias: 3 });
  const hoyAnio = (await c.get('/api/streak/calendario?anio=2027')).datos;
  assert.equal(hoyAnio.anio, 2027);
  assert.equal(hoyAnio.diasConActividad, 3);
  assert.equal(hoyAnio.dias['2027-03-10'], 'accion');
  assert.equal(hoyAnio.dias['2027-03-12'], 'accion');
  assert.equal(hoyAnio.dias['2027-03-13'], undefined);
  assert.equal(hoyAnio.primerAnio, 2027);

  // años sin datos: vacío, sin error; fuera de rango o texto: 400
  const vacio = (await c.get('/api/streak/calendario?anio=2020')).datos;
  assert.equal(vacio.diasConActividad, 0);
  assert.equal((await c.get('/api/streak/calendario?anio=1900')).status, 400);
  assert.equal((await c.get('/api/streak/calendario?anio=abc')).status, 400);
  assert.equal((await s.cliente().get('/api/streak/calendario')).status, 401);
});
