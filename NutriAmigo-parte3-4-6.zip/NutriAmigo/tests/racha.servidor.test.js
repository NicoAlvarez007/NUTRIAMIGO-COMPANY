const test = require('node:test');
const assert = require('node:assert/strict');
const { iniciarServidor, iniciarSesion, BIOMETRIA_VALIDA } = require('./ayudas');
const { hoy, diaSemana, sumarDias } = require('../server/lib/fechas');

/* Reloj controlable: el servidor usa este instante en lugar de la hora real. */
function crearReloj(isoInicial) {
  const reloj = { valor: new Date(isoInicial) };
  reloj.ahora = () => reloj.valor;
  reloj.fijar = (iso) => { reloj.valor = new Date(iso); };
  return reloj;
}

async function arrancar(t, isoInicial, correo = 'ana@nutriamigo.test') {
  const reloj = crearReloj(isoInicial);
  const s = await iniciarServidor({ reloj: reloj.ahora });
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c, { email: correo });
  await c.post('/api/biometrics', BIOMETRIA_VALIDA);
  return { s, c, reloj };
}

const JUEVES = '2026-10-01T15:00:00Z';

test('usuario nuevo: racha 0 y volver a iniciar sesión no la sube', async (t) => {
  const { c } = await arrancar(t, JUEVES);
  assert.equal((await c.get('/api/streak')).datos.racha, 0);
  await iniciarSesion(c, { email: 'ana@nutriamigo.test' });
  assert.equal((await c.get('/api/streak')).datos.racha, 0);
  assert.equal((await c.get('/api/me')).datos.streak, 0);
});

test('marcar comida suma 1; otra el mismo día no; desmarcar y volver a marcar tampoco', async (t) => {
  const { c } = await arrancar(t, JUEVES);
  const a = await c.post('/api/completions', { itemKey: 'alimentacion-jueves-almuerzo' });
  assert.equal(a.status, 200);
  assert.equal(a.datos.completado, true);
  assert.equal(a.datos.racha.racha, 1);
  assert.equal((await c.post('/api/completions', { itemKey: 'alimentacion-jueves-cena-2' })).datos.racha.racha, 1);
  const quitar = await c.post('/api/completions', { itemKey: 'alimentacion-jueves-almuerzo' });
  assert.equal(quitar.datos.completado, false);
  assert.equal(quitar.datos.racha.racha, 1);
  assert.equal((await c.post('/api/completions', { itemKey: 'alimentacion-jueves-almuerzo' })).datos.racha.racha, 1);
  assert.deepEqual((await c.get('/api/completions')).datos.sort(), ['alimentacion-jueves-almuerzo', 'alimentacion-jueves-cena-2']);
});

test('registrar peso cuenta; agua y km no', async (t) => {
  const a = await arrancar(t, JUEVES, 'a@nutriamigo.test');
  await a.c.post('/api/daily-log', { vasosAgua: 4, kmRecorridos: 3 });
  assert.equal((await a.c.get('/api/streak')).datos.racha, 0);
  await a.c.post('/api/progress', { peso: 70 });
  assert.equal((await a.c.get('/api/streak')).datos.racha, 1);
});

test('marcar un día que no es hoy responde 409 dia_no_es_hoy', async (t) => {
  const { c } = await arrancar(t, JUEVES);
  const r = await c.post('/api/completions', { itemKey: 'entrenamiento-lunes' });
  assert.equal(r.status, 409);
  assert.equal(r.datos.code, 'dia_no_es_hoy');
  assert.equal((await c.get('/api/streak')).datos.racha, 0);
  assert.deepEqual((await c.get('/api/completions')).datos, []);
});

test('7 días seguidos dan 1 protector; reiniciar solo borra hoy y la semana es de solo lectura', async (t) => {
  const { c, reloj } = await arrancar(t, '2026-09-28T15:00:00Z');
  let fecha = '2026-09-28';
  for (let i = 0; i < 7; i += 1) {
    reloj.fijar(`${fecha}T15:00:00Z`);
    const r = await c.post('/api/completions', { itemKey: `entrenamiento-${diaSemana(fecha)}` });
    assert.equal(r.status, 200, fecha);
    fecha = sumarDias(fecha, 1);
  }
  reloj.fijar('2026-10-04T15:00:00Z');
  const e = (await c.get('/api/streak')).datos;
  assert.equal(e.racha, 7);
  assert.equal(e.protectores, 1);

  const semana = (await c.get('/api/completions/semana')).datos;
  assert.equal(semana.desde, '2026-09-28');
  assert.equal(Object.keys(semana.marcas).length, 7);

  const reinicio = await c.post('/api/completions/reiniciar', {});
  assert.deepEqual(reinicio.datos.completions, []);
  const despues = (await c.get('/api/completions/semana')).datos;
  assert.equal(Object.keys(despues.marcas).length, 6);
  assert.equal(despues.marcas['2026-10-04'], undefined);
});

test('a las 19:30 hora Colombia el día no cambia; X-Timezone mueve el día de otra zona', async (t) => {
  const { c, s } = await arrancar(t, '2026-10-02T00:30:00Z');
  assert.equal((await c.get('/api/me')).datos.hoy, '2026-10-01');
  assert.equal((await c.get('/api/me')).datos.diaSemanaHoy, 'jueves');

  const berlin = await c.get('/api/me', { 'X-Timezone': 'Europe/Berlin' });
  assert.equal(berlin.datos.hoy, '2026-10-02');
  assert.equal(berlin.datos.tz, 'Europe/Berlin');
  assert.equal(s.servidor.db.prepare('SELECT tz FROM users').get().tz, 'Europe/Berlin');

  const falsa = await c.get('/api/me', { 'X-Timezone': 'zona/inventada' });
  assert.equal(falsa.datos.tz, 'Europe/Berlin');
});

test('un usuario normal no puede usar fecha simulada', async (t) => {
  const { c, s } = await arrancar(t, JUEVES);
  s.servidor.db.prepare("UPDATE users SET sim_date = '2027-01-01'").run();
  const r = await c.get('/api/me', { 'X-Timezone': 'America/Bogota' });
  assert.equal(r.datos.hoy, hoy({ ahora: new Date(JUEVES) }));
  assert.notEqual(r.datos.hoy, '2027-01-01');
});
