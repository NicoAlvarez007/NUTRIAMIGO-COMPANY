const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { iniciarServidor, iniciarSesion, BIOMETRIA_VALIDA } = require('./ayudas');
const { hoy, diaSemana } = require('../server/lib/fechas');

test('exposición de archivos: solo se sirve public/', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  for (const ruta of ['/server/server.js', '/server/data/nutriamigo.db', '/server/.env', '/server/.env.example',
    '/docs/00-CONTEXTO-GENERAL.md', '/tests/ayudas.js', '/package.json', '/server/package.json',
    '/node_modules/express/package.json', '/%2e%2e/server/server.js', '/..%2fserver/server.js', '/../server/server.js']) {
    const r = await c.get(ruta);
    assert.equal(r.status, 404, ruta);
  }
  for (const ruta of ['/index.html', '/css/styles.css', '/js/app.js', '/js/api.js', '/js/tema-inicial.js']) {
    assert.equal((await c.get(ruta)).status, 200, ruta);
  }
});

test('cabeceras de seguridad', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const r = await s.cliente().get('/index.html');
  assert.ok(r.cabeceras.get('content-security-policy'));
  assert.match(r.cabeceras.get('content-security-policy'), /script-src 'self'/);
  assert.equal(/googleapis|gstatic/.test(r.cabeceras.get('content-security-policy')), false);
  assert.equal(r.cabeceras.get('x-content-type-options'), 'nosniff');
  assert.equal(r.cabeceras.get('x-powered-by'), null);
  const api = await s.cliente().get('/api/me');
  assert.equal(api.status, 401);
  assert.equal(api.cabeceras.get('cache-control'), 'no-store');
});

test('ninguna página tiene scripts en línea (CSP)', () => {
  const carpeta = path.join(__dirname, '..', 'public');
  for (const archivo of fs.readdirSync(carpeta).filter((f) => f.endsWith('.html'))) {
    const html = fs.readFileSync(path.join(carpeta, archivo), 'utf8');
    assert.equal(/<script(?![^>]*\bsrc=)[^>]*>/i.test(html), false, `${archivo} tiene un script en línea`);
    assert.equal(/\son[a-z]+\s*=/i.test(html), false, `${archivo} tiene un manejador en línea`);
    assert.match(html, /tema-inicial\.js/, archivo);
  }
});

test('validación de biometría, agua, km y reels', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c);

  for (const mala of [{ peso: 'abc' }, { estatura: -5 }, { edad: 3 }, { edad: 14 }, { sexo: 'zz' }, { peso: 251 }]) {
    const r = await c.post('/api/biometrics', { ...BIOMETRIA_VALIDA, ...mala });
    assert.equal(r.status, 400, JSON.stringify(mala));
    assert.ok(r.datos.code && r.datos.error);
  }
  assert.equal((await c.post('/api/biometrics', { ...BIOMETRIA_VALIDA, edad: 15 })).datos.code, 'consentimiento_requerido');
  assert.equal((await c.post('/api/biometrics', { ...BIOMETRIA_VALIDA, edad: 18 })).status, 200);
  assert.equal((await c.post('/api/daily-log', { vasosAgua: 'abc' })).status, 400);
  assert.equal((await c.post('/api/daily-log', { kmRecorridos: -3 })).status, 400);
  assert.equal((await c.post('/api/progress', { peso: 251 })).status, 400);
  assert.equal((await c.post('/api/reels', { texto: 'x'.repeat(501) })).status, 400);
  assert.equal((await c.post('/api/completions', { itemKey: 'cualquier-cosa' })).status, 400);
  assert.equal((await c.post('/api/completions', { itemKey: `entrenamiento-${diaSemana(hoy({ ahora: new Date() }))}` })).status, 200);
  assert.equal((await c.get('/api/friends/abc/messages')).status, 400);
  assert.equal((await c.get('/api/friends/999/messages')).status, 404);
  const r = await c.post('/api/biometrics', { ...BIOMETRIA_VALIDA, edad: 3 });
  assert.equal(r.datos.code, 'edad_minima');
  assert.equal(r.datos.field, 'edad');
});

test('menores: 16 años con definir se rechaza; con mantener se acepta', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c);
  const malo = await c.post('/api/biometrics', { ...BIOMETRIA_VALIDA, edad: 16, objetivo: 'definir' });
  assert.equal(malo.status, 400);
  assert.equal(malo.datos.code, 'objetivo_no_permitido_menor');
  const sinAdulto = await c.post('/api/biometrics', { ...BIOMETRIA_VALIDA, edad: 16, objetivo: 'mantener' });
  assert.equal(sinAdulto.datos.code, 'consentimiento_requerido');
  const consentimiento = { nombre: 'Marta Ruiz', parentesco: 'madre', contacto: '3101234567', acepta: true };
  assert.equal((await c.post('/api/biometrics', { ...BIOMETRIA_VALIDA, edad: 16, objetivo: 'mantener', consentimiento })).status, 200);
});

test('guardado parcial de biometría: peso solo conserva el resto', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c);
  await c.post('/api/biometrics', BIOMETRIA_VALIDA);
  const r = await c.post('/api/biometrics', { peso: 72 });
  assert.equal(r.status, 200);
  assert.equal(r.datos.peso, 72);
  assert.equal(r.datos.edad, 25);
  assert.equal(r.datos.nombre, 'Ana');
});

test('preferencias parciales: las dos series de datos conviven', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c);
  await c.post('/api/biometrics', BIOMETRIA_VALIDA);
  assert.equal((await c.post('/api/preferences', { proteinas: ['pollo'] })).status, 403);
  assert.equal((await c.post('/api/premium/activate', {})).status, 200);
  assert.equal((await c.post('/api/preferences', { proteinas: ['pollo', 'pescado'], restriccionesTexto: 'sin lactosa' })).status, 200);
  assert.equal((await c.post('/api/preferences', { frecuenciaSemanal: 4, distanciaKm: 5, enfoqueMuscular: 'piernas' })).status, 200);
  const prefs = (await c.get('/api/preferences')).datos;
  assert.deepEqual(prefs.proteinas.sort(), ['pescado', 'pollo']);
  assert.equal(prefs.restriccionesTexto, 'sin lactosa');
  assert.equal(prefs.frecuenciaSemanal, 4);
  assert.equal(prefs.distanciaKm, 5);
  assert.equal(prefs.enfoqueMuscular, 'piernas');
  await c.post('/api/preferences', { proteinas: ['vegano', 'pollo'] });
  assert.deepEqual((await c.get('/api/preferences')).datos.proteinas, ['vegano']);
  assert.equal((await c.get('/api/preferences')).datos.frecuenciaSemanal, 4);
});

test('las sesiones sobreviven a reiniciar el servidor', async (t) => {
  const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), 'nutriamigo-ses-'));
  t.after(() => fs.rmSync(carpeta, { recursive: true, force: true }));
  const rutaDb = path.join(carpeta, 'sesiones.db');

  const a = await iniciarServidor({ rutaDb });
  const c = a.cliente();
  await iniciarSesion(c);
  assert.equal((await c.get('/api/me')).status, 200);
  const cookie = c.cookie;
  assert.ok(cookie.includes('nutriamigo.sid'));
  await a.detener();

  const b = await iniciarServidor({ rutaDb });
  t.after(() => b.detener());
  const c2 = b.cliente();
  c2.cookie = cookie;
  assert.equal((await c2.get('/api/me')).status, 200);
});

test('CSRF simple: text/plain sin encabezado → 403', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c);
  const r = await c.post('/api/progress', '{"peso":70}', { 'Content-Type': 'text/plain' });
  assert.equal(r.status, 403);
  const ok = await c.post('/api/progress', '{"peso":70}', { 'Content-Type': 'text/plain', 'X-Requested-With': 'nutriamigo' });
  assert.notEqual(ok.status, 403);
  assert.equal((await c.post('/api/progress', { peso: 70 })).status, 200);
});

test('límite de intentos de autenticación → 429', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  let ultimo;
  for (let i = 0; i < 12; i++) ultimo = await c.get('/auth/google');
  assert.equal(ultimo.status, 429);
  assert.equal(ultimo.datos.code, 'demasiadas_peticiones');
});

test('premium: activar/desactivar responde 404 si el interruptor está apagado', async (t) => {
  const s = await iniciarServidor({ env: { ALLOW_FREE_PREMIUM_SWITCH: 'false' } });
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c);
  assert.equal((await c.post('/api/premium/activate', {})).status, 404);
  assert.equal((await c.post('/api/premium/deactivate', {})).status, 404);
});

test('ruta de prueba: no existe fuera de NODE_ENV=test', async () => {
  const { crearServidor } = require('../server/server');
  const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), 'nutriamigo-dev-'));
  const servidor = crearServidor({
    env: { NODE_ENV: 'development', PORT: '0', SESSION_SECRET: 'secreto-de-prueba', NUTRIAMIGO_DB: path.join(carpeta, 'dev.db') },
    escribirEnv: false
  });
  const { puerto } = await servidor.iniciar();
  try {
    const res = await fetch(`http://127.0.0.1:${puerto}/__test/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}'
    });
    assert.equal(res.status, 404);
  } finally {
    await servidor.detener();
    fs.rmSync(carpeta, { recursive: true, force: true });
  }
});

test('errores internos no filtran la traza', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  const r = await c.post('/api/progress', '{json roto', { 'Content-Type': 'application/json' });
  assert.equal(r.status, 400);
  assert.equal(r.datos.code, 'json_invalido');
  assert.equal(JSON.stringify(r.datos).includes('at '), false);
});

test('borrar la cuenta elimina los datos del usuario', async (t) => {
  const s = await iniciarServidor();
  t.after(() => s.detener());
  const c = s.cliente();
  await iniciarSesion(c);
  await c.post('/api/biometrics', BIOMETRIA_VALIDA);
  await c.post('/api/progress', { peso: 70 });
  assert.equal((await c.delete('/api/account')).status, 200);
  assert.equal((await c.get('/api/me')).status, 401);
  assert.equal(s.servidor.db.prepare('SELECT COUNT(*) AS n FROM progress').get().n, 0);
});

test('desarrollo sin Google: \"Continuar con Google\" lleva a la pantalla de Google simulado', async (t) => {
  const s = await iniciarServidor({ env: { NODE_ENV: 'development' } });
  t.after(() => s.detener());
  const c = s.cliente();
  const r = await c.get('/auth/google');
  assert.equal(r.status, 302);
  assert.equal(r.cabeceras.get('location'), '/google-simulado.html');
  assert.equal((await c.get('/api/me')).status, 401);
});
