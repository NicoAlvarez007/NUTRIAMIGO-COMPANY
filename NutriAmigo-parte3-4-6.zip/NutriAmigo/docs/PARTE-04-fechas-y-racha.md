# PARTE 4 de 12 — Fechas locales, racha estilo Duolingo y "Ya lo hice" del servidor

> Pega primero `00-CONTEXTO-GENERAL.md` (reglas 8.1 y 8.7) y después este documento. Requiere Partes 1 a 3.
> Corrige: **1.8** (el día cambia a las 7 p. m.), **1.9** (racha), **1.10** (marcar los 7 días el mismo día, lado servidor) y **A.3** (racha con protectores).

## Objetivo

1. Que "hoy" sea siempre el **día local de la persona** (Colombia por defecto).
2. Que la racha funcione como en Duolingo: empieza en 0, sube con acciones reales, se protege con protectores y se pierde si no hay protección.
3. Que solo se pueda marcar "Ya lo hice" del día de hoy, y que existan "Reiniciar" y reinicio automático diario.

## 1. Fechas (1.8)

`server/lib/fechas.js` (con pruebas unitarias):
- `hoy(req)` → `'YYYY-MM-DD'` en la zona horaria del usuario: `req.user.tz` (por defecto `America/Bogota`). Implementación con `Intl.DateTimeFormat('en-CA', { timeZone: tz })`. Si el usuario es **admin** y tiene `sim_date`, devuelve esa fecha (Parte 3). Nadie más puede usar fecha simulada.
- `diaSemana(fecha)` (`lun`…`dom`, con la convención que ya usa el código), `sumarDias(fecha, n)`, `diferenciaDias(a, b)`, `mesDe(fecha)` (`'YYYY-MM'`). Todo con fechas **sin hora** (aritmética sobre `Date.UTC`) para evitar errores de cambio de hora.
- `tz` se guarda en `users.tz`. El navegador la envía en el encabezado `X-Timezone` (agrégalo en `js/api.js`, con `Intl.DateTimeFormat().resolvedOptions().timeZone`). El servidor la **valida** intentando `Intl.DateTimeFormat(undefined, { timeZone })` (si falla, se ignora) y la guarda solo si es distinta. Si nunca llegó, `America/Bogota`.
- **Elimina todos los usos de `new Date().toISOString().slice(0, 10)`** del servidor (progreso, registro diario, completions, premium) y sustitúyelos por `hoy(req)`. En el navegador (`reminders.js`, `dashboard.js`, `alimentacion.js`, `entrenamiento.js`, y donde aparezca) usa una utilidad `hoyLocal()` (fecha local del navegador, no UTC) o, mejor, la fecha que devuelve `/api/me` (`hoy`).
- `GET /api/me` devuelve `hoy` y `diaSemanaHoy` para que la interfaz no calcule fechas por su cuenta.

## 2. "Ya lo hice" (1.10, lado servidor)

- Tabla `completions`: asegura columnas `user_id, item_key, fecha (local), creado_en` con índice único `(user_id, item_key, fecha)` (migración `006_completions.js`; si hay duplicados, conservar uno).
- `POST /api/completions` `{itemKey}`: la fecha es **siempre `hoy(req)`**, nunca la envía el cliente. `itemKey` = `alimentacion-<dia>-<comida>-<opcion>` o `entrenamiento-<dia>`; **el `<dia>` debe ser el día de la semana de hoy**; si no → 409 `code: 'dia_no_es_hoy'`. Alterna: si ya estaba marcado, lo desmarca (204/200 con el estado nuevo).
- `GET /api/completions?fecha=hoy` devuelve las marcas de hoy; `GET /api/completions/semana` devuelve las de la semana en curso (solo lectura para los otros días).
- **`POST /api/completions/reiniciar`**: borra las marcas de hoy del usuario y devuelve el nuevo estado. Es lo que usa el botón **"Reiniciar"** de Alimentación y Entrenamiento (la interfaz llega en las Partes 5 y 6; aquí solo la ruta).
- **Reinicio automático:** como cada marca lleva su fecha local, al cambiar el día la lista de hoy queda vacía sin ejecutar nada.
- Marcar o desmarcar **no** cuenta el mismo día dos veces para la racha (ver 3.4).

## 3. Racha (1.9, A.3, regla 8.1)

### 3.1 Modelo (migración `007_racha.js`)
`streaks(user_id PRIMARY KEY, racha INTEGER DEFAULT 0, mejor INTEGER DEFAULT 0, ultimo_dia TEXT, protectores INTEGER DEFAULT 0, regalo_mes TEXT, congelados TEXT DEFAULT '[]')` y `streak_events(id, user_id, fecha, tipo, detalle)` con `tipo` ∈ `accion | protector_usado | protector_ganado | protector_regalo | perdida | ajuste_admin`.
- `congelados`: lista JSON de fechas que un protector cubrió (para mostrarlas en el calendario).

### 3.2 Servicio `server/lib/racha.js`
Funciones puras (recibiendo la fecha de hoy) para poder probarlas sin reloj:
- `capProtectores(esPremium)` → 2 (gratis) o 3 (Premium).
- `registrarAccion(userId, tipo, hoy)` con `tipo` ∈ `comida | rutina | peso`:
  1. Primero **resuelve los días perdidos** (3.3).
  2. Si `ultimo_dia === hoy` no vuelve a sumar (ya contó hoy). Si no: `racha += 1`, `ultimo_dia = hoy`, `mejor = max(mejor, racha)`.
  3. Si `racha` pasó a ser **múltiplo de 7** → `protectores = min(cap, protectores + 1)` y evento `protector_ganado`.
- `resolverDiasPerdidos(userId, hoy)`: para cada día **estrictamente anterior a hoy** entre `ultimo_dia + 1` y `hoy − 1`:
  - si hay protectores → `protectores -= 1`, se agrega la fecha a `congelados`, evento `protector_usado` (la racha se conserva; ese día **no suma**);
  - si no hay → `racha = 0`, evento `perdida`, y se detiene el recorrido (después de perder, los días anteriores ya no importan).
  - El día de hoy **nunca** se considera perdido (todavía puede actuar).
- `regaloMensualPremium(userId, hoy, esPremium)`: si es Premium activo y `regalo_mes !== mesDe(hoy)` → `protectores = min(cap, protectores + 1)`, `regalo_mes = mesDe(hoy)`, evento `protector_regalo`. Se evalúa al llamar `GET /api/streak` y al registrar acciones.
- Cuando un usuario **deja de ser Premium** con más protectores que el tope gratuito, se recorta a 2 al evaluar.
- `estado(userId, hoy)` devuelve: `{ racha, mejor, protectores, cap, hoyCumplido: boolean, ultimoDia, proximoProtectorEn: días que faltan para el siguiente múltiplo de 7, congelados recientes }`.

### 3.3 Dónde se llama
- `POST /api/completions` (al **marcar** una comida o rutina) → `registrarAccion('comida' | 'rutina')`.
- `POST /api/progress` (al registrar peso) → `registrarAccion('peso')`.
- **No** se llama al iniciar sesión, ni con agua ni km. **Elimina `touchStreak`** del callback de login y las rutas que lo usaban.
- `GET /api/streak` → `estado` (resuelve días perdidos y regalo mensual antes de responder).

### 3.4 Casos borde que deben quedar definidos y probados
- Desmarcar una comida **no** resta racha, pero si ya contó hoy no hay doble conteo al volver a marcarla.
- Primera acción de la vida: `racha = 1`, `ultimo_dia = hoy`.
- Varios días sin entrar (por ejemplo 5) con 1 protector: se gasta el protector en el primer día perdido y en el segundo se pierde → `racha = 0`; no se sigue restando protectores más allá de la pérdida.
- Con 2 protectores y 2 días perdidos: la racha se conserva, protectores en 0.
- Cambio de mes: el regalo Premium se entrega una sola vez por mes.
- Cambio de zona horaria del usuario: las fechas ya guardadas no se reescriben.
- Fecha simulada del admin **hacia atrás** no debe alterar `ultimo_dia` hacia el pasado si eso corrompe la lógica: si `hoy < ultimo_dia`, `resolverDiasPerdidos` no hace nada y `registrarAccion` no suma (devuelve `estado` con `hoyCumplido: true`).

## 4. Interfaz de la racha

Componente `js/racha.js` (barra superior en escritorio; en móvil aparece en la barra superior compacta de la Parte 2):
- Llama 🔥 con el número y protectores 🧊 con su cantidad (`aria-label` descriptivo).
- Al pulsarla abre una hoja/modal "Tu racha": calendario de las últimas 4 semanas (días con acción, días congelados con 🧊, hoy resaltado), mejor racha, "te faltan N días para ganar un protector", explicación corta de cómo funciona (marcar comida, marcar rutina o registrar peso; los protectores cubren un día sin actividad).
- Aviso en pantalla (toast) cuando: se suma un día ("¡Racha de 5 días!"), se gana un protector, se usa un protector, o se pierde la racha (mensaje amable y motivador).
- Mensaje pendiente en el dashboard: "Hoy te falta una acción para mantener tu racha" mientras `hoyCumplido` sea falso y sea de tarde (después de las 18:00 local).
- Estados vacíos: racha 0 muestra "Empieza hoy: marca una comida, una rutina o registra tu peso".
- Todo en es/en/de.

## 5. Panel de administrador (activar lo que dejó la Parte 3)

- **Fecha simulada** ya conectada: al cambiarla, la racha se recalcula al consultar (`GET /api/streak`).
- Sección **Racha**: ver estado (`racha`, `mejor`, `protectores`, `ultimo_dia`, eventos recientes), botones "dar protector", "quitar protector", "poner racha en N", "reiniciar racha".
- **Reiniciar el día** del panel: borra las marcas de la fecha actual del admin y su registro diario (agua y km); si esa fecha había contado para la racha, deshace ese día (racha − 1 y `ultimo_dia` al día anterior con acción) solo desde el panel.
- Una sección **"Prueba guiada de la racha"** con botones que ejecutan escenarios y muestran el resultado esperado vs. obtenido: (a) 3 días seguidos; (b) saltar 1 día sin protector; (c) saltar 1 día con protector; (d) llegar a 7 días y ganar protector; (e) cambio de mes con Premium. Sirve para que el dueño compruebe todo sin esperar días reales.

## 6. Pruebas automáticas

Pruebas unitarias sobre `racha.js` y `fechas.js` con fechas fijas (sin depender del reloj real), cubriendo **todos los casos borde de 3.4**, y pruebas de integración:
1. Usuario nuevo: `GET /api/streak` → racha 0; iniciar sesión **no** la sube.
2. Marcar comida → racha 1; marcar otra el mismo día → sigue 1; desmarcar y volver a marcar → sigue 1.
3. Registrar peso cuenta; registrar agua/km **no** cuenta.
4. Marcar una comida de otro día de la semana → 409 `dia_no_es_hoy`.
5. Simulación de 7 días seguidos con fecha simulada del admin → protectores = 1; tope 2 (y 3 en Premium); regalo mensual Premium una sola vez.
6. `hoy(req)` a las 19:30 hora Colombia devuelve el mismo día (y no el siguiente como antes).
7. `POST /api/completions/reiniciar` deja las marcas de hoy vacías y no toca otros días.
8. Otro usuario (no admin) **no** puede usar fecha simulada aunque envíe el encabezado.

## 7. Criterios de aceptación

- [ ] Ningún cálculo de "hoy" usa UTC; a las 7 p. m. hora Colombia el día no cambia.
- [ ] La racha empieza en 0; solo comida, rutina y peso la mueven; protectores según la regla 8.1.
- [ ] Solo se puede marcar el día de hoy (servidor); existe la ruta de reinicio.
- [ ] Componente de racha con calendario y avisos, en 3 idiomas.
- [ ] Panel de administrador con fecha simulada, herramientas de racha y prueba guiada funcionando.
- [ ] Todas las pruebas pasan; el resumen incluye la tabla escenario → resultado de la "prueba guiada".
