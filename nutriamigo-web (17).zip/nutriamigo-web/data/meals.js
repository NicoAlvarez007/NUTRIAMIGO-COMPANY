const MEALS_DATA = {
  "definir": {
    "lunes": {
      "desayuno": [
        "Claras de huevo revueltas con espinaca y una tostada integral",
        "Huevos pericos (2) con tomate, sin acompañante graso"
      ],
      "almuerzo": [
        "Pechuga de pollo a la plancha con ensalada abundante y media taza de arroz",
        "Carne magra a la plancha con ensalada verde grande"
      ],
      "media_tarde": [
        "Un puñado pequeño de almendras",
        "Una fruta pequeña, sola"
      ],
      "cena": [
        "Sopa de vegetales con pollo desmechado, sin crema",
        "Tortilla de claras con vegetales salteados"
      ]
    },
    "martes": {
      "desayuno": [
        "Yogur griego natural con fresas y una cucharada de granola",
        "Batido de proteína con agua y espinaca"
      ],
      "almuerzo": [
        "Pescado al horno con vegetales al vapor, sin frituras",
        "Garbanzos al vapor con vegetales salteados, porción moderada"
      ],
      "media_tarde": [
        "Yogur griego natural sin azúcar",
        "Queso fresco bajo en grasa (porción pequeña)"
      ],
      "cena": [
        "Tortilla de claras con vegetales salteados",
        "Pescado a la plancha con ensalada verde"
      ]
    },
    "miercoles": {
      "desayuno": [
        "Avena con canela y un puñado pequeño de frutos rojos",
        "Requesón con tomate y un chorrito de limón"
      ],
      "almuerzo": [
        "Carne magra a la plancha con ensalada verde grande",
        "Lentejas con vegetales y una porción pequeña de arroz integral"
      ],
      "media_tarde": [
        "Batido de proteína con agua",
        "Té verde con un puñado de nueces"
      ],
      "cena": [
        "Pescado a la plancha con ensalada verde",
        "Vegetales al vapor con proteína magra"
      ]
    },
    "jueves": {
      "desayuno": [
        "Huevos pericos (2) con tomate, sin acompañante graso",
        "Tostada integral con aguacate en porción pequeña y huevo"
      ],
      "almuerzo": [
        "Garbanzos al vapor con vegetales salteados, porción moderada",
        "Pollo al curry ligero con brócoli"
      ],
      "media_tarde": [
        "Pepino y zanahoria en tiras con limón",
        "Un puñado pequeño de almendras"
      ],
      "cena": [
        "Vegetales al vapor con proteína magra",
        "Crema de calabaza ligera (sin crema de leche)"
      ]
    },
    "viernes": {
      "desayuno": [
        "Batido de proteína con agua y espinaca",
        "Claras de huevo revueltas con espinaca y una tostada integral"
      ],
      "almuerzo": [
        "Lentejas con vegetales y una porción pequeña de arroz integral",
        "Filete de pescado con ensalada mixta, sin salsas cremosas"
      ],
      "media_tarde": [
        "Una fruta pequeña, sola",
        "Yogur griego natural sin azúcar"
      ],
      "cena": [
        "Crema de calabaza ligera (sin crema de leche)",
        "Ensalada completa con atún al agua"
      ]
    },
    "sabado": {
      "desayuno": [
        "Requesón con tomate y un chorrito de limón",
        "Yogur griego natural con fresas y una cucharada de granola"
      ],
      "almuerzo": [
        "Pollo al curry ligero con brócoli",
        "Pechuga de pollo a la plancha con ensalada abundante y media taza de arroz"
      ],
      "media_tarde": [
        "Queso fresco bajo en grasa (porción pequeña)",
        "Batido de proteína con agua"
      ],
      "cena": [
        "Ensalada completa con atún al agua",
        "Wrap integral pequeño de pollo y vegetales"
      ]
    },
    "domingo": {
      "desayuno": [
        "Tostada integral con aguacate en porción pequeña y huevo",
        "Avena con canela y un puñado pequeño de frutos rojos"
      ],
      "almuerzo": [
        "Filete de pescado con ensalada mixta, sin salsas cremosas",
        "Pescado al horno con vegetales al vapor, sin frituras"
      ],
      "media_tarde": [
        "Té verde con un puñado de nueces",
        "Pepino y zanahoria en tiras con limón"
      ],
      "cena": [
        "Wrap integral pequeño de pollo y vegetales",
        "Sopa de vegetales con pollo desmechado, sin crema"
      ]
    }
  },
  "mantener": {
    "lunes": {
      "desayuno": [
        "Huevos revueltos con arepa y fruta picada",
        "Huevos pericos con aguacate y tostadas integrales"
      ],
      "almuerzo": [
        "Pechuga de pollo a la plancha con arroz y ensalada mixta",
        "Carne de res magra con arroz integral y ensalada verde"
      ],
      "media_tarde": [
        "Fruta picada con un puñado de nueces",
        "Barra de granola casera y una fruta"
      ],
      "cena": [
        "Sopa de verduras con proteína magra",
        "Tortilla de huevo con vegetales salteados"
      ]
    },
    "martes": {
      "desayuno": [
        "Avena con banano, canela y una cucharada de mantequilla de maní",
        "Batido de proteína con leche, avena y fruta"
      ],
      "almuerzo": [
        "Pescado al horno con papa criolla y vegetales al vapor",
        "Garbanzos guisados con arroz y ensalada de tomate"
      ],
      "media_tarde": [
        "Yogur griego con miel",
        "Queso fresco con galletas integrales"
      ],
      "cena": [
        "Tortilla de huevo con vegetales salteados",
        "Pescado a la plancha con ensalada verde"
      ]
    },
    "miercoles": {
      "desayuno": [
        "Yogur natural con granola casera y fresas",
        "Pan integral con queso fresco y tomate"
      ],
      "almuerzo": [
        "Carne de res magra con arroz integral y ensalada verde",
        "Lentejas con arroz, plátano y ensalada"
      ],
      "media_tarde": [
        "Batido de proteína con leche vegetal",
        "Smoothie de fruta con avena"
      ],
      "cena": [
        "Pescado a la plancha con ensalada verde",
        "Pollo desmechado con vegetales al vapor"
      ]
    },
    "jueves": {
      "desayuno": [
        "Huevos pericos con aguacate y tostadas integrales",
        "Panqueques de avena con miel y frutos rojos"
      ],
      "almuerzo": [
        "Garbanzos guisados con arroz y ensalada de tomate",
        "Pollo al curry con arroz y brócoli"
      ],
      "media_tarde": [
        "Tostadas integrales con aguacate",
        "Fruta picada con un puñado de nueces"
      ],
      "cena": [
        "Pollo desmechado con vegetales al vapor",
        "Crema de calabaza con tostadas integrales"
      ]
    },
    "viernes": {
      "desayuno": [
        "Batido de proteína con leche, avena y fruta",
        "Huevos revueltos con arepa y fruta picada"
      ],
      "almuerzo": [
        "Lentejas con arroz, plátano y ensalada",
        "Filete de pescado con puré de papa y vegetales salteados"
      ],
      "media_tarde": [
        "Barra de granola casera y una fruta",
        "Yogur griego con miel"
      ],
      "cena": [
        "Crema de calabaza con tostadas integrales",
        "Ensalada completa con atún y vegetales"
      ]
    },
    "sabado": {
      "desayuno": [
        "Pan integral con queso fresco y tomate",
        "Avena con banano, canela y una cucharada de mantequilla de maní"
      ],
      "almuerzo": [
        "Pollo al curry con arroz y brócoli",
        "Pechuga de pollo a la plancha con arroz y ensalada mixta"
      ],
      "media_tarde": [
        "Queso fresco con galletas integrales",
        "Batido de proteína con leche vegetal"
      ],
      "cena": [
        "Ensalada completa con atún y vegetales",
        "Wrap integral de pollo y vegetales"
      ]
    },
    "domingo": {
      "desayuno": [
        "Panqueques de avena con miel y frutos rojos",
        "Yogur natural con granola casera y fresas"
      ],
      "almuerzo": [
        "Filete de pescado con puré de papa y vegetales salteados",
        "Pescado al horno con papa criolla y vegetales al vapor"
      ],
      "media_tarde": [
        "Smoothie de fruta con avena",
        "Tostadas integrales con aguacate"
      ],
      "cena": [
        "Wrap integral de pollo y vegetales",
        "Sopa de verduras con proteína magra"
      ]
    }
  },
  "volumen": {
    "lunes": {
      "desayuno": [
        "Huevos completos (3) con arepa grande, aguacate y jugo de fruta",
        "Huevos pericos con queso, tocineta y dos tostadas integrales"
      ],
      "almuerzo": [
        "Pechuga de pollo con arroz grande, aguacate y ensalada",
        "Pescado al horno con arroz, plátano maduro y vegetales"
      ],
      "media_tarde": [
        "Batido de proteína con leche entera, avena y fruta",
        "Batido de banano, leche y avena"
      ],
      "cena": [
        "Pasta integral con proteína magra y salsa de tomate natural",
        "Arroz con pollo y vegetales, porción generosa"
      ]
    },
    "martes": {
      "desayuno": [
        "Avena grande con banano, mantequilla de maní y miel",
        "Panqueques de avena con miel, banano y mantequilla de maní"
      ],
      "almuerzo": [
        "Carne de res con arroz, papa y ensalada — porción generosa",
        "Pollo al curry con arroz grande y pan de acompañamiento"
      ],
      "media_tarde": [
        "Sándwich de mantequilla de maní y banano",
        "Queso con galletas integrales y fruta"
      ],
      "cena": [
        "Arroz con pollo y vegetales, porción generosa",
        "Carne magra con papa y ensalada abundante"
      ]
    },
    "miercoles": {
      "desayuno": [
        "Batido de proteína con leche entera, avena y banano",
        "Sándwich de huevo, queso y aguacate en pan integral grande"
      ],
      "almuerzo": [
        "Pescado al horno con arroz, plátano maduro y vegetales",
        "Lentejas con arroz, plátano y aguacate — porción grande"
      ],
      "media_tarde": [
        "Yogur griego con granola y miel",
        "Barra energética casera con avena y miel"
      ],
      "cena": [
        "Carne magra con papa y ensalada abundante",
        "Pescado con arroz y aguacate"
      ]
    },
    "jueves": {
      "desayuno": [
        "Huevos pericos con queso, tocineta y dos tostadas integrales",
        "Yogur griego con granola, miel y frutos secos abundantes"
      ],
      "almuerzo": [
        "Pollo al curry con arroz grande y pan de acompañamiento",
        "Carne asada con papa, arroz y ensalada abundante"
      ],
      "media_tarde": [
        "Frutos secos mixtos (porción generosa) con fruta",
        "Batido de proteína con leche entera, avena y fruta"
      ],
      "cena": [
        "Pescado con arroz y aguacate",
        "Tortilla de huevo con queso, papa y vegetales"
      ]
    },
    "viernes": {
      "desayuno": [
        "Panqueques de avena con miel, banano y mantequilla de maní",
        "Huevos completos (3) con arepa grande, aguacate y jugo de fruta"
      ],
      "almuerzo": [
        "Lentejas con arroz, plátano y aguacate — porción grande",
        "Filete de pescado con puré de papa grande y vegetales salteados en aceite de oliva"
      ],
      "media_tarde": [
        "Batido de banano, leche y avena",
        "Sándwich de mantequilla de maní y banano"
      ],
      "cena": [
        "Tortilla de huevo con queso, papa y vegetales",
        "Wrap grande de pollo, arroz y vegetales"
      ]
    },
    "sabado": {
      "desayuno": [
        "Sándwich de huevo, queso y aguacate en pan integral grande",
        "Avena grande con banano, mantequilla de maní y miel"
      ],
      "almuerzo": [
        "Carne asada con papa, arroz y ensalada abundante",
        "Pechuga de pollo con arroz grande, aguacate y ensalada"
      ],
      "media_tarde": [
        "Queso con galletas integrales y fruta",
        "Yogur griego con granola y miel"
      ],
      "cena": [
        "Wrap grande de pollo, arroz y vegetales",
        "Crema de calabaza con pan integral y queso"
      ]
    },
    "domingo": {
      "desayuno": [
        "Yogur griego con granola, miel y frutos secos abundantes",
        "Batido de proteína con leche entera, avena y banano"
      ],
      "almuerzo": [
        "Filete de pescado con puré de papa grande y vegetales salteados en aceite de oliva",
        "Carne de res con arroz, papa y ensalada — porción generosa"
      ],
      "media_tarde": [
        "Barra energética casera con avena y miel",
        "Frutos secos mixtos (porción generosa) con fruta"
      ],
      "cena": [
        "Crema de calabaza con pan integral y queso",
        "Pasta integral con proteína magra y salsa de tomate natural"
      ]
    }
  }
};
