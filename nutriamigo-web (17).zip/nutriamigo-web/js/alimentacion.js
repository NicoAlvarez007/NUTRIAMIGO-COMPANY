let mealsData = null;
let diaActivo = 'lunes';
let tipoProteina = '';
let restriccionesTexto = '';
let biometria = {};
let completionsHoy = [];

function objetivoDePlan() {
  return biometria.objetivo || 'mantener';
}

function renderResumen() {
  const el = document.getElementById('planSummary');
  if (!biometria.peso) {
    el.innerHTML = `Aún no has completado tus datos. <a href="./onboarding.html" style="color:var(--green-600);font-weight:600;">Complétalos aquí</a> para un plan calculado para ti.`;
    return;
  }
  el.innerHTML = `Plan calculado para: <b>${biometria.sexo === 'hombre' ? 'hombre' : 'mujer'}</b>, <b>${biometria.peso} kg</b>, <b>${biometria.estatura} cm</b>, actividad <b>${biometria.actividad}</b>, objetivo <b>${OBJETIVO_LABEL[objetivoDePlan()]}</b>.`;
}

function renderTabs() {
  const wrap = document.getElementById('weekTabs');
  wrap.innerHTML = DIAS.map(d =>
    `<button class="week-tab ${d === diaActivo ? 'active' : ''}" data-dia="${d}">${DIA_LABEL[d]}</button>`
  ).join('');
  wrap.querySelectorAll('.week-tab').forEach(btn => {
    btn.addEventListener('click', () => { diaActivo = btn.dataset.dia; renderTabs(); renderDay(); });
  });
}

function renderDay() {
  const wrap = document.getElementById('daySlots');
  const dia = mealsData[objetivoDePlan()][diaActivo];
  const nota = restriccionesTexto
    ? `<div class="slot-card" style="grid-column:1/-1;background:var(--green-50);">
         <h4>Ten en cuenta</h4>
         <div class="slot-option">${restriccionesTexto}</div>
       </div>`
    : '';

  wrap.innerHTML = nota + Object.keys(SLOT_LABEL).map(slot => {
    const itemKey = `alimentacion-${diaActivo}-${slot}`;
    const hecho = completionsHoy.includes(itemKey);
    return `
    <div class="slot-card">
      <div class="slot-card-header">
        <h4>${SLOT_LABEL[slot]}</h4>
        <button type="button" class="done-toggle ${hecho ? 'done' : ''}" data-item-key="${itemKey}">${hecho ? '✓ Hecho hoy' : 'Ya lo hice'}</button>
      </div>
      ${dia[slot].map((opcion, i) => `
        <div class="slot-option"><b>Opción ${i + 1}</b>${aplicarProteina(opcion, tipoProteina)}</div>
      `).join('')}
    </div>
  `;
  }).join('');

  wrap.querySelectorAll('.done-toggle').forEach(btn => {
    btn.addEventListener('click', () => marcarCompletado(btn.dataset.itemKey));
  });
}

async function marcarCompletado(itemKey) {
  try {
    const res = await fetch('./api/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemKey })
    });
    const data = await res.json();
    if (data.completado) completionsHoy.push(itemKey);
    else completionsHoy = completionsHoy.filter(k => k !== itemKey);
  } catch (err) {
    console.error('No se pudo registrar como completado', err);
  }
  renderDay();
}

async function cargarCompletions() {
  try {
    const res = await fetch('./api/completions');
    completionsHoy = await res.json();
  } catch (err) {
    console.error('No se pudieron cargar tus tareas completadas', err);
  }
}

function descargarPDF() {
  document.getElementById('printableBody').innerHTML = construirHtmlComidas(objetivoDePlan(), tipoProteina, restriccionesTexto);
  window.print();
}

async function cargarBiometria() {
  try {
    const res = await fetch('./api/biometrics');
    biometria = (await res.json()) || {};
  } catch (err) {
    console.error('No se pudieron cargar tus datos base', err);
    biometria = biometria || {};
  }
}

async function cargarPreferencias() {
  try {
    const res = await fetch('./api/preferences');
    if (!res.ok) return;
    const prefs = await res.json();
    if (prefs) {
      tipoProteina = prefs.tipoProteina || '';
      restriccionesTexto = prefs.restriccionesTexto || '';
      document.getElementById('tipoProteina').value = tipoProteina;
      document.getElementById('restriccionesTexto').value = restriccionesTexto;
    }
  } catch (err) {
    console.error('No se pudieron cargar tus preferencias', err);
  }
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  mealsData = MEALS_DATA;

  renderTabs();
  renderDay();

  document.getElementById('downloadMealsBtn').addEventListener('click', descargarPDF);

  const modal = document.getElementById('personalizeModal');
  document.getElementById('personalizeBtn').addEventListener('click', () => {
    if (!user.isPremium) { window.location.href = './premium.html'; return; }
    modal.hidden = false;
  });
  document.getElementById('closeModalBtn').addEventListener('click', () => { modal.hidden = true; });

  document.getElementById('personalizeForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    tipoProteina = document.getElementById('tipoProteina').value;
    restriccionesTexto = document.getElementById('restriccionesTexto').value.trim();

    try {
      await fetch('./api/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tipoProteina, restriccionesTexto })
      });
    } catch (err) {
      console.error('No se pudieron guardar las preferencias', err);
    }

    modal.hidden = true;
    renderDay();
  });

  (async () => {
    try {
      await cargarBiometria();
      await cargarPreferencias();
      await cargarCompletions();
    } catch (err) {
      console.error('No se pudieron cargar tus datos guardados', err);
    }
    renderResumen();
    renderDay();
  })();
});
