function normalizar(texto) {
  return texto
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[¿?¡!.,]/g, '')
    .trim();
}

function puntuarCoincidencia(mensaje, faq) {
  const msg = normalizar(mensaje);
  const msgWords = new Set(msg.split(/\s+/).filter(w => w.length > 2));
  let score = 0;

  faq.keywords.forEach((kw) => {
    const k = normalizar(kw);

    if (msg.includes(k)) {
      score += k.split(' ').length * 3;
      return;
    }

    const kWords = k.split(/\s+/).filter(w => w.length > 2);
    const coincidencias = kWords.filter(w => msgWords.has(w)).length;
    if (coincidencias > 0) score += coincidencias;
  });

  return score;
}

function buscarRespuesta(mensaje, faqData) {
  let mejor = null;
  let mejorScore = 0;

  faqData.forEach((faq) => {
    const score = puntuarCoincidencia(mensaje, faq);
    if (score > mejorScore) {
      mejorScore = score;
      mejor = faq;
    }
  });

  return mejorScore > 0 ? mejor : null;
}

document.addEventListener('DOMContentLoaded', async () => {
  const fab = document.getElementById('chatFab');
  const panel = document.getElementById('chatPanel');
  const closeBtn = document.getElementById('chatClose');
  const messagesEl = document.getElementById('chatMessages');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');

  if (!fab || !panel) return;

  let faqData = FAQ_DATA || [];

  let open = false;
  function togglePanel(forceOpen) {
    open = typeof forceOpen === 'boolean' ? forceOpen : !open;
    panel.hidden = !open;
    if (open) input.focus();
  }

  fab.addEventListener('click', () => togglePanel(true));
  closeBtn.addEventListener('click', () => togglePanel(false));

  function appendMessage(text, role) {
    const div = document.createElement('div');
    div.className = 'chat-msg ' + (role === 'user' ? 'chat-msg-user' : 'chat-msg-bot');
    div.textContent = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  const SIN_COINCIDENCIA = 'No tengo una respuesta preparada para eso todavía. Prueba con palabras como "premium", "objetivo", "comunidad" o "racha", o escribe a soporte para hablar con una persona.';

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;

    appendMessage(text, 'user');
    input.value = '';

    const match = buscarRespuesta(text, faqData);
    setTimeout(() => {
      appendMessage(match ? match.respuesta : SIN_COINCIDENCIA, 'bot');
    }, 300);
  });
});
