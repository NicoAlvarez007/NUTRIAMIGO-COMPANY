const DIAS = ['lunes','martes','miercoles','jueves','viernes','sabado','domingo'];
const DIA_LABEL = { lunes:'Lun', martes:'Mar', miercoles:'Mié', jueves:'Jue', viernes:'Vie', sabado:'Sáb', domingo:'Dom' };
const DIA_LABEL_LARGO = { lunes:'Lunes', martes:'Martes', miercoles:'Miércoles', jueves:'Jueves', viernes:'Viernes', sabado:'Sábado', domingo:'Domingo' };
const SLOT_LABEL = { desayuno:'Desayuno', almuerzo:'Almuerzo', media_tarde:'Media tarde', cena:'Cena' };
const OBJETIVO_LABEL = { definir: 'Definir', mantener: 'Mantener', volumen: 'Subir de peso' };
const ENFOQUE_LABEL = { piernas: 'piernas', brazos: 'brazos', espalda: 'espalda', cuerpo_completo: 'cuerpo completo' };
const ACTIVIDAD_LABEL = { sedentario: 'sedentario', ligero: 'ligero', moderado: 'moderado', activo: 'activo', muy_activo: 'muy activo' };

function aplicarProteina(texto, tipoProteina) {
  let t = texto;
  if (tipoProteina === 'vegano') {
    t = t.replace(/Pechuga de pollo|Pollo desmechado|Pollo al curry/gi, 'Tofu a la plancha')
         .replace(/Carne de res magra|Carne magra|Carne asada|Filete de pescado|Pescado al horno|Pescado a la plancha/gi, 'Garbanzos guisados')
         .replace(/[Hh]uevos?/g, 'Tofu revuelto')
         .replace(/[Qq]ueso fresco|[Qq]ueso/g, 'queso vegetal')
         .replace(/[Ll]eche/g, 'leche vegetal')
         .replace(/[Aa]tún/g, 'garbanzos');
  } else if (tipoProteina === 'vegetariano') {
    t = t.replace(/Pechuga de pollo|Pollo desmechado|Pollo al curry/gi, 'Garbanzos guisados')
         .replace(/Carne de res magra|Carne magra|Carne asada|Filete de pescado|Pescado al horno|Pescado a la plancha|[Aa]tún/gi, 'Lentejas con vegetales');
  } else if (tipoProteina === 'pollo') {
    t = t.replace(/Carne de res magra|Carne magra|Carne asada|Filete de pescado|Pescado al horno|Pescado a la plancha/gi, 'Pechuga de pollo a la plancha');
  } else if (tipoProteina === 'pescado') {
    t = t.replace(/Pechuga de pollo|Carne de res magra|Carne magra|Carne asada/gi, 'Filete de pescado a la plancha');
  } else if (tipoProteina === 'carne') {
    t = t.replace(/Pechuga de pollo|Filete de pescado/gi, 'Carne de res magra a la plancha');
  }
  return t;
}

function aplicarEnfoque(texto, enfoqueMuscular) {
  if (!enfoqueMuscular || enfoqueMuscular === 'cuerpo_completo') return texto;
  if (/Fuerza|Accesorios|Enfoque muscular/i.test(texto)) {
    return `Fuerza — enfoque en ${ENFOQUE_LABEL[enfoqueMuscular]}`;
  }
  return texto;
}

function aplicarActividad(texto, actividad) {
  if (actividad === 'sedentario') return `${texto} (empieza suave: reduce a la mitad las series si es tu primera semana)`;
  if (actividad === 'ligero') return `${texto} (intensidad moderada, sube el peso o el ritmo cada 2 semanas)`;
  if (actividad === 'activo' || actividad === 'muy_activo') return `${texto} (puedes exigir más: agrega una serie extra o acorta los descansos)`;
  return texto;
}

function construirHtmlComidas(objetivo, tipoProteina, restriccionesTexto) {
  const plan = MEALS_DATA[objetivo] || MEALS_DATA.mantener;
  let html = `<h3>Plan de alimentación — Objetivo: ${OBJETIVO_LABEL[objetivo] || objetivo}</h3>`;
  if (restriccionesTexto) html += `<p><b>Restricciones:</b> ${restriccionesTexto}</p>`;

  DIAS.forEach(d => {
    html += `<h4>${DIA_LABEL_LARGO[d]}</h4><ul>`;
    Object.keys(SLOT_LABEL).forEach(slot => {
      const opciones = plan[d][slot].map(o => aplicarProteina(o, tipoProteina));
      html += `<li><b>${SLOT_LABEL[slot]}:</b> ${opciones.join(' — o — ')}</li>`;
    });
    html += `</ul>`;
  });
  return html;
}

function construirHtmlEntrenamiento(objetivo, enfoqueMuscular, actividad) {
  const plan = WORKOUTS_DATA[objetivo] || WORKOUTS_DATA.mantener;
  let html = `<h3>Plan de entrenamiento — Objetivo: ${OBJETIVO_LABEL[objetivo] || objetivo}</h3>`;
  if (enfoqueMuscular) html += `<p><b>Enfoque muscular:</b> ${ENFOQUE_LABEL[enfoqueMuscular] || enfoqueMuscular}</p>`;

  DIAS.forEach(d => {
    html += `<h4>${DIA_LABEL_LARGO[d]}</h4><ul>`;
    plan[d].forEach((op, i) => {
      html += `<li><b>Opción ${i + 1}:</b> ${aplicarActividad(aplicarEnfoque(op, enfoqueMuscular), actividad)}</li>`;
    });
    html += `</ul>`;
  });
  return html;
}
