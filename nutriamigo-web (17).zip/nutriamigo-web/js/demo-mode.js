(function () {
  const STORAGE_KEY = 'nutriamigo_demo_state';
  const originalFetch = window.fetch.bind(window);
  let modoDemo = false;

  function leerEstado() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; }
    catch (e) { return {}; }
  }
  function guardarEstado(estado) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(estado)); }
    catch (e) { /* localStorage no disponible: el modo demo sigue funcionando en memoria para esta carga de página */ }
  }
  function json(data, status) {
    return new Response(JSON.stringify(data), {
      status: status || 200,
      headers: { 'Content-Type': 'application/json' }
    });
  }
  function normalizar(url) {
    return url.replace(/^https?:\/\/[^/]+/, '').replace(/^\.?\//, '');
  }
  function esRutaBackend(path) {
    return path.indexOf('api/') === 0 || path.indexOf('auth/') === 0;
  }

  function crearIOFalso() {
    const listeners = {};
    return {
      on(evento, cb) {
        (listeners[evento] = listeners[evento] || []).push(cb);
      },
      emit(evento, datos) {
        if (evento === 'message') {
          const idiomas = ['es', 'en', 'pt'];
          const translations = {};
          idiomas.forEach(l => { translations[l] = datos.text; });
          const mensaje = {
            author: datos.author,
            country: datos.showCountry ? datos.country : null,
            sourceLang: datos.lang,
            translations,
            timestamp: Date.now()
          };
          setTimeout(() => (listeners.message || []).forEach(cb => cb(mensaje)), 200);
          return;
        }
        if (evento === 'friend:message') {
          const estado = leerEstado();
          estado.friendMessages = estado.friendMessages || {};
          const lista = estado.friendMessages[datos.friendId] || [];
          const mensaje = { autor: datos.autor, texto: datos.texto, created_at: new Date().toISOString() };
          lista.push(mensaje);
          estado.friendMessages[datos.friendId] = lista;
          guardarEstado(estado);
          setTimeout(() => (listeners['friend:message'] || []).forEach(cb => cb(mensaje)), 150);
        }
      }
    };
  }

  function activarModoDemo() {
    if (modoDemo) return;
    modoDemo = true;
    window.__nutriamigoModoDemo = true;
    window.io = crearIOFalso;
  }

  async function demoFetch(path, init) {
    const method = ((init && init.method) || 'GET').toUpperCase();
    const estado = leerEstado();

    if (path === 'api/me') {
      if (!estado.user) return json({ error: 'No autenticado' }, 401);
      const totalCompletions = Object.values(estado.completions || {}).reduce((acc, lista) => acc + lista.length, 0);
      return json(Object.assign({ streak: estado.streak || 1, totalCompletions }, estado.user));
    }
    if (path === 'auth/logout') { guardarEstado({}); return json({ ok: true }); }
    if (path === 'api/account' && method === 'DELETE') { guardarEstado({}); return json({ ok: true }); }

    if (path === 'api/biometrics') {
      if (method === 'GET') return json(estado.bio || null);
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        estado.bio = body;
        guardarEstado(estado);
        return json(body);
      }
    }
    if (path === 'api/preferences') {
      if (method === 'GET') return json(estado.prefs || null);
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        estado.prefs = Object.assign({}, estado.prefs, body);
        guardarEstado(estado);
        return json({ ok: true });
      }
    }
    if (path === 'api/progress') {
      estado.progress = estado.progress || [];
      if (method === 'GET') return json(estado.progress);
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        estado.progress.push({ peso: body.peso, fecha: new Date().toISOString().slice(0, 10) });
        guardarEstado(estado);
        return json({ ok: true });
      }
      if (method === 'DELETE') { estado.progress = []; guardarEstado(estado); return json({ ok: true }); }
    }
    if (path === 'api/premium/activate') {
      estado.user = estado.user || {};
      estado.user.isPremium = true;
      guardarEstado(estado);
      return json({ ok: true });
    }
    if (path === 'api/premium/deactivate') {
      estado.user = estado.user || {};
      estado.user.isPremium = false;
      guardarEstado(estado);
      return json({ ok: true });
    }
    if (path === 'api/profile-visibility') {
      estado.user = estado.user || {};
      if (method === 'GET') return json({ publico: !!estado.user.perfilPublico });
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        estado.user.perfilPublico = !!body.publico;
        guardarEstado(estado);
        return json({ ok: true });
      }
    }
    if (path === 'api/reels') {
      estado.reels = estado.reels || [];
      if (method === 'GET') return json([...estado.reels].reverse());
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        const reel = {
          id: Date.now(),
          autor: (estado.user && estado.user.name) || 'Usuario Demo',
          texto: body.texto,
          imagen_url: body.imagenUrl || null,
          upvotes: 0, downvotes: 0, likes: 0,
          created_at: new Date().toISOString()
        };
        estado.reels.push(reel);
        guardarEstado(estado);
        return json(reel);
      }
    }
    const votoReelMatch = path.match(/^api\/reels\/(\d+)\/voto$/);
    if (votoReelMatch && method === 'POST') {
      const body = JSON.parse((init && init.body) || '{}');
      estado.reels = estado.reels || [];
      const reel = estado.reels.find(r => String(r.id) === votoReelMatch[1]);
      if (reel) {
        estado.votos = estado.votos || {};
        const clave = `${reel.id}:${body.tipo}`;
        if (!estado.votos[clave]) {
          estado.votos[clave] = true;
          if (body.tipo === 'up') reel.upvotes++;
          if (body.tipo === 'down') reel.downvotes++;
          if (body.tipo === 'like') reel.likes++;
        }
        guardarEstado(estado);
        return json(reel);
      }
      return json({ error: 'No encontrado' }, 404);
    }
    const borrarReelMatch = path.match(/^api\/reels\/(\d+)$/);
    if (borrarReelMatch && method === 'DELETE') {
      estado.reels = estado.reels || [];
      estado.reels = estado.reels.filter(r => String(r.id) !== borrarReelMatch[1]);
      guardarEstado(estado);
      return json({ ok: true });
    }
    if (path === 'api/friends') {
      estado.friends = estado.friends || [];
      if (method === 'GET') return json(estado.friends);
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        const amigo = { id: Date.now(), nombre: body.nombre, created_at: new Date().toISOString() };
        estado.friends.push(amigo);
        guardarEstado(estado);
        return json(amigo);
      }
    }
    const mensajesAmigoMatch = path.match(/^api\/friends\/(\d+)\/messages$/);
    if (mensajesAmigoMatch && method === 'GET') {
      estado.friendMessages = estado.friendMessages || {};
      return json(estado.friendMessages[mensajesAmigoMatch[1]] || []);
    }

    if (path === 'api/daily-log') {
      const hoy = new Date().toISOString().slice(0, 10);
      estado.dailyLogs = estado.dailyLogs || {};
      if (method === 'GET') {
        return json(estado.dailyLogs[hoy] || { fecha: hoy, vasos_agua: 0, km_recorridos: 0 });
      }
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        const actual = estado.dailyLogs[hoy] || { fecha: hoy, vasos_agua: 0, km_recorridos: 0 };
        const nuevo = {
          fecha: hoy,
          vasos_agua: body.vasosAgua !== undefined ? body.vasosAgua : actual.vasos_agua,
          km_recorridos: body.kmRecorridos !== undefined ? body.kmRecorridos : actual.km_recorridos
        };
        estado.dailyLogs[hoy] = nuevo;
        guardarEstado(estado);
        return json(nuevo);
      }
    }

    if (path === 'api/completions') {
      const hoy = new Date().toISOString().slice(0, 10);
      estado.completions = estado.completions || {};
      estado.completions[hoy] = estado.completions[hoy] || [];
      if (method === 'GET') return json(estado.completions[hoy]);
      if (method === 'POST') {
        const body = JSON.parse((init && init.body) || '{}');
        const lista = estado.completions[hoy];
        const idx = lista.indexOf(body.itemKey);
        let completado;
        if (idx >= 0) { lista.splice(idx, 1); completado = false; }
        else { lista.push(body.itemKey); completado = true; }
        guardarEstado(estado);
        return json({ completado });
      }
    }

    return json({ error: 'Ruta no disponible en modo demo' }, 404);
  }

  window.fetch = async function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const path = normalizar(url);
    const esBackend = esRutaBackend(path);

    try {
      const res = await originalFetch(input, init);
      if (esBackend && res.status === 404) {
        activarModoDemo();
        return demoFetch(path, init);
      }
      return res;
    } catch (errorDeRed) {
      if (esBackend) {
        activarModoDemo();
        return demoFetch(path, init);
      }
      throw errorDeRed;
    }
  };

  window.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('a[href="./auth/google"], a[href="/auth/google"]').forEach(enlace => {
      enlace.addEventListener('click', async function (e) {
        e.preventDefault();
        const res = await fetch('./api/me');
        if (modoDemo) {
          const estado = leerEstado();
          estado.user = {
            id: 'demo',
            name: 'Usuario Demo',
            email: 'demo@nutriamigo.test',
            avatar: null,
            isPremium: false
          };
          estado.streak = estado.streak || 1;
          guardarEstado(estado);
          window.location.href = './onboarding.html';
        } else if (res.ok) {
          window.location.href = './dashboard.html';
        } else {
          window.location.href = enlace.getAttribute('href');
        }
      });
    });
  });
})();
