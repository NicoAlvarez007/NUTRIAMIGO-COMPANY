function formatearFechaCorta(fechaStr) {
  const [y, m, d] = fechaStr.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('es-CO', { day: '2-digit', month: 'short' });
}

function formatearMesCorto(fechaStr) {
  const [y, m] = fechaStr.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('es-CO', { month: 'short', year: '2-digit' });
}

function filtrarPorVista(entries, vista) {
  const ordenadas = [...entries].sort((a, b) => a.fecha.localeCompare(b.fecha));
  const hoy = new Date();

  if (vista === 'semana') {
    const limite = new Date(hoy); limite.setDate(limite.getDate() - 7);
    const limiteStr = limite.toISOString().slice(0, 10);
    return ordenadas.filter(e => e.fecha >= limiteStr)
      .map(e => ({ fecha: e.fecha, peso: e.peso, label: formatearFechaCorta(e.fecha) }));
  }

  if (vista === 'mes') {
    const limite = new Date(hoy); limite.setDate(limite.getDate() - 30);
    const limiteStr = limite.toISOString().slice(0, 10);
    const porDia = {};
    ordenadas.filter(e => e.fecha >= limiteStr).forEach(e => { porDia[e.fecha] = e.peso; });
    return Object.keys(porDia).sort().map(fecha => ({ fecha, peso: porDia[fecha], label: formatearFechaCorta(fecha) }));
  }

  const limite = new Date(hoy); limite.setFullYear(limite.getFullYear() - 1);
  const limiteStr = limite.toISOString().slice(0, 10);
  const porMes = {};
  ordenadas.filter(e => e.fecha >= limiteStr).forEach(e => {
    const mesKey = e.fecha.slice(0, 7);
    (porMes[mesKey] = porMes[mesKey] || []).push(e.peso);
  });
  return Object.keys(porMes).sort().map(mesKey => {
    const pesos = porMes[mesKey];
    const promedio = Math.round((pesos.reduce((a, b) => a + b, 0) / pesos.length) * 10) / 10;
    return { fecha: `${mesKey}-01`, peso: promedio, label: formatearMesCorto(`${mesKey}-01`) };
  });
}

function drawWeightChart(entries) {
  const canvas = document.getElementById('progressChart');
  const empty = document.getElementById('progressEmpty');
  if (!entries.length) {
    canvas.style.display = 'none';
    empty.style.display = 'block';
    return;
  }
  canvas.style.display = 'block';
  empty.style.display = 'none';

  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const pad = 36;
  const pesos = entries.map(e => e.peso);
  const min = Math.min(...pesos) - 1;
  const max = Math.max(...pesos) + 1;
  const range = max - min || 1;
  const stepX = entries.length > 1 ? (w - pad * 2) / (entries.length - 1) : 0;

  const points = entries.map((e, i) => ({
    x: pad + stepX * i,
    y: h - pad - ((e.peso - min) / range) * (h - pad * 2)
  }));

  ctx.strokeStyle = '#d9ede1';
  ctx.beginPath();
  ctx.moveTo(pad, h - pad);
  ctx.lineTo(w - pad, h - pad);
  ctx.stroke();

  ctx.strokeStyle = '#34c281';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  points.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
  ctx.stroke();

  points.forEach((p, i) => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#279d68';
    ctx.fill();

    ctx.fillStyle = '#263029';
    ctx.font = '600 11px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(entries[i].peso + ' kg', p.x, p.y - 12);

    ctx.fillStyle = '#5c6b62';
    ctx.font = '500 10px Inter, sans-serif';
    ctx.fillText(entries[i].label, p.x, h - pad + 16);
  });
}

let ultimoResultado = null;

async function cargarMetaCalorica() {
  try {
    const res = await fetch('./api/biometrics');
    const data = await res.json();
    const resultsGrid = document.getElementById('resultsGrid');
    const noBioCard = document.getElementById('noBioCard');

    if (!data) { resultsGrid.style.display = 'none'; noBioCard.style.display = 'block'; return; }

    const imc = calcularIMC(data);
    const kcal = calcularMetaCalorica(data);
    const macros = calcularMacros(kcal, data.objetivo);

    if (imc && kcal && macros) {
      ultimoResultado = { imc, kcal, macros, datos: data };
      resultsGrid.style.display = 'grid';
      noBioCard.style.display = 'none';
      document.getElementById('imcValue').textContent = imc.toFixed(1);
      document.getElementById('imcTag').textContent = categoriaIMC(imc);
      const sugerencia = sugerirObjetivo(imc);
      document.getElementById('aiSuggestionValue').textContent = sugerencia ? sugerencia.titulo : '—';
      document.getElementById('kcalValue').textContent = kcal.toLocaleString('es-CO') + ' kcal';
      document.getElementById('macroProteina').textContent = `${macros.proteina.gramos} g (${macros.proteina.pct}%)`;
      document.getElementById('macroCarbs').textContent = `${macros.carbohidratos.gramos} g (${macros.carbohidratos.pct}%)`;
      document.getElementById('macroGrasas').textContent = `${macros.grasas.gramos} g (${macros.grasas.pct}%)`;
    }
    if (data.nombre) {
      document.querySelectorAll('[data-user-name]').forEach(el => {
        el.textContent = `${data.nombre} ${data.apellido || ''}`.trim();
      });
    }
  } catch (err) {
    console.error('No se pudo cargar tu meta calórica', err);
  }
}

async function descargarResumenPDF() {
  if (!ultimoResultado) { alert('Completa tus datos primero desde Configuración, en el menú de tu perfil.'); return; }
  const { imc, kcal, macros, datos } = ultimoResultado;

  let prefs = null;
  try {
    const res = await fetch('./api/preferences');
    if (res.ok) prefs = await res.json();
  } catch (err) {
    console.error('No se pudieron cargar tus preferencias para el PDF', err);
  }
  const tipoProteina = (prefs && prefs.tipoProteina) || '';
  const restriccionesTexto = (prefs && prefs.restriccionesTexto) || '';
  const enfoqueMuscular = (prefs && prefs.enfoqueMuscular) || '';

  document.getElementById('printableBody').innerHTML = `
    <h3>Tus datos</h3>
    <ul>
      ${datos.nombre ? `<li>Nombre: ${datos.nombre} ${datos.apellido || ''}</li>` : ''}
      ${datos.correo ? `<li>Correo: ${datos.correo}</li>` : ''}
      <li>Peso: ${datos.peso} kg — Estatura: ${datos.estatura} cm</li>
      <li>Género: ${datos.sexo === 'hombre' ? 'Hombre' : 'Mujer'} — Edad: ${datos.edad}</li>
      <li>Nivel de actividad: ${datos.actividad}</li>
      <li>Objetivo: ${datos.objetivo}</li>
    </ul>
    <h3>Resultado</h3>
    <ul>
      <li>Índice de masa corporal: ${imc.toFixed(1)} (${categoriaIMC(imc)})</li>
      <li>Meta calórica diaria: ${kcal} kcal</li>
      <li>Proteína: ${macros.proteina.gramos} g (${macros.proteina.pct}%)</li>
      <li>Carbohidratos: ${macros.carbohidratos.gramos} g (${macros.carbohidratos.pct}%)</li>
      <li>Grasas: ${macros.grasas.gramos} g (${macros.grasas.pct}%)</li>
    </ul>
    ${construirHtmlComidas(datos.objetivo, tipoProteina, restriccionesTexto)}
    ${construirHtmlEntrenamiento(datos.objetivo, enfoqueMuscular, datos.actividad)}
  `;
  window.print();
}

function exportarProgresoCSV() {
  if (!entriesCache.length) { alert('Aún no tienes registros de peso para exportar.'); return; }

  const filas = ['Fecha,Peso (kg)'];
  [...entriesCache].sort((a, b) => a.fecha.localeCompare(b.fecha)).forEach(e => {
    filas.push(`${e.fecha},${e.peso}`);
  });

  const csv = '\uFEFF' + filas.join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'historial-peso-nutriamigo.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

let entriesCache = [];
let vistaActual = 'semana';

async function cargarProgreso() {
  try {
    const res = await fetch('./api/progress');
    entriesCache = await res.json();
    drawWeightChart(filtrarPorVista(entriesCache, vistaActual));
  } catch (err) {
    console.error('No se pudo cargar tu progreso', err);
  }
}

let vasosAguaActual = 0;

async function cargarDailyLog() {
  try {
    const res = await fetch('./api/daily-log');
    const data = await res.json();
    vasosAguaActual = data.vasos_agua || 0;
    document.getElementById('waterCount').textContent = vasosAguaActual;
    document.getElementById('kmInput').value = data.km_recorridos || '';
  } catch (err) {
    console.error('No se pudo cargar tu registro diario', err);
  }
}

const LOGROS = [
  { id: 'racha3', icono: '🔥', nombre: '3 días de racha', check: (d) => d.streak >= 3 },
  { id: 'racha7', icono: '🏆', nombre: '7 días de racha', check: (d) => d.streak >= 7 },
  { id: 'primerPeso', icono: '⚖️', nombre: 'Primer registro de peso', check: (d) => d.totalProgreso >= 1 },
  { id: 'constanciaPeso', icono: '📈', nombre: '5 registros de peso', check: (d) => d.totalProgreso >= 5 },
  { id: 'cumplidor', icono: '✅', nombre: '10 tareas completadas', check: (d) => d.totalCompletions >= 10 },
  { id: 'premium', icono: '💎', nombre: 'Miembro Premium', check: (d) => d.isPremium }
];

function renderLogros(datos) {
  const grid = document.getElementById('achievementsGrid');
  grid.innerHTML = LOGROS.map(l => {
    const desbloqueado = l.check(datos);
    return `<div class="achievement-badge ${desbloqueado ? 'unlocked' : ''}">
      <span class="achievement-icon">${l.icono}</span>
      <span class="achievement-name">${l.nombre}</span>
    </div>`;
  }).join('');
}

async function cargarLogros(usuario) {
  try {
    const res = await fetch('./api/progress');
    const progreso = await res.json();
    renderLogros({
      streak: usuario.streak || 0,
      totalProgreso: progreso.length,
      totalCompletions: usuario.totalCompletions || 0,
      isPremium: usuario.isPremium
    });
  } catch (err) {
    console.error('No se pudieron cargar los logros', err);
  }
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const usuario = e.detail;
  cargarProgreso();
  cargarMetaCalorica();
  cargarDailyLog();
  cargarLogros(usuario);
  document.getElementById('downloadSummaryBtn').addEventListener('click', descargarResumenPDF);
  document.getElementById('exportProgressBtn').addEventListener('click', exportarProgresoCSV);

  document.getElementById('waterPlusBtn').addEventListener('click', () => {
    vasosAguaActual++;
    document.getElementById('waterCount').textContent = vasosAguaActual;
  });
  document.getElementById('waterMinusBtn').addEventListener('click', () => {
    vasosAguaActual = Math.max(0, vasosAguaActual - 1);
    document.getElementById('waterCount').textContent = vasosAguaActual;
  });
  document.getElementById('saveDailyLogBtn').addEventListener('click', async () => {
    const km = parseFloat(document.getElementById('kmInput').value) || 0;
    try {
      await fetch('./api/daily-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vasosAgua: vasosAguaActual, kmRecorridos: km })
      });
    } catch (err) {
      console.error('No se pudo guardar tu registro diario', err);
    }
  });

  document.querySelectorAll('#progressViewTabs .week-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      vistaActual = btn.dataset.vista;
      document.querySelectorAll('#progressViewTabs .week-tab').forEach(b => b.classList.toggle('active', b === btn));
      drawWeightChart(filtrarPorVista(entriesCache, vistaActual));
    });
  });

  document.getElementById('progressForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = document.getElementById('progressPeso');
    const peso = parseFloat(input.value);
    if (!peso) return;

    try {
      await fetch('./api/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ peso })
      });
    } catch (err) {
      console.error('No se pudo guardar el registro de peso', err);
    }
    input.value = '';
    await cargarProgreso();

    try {
      const bioRes = await fetch('./api/biometrics');
      const bio = await bioRes.json();
      if (bio && bio.peso && Math.abs(bio.peso - peso) >= 1) {
        const actualizar = confirm(`Tu peso cambió de ${bio.peso} kg a ${peso} kg. ¿Quieres actualizar tu plan con este nuevo peso?`);
        if (actualizar) {
          await fetch('./api/biometrics', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...bio, peso })
          });
          cargarMetaCalorica();
        }
      }
    } catch (err) {
      console.error('No se pudo comparar tu peso con el plan actual', err);
    }
  });

  document.getElementById('clearProgressBtn').addEventListener('click', async () => {
    try {
      await fetch('./api/progress', { method: 'DELETE' });
    } catch (err) {
      console.error('No se pudo borrar el historial', err);
    }
    cargarProgreso();
  });
});
