const AD_PROBABILIDAD = 0.05;

function mostrarAnuncio() {
  if (document.getElementById('adOverlay')) return;

  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'adOverlay';
  overlay.innerHTML = `
    <div class="modal" style="text-align:center;">
      <p class="eyebrow">Publicidad</p>
      <h3>Anuncio de ejemplo</h3>
      <p class="section-sub" style="margin:14px 0 22px;">Así se vería un espacio publicitario en la versión gratuita de NutriAmigo.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" id="closeAdBtn">Cerrar</button>
        <a href="./premium.html" class="btn btn-primary">Quitar anuncios</a>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  document.getElementById('closeAdBtn').addEventListener('click', () => overlay.remove());
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  if (!user || user.isPremium) return;

  if (Math.random() < AD_PROBABILIDAD) {
    setTimeout(mostrarAnuncio, 2000);
  }
});
