async function cargarPerfil() {
  try {
    const res = await fetch('./api/me');
    if (res.status === 401) return null;
    return await res.json();
  } catch (err) {
    console.error('No se pudo cargar el perfil', err);
    return null;
  }
}

async function cargarBiometriaExiste() {
  try {
    const res = await fetch('./api/biometrics');
    const bio = await res.json();
    return !!bio;
  } catch (err) {
    console.error('No se pudo verificar tus datos base', err);
    return true; // si falla la verificación, no bloqueamos la página con una redirección
  }
}

function pintarPerfil(user) {
  const avatarEls = document.querySelectorAll('[data-user-avatar]');
  const nameEls = document.querySelectorAll('[data-user-name]');
  const streakEls = document.querySelectorAll('[data-user-streak]');
  const premiumEls = document.querySelectorAll('[data-premium-only]');
  const badgeEls = document.querySelectorAll('[data-plan-badge]');

  nameEls.forEach(el => { el.textContent = user.name; });
  streakEls.forEach(el => { el.textContent = user.streak; });

  avatarEls.forEach(el => {
    if (user.avatar) {
      el.innerHTML = `<img src="${user.avatar}" alt="${user.name}">`;
    } else {
      el.textContent = user.name.slice(0, 2).toUpperCase();
    }
  });

  badgeEls.forEach(el => {
    el.textContent = user.isPremium ? 'Premium' : 'Gratis';
    el.classList.toggle('is-premium', !!user.isPremium);
  });

  premiumEls.forEach(el => { el.hidden = !user.isPremium; });
  document.querySelectorAll('[data-free-only]').forEach(el => { el.hidden = user.isPremium; });
}

function initProfileMenu() {
  const btn = document.getElementById('profileBtn');
  const menu = document.getElementById('profileMenu');
  if (!btn || !menu) return;

  btn.addEventListener('click', () => menu.classList.toggle('open'));
  menu.addEventListener('click', (e) => {
    if (e.target === menu) menu.classList.remove('open');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') menu.classList.remove('open');
  });

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      try {
        await fetch('./auth/logout', { method: 'POST' });
      } catch (err) {
        console.error('No se pudo cerrar sesión en el servidor', err);
      }
      window.location.href = './index.html';
    });
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  initProfileMenu();

  const esPaginaPublica = window.location.pathname.endsWith('premium.html');
  const user = await cargarPerfil();

  if (!user) {
    if (esPaginaPublica) {
      window.__nutriamigoUser = null;
      document.dispatchEvent(new CustomEvent('nutriamigo:user-ready', { detail: null }));
      return;
    }
    window.location.href = './index.html';
    return;
  }

  const enOnboarding = window.location.pathname.endsWith('onboarding.html');
  if (!enOnboarding) {
    const tieneBiometria = await cargarBiometriaExiste();
    if (!tieneBiometria) { window.location.href = './onboarding.html'; return; }
  }

  try {
    pintarPerfil(user);
  } catch (err) {
    console.error('No se pudo pintar el perfil', err);
  }

  window.__nutriamigoUser = user;
  document.dispatchEvent(new CustomEvent('nutriamigo:user-ready', { detail: user }));
});
