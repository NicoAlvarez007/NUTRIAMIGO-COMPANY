function construirModalConfiguracion() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'settingsModal';
  overlay.hidden = true;
  overlay.innerHTML = `
    <div class="modal">
      <h3>Configuración</h3>
      <p class="section-sub">Cambia tus datos, tu tema o tu cuenta.</p>
      <form id="settingsForm">
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label>Nombre</label><input type="text" id="cfgNombre"></div>
          <div class="field"><label>Apellido</label><input type="text" id="cfgApellido"></div>
        </div>
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label>Peso (kg)</label><input type="number" id="cfgPeso" step="0.1"></div>
          <div class="field"><label>Estatura (cm)</label><input type="number" id="cfgEstatura"></div>
        </div>
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label>Edad</label><input type="number" id="cfgEdad"></div>
          <div class="field">
            <label>Nivel de actividad</label>
            <select id="cfgActividad">
              <option value="sedentario">Sedentario</option>
              <option value="ligero">Ligero</option>
              <option value="moderado">Moderado</option>
              <option value="activo">Activo</option>
              <option value="muy_activo">Muy activo</option>
            </select>
          </div>
        </div>
        <div class="field">
          <label>Objetivo</label>
          <div class="pill-group" id="cfgObjetivoGroup">
            <button type="button" class="pill" data-objetivo="definir">Definir</button>
            <button type="button" class="pill" data-objetivo="mantener">Mantener</button>
            <button type="button" class="pill" data-objetivo="volumen">Subir de peso</button>
          </div>
        </div>
        <div class="field">
          <label>Tipo de perfil</label>
          <div class="pill-group" id="cfgPerfilGroup">
            <button type="button" class="pill" data-perfil="privado">Privado</button>
            <button type="button" class="pill" data-perfil="publico">Público</button>
          </div>
        </div>
        <div class="field">
          <label>Tema</label>
          <div class="pill-group" id="temaGroup">
            <button type="button" class="pill" data-tema="claro">Claro</button>
            <button type="button" class="pill" data-tema="dark">Oscuro</button>
          </div>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" id="closeSettingsBtn">Cancelar</button>
          <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
      </form>
      <button type="button" id="deleteAccountBtn" style="width:100%;margin-top:16px;background:none;border:none;color:#c5533b;font-size:13px;font-weight:600;cursor:pointer;">Borrar cuenta</button>
      <div class="settings-contact">
        <span>Contáctanos:</span>
        <a href="https://wa.me/573000000000" target="_blank" rel="noopener">WhatsApp</a>
        <a href="https://instagram.com/nutriamigo" target="_blank" rel="noopener">Instagram</a>
        <a href="https://tiktok.com/@nutriamigo" target="_blank" rel="noopener">TikTok</a>
        <span>nutriamigo@gmail.com</span>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  return overlay;
}

function aplicarTema(tema) {
  document.documentElement.setAttribute('data-theme', tema);
  try { localStorage.setItem('nutriamigo_theme', tema); } catch (e) { /* almacenamiento no disponible */ }
  document.querySelectorAll('#temaGroup .pill').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tema === tema);
  });
}

let objetivoCfg = 'mantener';
let perfilCfg = 'privado';

function marcarObjetivoCfg(valor) {
  objetivoCfg = valor;
  document.querySelectorAll('#cfgObjetivoGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.objetivo === valor));
}

function marcarPerfilCfg(valor) {
  perfilCfg = valor;
  document.querySelectorAll('#cfgPerfilGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.perfil === valor));
}

document.addEventListener('nutriamigo:user-ready', () => {
  const settingsBtn = document.getElementById('settingsBtn');
  if (!settingsBtn) return;

  const overlay = construirModalConfiguracion();

  document.querySelectorAll('#temaGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => aplicarTema(btn.dataset.tema));
  });
  document.querySelectorAll('#cfgObjetivoGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => marcarObjetivoCfg(btn.dataset.objetivo));
  });
  document.querySelectorAll('#cfgPerfilGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => marcarPerfilCfg(btn.dataset.perfil));
  });

  document.getElementById('closeSettingsBtn').addEventListener('click', () => { overlay.hidden = true; });

  settingsBtn.addEventListener('click', async () => {
    document.getElementById('profileMenu').classList.remove('open');
    aplicarTema(document.documentElement.getAttribute('data-theme') || 'claro');

    try {
      const res = await fetch('./api/biometrics');
      const data = await res.json();
      if (data) {
        document.getElementById('cfgNombre').value = data.nombre || '';
        document.getElementById('cfgApellido').value = data.apellido || '';
        document.getElementById('cfgPeso').value = data.peso || '';
        document.getElementById('cfgEstatura').value = data.estatura || '';
        document.getElementById('cfgEdad').value = data.edad || '';
        if (data.actividad) document.getElementById('cfgActividad').value = data.actividad;
        marcarObjetivoCfg(data.objetivo || 'mantener');
        overlay.dataset.sexo = data.sexo || '';
        overlay.dataset.correo = data.correo || '';
      }
    } catch (err) {
      console.error('No se pudieron cargar tus datos para Configuración', err);
    }

    try {
      const resPerfil = await fetch('./api/profile-visibility');
      const perfil = await resPerfil.json();
      marcarPerfilCfg(perfil && perfil.publico ? 'publico' : 'privado');
    } catch (err) {
      console.error('No se pudo cargar la visibilidad del perfil', err);
      marcarPerfilCfg('privado');
    }

    overlay.hidden = false;
  });

  document.getElementById('settingsForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await fetch('./api/biometrics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: document.getElementById('cfgNombre').value.trim(),
          apellido: document.getElementById('cfgApellido').value.trim(),
          correo: overlay.dataset.correo || '',
          peso: parseFloat(document.getElementById('cfgPeso').value) || null,
          estatura: parseFloat(document.getElementById('cfgEstatura').value) || null,
          edad: parseInt(document.getElementById('cfgEdad').value, 10) || null,
          actividad: document.getElementById('cfgActividad').value,
          sexo: overlay.dataset.sexo || null,
          objetivo: objetivoCfg
        })
      });
      await fetch('./api/profile-visibility', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ publico: perfilCfg === 'publico' })
      });
    } catch (err) {
      console.error('No se pudieron guardar tus cambios', err);
    }
    window.location.reload();
  });

  document.getElementById('deleteAccountBtn').addEventListener('click', async () => {
    if (!confirm('¿Seguro que quieres borrar tu cuenta? Esta acción no se puede deshacer.')) return;
    try {
      await fetch('./api/account', { method: 'DELETE' });
    } catch (err) {
      console.error('No se pudo borrar la cuenta', err);
    }
    window.location.href = './index.html';
  });
});
