let workoutsData = null;
let objetivoActivo = 'mantener';
let diaActivo = 'lunes';
let enfoqueMuscular = '';
let biometria = {};
let completionsHoy = [];

function renderObjetivoLabel() {
  document.getElementById('objetivoActualLabel').textContent = OBJETIVO_LABEL[objetivoActivo];
}

function renderResumen() {
  const el = document.getElementById('planSummary');
  if (!biometria.peso) {
    el.innerHTML = `Aún no has completado tus datos. <a href="./onboarding.html" style="color:var(--green-600);font-weight:600;">Complétalos aquí</a> para un plan calculado para ti.`;
    return;
  }
  el.innerHTML = `Plan calculado para: <b>${biometria.sexo === 'hombre' ? 'hombre' : 'mujer'}</b>, <b>${biometria.peso} kg</b>, <b>${biometria.estatura} cm</b>, actividad <b>${ACTIVIDAD_LABEL[biometria.actividad] || '—'}</b>, objetivo <b>${OBJETIVO_LABEL[objetivoActivo]}</b>.`;
}

function renderTabs() {
  const wrap = document.getElementById('weekTabs');
  wrap.innerHTML = DIAS.map(d =>
    `<button class="week-tab ${d === diaActivo ? 'active' : ''}" data-dia="${d}">${DIA_LABEL[d]}</button>`
  ).join('');
  wrap.querySelectorAll('.week-tab').forEach(btn => {
    btn.addEventListener('click', () => { diaActivo = btn.dataset.dia; renderTabs(); renderDay(); });
  });
}

function renderDay() {
  const wrap = document.getElementById('daySlots');
  const opciones = workoutsData[objetivoActivo][diaActivo];
  const itemKey = `entrenamiento-${diaActivo}`;
  const hecho = completionsHoy.includes(itemKey);
  wrap.innerHTML = `
    <div class="slot-card" style="grid-column: 1 / -1;">
      <div class="slot-card-header">
        <h4>Rutina del día</h4>
        <button type="button" class="done-toggle ${hecho ? 'done' : ''}" data-item-key="${itemKey}">${hecho ? '✓ Hecho hoy' : 'Ya lo hice'}</button>
      </div>
      ${opciones.map((op, i) => `<div class="slot-option"><b>Opción ${i + 1}</b>${aplicarActividad(aplicarEnfoque(op, enfoqueMuscular), biometria.actividad)}</div>`).join('')}
    </div>
  `;
  document.querySelector('.done-toggle').addEventListener('click', () => marcarCompletado(itemKey));
}

async function marcarCompletado(itemKey) {
  try {
    const res = await fetch('./api/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemKey })
    });
    const data = await res.json();
    if (data.completado) completionsHoy.push(itemKey);
    else completionsHoy = completionsHoy.filter(k => k !== itemKey);
  } catch (err) {
    console.error('No se pudo registrar como completado', err);
  }
  renderDay();
}

async function cargarCompletions() {
  try {
    const res = await fetch('./api/completions');
    completionsHoy = await res.json();
  } catch (err) {
    console.error('No se pudieron cargar tus tareas completadas', err);
  }
}

function renderKcal() {
  const kcal = calcularMetaCalorica({ ...biometria, objetivo: objetivoActivo });
  const card = document.getElementById('kcalCard');
  if (kcal) {
    card.style.display = 'block';
    document.getElementById('kcalValue').textContent = kcal.toLocaleString('es-CO') + ' kcal';
  } else {
    card.style.display = 'none';
  }
}

function descargarPDF() {
  document.getElementById('printableBody').innerHTML = construirHtmlEntrenamiento(objetivoActivo, enfoqueMuscular, biometria.actividad);
  window.print();
}

async function cargarBiometria() {
  try {
    const res = await fetch('./api/biometrics');
    const data = await res.json();
    if (data) {
      biometria = { peso: data.peso, estatura: data.estatura, sexo: data.sexo, edad: data.edad, actividad: data.actividad };
      if (data.objetivo) objetivoActivo = data.objetivo;
    }
  } catch (err) {
    console.error('No se pudieron cargar tus datos base', err);
  }
}

async function cargarPreferencias() {
  try {
    const res = await fetch('./api/preferences');
    if (!res.ok) return;
    const prefs = await res.json();
    if (prefs) {
      if (prefs.enfoqueMuscular) enfoqueMuscular = prefs.enfoqueMuscular;
      if (prefs.frecuenciaSemanal) document.getElementById('frecuenciaSemanal').value = prefs.frecuenciaSemanal;
      if (prefs.distanciaKm) document.getElementById('distanciaKm').value = prefs.distanciaKm;
      if (prefs.enfoqueMuscular) document.getElementById('enfoqueMuscular').value = prefs.enfoqueMuscular;
    }
  } catch (err) {
    console.error('No se pudieron cargar tus preferencias', err);
  }
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  workoutsData = WORKOUTS_DATA;

  renderObjetivoLabel();
  renderResumen();
  renderTabs();
  renderDay();
  renderKcal();

  document.getElementById('downloadWorkoutBtn').addEventListener('click', descargarPDF);

  const modal = document.getElementById('personalizeModal');
  document.getElementById('personalizeBtn').addEventListener('click', () => {
    if (!user.isPremium) { window.location.href = './premium.html'; return; }
    modal.hidden = false;
  });
  document.getElementById('closeModalBtn').addEventListener('click', () => { modal.hidden = true; });

  document.getElementById('personalizeForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    enfoqueMuscular = document.getElementById('enfoqueMuscular').value;

    try {
      await fetch('./api/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          frecuenciaSemanal: parseInt(document.getElementById('frecuenciaSemanal').value, 10),
          distanciaKm: parseFloat(document.getElementById('distanciaKm').value) || null,
          enfoqueMuscular
        })
      });
    } catch (err) {
      console.error('No se pudieron guardar las preferencias', err);
    }

    modal.hidden = true;
    renderDay();
  });

  (async () => {
    try {
      await cargarBiometria();
      await cargarPreferencias();
      await cargarCompletions();
    } catch (err) {
      console.error('No se pudieron cargar tus datos guardados', err);
    }
    renderObjetivoLabel();
    renderResumen();
    renderDay();
    renderKcal();
  })();
});
