let pasoActual = 1;
let sexoElegido = null;
let objetivoElegido = null;

function mostrarSugerenciaIMC() {
  const peso = parseFloat(document.getElementById('obPeso').value);
  const estatura = parseFloat(document.getElementById('obEstatura').value);
  const imc = calcularIMC({ peso, estatura });
  if (!imc) return;

  const sugerencia = sugerirObjetivo(imc);
  if (!sugerencia) return;

  document.getElementById('aiSuggestionTitle').textContent = `Sugerencia: ${sugerencia.titulo}`;
  document.getElementById('aiSuggestionText').textContent = `Tu IMC es ${imc.toFixed(1)} (${categoriaIMC(imc)}). ${sugerencia.texto}`;
  document.getElementById('aiSuggestion').hidden = false;

  if (!objetivoElegido) {
    objetivoElegido = sugerencia.objetivo;
    document.querySelectorAll('#objetivoGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.objetivo === objetivoElegido));
  }
}

function mostrarPaso(n) {
  document.querySelectorAll('.onboarding-step').forEach(s => {
    s.hidden = parseInt(s.dataset.step, 10) !== n;
  });
  document.querySelectorAll('.step-dot').forEach(d => {
    const step = parseInt(d.dataset.step, 10);
    d.classList.toggle('active', step === n);
    d.classList.toggle('done', step < n);
  });
  pasoActual = n;
}

function validarPaso1() {
  return document.getElementById('obNombre').value.trim() && document.getElementById('obApellido').value.trim();
}
function validarPaso2() {
  return document.getElementById('obPeso').value && document.getElementById('obEstatura').value;
}
function validarPaso3() {
  return sexoElegido && document.getElementById('obEdad').value && document.getElementById('obActividad').value;
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('#sexoGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => {
      sexoElegido = btn.dataset.sexo;
      document.querySelectorAll('#sexoGroup .pill').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  document.querySelectorAll('#objetivoGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => {
      objetivoElegido = btn.dataset.objetivo;
      document.querySelectorAll('#objetivoGroup .pill').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  document.querySelectorAll('[data-next]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (pasoActual === 1 && !validarPaso1()) { alert('Ingresa tu nombre y tu apellido.'); return; }
      if (pasoActual === 2 && !validarPaso2()) { alert('Ingresa tu peso y tu altura.'); return; }
      if (pasoActual === 3 && !validarPaso3()) { alert('Completa género, edad y nivel de actividad.'); return; }
      if (pasoActual === 3) mostrarSugerenciaIMC();
      mostrarPaso(pasoActual + 1);
    });
  });

  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.addEventListener('click', () => mostrarPaso(pasoActual - 1));
  });

  document.getElementById('onboardingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!objetivoElegido) { alert('Elige un objetivo.'); return; }

    try {
      await fetch('./api/biometrics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: document.getElementById('obNombre').value.trim(),
          apellido: document.getElementById('obApellido').value.trim(),
          correo: document.getElementById('obCorreo').value.trim(),
          peso: parseFloat(document.getElementById('obPeso').value),
          estatura: parseFloat(document.getElementById('obEstatura').value),
          sexo: sexoElegido,
          edad: parseInt(document.getElementById('obEdad').value, 10),
          actividad: document.getElementById('obActividad').value,
          objetivo: objetivoElegido
        })
      });
    } catch (err) {
      console.error('No se pudieron guardar tus datos', err);
    }

    window.location.href = './dashboard.html';
  });

  mostrarPaso(1);

  fetch('./api/me').then(res => {
    if (res.status === 401) window.location.href = './index.html';
  }).catch(err => {
    console.error('No se pudo verificar la sesión', err);
  });
});
