const ROOMS = [
  { id: 'global', label: 'Global' },
  { id: 'norteamerica', label: 'Norteamérica' },
  { id: 'sudamerica', label: 'Sudamérica' },
  { id: 'europa', label: 'Europa' },
  { id: 'asia', label: 'Asia' },
  { id: 'africa', label: 'África' },
  { id: 'oceania', label: 'Oceanía' }
];

let salaActiva = 'global';
let usuario = null;
let socket = null;
let amigoActivo = null;
let amigosCache = [];

/* ---------- Pestañas ---------- */
function initTabs() {
  document.querySelectorAll('#communityTabs .week-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#communityTabs .week-tab').forEach(b => b.classList.toggle('active', b === btn));
      document.querySelectorAll('.community-panel').forEach(p => { p.hidden = p.dataset.panel !== btn.dataset.tab; });
      if (btn.dataset.tab === 'reels') cargarReels();
      if (btn.dataset.tab === 'friends') cargarAmigos();
    });
  });
}

/* ---------- Chat (Global / regiones) ---------- */
function renderRooms() {
  const wrap = document.getElementById('roomList');
  wrap.innerHTML = ROOMS.map(r =>
    `<button class="room-item ${r.id === salaActiva ? 'active' : ''}" data-room="${r.id}">${r.label}</button>`
  ).join('');
  wrap.querySelectorAll('.room-item').forEach(btn => {
    btn.addEventListener('click', () => cambiarSala(btn.dataset.room));
  });
}

function pintarMensaje(msg) {
  const body = document.getElementById('chatBody');
  const lang = document.getElementById('langSelect').value;
  const texto = msg.translations[lang] || msg.translations[msg.sourceLang];

  const div = document.createElement('div');
  div.className = 'chat-msg-app';
  const metaCountry = msg.country ? ` · ${msg.country}` : '';
  div.innerHTML = `<div class="chat-msg-meta">${msg.author}${metaCountry}</div>${texto}`;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}

function cambiarSala(nuevaSala) {
  socket.emit('leave', salaActiva);
  salaActiva = nuevaSala;
  socket.emit('join', salaActiva);
  document.getElementById('roomTitle').textContent = ROOMS.find(r => r.id === salaActiva).label;
  document.getElementById('chatBody').innerHTML = '';
  renderRooms();
}

function initChat() {
  renderRooms();
  socket.emit('join', salaActiva);
  socket.on('message', pintarMensaje);

  document.getElementById('chatSettingsBtn').addEventListener('click', () => {
    const panel = document.getElementById('chatSettingsPanel');
    panel.hidden = !panel.hidden;
  });

  document.getElementById('communityForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    const input = document.getElementById('communityInput');
    const text = input.value.trim();
    if (!text) return;

    const country = document.getElementById('countrySelect').value;
    socket.emit('message', {
      room: salaActiva,
      text,
      lang: document.getElementById('langSelect').value,
      author: usuario.name,
      showCountry: !!country,
      country: country || null
    });
    input.value = '';
  });
}

/* ---------- Reels ---------- */
function tiempoRelativo(fechaISO) {
  const diffMin = Math.round((Date.now() - new Date(fechaISO).getTime()) / 60000);
  if (diffMin < 1) return 'ahora mismo';
  if (diffMin < 60) return `hace ${diffMin} min`;
  const diffH = Math.round(diffMin / 60);
  if (diffH < 24) return `hace ${diffH} h`;
  return `hace ${Math.round(diffH / 24)} d`;
}

function renderReel(reel) {
  const esMio = usuario && reel.autor === usuario.name;
  const div = document.createElement('article');
  div.className = 'reel-card';
  div.innerHTML = `
    <div class="reel-votes">
      <button type="button" data-voto="up" data-id="${reel.id}">▲</button>
      <span class="reel-score">${reel.upvotes - reel.downvotes}</span>
      <button type="button" data-voto="down" data-id="${reel.id}">▼</button>
    </div>
    <div class="reel-body">
      <span class="reel-author">${reel.autor}</span><span class="reel-date">${tiempoRelativo(reel.created_at)}</span>
      <p>${reel.texto}</p>
      ${reel.imagen_url ? `<img src="${reel.imagen_url}" alt="">` : ''}
      <div class="reel-actions">
        <button type="button" class="reel-like-btn" data-voto="like" data-id="${reel.id}">♥ <span>${reel.likes}</span></button>
        ${esMio ? `<button type="button" class="reel-delete-btn" data-borrar="${reel.id}">Eliminar</button>` : ''}
      </div>
    </div>
  `;
  return div;
}

async function cargarReels() {
  const feed = document.getElementById('reelsFeed');
  try {
    const res = await fetch('./api/reels');
    const reels = await res.json();
    feed.innerHTML = '';
    if (!reels.length) {
      feed.innerHTML = '<p class="reels-empty">Aún no hay publicaciones. ¡Sé el primero en compartir algo!</p>';
      return;
    }
    reels.forEach(r => feed.appendChild(renderReel(r)));
  } catch (err) {
    console.error('No se pudieron cargar los reels', err);
  }
}

function initReels() {
  document.getElementById('reelPublishBtn').addEventListener('click', async () => {
    const texto = document.getElementById('reelTexto').value.trim();
    if (!texto) return;
    const imagenUrl = document.getElementById('reelImagenUrl').value.trim();

    try {
      await fetch('./api/reels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ texto, imagenUrl })
      });
    } catch (err) {
      console.error('No se pudo publicar', err);
    }
    document.getElementById('reelTexto').value = '';
    document.getElementById('reelImagenUrl').value = '';
    cargarReels();
  });

  document.getElementById('reelsFeed').addEventListener('click', async (ev) => {
    const votoBtn = ev.target.closest('[data-voto]');
    if (votoBtn) {
      try {
        await fetch(`./api/reels/${votoBtn.dataset.id}/voto`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tipo: votoBtn.dataset.voto })
        });
      } catch (err) {
        console.error('No se pudo votar', err);
      }
      cargarReels();
      return;
    }

    const borrarBtn = ev.target.closest('[data-borrar]');
    if (borrarBtn) {
      if (!confirm('¿Eliminar esta publicación?')) return;
      try {
        await fetch(`./api/reels/${borrarBtn.dataset.borrar}`, { method: 'DELETE' });
      } catch (err) {
        console.error('No se pudo eliminar', err);
      }
      cargarReels();
    }
  });
}

/* ---------- Friends (estilo Snapchat) ---------- */
function renderFriendsList() {
  const wrap = document.getElementById('friendsItems');
  if (!amigosCache.length) {
    wrap.innerHTML = '<p class="friends-empty">Agrega a tu primer amigo arriba.</p>';
    return;
  }
  wrap.innerHTML = amigosCache.map(a => `
    <button type="button" class="friend-item ${amigoActivo && amigoActivo.id === a.id ? 'active' : ''}" data-id="${a.id}">
      <span class="friend-avatar">${a.nombre.slice(0, 2).toUpperCase()}</span>
      <span>${a.nombre}</span>
    </button>
  `).join('');
  wrap.querySelectorAll('.friend-item').forEach(btn => {
    btn.addEventListener('click', () => abrirChatAmigo(amigosCache.find(a => String(a.id) === btn.dataset.id)));
  });
}

async function cargarAmigos() {
  try {
    const res = await fetch('./api/friends');
    amigosCache = await res.json();
    renderFriendsList();
  } catch (err) {
    console.error('No se pudieron cargar tus amigos', err);
  }
}

async function abrirChatAmigo(amigo) {
  amigoActivo = amigo;
  renderFriendsList();
  document.getElementById('friendChatTitle').textContent = amigo.nombre;
  document.getElementById('friendChatInput').disabled = false;
  document.querySelector('#friendChatForm button').disabled = false;

  socket.emit('friend:join', amigo.id);

  const body = document.getElementById('friendChatBody');
  body.innerHTML = '';
  try {
    const res = await fetch(`./api/friends/${amigo.id}/messages`);
    const mensajes = await res.json();
    mensajes.forEach(pintarMensajeAmigo);
  } catch (err) {
    console.error('No se pudieron cargar los mensajes', err);
  }
}

function pintarMensajeAmigo(msg) {
  if (!amigoActivo) return;
  const body = document.getElementById('friendChatBody');
  const div = document.createElement('div');
  const esMio = msg.autor === usuario.name;
  div.className = 'chat-msg-app' + (esMio ? ' mine' : '');
  div.innerHTML = `<div class="chat-msg-meta">${msg.autor}</div>${msg.texto}`;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}

function initFriends() {
  socket.on('friend:message', pintarMensajeAmigo);

  document.getElementById('addFriendForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const input = document.getElementById('addFriendInput');
    const nombre = input.value.trim();
    if (!nombre) return;

    try {
      await fetch('./api/friends', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre })
      });
    } catch (err) {
      console.error('No se pudo agregar el amigo', err);
    }
    input.value = '';
    cargarAmigos();
  });

  document.getElementById('friendChatForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    if (!amigoActivo) return;
    const input = document.getElementById('friendChatInput');
    const texto = input.value.trim();
    if (!texto) return;

    socket.emit('friend:message', { friendId: amigoActivo.id, autor: usuario.name, texto });
    input.value = '';
  });
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  usuario = e.detail;
  socket = io();

  initTabs();
  initChat();
  initReels();
  initFriends();
});
