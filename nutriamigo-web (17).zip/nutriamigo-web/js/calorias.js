const ACTIVIDAD_FACTOR = {
  sedentario: 1.2,
  ligero: 1.375,
  moderado: 1.55,
  activo: 1.725,
  muy_activo: 1.9
};

const OBJETIVO_AJUSTE = { definir: -500, mantener: 0, volumen: 400 };
const OBJETIVO_MACROS = {
  definir: { proteina: 35, carbohidratos: 35, grasas: 30 },
  mantener: { proteina: 30, carbohidratos: 40, grasas: 30 },
  volumen: { proteina: 30, carbohidratos: 45, grasas: 25 }
};

function calcularIMC({ peso, estatura }) {
  if (!peso || !estatura) return null;
  const alturaM = estatura / 100;
  return peso / (alturaM * alturaM);
}

function categoriaIMC(imc) {
  if (imc < 18.5) return 'Bajo peso';
  if (imc < 25) return 'Peso saludable';
  if (imc < 30) return 'Sobrepeso';
  return 'Rango alto';
}

function calcularMetaCalorica({ peso, estatura, sexo, edad, actividad, objetivo }) {
  if (!peso || !estatura || !sexo || !edad || !actividad) return null;

  const bmr = sexo === 'hombre'
    ? 10 * peso + 6.25 * estatura - 5 * edad + 5
    : 10 * peso + 6.25 * estatura - 5 * edad - 161;

  const factor = ACTIVIDAD_FACTOR[actividad] || 1.2;
  const ajuste = OBJETIVO_AJUSTE[objetivo] ?? 0;

  return Math.round((bmr * factor + ajuste) / 10) * 10;
}

function calcularMacros(kcal, objetivo) {
  if (!kcal) return null;
  const pct = OBJETIVO_MACROS[objetivo] || OBJETIVO_MACROS.mantener;
  return {
    proteina: { pct: pct.proteina, gramos: Math.round((kcal * pct.proteina / 100) / 4) },
    carbohidratos: { pct: pct.carbohidratos, gramos: Math.round((kcal * pct.carbohidratos / 100) / 4) },
    grasas: { pct: pct.grasas, gramos: Math.round((kcal * pct.grasas / 100) / 9) }
  };
}

const OBJETIVO_LABEL_CORTO = { definir: 'Definir', mantener: 'Mantener', volumen: 'Subir de peso' };

const SUGERENCIA_POR_IMC = {
  'Bajo peso': {
    objetivo: 'volumen',
    titulo: 'Subir de peso',
    texto: 'Entrenamiento sugerido: fuerza con superávit calórico, priorizando ganar masa muscular.'
  },
  'Peso saludable': {
    objetivo: 'mantener',
    titulo: 'Mantener',
    texto: 'Entrenamiento sugerido: rutina equilibrada de fuerza y cardio para conservar tu condición actual.'
  },
  'Sobrepeso': {
    objetivo: 'definir',
    titulo: 'Definir (bajar de peso)',
    texto: 'Entrenamiento sugerido: cardio y déficit calórico moderado para bajar de peso de forma saludable.'
  },
  'Rango alto': {
    objetivo: 'definir',
    titulo: 'Definir (bajar de peso)',
    texto: 'Entrenamiento sugerido: cardio y déficit calórico; te recomendamos también acompañamiento profesional.'
  }
};

function sugerirObjetivo(imc) {
  const categoria = categoriaIMC(imc);
  return SUGERENCIA_POR_IMC[categoria] || null;
}
