require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const http = require('http');
const { Server } = require('socket.io');

const db = require('./db');
const { translateToAll } = require('./translate');

const PORT = process.env.PORT || 3000;
const CALLBACK_URL = process.env.GOOGLE_CALLBACK_URL || `http://localhost:${PORT}/auth/google/callback`;

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'nutriamigo-dev-secret',
  resave: false,
  saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser((id, done) => done(null, db.getUserById(id)));

if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: CALLBACK_URL
  }, (accessToken, refreshToken, profile, done) => {
    const user = db.findOrCreateUser({
      googleId: profile.id,
      name: profile.displayName,
      email: profile.emails?.[0]?.value || null,
      avatar: profile.photos?.[0]?.value || null
    });
    done(null, user);
  }));
} else {
  console.warn('\n⚠️  Faltan GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET en .env — el login con Google no funcionará hasta configurarlos.\n');
}

app.use(express.static(path.join(__dirname, '..')));

function requireAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.status(401).json({ error: 'No autenticado' });
}

app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }),
  (req, res) => {
    db.touchStreak(req.user.id);
    const bio = db.getBiometrics(req.user.id);
    res.redirect(bio ? '/dashboard.html' : '/onboarding.html');
  }
);

app.post('/auth/logout', (req, res) => {
  req.logout(() => res.json({ ok: true }));
});

app.get('/api/me', requireAuth, (req, res) => {
  res.json({
    id: req.user.id,
    name: req.user.name,
    email: req.user.email,
    avatar: req.user.avatar,
    isPremium: !!req.user.is_premium,
    createdAt: req.user.created_at,
    streak: db.getStreak(req.user.id),
    totalCompletions: db.contarCompletionsTotal(req.user.id)
  });
});

app.get('/api/progress', requireAuth, (req, res) => {
  res.json(db.getProgress(req.user.id));
});

app.post('/api/progress', requireAuth, (req, res) => {
  const peso = parseFloat(req.body.peso);
  if (!peso || peso <= 0) return res.status(400).json({ error: 'Peso inválido' });
  res.json(db.addProgress(req.user.id, peso));
});

app.delete('/api/progress', requireAuth, (req, res) => {
  db.clearProgress(req.user.id);
  res.json({ ok: true });
});

app.get('/api/biometrics', requireAuth, (req, res) => {
  res.json(db.getBiometrics(req.user.id));
});

app.post('/api/biometrics', requireAuth, (req, res) => {
  const { nombre, apellido, correo, peso, estatura, sexo, edad, actividad, objetivo } = req.body;
  res.json(db.saveBiometrics(req.user.id, { nombre, apellido, correo, peso, estatura, sexo, edad, actividad, objetivo }));
});

app.get('/api/preferences', requireAuth, (req, res) => {
  res.json(db.getPreferences(req.user.id));
});

app.post('/api/preferences', requireAuth, (req, res) => {
  if (!req.user.is_premium) return res.status(403).json({ error: 'Función premium' });
  db.savePreferences(req.user.id, req.body);
  res.json({ ok: true });
});

app.post('/api/premium/activate', requireAuth, (req, res) => {
  db.setPremium(req.user.id, true);
  res.json({ ok: true });
});

app.post('/api/premium/deactivate', requireAuth, (req, res) => {
  db.setPremium(req.user.id, false);
  res.json({ ok: true });
});

app.get('/api/profile-visibility', requireAuth, (req, res) => {
  res.json({ publico: !!req.user.perfil_publico });
});

app.post('/api/profile-visibility', requireAuth, (req, res) => {
  db.setPerfilPublico(req.user.id, !!req.body.publico);
  res.json({ ok: true });
});

function hoy() { return new Date().toISOString().slice(0, 10); }

app.get('/api/daily-log', requireAuth, (req, res) => {
  res.json(db.getDailyLog(req.user.id, hoy()));
});

app.post('/api/daily-log', requireAuth, (req, res) => {
  const actual = db.getDailyLog(req.user.id, hoy());
  const vasosAgua = req.body.vasosAgua !== undefined ? req.body.vasosAgua : actual.vasos_agua;
  const kmRecorridos = req.body.kmRecorridos !== undefined ? req.body.kmRecorridos : actual.km_recorridos;
  res.json(db.guardarDailyLog(req.user.id, hoy(), vasosAgua, kmRecorridos));
});

app.get('/api/completions', requireAuth, (req, res) => {
  res.json(db.getCompletions(req.user.id, hoy()));
});

app.post('/api/completions', requireAuth, (req, res) => {
  if (!req.body.itemKey) return res.status(400).json({ error: 'Falta itemKey' });
  res.json(db.toggleCompletion(req.user.id, req.body.itemKey, hoy()));
});

app.delete('/api/account', requireAuth, (req, res) => {
  db.deleteAccount(req.user.id);
  req.logout(() => res.json({ ok: true }));
});

app.get('/api/reels', requireAuth, (req, res) => {
  res.json(db.listarReels());
});

app.post('/api/reels', requireAuth, (req, res) => {
  const { texto, imagenUrl } = req.body;
  if (!texto || !texto.trim()) return res.status(400).json({ error: 'El texto no puede estar vacío' });
  const autor = req.user.name;
  res.json(db.crearReel(req.user.id, autor, texto.trim(), imagenUrl));
});

app.post('/api/reels/:id/voto', requireAuth, (req, res) => {
  const { tipo } = req.body;
  if (!['up', 'down', 'like'].includes(tipo)) return res.status(400).json({ error: 'Tipo de voto inválido' });
  res.json(db.votarReel(parseInt(req.params.id, 10), req.user.id, tipo));
});

app.delete('/api/reels/:id', requireAuth, (req, res) => {
  const borrado = db.eliminarReel(parseInt(req.params.id, 10), req.user.id);
  if (!borrado) return res.status(403).json({ error: 'No puedes borrar esta publicación' });
  res.json({ ok: true });
});

app.get('/api/friends', requireAuth, (req, res) => {
  res.json(db.listarAmigos(req.user.id));
});

app.post('/api/friends', requireAuth, (req, res) => {
  const { nombre } = req.body;
  if (!nombre || !nombre.trim()) return res.status(400).json({ error: 'El nombre no puede estar vacío' });
  res.json(db.agregarAmigo(req.user.id, nombre.trim()));
});

app.get('/api/friends/:id/messages', requireAuth, (req, res) => {
  const amigo = db.getAmigo(req.user.id, parseInt(req.params.id, 10));
  if (!amigo) return res.status(404).json({ error: 'Amigo no encontrado' });
  res.json(db.listarMensajesAmigo(amigo.id));
});

const CHAT_ROOMS = ['global', 'norteamerica', 'sudamerica', 'europa', 'asia', 'africa', 'oceania'];

io.on('connection', (socket) => {
  socket.on('join', (room) => {
    if (!CHAT_ROOMS.includes(room)) return;
    socket.join(room);
  });

  socket.on('leave', (room) => {
    socket.leave(room);
  });

  socket.on('message', async ({ room, text, lang, author, showCountry, country }) => {
    if (!CHAT_ROOMS.includes(room) || !text || !text.trim()) return;
    const safeLang = ['es', 'en', 'pt'].includes(lang) ? lang : 'es';

    let translations = { [safeLang]: text };
    try {
      translations = await translateToAll(text.slice(0, 500), safeLang);
    } catch (err) {
      console.error('Error de traducción:', err.message);
    }

    io.to(room).emit('message', {
      author: author || 'Anónimo',
      country: showCountry ? country : null,
      sourceLang: safeLang,
      translations,
      timestamp: Date.now()
    });
  });

  socket.on('friend:join', (friendId) => {
    socket.join(`friend-${friendId}`);
  });

  socket.on('friend:message', ({ friendId, autor, texto }) => {
    if (!friendId || !texto || !texto.trim()) return;
    const mensajes = db.guardarMensajeAmigo(friendId, autor || 'Anónimo', texto.trim());
    io.to(`friend-${friendId}`).emit('friend:message', mensajes[mensajes.length - 1]);
  });
});

server.listen(PORT, () => {
  console.log(`\n✅ NutriAmigo corriendo en http://localhost:${PORT}\n`);
});
