const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'nutriamigo.db'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  google_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  email TEXT,
  avatar TEXT,
  is_premium INTEGER NOT NULL DEFAULT 0,
  perfil_publico INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS progress (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  fecha TEXT NOT NULL,
  peso REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS streaks (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  current_streak INTEGER NOT NULL DEFAULT 0,
  last_active_date TEXT
);

-- Datos gratuitos: disponibles para todos los usuarios, sin requerir Premium
CREATE TABLE IF NOT EXISTS biometrics (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  nombre TEXT,
  apellido TEXT,
  correo TEXT,
  peso REAL,
  estatura REAL,
  sexo TEXT,
  edad INTEGER,
  actividad TEXT,
  objetivo TEXT
);

-- Personalización avanzada: exclusiva de usuarios Premium
CREATE TABLE IF NOT EXISTS preferences (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  tipo_proteina TEXT,
  restricciones_texto TEXT,
  frecuencia_semanal INTEGER,
  distancia_km REAL,
  enfoque_muscular TEXT
);

CREATE TABLE IF NOT EXISTS reels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  autor TEXT NOT NULL,
  texto TEXT NOT NULL,
  imagen_url TEXT,
  upvotes INTEGER NOT NULL DEFAULT 0,
  downvotes INTEGER NOT NULL DEFAULT 0,
  likes INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reel_votes (
  reel_id INTEGER NOT NULL REFERENCES reels(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  tipo TEXT NOT NULL,
  PRIMARY KEY (reel_id, user_id, tipo)
);

CREATE TABLE IF NOT EXISTS friends (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  nombre TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS friend_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  friend_id INTEGER NOT NULL REFERENCES friends(id),
  autor TEXT NOT NULL,
  texto TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS daily_logs (
  user_id INTEGER NOT NULL REFERENCES users(id),
  fecha TEXT NOT NULL,
  vasos_agua INTEGER NOT NULL DEFAULT 0,
  km_recorridos REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, fecha)
);

CREATE TABLE IF NOT EXISTS completions (
  user_id INTEGER NOT NULL REFERENCES users(id),
  item_key TEXT NOT NULL,
  fecha TEXT NOT NULL,
  PRIMARY KEY (user_id, item_key, fecha)
);
`);

function findOrCreateUser({ googleId, name, email, avatar }) {
  const existing = db.prepare('SELECT * FROM users WHERE google_id = ?').get(googleId);
  if (existing) return existing;

  const createdAt = new Date().toISOString();
  const info = db.prepare(
    'INSERT INTO users (google_id, name, email, avatar, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run(googleId, name, email, avatar, createdAt);

  return db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
}

function getUserById(id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

function addProgress(userId, peso) {
  const fecha = new Date().toISOString().slice(0, 10);
  db.prepare('INSERT INTO progress (user_id, fecha, peso) VALUES (?, ?, ?)').run(userId, fecha, peso);
  return getProgress(userId);
}

function getProgress(userId) {
  return db.prepare('SELECT fecha, peso FROM progress WHERE user_id = ? ORDER BY id ASC').all(userId);
}

function clearProgress(userId) {
  db.prepare('DELETE FROM progress WHERE user_id = ?').run(userId);
}

function touchStreak(userId) {
  const today = new Date().toISOString().slice(0, 10);
  const row = db.prepare('SELECT * FROM streaks WHERE user_id = ?').get(userId);

  if (!row) {
    db.prepare('INSERT INTO streaks (user_id, current_streak, last_active_date) VALUES (?, 1, ?)').run(userId, today);
    return 1;
  }
  if (row.last_active_date === today) return row.current_streak;

  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const newStreak = row.last_active_date === yesterday ? row.current_streak + 1 : 1;

  db.prepare('UPDATE streaks SET current_streak = ?, last_active_date = ? WHERE user_id = ?')
    .run(newStreak, today, userId);
  return newStreak;
}

function getStreak(userId) {
  const row = db.prepare('SELECT current_streak FROM streaks WHERE user_id = ?').get(userId);
  return row ? row.current_streak : 0;
}

function setPremium(userId, value) {
  db.prepare('UPDATE users SET is_premium = ? WHERE id = ?').run(value ? 1 : 0, userId);
}

function setPerfilPublico(userId, value) {
  db.prepare('UPDATE users SET perfil_publico = ? WHERE id = ?').run(value ? 1 : 0, userId);
}

function deleteAccount(userId) {
  db.prepare('DELETE FROM progress WHERE user_id = ?').run(userId);
  db.prepare('DELETE FROM streaks WHERE user_id = ?').run(userId);
  db.prepare('DELETE FROM biometrics WHERE user_id = ?').run(userId);
  db.prepare('DELETE FROM preferences WHERE user_id = ?').run(userId);
  db.prepare('DELETE FROM users WHERE id = ?').run(userId);
}

function crearReel(userId, autor, texto, imagenUrl) {
  const createdAt = new Date().toISOString();
  const info = db.prepare(
    'INSERT INTO reels (user_id, autor, texto, imagen_url, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run(userId, autor, texto, imagenUrl || null, createdAt);
  return db.prepare('SELECT * FROM reels WHERE id = ?').get(info.lastInsertRowid);
}

function listarReels() {
  return db.prepare('SELECT * FROM reels ORDER BY id DESC LIMIT 50').all();
}

function eliminarReel(reelId, userId) {
  const reel = db.prepare('SELECT * FROM reels WHERE id = ? AND user_id = ?').get(reelId, userId);
  if (!reel) return false;
  db.prepare('DELETE FROM reel_votes WHERE reel_id = ?').run(reelId);
  db.prepare('DELETE FROM reels WHERE id = ?').run(reelId);
  return true;
}

function votarReel(reelId, userId, tipo) {
  const yaVoto = db.prepare('SELECT * FROM reel_votes WHERE reel_id = ? AND user_id = ? AND tipo = ?').get(reelId, userId, tipo);
  if (yaVoto) return db.prepare('SELECT * FROM reels WHERE id = ?').get(reelId);

  db.prepare('INSERT INTO reel_votes (reel_id, user_id, tipo) VALUES (?, ?, ?)').run(reelId, userId, tipo);
  const columna = tipo === 'up' ? 'upvotes' : tipo === 'down' ? 'downvotes' : 'likes';
  db.prepare(`UPDATE reels SET ${columna} = ${columna} + 1 WHERE id = ?`).run(reelId);
  return db.prepare('SELECT * FROM reels WHERE id = ?').get(reelId);
}

function listarAmigos(userId) {
  return db.prepare('SELECT * FROM friends WHERE user_id = ? ORDER BY nombre ASC').all(userId);
}

function agregarAmigo(userId, nombre) {
  const createdAt = new Date().toISOString();
  const info = db.prepare('INSERT INTO friends (user_id, nombre, created_at) VALUES (?, ?, ?)').run(userId, nombre, createdAt);
  return db.prepare('SELECT * FROM friends WHERE id = ?').get(info.lastInsertRowid);
}

function getAmigo(userId, friendId) {
  return db.prepare('SELECT * FROM friends WHERE id = ? AND user_id = ?').get(friendId, userId);
}

function listarMensajesAmigo(friendId) {
  return db.prepare('SELECT * FROM friend_messages WHERE friend_id = ? ORDER BY id ASC').all(friendId);
}

function guardarMensajeAmigo(friendId, autor, texto) {
  const createdAt = new Date().toISOString();
  db.prepare('INSERT INTO friend_messages (friend_id, autor, texto, created_at) VALUES (?, ?, ?, ?)').run(friendId, autor, texto, createdAt);
  return listarMensajesAmigo(friendId);
}

function getDailyLog(userId, fecha) {
  return db.prepare('SELECT * FROM daily_logs WHERE user_id = ? AND fecha = ?').get(userId, fecha)
    || { user_id: userId, fecha, vasos_agua: 0, km_recorridos: 0 };
}

function guardarDailyLog(userId, fecha, vasosAgua, kmRecorridos) {
  const existente = db.prepare('SELECT user_id FROM daily_logs WHERE user_id = ? AND fecha = ?').get(userId, fecha);
  if (existente) {
    db.prepare('UPDATE daily_logs SET vasos_agua = ?, km_recorridos = ? WHERE user_id = ? AND fecha = ?')
      .run(vasosAgua, kmRecorridos, userId, fecha);
  } else {
    db.prepare('INSERT INTO daily_logs (user_id, fecha, vasos_agua, km_recorridos) VALUES (?, ?, ?, ?)')
      .run(userId, fecha, vasosAgua, kmRecorridos);
  }
  return getDailyLog(userId, fecha);
}

function getCompletions(userId, fecha) {
  return db.prepare('SELECT item_key FROM completions WHERE user_id = ? AND fecha = ?').all(userId, fecha).map(r => r.item_key);
}

function toggleCompletion(userId, itemKey, fecha) {
  const existente = db.prepare('SELECT 1 FROM completions WHERE user_id = ? AND item_key = ? AND fecha = ?').get(userId, itemKey, fecha);
  if (existente) {
    db.prepare('DELETE FROM completions WHERE user_id = ? AND item_key = ? AND fecha = ?').run(userId, itemKey, fecha);
    return { completado: false };
  }
  db.prepare('INSERT INTO completions (user_id, item_key, fecha) VALUES (?, ?, ?)').run(userId, itemKey, fecha);
  return { completado: true };
}

function contarCompletionsTotal(userId) {
  const row = db.prepare('SELECT COUNT(*) AS total FROM completions WHERE user_id = ?').get(userId);
  return row.total;
}

function saveBiometrics(userId, data) {
  const existing = db.prepare('SELECT user_id FROM biometrics WHERE user_id = ?').get(userId);
  if (existing) {
    db.prepare(`UPDATE biometrics SET nombre=?, apellido=?, correo=?, peso=?, estatura=?, sexo=?, edad=?, actividad=?, objetivo=? WHERE user_id=?`)
      .run(data.nombre, data.apellido, data.correo, data.peso, data.estatura, data.sexo, data.edad, data.actividad, data.objetivo, userId);
  } else {
    db.prepare(`INSERT INTO biometrics (user_id, nombre, apellido, correo, peso, estatura, sexo, edad, actividad, objetivo)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(userId, data.nombre, data.apellido, data.correo, data.peso, data.estatura, data.sexo, data.edad, data.actividad, data.objetivo);
  }
  return getBiometrics(userId);
}

function getBiometrics(userId) {
  return db.prepare('SELECT * FROM biometrics WHERE user_id = ?').get(userId) || null;
}

function savePreferences(userId, prefs) {
  const existing = db.prepare('SELECT user_id FROM preferences WHERE user_id = ?').get(userId);
  if (existing) {
    db.prepare(`UPDATE preferences SET tipo_proteina=?, restricciones_texto=?, frecuencia_semanal=?,
      distancia_km=?, enfoque_muscular=? WHERE user_id=?`)
      .run(prefs.tipoProteina, prefs.restriccionesTexto, prefs.frecuenciaSemanal,
           prefs.distanciaKm, prefs.enfoqueMuscular, userId);
  } else {
    db.prepare(`INSERT INTO preferences
      (user_id, tipo_proteina, restricciones_texto, frecuencia_semanal, distancia_km, enfoque_muscular)
      VALUES (?, ?, ?, ?, ?, ?)`)
      .run(userId, prefs.tipoProteina, prefs.restriccionesTexto, prefs.frecuenciaSemanal,
           prefs.distanciaKm, prefs.enfoqueMuscular);
  }
}

function getPreferences(userId) {
  const row = db.prepare('SELECT * FROM preferences WHERE user_id = ?').get(userId);
  if (!row) return null;
  return {
    tipoProteina: row.tipo_proteina,
    restriccionesTexto: row.restricciones_texto,
    frecuenciaSemanal: row.frecuencia_semanal,
    distanciaKm: row.distancia_km,
    enfoqueMuscular: row.enfoque_muscular
  };
}

module.exports = {
  findOrCreateUser, getUserById, addProgress, getProgress, clearProgress,
  touchStreak, getStreak, setPremium, setPerfilPublico, deleteAccount, saveBiometrics, getBiometrics,
  savePreferences, getPreferences,
  crearReel, listarReels, votarReel, eliminarReel,
  listarAmigos, agregarAmigo, getAmigo, listarMensajesAmigo, guardarMensajeAmigo,
  getDailyLog, guardarDailyLog, getCompletions, toggleCompletion, contarCompletionsTotal
};
