const SUPPORTED = ['es', 'en', 'pt'];

async function translateText(text, sourceLang, targetLang) {
  if (sourceLang === targetLang) return text;

  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${sourceLang}|${targetLang}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('translation request failed');

  const data = await res.json();
  return data?.responseData?.translatedText || text;
}

async function translateToAll(text, sourceLang) {
  const targets = SUPPORTED.filter(l => l !== sourceLang);
  const entries = await Promise.all(
    targets.map(async (lang) => [lang, await translateText(text, sourceLang, lang).catch(() => text)])
  );

  const result = { [sourceLang]: text };
  entries.forEach(([lang, value]) => { result[lang] = value; });
  return result;
}

module.exports = { translateToAll, SUPPORTED };
