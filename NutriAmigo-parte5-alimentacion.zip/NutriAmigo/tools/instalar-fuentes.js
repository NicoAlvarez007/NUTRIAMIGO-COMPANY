/* Copia Manrope e Inter (Fontsource) a assets/fonts/ y escribe css/fonts.css.
   Uso único con internet: npm run fuentes */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const RAIZ = path.join(__dirname, '..');
const PUBLICO = path.join(RAIZ, 'public');
const DESTINO = path.join(PUBLICO, 'assets', 'fonts');
const FAMILIAS = [
  { paquete: 'manrope', nombre: 'Manrope', pesos: [500, 700, 800] },
  { paquete: 'inter', nombre: 'Inter', pesos: [400, 500, 600, 700] }
];
const RANGOS = {
  latin: 'U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD',
  'latin-ext': 'U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF'
};

const paquetes = FAMILIAS.map(f => `@fontsource/${f.paquete}`).join(' ');
execSync(`npm install --no-save ${paquetes}`, { cwd: RAIZ, stdio: 'inherit' });
fs.mkdirSync(DESTINO, { recursive: true });

let css = '/* Generado por tools/instalar-fuentes.js */\n';
FAMILIAS.forEach(({ paquete, nombre, pesos }) => {
  pesos.forEach(peso => {
    Object.keys(RANGOS).forEach(subconjunto => {
      const archivo = `${paquete}-${subconjunto}-${peso}-normal.woff2`;
      const origen = path.join(RAIZ, 'node_modules', '@fontsource', paquete, 'files', archivo);
      fs.copyFileSync(origen, path.join(DESTINO, archivo));
      css += `@font-face {\n  font-family: '${nombre}';\n  font-style: normal;\n  font-weight: ${peso};\n  font-display: swap;\n  src: url('../assets/fonts/${archivo}') format('woff2');\n  unicode-range: ${RANGOS[subconjunto]};\n}\n`;
    });
  });
});
fs.writeFileSync(path.join(PUBLICO, 'css', 'fonts.css'), css);
console.log('Fuentes instaladas en public/assets/fonts/ y public/css/fonts.css actualizado.');
