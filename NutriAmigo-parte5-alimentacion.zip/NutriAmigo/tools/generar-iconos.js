/* Genera los íconos de la PWA a partir de assets/logo.png.
   Uso único: npm install --no-save sharp && npm run iconos */
const path = require('path');
const sharp = require('sharp');

const ORIGEN = path.join(__dirname, '..', 'public', 'assets', 'logo.png');
const DESTINO = path.join(__dirname, '..', 'public', 'assets');
const FONDO = '#eef9f2';

async function circulo(tam) {
  const mascara = Buffer.from(`<svg width="${tam}" height="${tam}"><circle cx="${tam / 2}" cy="${tam / 2}" r="${tam / 2}" fill="#fff"/></svg>`);
  return sharp(ORIGEN)
    .resize(tam, tam)
    .composite([{ input: mascara, blend: 'dest-in' }])
    .png()
    .toBuffer();
}

async function estandar(tam) {
  await sharp(await circulo(tam)).toFile(path.join(DESTINO, `icon-${tam}.png`));
}

async function maskable(tam) {
  const logo = await circulo(Math.round(tam * 0.7));
  await sharp({ create: { width: tam, height: tam, channels: 4, background: FONDO } })
    .composite([{ input: logo, gravity: 'center' }])
    .png()
    .toFile(path.join(DESTINO, `icon-maskable-${tam}.png`));
}

(async () => {
  await estandar(192);
  await estandar(512);
  await maskable(192);
  await maskable(512);
  console.log('Íconos generados en public/assets/');
})().catch(err => { console.error(err); process.exit(1); });
