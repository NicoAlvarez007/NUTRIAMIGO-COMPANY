const fs = require('fs');
const path = require('path');

const rutaDb = process.env.NUTRIAMIGO_DB || path.join(__dirname, '..', 'server', 'data', 'nutriamigo.db');
if (!fs.existsSync(rutaDb)) {
  console.error('No se encontró la base de datos en ' + rutaDb);
  process.exit(1);
}

let Database;
try {
  Database = require(path.join(__dirname, '..', 'server', 'node_modules', 'better-sqlite3'));
} catch (e) {
  Database = require('better-sqlite3');
}

const db = new Database(rutaDb);
const borrados = db.prepare('DELETE FROM login_attempts').run().changes;
db.close();
console.log(`Listo: se quitaron ${borrados} bloqueo(s) de inicio de sesión.`);
