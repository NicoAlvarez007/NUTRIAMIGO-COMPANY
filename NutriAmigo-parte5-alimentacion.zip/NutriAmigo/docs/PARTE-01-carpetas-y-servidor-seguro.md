# PARTE 1 de 12 — Carpetas y servidor seguro

> Pega primero `00-CONTEXTO-GENERAL.md` y después este documento.
> Punto de partida: el proyecto del zip `nutriamigo-web-fixed (6).zip`.
> Corrige: **1.1, 1.4, 1.5**, parte de **1.22** (organigrama) y deja listas las bases (migraciones, validadores, arranque en red) que usan las partes siguientes.

## Objetivo

Reorganizar el proyecto en la estructura del contexto (sección 5) y dejar el servidor **seguro, validado y fácil de iniciar** en el computador y en la red local. Al terminar, la app se ve y funciona **igual que antes** para la persona usuaria; lo que cambia es dónde están los archivos y que el servidor ya no acepta datos inválidos ni expone nada indebido.

**No hagas en esta parte:** cambios de diseño (Parte 2), cuentas con contraseña (Parte 3), fechas locales y racha (Parte 4), ni nada de la lista de "fuera de alcance". No borres `demo-mode.js` todavía (se retira en la Parte 3).

---

## 1. Reorganizar carpetas

1. Crea la estructura de la sección 5 del contexto.
2. Mueve **con `git mv` o equivalente** (sin perder historial de contenido):
   - `index.html, onboarding.html, dashboard.html, alimentacion.html, entrenamiento.html, comunidad.html, premium.html, manifest.json, service-worker.js` → `public/`
   - `css/, js/, data/, assets/` → `public/`
   - `backend/db.js, server.js, translate.js, package.json, .env.example` → `server/` (ver punto 2)
   - `ESPECIFICACION-COMPLETA.md, 50-preguntas-frecuentes.md` → `docs/`
3. **Elimina `assets/organigrama.png`** y toda mención a "organigrama" en el README y en cualquier archivo (ya no se usa).
4. Verifica con una búsqueda que ningún HTML/JS/CSS referencia archivos que dejaron de existir. Las rutas en el navegador siguen siendo relativas (`./css/...`, `./js/...`, `./api/...`) y deben seguir funcionando porque `public/` se sirve como raíz.
5. Crea `.gitignore` con: `node_modules/`, `server/data/`, `server/uploads/`, `server/.env`, `*.db`, `*.db-wal`, `*.db-shm`.
6. Mantén (y actualiza si hace falta) `.vscode/` en la raíz.

## 2. Servidor: dividir `server.js` en módulos

Sin cambiar el comportamiento de las rutas actuales, separa así:

```
server/
├── server.js                 crea app, middleware, monta rutas, escucha
├── config.js                 lee y valida .env (ver 3)
├── db/
│   ├── index.js              abre la base (server/data/nutriamigo.db, WAL) y ejecuta migraciones
│   ├── migrate.js            sistema de migraciones (ver 4)
│   ├── migrations/001_inicial.js  002_...   (ver 4)
│   └── queries/              usuarios.js, progreso.js, comunidad.js ... (lo que hoy está en db.js)
├── routes/                   auth.js, perfil.js, progreso.js, plan.js, comunidad.js, amigos.js
├── middleware/               requireAuth.js, validar.js, seguridad.js, limites.js
├── lib/                      validadores.js, sesionSqlite.js, fechas.js (por ahora solo hoy())
└── package.json
```

- Las funciones de `db.js` se conservan (mismos nombres) repartidas en `db/queries/`. `translate.js` pasa a `lib/traduccion.js`.
- `deleteAccount` sigue borrando todo lo del usuario.
- Sockets: mueve la lógica de Socket.io a `server/sockets.js` **sin cambiarla todavía** (la autenticación de sockets es la Parte 9).

## 3. Configuración (`.env`) y arranque

`server/config.js` lee `server/.env` con `dotenv` y expone un objeto de configuración. Variables:

| Variable | Uso | Valor en `.env.example` |
|---|---|---|
| `PORT` | puerto | `3000` |
| `NODE_ENV` | `development` / `production` / `test` | `development` |
| `SESSION_SECRET` | secreto de cookies | vacío (ver abajo) |
| `COOKIE_SECURE` | `true` solo si se sirve por HTTPS | `false` |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_CALLBACK_URL` | Google real (opcional) | vacíos |
| `ADMIN_USER` | usuario del administrador (se usa en la Parte 3) | `administrador` |
| `ADMIN_PASSWORD` | contraseña inicial (se usa en la Parte 3) | `12345678` |
| `ALLOW_FREE_PREMIUM_SWITCH` | permite activar/desactivar Premium sin pago **solo mientras no exista la pantalla de pago** (se elimina en la Parte 10) | `true` |

**`SESSION_SECRET`:** si está vacío o es el valor de ejemplo, el servidor **genera uno aleatorio de 48 bytes**, lo guarda en `server/.env` y sigue (así el dueño no tiene que configurarlo). En `NODE_ENV=production` sin secreto, el servidor **se niega a arrancar** con un mensaje claro.

**Arranque:**
- `INICIAR.bat` (Windows) e `iniciar.sh` (Mac/Linux): si no existe `server/node_modules`, ejecutan `npm install` en `server/`; si no existe `server/.env`, lo copian de `.env.example`; luego `npm start`. Si Node no está instalado, muestran un mensaje en español explicando dónde descargarlo (nodejs.org, versión LTS).
- `npm start` y `npm run dev` (con `node --watch`) en `server/package.json`.
- El servidor escucha en **`0.0.0.0`** y al iniciar imprime, en español:
  ```
  ✅ NutriAmigo está funcionando
     En este computador:  http://localhost:3000
     Desde tu celular (misma red Wi-Fi):  http://192.168.x.x:3000
  ```
  (lista todas las direcciones IPv4 no internas usando `os.networkInterfaces()`). Explica en el README que el celular debe estar en la misma red y que, si no abre, hay que permitir Node.js en el firewall.
- Aviso al iniciar si falta Google: mensaje corto indicando que se usará el inicio de sesión simulado (la simulación se construye en la Parte 3; por ahora mantén el aviso actual).

## 4. Base de datos y migraciones

1. La base pasa a `server/data/nutriamigo.db` (crear la carpeta si no existe). **Si existe una base antigua en `backend/nutriamigo.db`, se copia sola a la ubicación nueva la primera vez** (no perder datos).
2. Sistema de migraciones propio y simple: tabla `schema_migrations(version INTEGER PRIMARY KEY, nombre TEXT, aplicada_en TEXT)`; cada archivo `NNN_nombre.js` exporta `up(db)`; `migrate.js` aplica en orden las que falten, **cada una en una transacción**, y se ejecuta al iniciar.
3. `001_inicial.js` = el esquema actual completo (usa `CREATE TABLE IF NOT EXISTS`, así funciona sobre bases ya existentes). Las tres `ALTER TABLE` con `try/catch` que hoy están en `db.js` pasan a `002_columnas_usuario.js`, comprobando primero si la columna existe (con `PRAGMA table_info`), sin `try/catch` ciego.
4. `003_indices.js`: índices en `progress(user_id, fecha)`, `completions(user_id, fecha)`, `reels(id)`, `friend_messages(friend_id)`.
5. `004_sesiones.js`: tabla `sessions(sid TEXT PRIMARY KEY, sess TEXT NOT NULL, expires INTEGER NOT NULL)` + índice sobre `expires`.
6. Activa `PRAGMA foreign_keys = ON` y `journal_mode = WAL`.

## 5. Seguridad (corrige 1.1 y 1.4)

1. **Solo se publica `public/`.** `express.static(path.join(__dirname, '..', 'public'))`. Comprueba que ya **no** se pueden descargar `server/`, `docs/`, `tests/`, `.env`, `nutriamigo.db`, `package.json` ni `node_modules` (deben dar 404). Dentro de `public/` no debe haber ningún archivo sensible.
2. **Sesiones en SQLite** (sin dependencias nuevas): implementa `lib/sesionSqlite.js`, un *store* compatible con `express-session` (métodos `get`, `set`, `destroy`, `touch`) usando la tabla `sessions`, con limpieza de sesiones vencidas cada 15 minutos. Las sesiones **sobreviven a reiniciar el servidor** y no crecen sin límite.
3. **Cookie de sesión:** `httpOnly: true`, `sameSite: 'lax'`, `secure: config.COOKIE_SECURE`, `maxAge` 30 días, nombre `nutriamigo.sid`, `resave: false`, `saveUninitialized: false`, `rolling: true`. Renueva el id de sesión al iniciar sesión (`req.session.regenerate`) para evitar fijación de sesión.
4. **Cabeceras de seguridad** con `helmet`. Política de contenido (CSP) que permita lo que la app usa hoy:
   - `default-src 'self'`; `script-src 'self'`; `style-src 'self' 'unsafe-inline' https://fonts.googleapis.com`; `font-src 'self' https://fonts.gstatic.com`; `img-src 'self' data: blob: https:`; `connect-src 'self' ws: wss:`; `object-src 'none'`; `frame-ancestors 'none'`.
   - **Los scripts en línea no están permitidos**: el pequeño script del tema que hoy está dentro del `<head>` de cada HTML se mueve a `public/js/tema-inicial.js` y se carga con `<script src>` en el `<head>` (para evitar parpadeo). **Cambia su lógica:** si la persona nunca eligió tema, usar **claro** (se elimina el cambio automático a oscuro por hora).
   - Las fuentes de Google se mantienen permitidas **solo hasta la Parte 2**, donde se descargan y se sirven locales.
   - Verifica en el navegador que ninguna página muestra errores de CSP en la consola.
5. **Límite de peticiones** con `express-rate-limit`:
   - General: 300 peticiones / 15 min por IP para `/api`.
   - Autenticación (`/auth/*`, login): 10 / 15 min por IP.
   - Escritura en comunidad (reels, mensajes): 30 / minuto por usuario.
   - Respuesta 429 con `{ error, code: 'demasiadas_peticiones' }`.
6. **Protección CSRF simple:** todas las peticiones `POST/PUT/PATCH/DELETE` a `/api` y `/auth` deben traer `Content-Type: application/json` **o** el encabezado `X-Requested-With: nutriamigo`; si no, 403. Añade el encabezado por defecto en un solo lugar del navegador (un `fetch` envuelto en `public/js/api.js`, que además maneja errores de red de forma uniforme). `SameSite=Lax` cubre el resto.
7. Tamaño máximo del cuerpo JSON: 100 kb (las fotos tendrán su propio límite en la Parte 7).
8. `app.disable('x-powered-by')`. Cabecera `Cache-Control: no-store` en todas las respuestas `/api`.
9. **`ALLOW_FREE_PREMIUM_SWITCH`:** las rutas `/api/premium/activate` y `/deactivate` responden 404 si esta variable no es `true`. (Se eliminan por completo en la Parte 10.)
10. Manejador de errores final: nunca devolver la traza al navegador; registrar el error en consola; responder `{ error: 'Error interno', code: 'interno' }` con 500.

## 6. Validación en el servidor (corrige 1.5)

Crea `lib/validadores.js` con funciones **puras y probadas** y un `middleware/validar.js` que las aplica. Todas las respuestas de error usan el formato:

```json
{ "error": "Texto en español para el usuario", "code": "peso_invalido", "field": "peso" }
```
(`code` es una clave estable que el navegador traduce en es/en/de con el diccionario `i18n` — agrega las claves `err.<code>` en los 3 idiomas.)

| Dato | Regla |
|---|---|
| `peso` (kg) | número, 30 a 250 (un decimal) |
| `estatura` (cm) | número, 120 a 220 |
| `edad` | entero, **15 a 90** (menor de 15 → `code: 'edad_minima'`, mensaje: "NutriAmigo está disponible desde los 15 años") |
| `sexo` | `'hombre'` o `'mujer'` |
| `actividad` | `sedentario, ligero, moderado, activo, muy_activo` |
| `objetivo` | `definir, mantener, volumen` |
| `nombre`, `apellido` | texto 1 a 50 caracteres, sin etiquetas HTML (recortar espacios) |
| `correo` | opcional; formato de correo válido; máx. 120 |
| `vasosAgua` | entero 0 a 40 |
| `kmRecorridos` | número 0 a 200 (un decimal) |
| `peso` en `/api/progress` | igual que arriba (unifica el `max=200` del formulario del dashboard a **250**) |
| `restriccionesTexto` | máx. 300 caracteres |
| `frecuenciaSemanal` | entero 1 a 7 |
| `distanciaKm` | número 0 a 100 |
| `enfoqueMuscular` | `piernas, brazos, espalda, cuerpo_completo` |
| `proteinas` | lista de valores permitidos; reglas de exclusividad vegano/vegetariano ya existentes |
| `texto` de reel / mensaje | 1 a 500 caracteres; `imagenUrl` solo `https://` y máx. 300 caracteres (la subida de archivos llega en la Parte 9) |
| `nombre` de amigo | 1 a 40 caracteres |
| ids en la ruta | enteros positivos |

Además:
- **Reglas cruzadas de seguridad calórica** (`lib/calorias.js`, se reutiliza en todo el proyecto): piso de **1.200 kcal (mujer) / 1.500 kcal (hombre)**; si la edad es **15 a 17**, el objetivo `definir` se **rechaza** con `code: 'objetivo_no_permitido_menor'` (solo `mantener` o `volumen`). Aplica al guardar biometría y al guardar preferencias. (El consentimiento del adulto se agrega en la Parte 3; aquí solo la regla.)
- Rechazar cuerpos con campos desconocidos no es necesario, pero **ignora** cualquier campo que no esté en la lista (no guardar basura).
- Devuelve **400** para datos inválidos, **401** sin sesión, **403** sin permiso, **404** si no existe, **409** si hay conflicto, **429** por límites.
- Aplica la validación a: `POST /api/biometrics`, `POST /api/progress`, `POST /api/daily-log`, `POST /api/preferences`, `POST /api/reels`, `POST /api/friends`, `POST /api/completions` (`itemKey` con formato `alimentacion-<dia>-<comida>` o `entrenamiento-<dia>`, días y comidas de las listas válidas), `/api/reels/:id/voto`, mensajes de sockets (`text` ≤ 500, `room` válida).
- `POST /api/biometrics` debe hacer **guardado parcial** correcto: sin `NaN` ni `null` accidentales; si falta un campo obligatorio para el cálculo, 400.
- `savePreferences`: **guardado parcial** (solo cambia los campos enviados; guardar en Alimentación no borra lo de Entrenamiento y viceversa; es la corrección de 1.6, imprescindible aquí).

## 7. Cambios mínimos en el navegador

Solo lo necesario para que todo siga funcionando con las validaciones:

1. Crea `public/js/api.js` con un `fetch` envuelto (`api.get/post/delete`) que: agrega el encabezado `X-Requested-With`, convierte errores en objetos `{ code, field, message }`, traduce `message` con `i18n` (`err.<code>`) y muestra el error con un **aviso en pantalla** (un pequeño componente `mostrarAviso(texto, tipo)` en `public/js/avisos.js`, que también se usará para reemplazar `alert()` en las siguientes partes). Reemplaza los `fetch('./api/...')` existentes por este cliente **sin cambiar la lógica de cada página**.
2. Los formularios (registro, Configuración, peso, km, agua) usan los **mismos límites** que el servidor (atributos `min`/`max`/`step`) y muestran el error del servidor si aun así falla. Configuración deja de ejecutar `window.location.reload()` sin comprobar la respuesta: si el guardado falla, muestra el error y no recarga.
3. Cambia los textos "Sugerencia recomendada por IA", "Nutrición y entrenamiento con inteligencia artificial" y "con IA" (`manifest.json`, README, `i18n`) por **"recomendación personalizada"** y variantes equivalentes (decisión 1.20, opción b). Quita del registro el texto "datos de demostración / prototipo".
4. Todos los HTML cargan `js/tema-inicial.js` en lugar del script en línea del tema.
5. Actualiza `service-worker.js`: `CACHE_NAME = 'nutriamigo-v20'`, estrategia **red primero con respaldo en caché**, la lista completa de archivos a precargar (incluye `js/i18n.js`, `js/dashboard.js`, `js/reminders.js`, `js/alimentacion.js`, `js/entrenamiento.js`, `js/comunidad.js`, `js/onboarding.js`, `js/api.js`, `js/avisos.js`, `js/tema-inicial.js`, los `.i18n.js`), y **no** devolver `index.html` para peticiones que no sean de navegación.

## 8. Pruebas automáticas (`tests/`)

Usa el ejecutor incluido en Node (`node --test`), sin frameworks. Crea `tests/ayudas.js` que inicia el servidor en un puerto libre con `NODE_ENV=test` y una base temporal. Solo en `NODE_ENV=test`, habilita `POST /__test/login` (crea/entra a un usuario de prueba y devuelve la cookie) para probar rutas autenticadas. **Esa ruta no debe existir fuera de `test`** (hay una prueba que lo comprueba).

Casos mínimos (todos deben pasar):

1. **Exposición de archivos:** `GET /server/server.js`, `/server/data/nutriamigo.db`, `/server/.env`, `/docs/…`, `/tests/…`, `/package.json`, `/../server/server.js` → **404**. `GET /index.html`, `/css/styles.css`, `/js/app.js` → **200**.
2. **Cabeceras:** presencia de `Content-Security-Policy`, `X-Content-Type-Options`, ausencia de `X-Powered-By`.
3. **Validación (1.5):** biometría con `peso:"abc"`, `estatura:-5`, `edad:3`, `edad:14`, `sexo:"zz"` → 400 con `code`; edad 15 válida; `vasosAgua:"abc"` y `kmRecorridos:-3` → 400; peso 251 → 400; texto de reel de 501 caracteres → 400.
4. **Menores:** edad 16 + objetivo `definir` → 400 `objetivo_no_permitido_menor`; edad 16 + `mantener` → 200.
5. **Preferencias parciales:** guardar `{proteinas, restriccionesTexto}` y luego `{frecuenciaSemanal, distanciaKm, enfoqueMuscular}`; leer y comprobar que **están las dos series de datos**.
6. **Sesiones persistentes:** iniciar sesión de prueba, reiniciar el servidor (misma base) y comprobar que la cookie sigue siendo válida.
7. **CSRF simple:** `POST /api/progress` con `Content-Type: text/plain` y sin encabezado → 403.
8. **Límites:** más de 10 intentos de login en la ventana → 429.
9. **Migraciones:** dos arranques seguidos no duplican ni fallan; una base "antigua" (con el esquema original y datos) se migra sin perder filas.
10. **Ruta de prueba:** con `NODE_ENV=development`, `POST /__test/login` → 404.
11. **Unitarias** de `validadores.js` y `calorias.js` (piso de 1.200 / 1.500, rangos límite: 30, 250, 15, 90…).

Además, comprueba **a mano en el navegador** (y describe el resultado): abrir cada una de las 7 páginas en `http://localhost:3000` sin errores en consola ni de CSP; registro de peso, agua y km, Configuración, plan de alimentación, comunidad (chat de texto) funcionando como antes.

## 9. README

Reescribe `README.md` (en español, corto y claro) con: qué es, cómo instalar Node, cómo iniciar (`INICIAR.bat` / `iniciar.sh`), cómo abrir desde el celular en la misma red, variables `.env` (tabla), estructura de carpetas, cómo correr las pruebas, y una **nota destacada**: "Antes de publicar en internet: cambiar `ADMIN_PASSWORD`, poner `COOKIE_SECURE=true` con HTTPS y definir `SESSION_SECRET`".

## 10. Criterios de aceptación de la Parte 1

- [ ] La estructura de carpetas coincide con el contexto y `organigrama.png` ya no existe.
- [ ] `INICIAR.bat`/`iniciar.sh` levantan el servidor desde cero y muestran la dirección local y las de red.
- [ ] Ningún archivo del servidor, de `docs/` ni la base de datos se puede descargar desde el navegador.
- [ ] Las sesiones sobreviven a un reinicio del servidor.
- [ ] Los datos inválidos de la lista de la sección 6 se rechazan con código y mensaje traducible.
- [ ] La edad mínima es 15 y las personas de 15 a 17 no pueden elegir `definir`.
- [ ] Guardar preferencias desde una página ya no borra las de la otra.
- [ ] Ninguna página muestra errores de consola ni de CSP; el tema por defecto es claro.
- [ ] No queda ninguna mención visible de "IA" como característica ni de "demostración/prototipo".
- [ ] `node --test` pasa completo.
- [ ] La respuesta final resume lo hecho, los archivos cambiados, cómo probarlo y lo que quedó pendiente para la Parte 2.
