# Fuentes y criterios de nutrición (Parte 5)

Los valores del catálogo (`public/data/ingredientes.js`) son por 100 g del alimento tal como se pesa
(cocido, crudo, seco o líquido, según el campo `estado`) y son **aproximados**: sirven para planear, no para uso clínico.

## De dónde salen
- Base: tablas de composición de alimentos de USDA FoodData Central (valores de referencia conocidos de cada alimento).
- Alimentos de uso colombiano (arepa, papa criolla, plátano, yuca, panela, queso campesino): se contrastaron con el orden de magnitud de las tablas del ICBF; varían por receta y marca.
- Cada fila se verifica con la relación de Atwater (4·proteína + 4·carbohidratos + 9·grasa ≈ kcal, tolerancia 20 %): ver la primera prueba de `tests/generador.test.js`.

## Valores menos seguros (revisar con una fuente propia antes de usarlos en serio)
`arepa`, `papa_criolla`, `yuca` (cocida, tomada como equivalente a la cruda), `queso_campesino`, `queso_vegano`, `yogur_vegetal`,
`proteina_arveja`, `jamon_pavo`, `mantequilla_mani`, `leche_avena`: dependen mucho de la marca o la receta.

## Reglas de seguridad
- Meta calórica mínima: 1200 kcal (mujer) y 1500 kcal (hombre). Está en el servidor (`server/lib/calorias.js`) y ahora también en el cliente (`public/js/calorias.js`).
- Ayuno intermitente: solo mayores de 18 años y con IMC ≥ 18,5. Se valida en el servidor y en la pantalla.
- Cada plato queda a ±7 % de las calorías de su comida; la proteína es una meta de mejor esfuerzo.
- Las etiquetas (alergias, dieta) filtran por datos del ingrediente, nunca por texto. El texto libre se traduce a etiquetas con palabras clave (es/en/de); si la palabra aparece, se excluye (por seguridad también cuando la persona dice "me gusta el cerdo").
- Nada de esto reemplaza a un profesional de la salud.
