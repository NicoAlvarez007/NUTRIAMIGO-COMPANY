# NutriAmigo — CONTEXTO GENERAL (pegar al inicio de CADA parte del prompt)

> Este documento explica el proyecto, las reglas de trabajo y todas las decisiones ya tomadas por el dueño.
> La IA que implementa debe leerlo completo antes de escribir código y **no debe volver a preguntar nada de lo que ya está decidido aquí**.
> Cada parte del prompt (`PARTE-01`, `PARTE-02`…) se entrega por separado; el proyecto debe quedar funcionando al terminar cada una.

---

## 1. Qué es el proyecto

**NutriAmigo** (nombre legal: **Nuestro Amigo**) es una aplicación web de nutrición y entrenamiento. La persona se registra, mete sus datos (peso, estatura, sexo, edad, nivel de actividad, objetivo) y la página le muestra su IMC, su meta de calorías, sus macronutrientes, un plan de alimentación semanal y un plan de entrenamiento semanal. Tiene racha de constancia (estilo Duolingo), logros, registro de peso, agua y kilómetros, comunidad (chat, reels, amigos) y membresía Premium.

- **Estado actual:** demostración que se va a presentar. Después se rehará como producto real (con IA real, hosting y pagos). Por eso ahora se construye **solo con código propio**.
- **Cómo se usa ahora:** se ejecuta en el computador del dueño (`npm start`) y se abre en `http://localhost:3000`. Para probar en celular/tableta se abre desde la misma red Wi-Fi con la dirección IP del computador (ver regla 3.7). **No hay hosting ni link público todavía.**
- **Código base:** el proyecto ya existe (zip `nutriamigo-web-fixed (6).zip`): páginas HTML (`index`, `onboarding`, `dashboard`, `alimentacion`, `entrenamiento`, `comunidad`, `premium`), CSS y JS del navegador, datos de comidas/rutinas/preguntas frecuentes en `data/`, y un backend Node/Express + SQLite (`better-sqlite3`) + Socket.io + Passport (Google). **No se reescribe desde cero: se mejora lo que existe.**

## 2. Stack y qué cuenta como "código propio"

- Navegador: HTML, CSS y JavaScript **sin framework** (como está). Sin paso de compilación.
- Servidor: Node.js ≥ 18, Express, SQLite con `better-sqlite3`, Socket.io.
- Se permiten **librerías gratuitas de `npm`** (por ejemplo `helmet`, `express-rate-limit`, Chart.js, KaTeX). Las librerías que use el navegador se **copian dentro de `public/vendor/`** para que funcionen sin internet; no se cargan desde un CDN.
- **Prohibido en este prompt** (va en otra etapa): cualquier cuenta o servicio de terceros: Cloudinary, hosting, bases de datos en la nube, APIs de IA, pasarelas de pago, correo automático, Open Food Facts, notificaciones push reales, login real con Facebook/Apple. Donde la función exista visualmente, se **simula localmente** como indica cada parte.

## 3. Reglas de trabajo para la IA que implementa

1. **Compatibilidad con Visual Studio Code y Windows/Mac/Linux.** Nada que dependa de una sola plataforma; los scripts de inicio tienen versión `.bat` (Windows) y `.sh`.
2. **Sin comentarios "estilo IA"** en el código: solo comentarios técnicos breves y necesarios, en español.
3. **No romper lo que ya funciona.** Antes de mover o cambiar algo, leer el archivo actual. Al terminar cada parte, todas las páginas siguen abriendo.
4. **Textos visibles en 3 idiomas: español (por defecto), inglés y alemán.** Todo texto nuevo entra al diccionario `i18n` con las 3 claves (`es` incluido en el HTML, `en` y `de` en el diccionario). Nada de textos sueltos en `alert()` sin traducir.
5. **Nunca mostrar las palabras "demo", "demostración" o "prototipo"** en la interfaz visible al usuario normal. (La pantalla de pago simulada muestra "Pago seguro", sin decir demo; los avisos internos solo los ve el administrador.)
6. **Validar SIEMPRE en el servidor**, aunque el formulario ya valide. Nunca confiar en lo que manda el navegador (ni el autor de un mensaje, ni el `user_id`, ni si es Premium).
7. **Servidor accesible en la red local:** escuchar en `0.0.0.0` e imprimir al iniciar la dirección local y las de red (por ejemplo `http://192.168.1.20:3000`) para abrir la página desde el celular.
8. **Cada parte termina con pruebas.** Además de probar a mano, dejar pruebas automáticas en `tests/` (`node --test`) y, desde la Parte 2, revisión en navegador a 390 px (celular), 820 px (tableta) y 1280 px (escritorio) comprobando que no hay desbordamiento horizontal.
9. **Migraciones de base de datos numeradas** (ver Parte 1): nunca borrar la base del usuario; toda tabla o columna nueva entra por una migración.
10. **Entregar cada parte con un resumen breve**: qué se hizo, qué archivos cambiaron, cómo probarlo y qué quedó pendiente. Si algo de la parte no se pudo hacer, decirlo claramente; no fingir que quedó hecho.
11. **No inventar datos legales, médicos ni de contacto.** Usar solo los de la sección 7.
12. **Accesibilidad mínima en todo lo nuevo:** etiquetas en los campos, foco visible, contraste suficiente, botones de al menos 44×44 px en móvil, `aria-label` en botones de solo ícono.

## 4. Estilo visual (ya definido por el dueño)

Inspirado en Apple: limpio, interactivo, mucho aire, esquinas redondeadas, animaciones suaves (respetando `prefers-reduced-motion`). **Colores: verde claro y blanco** como base (los tokens `--green-*` ya existen en `css/styles.css`); sin negro puro ni verde oscuro en el tema claro. El tema oscuro existe como opción de la persona en Configuración, **pero el tema por defecto es siempre el claro** (quitar el cambio automático a oscuro de 7 p. m. a 7 a. m.). El logo está en `assets/logo.png`.

## 5. Estructura de carpetas objetivo

```
NutriAmigo/
├── docs/                        documentos y prompts (no se sirven al navegador)
├── public/                      TODO lo que ve el navegador (es lo único que sirve Express)
│   ├── index.html  onboarding.html  dashboard.html  alimentacion.html
│   ├── entrenamiento.html  comunidad.html  premium.html  logros.html  admin.html ...
│   ├── css/  js/  data/  assets/  vendor/
│   ├── manifest.json  service-worker.js
│   └── quimica/                 Versión 2 (solo desde el panel de admin)
├── server/
│   ├── server.js                arranque
│   ├── config.js                lee .env y valida
│   ├── db/                      conexión, migraciones, consultas
│   ├── routes/                  una ruta por tema (auth, progress, plan, community, admin…)
│   ├── middleware/              auth, validación, límites, seguridad
│   ├── lib/                     utilidades (fechas, calorías, contraseñas, validadores)
│   ├── data/                    nutriamigo.db (NO se sube a git) 
│   ├── uploads/                 fotos de progreso y de reels (NO se sube a git)
│   ├── .env.example
│   └── package.json
├── tests/
├── INICIAR.bat   iniciar.sh     instalan dependencias si faltan y arrancan el servidor
├── .gitignore
└── README.md
```

## 6. Decisiones cerradas (no volver a preguntar)

| Tema | Decisión |
|---|---|
| Alcance | Todo lo que sea código propio se implementa; lo externo queda para el final y **no** va en este prompt. |
| Texto "IA" (1.20) | **Opción b:** ahora se escribe **"recomendación personalizada"**, no "IA". Cuando exista la IA real se cambiará. Aplica a: tarjeta del dashboard, titular de la portada, `manifest.json`, README y diccionario de idiomas. |
| Administrador | Usuario `administrador` (acepta usuario **o** correo), contraseña inicial `12345678`. Se leen de `server/.env` (`ADMIN_USER`, `ADMIN_PASSWORD`) y `.env.example` los trae con esos valores. Como por ahora no se publica en línea, el dueño acepta que se vea. **Antes de publicar hay que cambiarla** (dejar esta nota en el README). |
| Cuentas | **Un correo = una cuenta.** Se puede entrar con correo + contraseña o con Google (simulado localmente si no hay credenciales de Google en `.env`). Si el correo ya existe, no se crea otra cuenta: se inicia sesión y, si venía de Google y no tenía contraseña, se le permite crearla. |
| Facebook / Apple | Botones visibles con la etiqueta **"Próximamente"**, desactivados. |
| Fotos de progreso | Se guardan en `server/uploads/<idUsuario>/` (sin servicios externos), máximo 60 por persona, solo JPEG reducido a 1080 px, servidas solo a su dueño. |
| Racha | Ver 8.1. |
| Recalcular el plan por peso | Diferencia mínima de **5 kg** respecto al peso del plan. Ver 8.2. |
| Kilómetros | Suman calorías a la meta del día y se muestra "calorías cambiadas por entrenamiento". Ver 8.3. |
| Medidas ("Mostrar medidas") | Función **Premium**, botón dentro de "Personalizar" en Alimentación. |
| Ayuno intermitente | Solo **Premium**, dentro de "Personalizar". Solo mayores de 18 y con IMC ≥ 18,5. |
| "Ya lo hice" | Se reinicia solo cada día; **solo se puede marcar el día de hoy**; además hay botón **"Reiniciar"** visible (reinicia lo marcado hoy). |
| Edad | Mínimo **15 años**. De 15 a 17: solo objetivos *mantener* o *subir de peso*, **sin déficit calórico y sin ayuno**, y el registro exige **autorización de un adulto** (ver 8.5). |
| Comunidad | El administrador puede **borrar cualquier reel/mensaje y suspender usuarios**. El autor puede borrar los suyos. Un voto por persona. |
| Premium | **$3.000 COP/mes** y **$30.000 COP/año** (precio fijo). Pantalla de pago simulada (ver Parte 10). |
| Notificaciones | Si el navegador las bloquea o no existen, se reemplazan por **avisos dentro de la página** (globos/toasts). |
| Idiomas | **es / en / de** en toda la app (el chat deja de usar portugués). |
| Versión Química | **Carpeta aparte** `public/quimica/`, accesible **solo desde el panel de administrador**. Nivel: secundaria/bachillerato (el dueño no indicó curso; ajustable). |
| Librerías npm | Cuentan como código propio; se copian a `public/vendor/`. |
| Términos y condiciones | Se crean en la Parte 10 (ver sección 7). |

## 7. Datos de la empresa (para términos y condiciones, pie de página y contacto)

- **Nombre legal / marca:** Nuestro Amigo (producto: NutriAmigo).
- **Representante legal:** Andrés Felipe Fajardo (segundo apellido: `[POR CONFIRMAR]`).
- **Ciudad:** `Yopal, Casanare, Colombia` — `[POR CONFIRMAR: la ciudad se dictó por voz; verificar antes de publicar]`.
- **Correo de contacto:** `nutriamigo@gmail.com` (es el que ya usa la app) — `[POR CONFIRMAR si debe cambiar a nuestroamigo@gmail.com]`.
- **País de origen:** Colombia.
- Poner estos valores en **un solo archivo** (`public/js/empresa.js` o `server/config.js`) para cambiarlos en un solo lugar. Los `[POR CONFIRMAR]` deben verse como marcadores visibles en el borrador de los términos.

## 8. Reglas de negocio

### 8.1 Racha (estilo Duolingo)
- Empieza en **0**. Sube **+1 por día** en que la persona hace **al menos una** de estas acciones: **marcar una comida, marcar una rutina de entrenamiento o registrar su peso**. Iniciar sesión, tomar agua o registrar km **no** cuentan para la racha (sí cuentan para logros).
- El "día" es el día **local del usuario** (por defecto zona `America/Bogota`), no UTC.
- **Protectores de racha (🧊):** se gana **1 por cada 7 días de racha**; máximo **2** guardados. **Premium**: recibe **1 protector extra** (máximo 3 guardados) y **+1 protector regalado cada mes de suscripción activa**.
- Si pasa un día sin acción: se consume 1 protector si hay (la racha se conserva, ese día "congelado" no suma); si no hay protector, la racha **vuelve a 0**.
- La interfaz muestra: llama con el número, protectores disponibles, y el mensaje "hoy te falta una acción para mantener tu racha" cuando corresponde.
- El panel de administrador puede cambiar la fecha simulada para probarlo (Parte 3/4).

### 8.2 Peso y plan
- Todo peso registrado se guarda en el historial.
- Configuración → categoría **"Registro de peso"** con dos interruptores:
  1. **"Actualizar mi plan cuando registre un peso nuevo"**. Apagado: el plan conserva el peso inicial. Encendido: si la diferencia entre el peso nuevo y el peso del plan es **≥ 5 kg**, se recalcula el plan.
  2. **"Avisarme antes de cambiar mi plan"** (solo se puede encender si el 1 está encendido). Encendido: aviso arriba "Vas a cambiar tu plan de X kg a Y kg" con **Aceptar / Cancelar**. Apagado: se cambia directo sin preguntar.
- El umbral vive en una constante (`PESO_UMBRAL_KG = 5`).

### 8.3 Agua, kilómetros y calorías
- Meta de agua = **35 ml × peso (kg)**, en vasos de 250 ml, redondeada hacia arriba.
- **Calorías por kilómetros** = `km × peso(kg) × 0.75` (constante `KCAL_POR_KM_POR_KG`), máximo 800 kcal por día. Se **suman a la meta calórica del día** y se muestra una línea: **"Calorías cambiadas por entrenamiento: +N kcal"**. El panel del día usa `meta base + N`.
- La meta de kilómetros semanal sale de la frecuencia y la distancia que la persona elige en Entrenamiento (Premium).

### 8.4 Calorías y seguridad
- Fórmula actual (Mifflin-St Jeor) se mantiene. **Piso:** 1.200 kcal (mujeres), 1.500 kcal (hombres); nunca recomendar menos.
- **Distribución por comida** (base de 4 comidas): desayuno 25 %, almuerzo 35 %, media tarde 10 %, cena 30 %; con ayuno intermitente se redistribuye entre las comidas que quedan.
- Mostrar el cálculo paso a paso (gasto basal → gasto total → objetivo).

### 8.5 Menores de 15 a 17 años
- Menores de 15: **no se permite el registro** (mensaje claro).
- De 15 a 17: el registro pide **nombre del adulto responsable, parentesco, teléfono o correo y una casilla de autorización**; se guarda con fecha y hora. Solo pueden elegir objetivo *mantener* o *subir de peso*. Sin ayuno. Aviso de que las recomendaciones no reemplazan a un profesional.

### 8.6 Premium
- Precio: $3.000 COP/mes o $30.000 COP/año. Al aprobarse el pago simulado se guardan `premium_desde`, `premium_hasta` y `renovacion` (= `premium_hasta` − 2 días). Al vencer sin renovar, vuelve a gratuito automáticamente. Funciones Premium: sin anuncios, personalizar alimentación (proteínas, restricciones, medidas, ayuno), personalizar entrenamiento (frecuencia, distancia, enfoque), rangos visibles, protector de racha extra, lista de espera del entrenador humano.

### 8.7 "Ya lo hice"
- Cada comida/rutina tiene su marca por **fecha local**. Solo se marca el día de hoy; en los demás días de la semana se muestra solo lectura. Las opciones 1 y 2 de cada comida se eligen con **botones** (no una encima de otra). Botón **"Reiniciar"** que borra las marcas de hoy. Se reinicia solo al cambiar el día.

### 8.8 Rangos
Se mantienen los umbrales actuales (bronce/plata/oro/platino según racha y total de acciones) y ahora tienen **efecto visible**: marco del avatar con el color del rango y distintivo junto al nombre en chat y reels.

## 9. Datos que se guardan (resumen del modelo objetivo)

Se van creando por migraciones, parte por parte: `users` (con `email`, `username`, `password_hash`, `role` = user/admin, `suspended`, `premium_desde/hasta`, `plan` …), `sessions`, `biometrics` (+ consentimiento de adulto), `progress`, `daily_logs`, `completions` (con fecha local), `streaks` (racha, protectores, último día), `settings` (interruptores de peso y avisos), `progress_photos`, `friendships`, `dm_messages`, `chat_messages`, `reels`, `reel_votes`, `reports`, `subscriptions`, `audit_log`, `bot_unanswered`, `waitlist`.

## 10. Fuera de alcance de este prompt (NO implementar)

Hosting/link público, Cloudinary, IA real, pasarela de pago real, correo automático, notificaciones push reales, Facebook/Apple reales, Open Food Facts, Google Fit, videos/GIF de ejercicios, anuncios reales, base de datos en la nube, app móvil. Dejar los puntos de integración preparados (interfaces simples) pero sin conectar nada.

## 11. Definición de "terminado" de cada parte

- Todas las páginas abren sin errores en la consola.
- Las pruebas de `tests/` pasan (`node --test`).
- No hay desbordamiento horizontal a 390/820/1280 px (desde la Parte 2).
- Todo texto nuevo existe en es/en/de.
- Nada nuevo depende de internet para funcionar.
- El resumen final cumple la regla 3.10.

## 12. Índice de partes (se entregan una por una)

1. Carpetas + servidor seguro (1.1, 1.4, 1.5, validaciones, migraciones, arranque local y en red)
2. Diseño responsive en todas las páginas y barra inferior en móvil (sección 0)
3. Cuentas con correo y contraseña + pantalla de acceso + panel de administrador
4. Fechas locales, racha estilo Duolingo, protectores
5. Alimentación: generador de platos, filtros, botones de opciones, medidas, ayuno
6. Entrenamiento: frecuencia, distancia, series/descansos, generador
7. Dashboard: gráfica unificada, agua y km, configuración de registro de peso, fotos de progreso
8. Logros y rangos
9. Comunidad: chat autenticado, amigos reales, reels, moderación
10. Premium simulado, cookies, términos y condiciones
11. Bot, traducción, idiomas, PWA, accesibilidad
12. Versión 2 Química

## 13. Supuestos que la IA debe respetar y anunciar (el dueño no los especificó)

- Premium recibe 1 protector de racha extra y +1 por mes (el dueño dijo solo "que el premium reciba uno extra").
- La pestaña **Logros** va en la barra superior junto a Alimentación y también hay acceso en el menú de perfil.
- La ciudad y el correo de la empresa quedan marcados `[POR CONFIRMAR]`.
- Curso/nivel de la Versión Química: secundaria/bachillerato.
