const WORKOUTS_DATA = {
  "definir": {
    "lunes": [
      "Cardio moderado 35 min + core",
      "Circuito de fuerza con repeticiones altas"
    ],
    "martes": [
      "Caminata rápida 40 min",
      "Rutina de tren superior con bandas"
    ],
    "miercoles": [
      "Bicicleta o elíptica 30 min",
      "Circuito HIIT de 20 min"
    ],
    "jueves": [
      "Cardio moderado 35 min + core",
      "Rutina de tren inferior con peso corporal"
    ],
    "viernes": [
      "Caminata activa 40 min",
      "Circuito de fuerza con repeticiones altas"
    ],
    "sabado": [
      "Deporte recreativo o caminata larga",
      "Yoga o movilidad 30 min"
    ],
    "domingo": [
      "Descanso activo: estiramiento 20 min",
      "Caminata suave 30 min"
    ]
  },
  "mantener": {
    "lunes": [
      "Fuerza full-body con pesas moderadas",
      "Cardio ligero 25 min"
    ],
    "martes": [
      "Caminata o trote suave 30 min",
      "Rutina de tren superior"
    ],
    "miercoles": [
      "Fuerza full-body con pesas moderadas",
      "Yoga o movilidad 25 min"
    ],
    "jueves": [
      "Cardio ligero 25 min",
      "Rutina de tren inferior"
    ],
    "viernes": [
      "Fuerza full-body con pesas moderadas",
      "Deporte recreativo"
    ],
    "sabado": [
      "Caminata larga o ciclismo",
      "Estiramiento y movilidad"
    ],
    "domingo": [
      "Descanso activo",
      "Caminata suave 30 min"
    ]
  },
  "volumen": {
    "lunes": [
      "Fuerza — tren superior, cargas altas",
      "Empuje: pecho, hombro y tríceps"
    ],
    "martes": [
      "Fuerza — tren inferior, cargas altas",
      "Tracción: espalda y bíceps"
    ],
    "miercoles": [
      "Descanso activo o movilidad",
      "Cardio corto de baja intensidad"
    ],
    "jueves": [
      "Empuje: pecho, hombro y tríceps",
      "Fuerza — tren superior, cargas altas"
    ],
    "viernes": [
      "Tracción: espalda y bíceps",
      "Fuerza — tren inferior, cargas altas"
    ],
    "sabado": [
      "Accesorios y core",
      "Enfoque muscular a elección"
    ],
    "domingo": [
      "Descanso completo",
      "Movilidad y estiramiento"
    ]
  }
};
