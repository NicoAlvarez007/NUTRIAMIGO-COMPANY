/* Plantillas de plato. Un plato = plantilla + ingredientes elegidos por el generador.
   roles: P proteína principal, D proteína de desayuno, C carbohidrato de almuerzo/cena, B carbohidrato de desayuno,
          V verdura, F fruta, G grasa, L lácteo o alternativa, S snack, X endulzante. "V2", "F2" repiten el rol.
          "B=avena,pan_integral" limita el rol a esos ingredientes.
   coccion: filtra la proteína principal por la forma de cocinarla (ingrediente.cocciones). */
(function (global) {
  const LECHES = 'leche_entera,leche_deslactosada,leche_avena,leche_soya,leche_almendra';
  const YOGURES = 'yogur_natural,yogur_griego,yogur_vegetal';
  const FRUTOS = 'almendras,nueces,mani';
  const T = (id, comidas, roles, es, en, de, coccion) => ({ id, comidas: comidas.split(' '), roles: roles.split(' '), nombre: { es, en, de }, coccion: coccion || null });
  const DC = 'desayuno', MT = 'media_tarde', AC = 'almuerzo cena';

  const lista = [
    /* Desayuno */
    T('d_revuelto', DC, 'D=huevo,tofu B F', 'Revuelto de {D} con {B} y {F}', '{D} scramble with {B} and {F}', '{D}-Scramble mit {B} und {F}', 'revuelto'),
    T('d_avena_leche', DC, `B=avena L=${LECHES} F`, 'Avena cocida en {L} con {F}', 'Oats cooked in {L} with {F}', 'Haferflocken in {L} mit {F}'),
    T('d_bowl_yogur', DC, `L=${YOGURES} B=avena F G=chia,${FRUTOS}`, 'Bowl de {L} con {B}, {F} y {G}', 'Bowl of {L} with {B}, {F} and {G}', 'Bowl mit {L}, {B}, {F} und {G}'),
    T('d_arepa_proteina', DC, 'B=arepa D=huevo,queso_campesino,tofu F', 'Arepa con {D} y {F}', 'Arepa with {D} and {F}', 'Arepa mit {D} und {F}'),
    T('d_tostadas', DC, 'B=pan_integral,tortilla_maiz G=aguacate D=huevo,queso_campesino,jamon_pavo,tofu F', 'Tostadas de {B} con {G} y {D}, con {F} al lado', 'Toast of {B} with {G} and {D}, with {F} on the side', 'Toast aus {B} mit {G} und {D}, dazu {F}'),
    T('d_batido', DC, `F L=${LECHES} D=proteina_arveja,yogur_griego,yogur_vegetal G=chia,${FRUTOS},mantequilla_mani`, 'Batido de {F} con {L}, {D} y {G}', 'Smoothie of {F} with {L}, {D} and {G}', 'Smoothie aus {F} mit {L}, {D} und {G}'),
    T('d_avena_remojada', DC, `B=avena L=${YOGURES} F G=chia,${FRUTOS}`, 'Avena remojada en {L} con {F} y {G}', 'Overnight oats in {L} with {F} and {G}', 'Overnight Oats in {L} mit {F} und {G}'),
    T('d_tortilla_huevo', DC, 'D=huevo,tofu V=espinaca,tomate,champinones,pimenton,cebolla B=arepa,pan_integral,tortilla_maiz', 'Tortilla de {D} con {V} y {B}', '{D} omelette with {V} and {B}', 'Omelett mit {D}, {V} und {B}', 'tortilla'),
    T('d_platano', DC, 'B=platano_maduro D=queso_campesino,huevo,tofu F', 'Plátano maduro con {D} y {F}', 'Ripe plantain with {D} and {F}', 'Reife Kochbanane mit {D} und {F}'),
    T('d_sandwich', DC, 'B=pan_integral,tortilla_maiz D=jamon_pavo,queso_campesino,tofu V=tomate,pepino,lechuga F', 'Sándwich de {D} con {V} en {B}, acompañado de {F}', 'Sandwich of {D} with {V} on {B}, with {F} on the side', 'Sandwich mit {D} und {V} auf {B}, dazu {F}'),
    T('d_salteado', DC, 'B=papa_criolla,batata D=huevo,queso_campesino,tofu V=tomate,cebolla,pimenton,espinaca', '{B} salteada con {D} y {V}', 'Sautéed {B} with {D} and {V}', 'Gebratene {B} mit {D} und {V}'),
    T('d_frutas_lacteo', DC, `F F2 L=${YOGURES} G=chia,${FRUTOS}`, 'Ensalada de {F} y {F2} con {L} y {G}', 'Fruit salad of {F} and {F2} with {L} and {G}', 'Obstsalat aus {F} und {F2} mit {L} und {G}'),
    T('d_frutas_proteina', DC, 'F F2 D=proteina_arveja G=chia,aguacate', 'Bowl de {F} y {F2} con {D} y {G}', 'Bowl of {F} and {F2} with {D} and {G}', 'Bowl aus {F} und {F2} mit {D} und {G}'),
    T('d_criollo_legumbre', DC, 'B=arepa,platano_maduro,papa_criolla P=frijoles,garbanzos,lentejas G=aguacate', '{B} con {P} y {G}', '{B} with {P} and {G}', '{B} mit {P} und {G}'),

    /* Almuerzo y cena */
    T('m_plancha', AC, 'P C V G=aceite_oliva', '{P} a la plancha con {C} y ensalada de {V}', 'Grilled {P} with {C} and {V} salad', '{P} vom Grill mit {C} und {V}-Salat', 'plancha'),
    T('m_horno', AC, 'P C V G=aceite_oliva', '{P} al horno con {C} y {V}', 'Baked {P} with {C} and {V}', '{P} aus dem Ofen mit {C} und {V}', 'horno'),
    T('m_salteado', AC, 'P V C G=aceite_oliva', 'Salteado de {P} con {V} y {C}', 'Stir-fried {P} with {V} and {C}', 'Gebratenes {P} mit {V} und {C}', 'salteado'),
    T('m_guiso', AC, 'P C V G=aceite_oliva', 'Guiso de {P} con {C} y {V}', 'Stew of {P} with {C} and {V}', 'Eintopf mit {P}, {C} und {V}', 'guisado'),
    T('m_sudado', AC, 'P C V', 'Sudado de {P} con {C} y {V}', 'Braised {P} with {C} and {V}', 'Geschmortes {P} mit {C} und {V}', 'sudado'),
    T('m_sopa', AC, 'P=pechuga_pollo,muslo_pollo,lentejas,garbanzos,frijoles C=papa,yuca,platano_verde,maiz,arroz_blanco V', 'Sopa de {P} con {C} y {V}', 'Soup of {P} with {C} and {V}', 'Suppe mit {P}, {C} und {V}', 'sopa'),
    T('m_bowl', AC, 'P C V G=aguacate', 'Bowl de {P} con {C}, {V} y {G}', 'Bowl of {P} with {C}, {V} and {G}', 'Bowl mit {P}, {C}, {V} und {G}', 'frio'),
    T('m_ensalada', AC, 'P V=lechuga,espinaca,repollo,tomate,pepino V2=zanahoria,tomate,pimenton,remolacha,pepino C=papa,quinoa,maiz,batata,arroz_integral G=aceite_oliva', 'Ensalada de {P} con {V}, {V2} y {C}', 'Salad of {P} with {V}, {V2} and {C}', 'Salat mit {P}, {V}, {V2} und {C}', 'frio'),
    T('m_pasta', AC, 'P C=pasta V G=aceite_oliva', 'Pasta con {P} y {V}', 'Pasta with {P} and {V}', 'Pasta mit {P} und {V}', 'salteado'),
    T('m_arroz', AC, 'P C=arroz_blanco,arroz_integral,quinoa V G=aceite_oliva', '{C} con {P} y {V}', '{C} with {P} and {V}', '{C} mit {P} und {V}', 'guisado'),
    T('m_tacos', AC, 'P C=tortilla_maiz V=repollo,tomate,cebolla,pimenton G=aguacate', 'Tacos de {P} con {V} y {G}', 'Tacos with {P}, {V} and {G}', 'Tacos mit {P}, {V} und {G}', 'salteado'),
    T('m_filete', AC, 'P=salmon,tilapia C V', 'Filete de {P} con {C} y {V}', 'Fillet of {P} with {C} and {V}', 'Filet von {P} mit {C} und {V}'),
    T('m_tortilla', AC, 'P=huevo,tofu C=papa,arepa,batata,platano_maduro V', 'Tortilla de {P} con {V} y {C}', '{P} omelette with {V} and {C}', 'Omelett mit {P}, {V} und {C}', 'tortilla'),
    T('m_plato_aguacate', AC, 'P C V G=aguacate', 'Plato de {P} con {C}, {V} y {G}', 'Plate of {P} with {C}, {V} and {G}', 'Teller mit {P}, {C}, {V} und {G}', 'plancha'),
    T('m_curri', AC, 'P=pechuga_pollo,tofu,garbanzos,lentejas,tempeh V=ahuyama,coliflor,espinaca,zanahoria,pimenton C=arroz_blanco,arroz_integral,quinoa G=aceite_oliva', 'Curri de {P} con {V} y {C}', 'Curry of {P} with {V} and {C}', 'Curry mit {P}, {V} und {C}', 'guisado'),

    /* Media tarde */
    T('s_fruta_frutos', MT, `F S=${FRUTOS},chia`, '{F} con {S}', '{F} with {S}', '{F} mit {S}'),
    T('s_yogur_fruta', MT, `L=${YOGURES} F`, '{L} con {F}', '{L} with {F}', '{L} mit {F}'),
    T('s_yogur_chia', MT, `L=${YOGURES} F G=chia`, '{L} con {F} y {G}', '{L} with {F} and {G}', '{L} mit {F} und {G}'),
    T('s_batido', MT, `F L=${LECHES}`, 'Batido de {F} con {L}', 'Smoothie of {F} with {L}', 'Smoothie aus {F} mit {L}'),
    T('s_tostada', MT, 'B=pan_integral,tortilla_maiz G=aguacate,mantequilla_mani F', 'Tostada de {B} con {G} y {F}', 'Toast of {B} with {G} and {F}', 'Toast aus {B} mit {G} und {F}'),
    T('s_arepa_queso', MT, 'B=arepa S=queso_campesino,queso_vegano F', 'Arepa con {S} y {F}', 'Arepa with {S} and {F}', 'Arepa mit {S} und {F}'),
    T('s_platano_queso', MT, 'B=platano_maduro,papa_criolla,batata S=queso_campesino,queso_vegano', '{B} con {S}', '{B} with {S}', '{B} mit {S}'),
    T('s_mix', MT, `S=${FRUTOS} F`, 'Mix de {S} y {F}', 'Mix of {S} and {F}', 'Mix aus {S} und {F}'),
    T('s_huevo_cocido', MT, 'D=huevo V=zanahoria,pepino F', 'Huevo cocido con palitos de {V} y {F}', 'Boiled egg with {V} sticks and {F}', 'Gekochtes Ei mit {V}-Sticks und {F}', 'cocido'),
    T('s_palitos_aguacate', MT, 'V=zanahoria,pepino,pimenton G=aguacate F', 'Palitos de {V} con {G} y {F}', '{V} sticks with {G} and {F}', '{V}-Sticks mit {G} und {F}'),
    T('s_avena_fria', MT, `B=avena L=${LECHES} F`, 'Avena fría con {L} y {F}', 'Cold oats with {L} and {F}', 'Kalte Haferflocken mit {L} und {F}'),
    T('s_wrap', MT, 'B=tortilla_maiz,pan_integral D=queso_campesino,jamon_pavo,tofu V=tomate,pepino,lechuga,zanahoria', 'Mini wrap de {B} con {D} y {V}', 'Mini wrap of {B} with {D} and {V}', 'Mini-Wrap aus {B} mit {D} und {V}'),
    T('s_fruta_miel', MT, `F X=miel,panela S=${FRUTOS}`, '{F} con {X} y {S}', '{F} with {X} and {S}', '{F} mit {X} und {S}'),
    T('s_fruta_proteina', MT, 'F F2 D=yogur_griego,yogur_natural,yogur_vegetal,proteina_arveja', 'Fruta picada ({F} y {F2}) con {D}', 'Chopped fruit ({F} and {F2}) with {D}', 'Obstsalat ({F} und {F2}) mit {D}')
  ];

  const api = { lista };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else global.NA_PLANTILLAS = api;
})(typeof window !== 'undefined' ? window : globalThis);
