const FAQ_DATA = [
  {
    "id": 1,
    "keywords": [
      "que es nutriamigo",
      "para que sirve la app",
      "que hace esta aplicacion",
      "de que trata la empresa",
      "que es esta empresa",
      "de que se trata esto",
      "que hace nutriamigo"
    ],
    "pregunta": "¿Qué es NutriAmigo?",
    "respuesta": "Es una app que te da un plan de alimentación y entrenamiento personalizado según tu objetivo: definir, mantener o aumentar volumen."
  },
  {
    "id": 2,
    "keywords": [
      "es gratis",
      "cuesta algo",
      "tiene costo la app",
      "debo pagar para usarla",
      "tiene version gratuita",
      "puedo usarla sin pagar"
    ],
    "pregunta": "¿Es gratis usar NutriAmigo?",
    "respuesta": "Sí. La versión gratuita incluye planes básicos con anuncios. La versión Premium quita los anuncios y desbloquea personalización avanzada."
  },
  {
    "id": 3,
    "keywords": [
      "que incluye premium",
      "beneficios premium",
      "que trae la version paga",
      "que gano si pago premium",
      "por que pagar premium",
      "vale la pena premium"
    ],
    "pregunta": "¿Qué incluye la versión premium?",
    "respuesta": "Sin anuncios, personalización completa de tus planes de comida y entrenamiento, y acceso al sistema de rangos."
  },
  {
    "id": 4,
    "keywords": [
      "cuanto cuesta premium",
      "precio premium",
      "valor de la suscripcion"
    ],
    "pregunta": "¿Cuánto cuesta Premium?",
    "respuesta": "Puedes ver los precios y planes disponibles en la sección Premium de la app."
  },
  {
    "id": 5,
    "keywords": [
      "como cancelo premium",
      "cancelar suscripcion",
      "dar de baja premium"
    ],
    "pregunta": "¿Cómo cancelo Premium?",
    "respuesta": "Desde tu perfil puedes gestionar tu suscripción y cancelarla cuando quieras; seguirás teniendo acceso hasta el fin del periodo pagado."
  },
  {
    "id": 6,
    "keywords": [
      "como inicio sesion",
      "como entro a mi cuenta",
      "login"
    ],
    "pregunta": "¿Cómo inicio sesión?",
    "respuesta": "Usa el botón \"Continuar con Google\" en la página principal; no necesitas crear una contraseña nueva."
  },
  {
    "id": 7,
    "keywords": [
      "necesito cuenta de google",
      "tengo que usar gmail",
      "puedo entrar sin google"
    ],
    "pregunta": "¿Necesito una cuenta de Google?",
    "respuesta": "Sí, por ahora el ingreso es exclusivamente con una cuenta de Google."
  },
  {
    "id": 8,
    "keywords": [
      "puedo usar otro correo",
      "correo diferente a gmail",
      "otro email"
    ],
    "pregunta": "¿Puedo usar un correo distinto a Gmail?",
    "respuesta": "Puedes iniciar sesión con cualquier cuenta de Google, incluso si usas ese correo para otro proveedor."
  },
  {
    "id": 9,
    "keywords": [
      "es seguro dar mi cuenta",
      "es seguro el login con google",
      "riesgo de usar google"
    ],
    "pregunta": "¿Es seguro iniciar sesión con Google?",
    "respuesta": "Sí. NutriAmigo nunca ve ni guarda tu contraseña; Google solo comparte tu nombre y correo para crear tu perfil."
  },
  {
    "id": 10,
    "keywords": [
      "que datos guardan de mi",
      "que informacion guardan",
      "privacidad de mis datos"
    ],
    "pregunta": "¿Qué datos guardan de mí?",
    "respuesta": "Guardamos tu nombre, correo, fecha de creación de la cuenta, tu progreso de peso y tus preferencias de plan."
  },
  {
    "id": 11,
    "keywords": [
      "como elijo mi objetivo",
      "cambiar mi meta",
      "seleccionar objetivo",
      "donde elijo mi meta",
      "cambiar de meta de entrenamiento"
    ],
    "pregunta": "¿Cómo elijo mi objetivo?",
    "respuesta": "En la sección Entrenamiento puedes elegir entre Definir, Mantener o Aumentar volumen; tu plan se ajusta automáticamente."
  },
  {
    "id": 12,
    "keywords": [
      "que significa definir",
      "objetivo definir"
    ],
    "pregunta": "¿Qué significa el objetivo \"Definir\"?",
    "respuesta": "Definir busca reducir grasa corporal manteniendo la masa muscular, con un plan ligeramente bajo en calorías."
  },
  {
    "id": 13,
    "keywords": [
      "que significa mantener",
      "objetivo mantener"
    ],
    "pregunta": "¿Qué significa el objetivo \"Mantener\"?",
    "respuesta": "Mantener busca sostener tu peso y composición actual con un plan balanceado."
  },
  {
    "id": 14,
    "keywords": [
      "que significa aumentar volumen",
      "objetivo volumen",
      "subir de peso"
    ],
    "pregunta": "¿Qué significa \"Aumentar volumen\"?",
    "respuesta": "Volumen busca ganar masa muscular con un plan más alto en calorías y proteína."
  },
  {
    "id": 15,
    "keywords": [
      "como cambio mi objetivo",
      "cambiar de meta despues"
    ],
    "pregunta": "¿Puedo cambiar mi objetivo después?",
    "respuesta": "Sí, puedes cambiarlo cuando quieras desde la sección Entrenamiento."
  },
  {
    "id": 16,
    "keywords": [
      "como personalizo mi plan de comidas",
      "personalizar alimentacion",
      "ajustar mi dieta"
    ],
    "pregunta": "¿Cómo personalizo mi plan de comidas?",
    "respuesta": "Con Premium, el botón \"Personalizar\" en Alimentación te deja elegir tipo de proteína, restricciones y alergias."
  },
  {
    "id": 17,
    "keywords": [
      "soy vegetariano",
      "opcion vegetariana",
      "dieta vegetariana"
    ],
    "pregunta": "¿Puedo indicar que soy vegetariano?",
    "respuesta": "Sí, es una de las restricciones disponibles al personalizar tu plan de comidas."
  },
  {
    "id": 18,
    "keywords": [
      "soy vegano",
      "dieta vegana",
      "opcion vegana"
    ],
    "pregunta": "¿Puedo indicar que soy vegano?",
    "respuesta": "Sí, selecciona \"Vegano\" en las restricciones alimentarias al personalizar tu plan."
  },
  {
    "id": 19,
    "keywords": [
      "tengo alergias",
      "alergico a algun alimento",
      "alergias alimentarias"
    ],
    "pregunta": "¿Qué pasa si tengo alergias?",
    "respuesta": "Puedes indicar tus alergias en la personalización y el plan evitará esos ingredientes."
  },
  {
    "id": 20,
    "keywords": [
      "elegir tipo de proteina",
      "que proteina prefiero",
      "pollo pescado carne"
    ],
    "pregunta": "¿Puedo elegir el tipo de proteína?",
    "respuesta": "Sí, puedes preferir pollo, pescado, carne u otras fuentes al personalizar tu plan."
  },
  {
    "id": 21,
    "keywords": [
      "como personalizo mi entrenamiento",
      "ajustar mi rutina",
      "personalizar ejercicio"
    ],
    "pregunta": "¿Cómo personalizo mi plan de entrenamiento?",
    "respuesta": "Con Premium, el botón \"Personalizar\" en Entrenamiento te permite ajustar frecuencia semanal, distancia y enfoque muscular."
  },
  {
    "id": 22,
    "keywords": [
      "cuantos dias entreno",
      "frecuencia de entrenamiento",
      "dias a la semana"
    ],
    "pregunta": "¿Puedo elegir cuántos días entreno a la semana?",
    "respuesta": "Sí, la frecuencia semanal es uno de los ajustes disponibles en la personalización premium."
  },
  {
    "id": 23,
    "keywords": [
      "rutinas para correr",
      "entrenamiento de running",
      "plan de carrera"
    ],
    "pregunta": "¿Tienen rutinas para correr?",
    "respuesta": "Sí, puedes indicar una distancia objetivo y el plan incluirá sesiones de carrera."
  },
  {
    "id": 24,
    "keywords": [
      "enfocarme en piernas",
      "rutina de piernas",
      "enfoque muscular"
    ],
    "pregunta": "¿Puedo enfocar mi rutina en un grupo muscular?",
    "respuesta": "Sí, puedes elegir un enfoque como piernas, brazos o tren superior al personalizar tu entrenamiento."
  },
  {
    "id": 25,
    "keywords": [
      "como registro mi peso",
      "anotar mi peso",
      "guardar mi peso"
    ],
    "pregunta": "¿Cómo registro mi peso?",
    "respuesta": "En tu panel principal hay un campo para ingresar tu peso de hoy y guardarlo con un clic."
  },
  {
    "id": 26,
    "keywords": [
      "donde veo mi progreso",
      "grafico de peso",
      "ver mi evolucion"
    ],
    "pregunta": "¿Dónde veo mi progreso?",
    "respuesta": "En el panel principal aparece un gráfico con la evolución de tu peso a lo largo del tiempo."
  },
  {
    "id": 27,
    "keywords": [
      "borrar mi historial de peso",
      "eliminar mis registros",
      "reiniciar progreso"
    ],
    "pregunta": "¿Puedo borrar mi historial de peso?",
    "respuesta": "Sí, hay un botón para borrar tu historial de progreso desde el panel principal."
  },
  {
    "id": 28,
    "keywords": [
      "que es la racha",
      "que es el streak",
      "dias consecutivos"
    ],
    "pregunta": "¿Qué es la racha (streak)?",
    "respuesta": "Es un contador de días consecutivos usando la app, para ayudarte a mantener la constancia."
  },
  {
    "id": 29,
    "keywords": [
      "como mantengo mi racha",
      "no perder la racha",
      "seguir la racha activa"
    ],
    "pregunta": "¿Cómo mantengo mi racha activa?",
    "respuesta": "Solo necesitas iniciar sesión y usar la app al menos una vez cada día."
  },
  {
    "id": 30,
    "keywords": [
      "que pasa si pierdo mi racha",
      "se reinicia la racha",
      "perdi mis dias seguidos"
    ],
    "pregunta": "¿Qué pasa si pierdo mi racha?",
    "respuesta": "Si dejas pasar un día sin usar la app, la racha vuelve a empezar desde cero."
  },
  {
    "id": 31,
    "keywords": [
      "que es la comunidad",
      "para que sirve comunidad",
      "seccion comunidad",
      "hay chat de usuarios",
      "puedo chatear con otros",
      "red social de la app"
    ],
    "pregunta": "¿Qué es la Comunidad?",
    "respuesta": "Es un chat en vivo donde usuarios de NutriAmigo se motivan entre sí, organizado por salas de país y una sala global."
  },
  {
    "id": 32,
    "keywords": [
      "como entro al chat",
      "acceder a la comunidad",
      "abrir el chat"
    ],
    "pregunta": "¿Cómo entro al chat de la comunidad?",
    "respuesta": "Desde el menú superior entra a \"Comunidad\"; necesitas haber iniciado sesión para escribir."
  },
  {
    "id": 33,
    "keywords": [
      "hablar con gente de otros paises",
      "chat internacional",
      "usuarios de otros paises"
    ],
    "pregunta": "¿Puedo hablar con gente de otros países?",
    "respuesta": "Sí, además de la sala de tu país puedes unirte a la sala Global con usuarios de todo el mundo."
  },
  {
    "id": 34,
    "keywords": [
      "el chat traduce",
      "traduccion automatica",
      "mensajes en otro idioma"
    ],
    "pregunta": "¿El chat traduce los mensajes automáticamente?",
    "respuesta": "Sí, cada mensaje se traduce automáticamente al idioma que tengas seleccionado."
  },
  {
    "id": 35,
    "keywords": [
      "ocultar mi pais",
      "no mostrar de donde soy",
      "privacidad en el chat"
    ],
    "pregunta": "¿Puedo ocultar mi país en el chat?",
    "respuesta": "Sí, hay una opción para mostrar u ocultar tu país junto a tus mensajes."
  },
  {
    "id": 36,
    "keywords": [
      "hay moderadores",
      "quien modera el chat",
      "control del chat"
    ],
    "pregunta": "¿Hay moderadores en el chat?",
    "respuesta": "Por ahora el chat no tiene moderación humana en vivo; se recomienda un uso respetuoso de la comunidad."
  },
  {
    "id": 37,
    "keywords": [
      "como reporto a alguien",
      "reportar un mensaje",
      "denunciar un usuario"
    ],
    "pregunta": "¿Cómo reporto a alguien en el chat?",
    "respuesta": "Por ahora esta función no está disponible; está planeada para una versión futura."
  },
  {
    "id": 38,
    "keywords": [
      "la app tiene anuncios",
      "hay publicidad",
      "anuncios en la version gratis",
      "por que salen anuncios",
      "anuncios molestos",
      "publicidad en la app gratis"
    ],
    "pregunta": "¿La app tiene anuncios?",
    "respuesta": "Sí, la versión gratuita incluye anuncios. La versión Premium los elimina por completo."
  },
  {
    "id": 39,
    "keywords": [
      "como quito los anuncios",
      "eliminar publicidad",
      "sin anuncios"
    ],
    "pregunta": "¿Cómo quito los anuncios?",
    "respuesta": "Activando la membresía Premium desde la sección Premium de la app."
  },
  {
    "id": 40,
    "keywords": [
      "que es el modo rangos",
      "sistema de rangos",
      "niveles de la app"
    ],
    "pregunta": "¿Qué es el sistema de \"rangos\"?",
    "respuesta": "Es un sistema de niveles disponible en Premium que reconoce tu constancia y progreso dentro de la app."
  },
  {
    "id": 41,
    "keywords": [
      "como subo de rango",
      "subir de nivel",
      "avanzar de rango"
    ],
    "pregunta": "¿Cómo subo de rango?",
    "respuesta": "Mantén tu racha activa y cumple tus registros de progreso; el rango sube automáticamente."
  },
  {
    "id": 42,
    "keywords": [
      "funciona sin internet",
      "modo offline",
      "sin conexion"
    ],
    "pregunta": "¿NutriAmigo funciona sin internet?",
    "respuesta": "Puedes abrir la app instalada sin conexión, pero el login, el chat y la sincronización de datos necesitan internet."
  },
  {
    "id": 43,
    "keywords": [
      "hay app para celular",
      "aplicacion movil",
      "version para el telefono"
    ],
    "pregunta": "¿Hay una app para celular?",
    "respuesta": "Sí, NutriAmigo se puede instalar en tu celular como aplicación desde el navegador."
  },
  {
    "id": 44,
    "keywords": [
      "como instalo la app en mi celular",
      "agregar a pantalla de inicio",
      "instalar como app"
    ],
    "pregunta": "¿Cómo instalo la app en mi celular?",
    "respuesta": "Abre el sitio en tu navegador y elige \"Agregar a pantalla de inicio\" o \"Instalar app\" cuando el navegador lo sugiera."
  },
  {
    "id": 45,
    "keywords": [
      "funciona en iphone",
      "funciona en android",
      "compatible con mi celular"
    ],
    "pregunta": "¿Funciona en iPhone y Android?",
    "respuesta": "Sí, al ser una app web instalable funciona en ambos sistemas desde el navegador."
  },
  {
    "id": 46,
    "keywords": [
      "reemplaza a un nutricionista",
      "es lo mismo que un profesional",
      "sustituye al medico",
      "puedo confiar en el plan sin ver a un profesional",
      "el plan es seguro sin nutricionista"
    ],
    "pregunta": "¿Los planes reemplazan a un nutricionista?",
    "respuesta": "No. NutriAmigo es una guía general y no reemplaza la asesoría de un nutricionista o médico."
  },
  {
    "id": 47,
    "keywords": [
      "hablar con un nutricionista real",
      "asesoria profesional",
      "contactar un experto"
    ],
    "pregunta": "¿Puedo hablar con un nutricionista real?",
    "respuesta": "Esta versión no incluye asesoría humana en vivo; para condiciones médicas, consulta siempre a un profesional."
  },
  {
    "id": 48,
    "keywords": [
      "como cambio mi contraseña",
      "olvide mi clave",
      "resetear password"
    ],
    "pregunta": "¿Cómo cambio mi contraseña?",
    "respuesta": "Como inicias sesión con Google, tu contraseña se administra directamente desde tu cuenta de Google."
  },
  {
    "id": 49,
    "keywords": [
      "como elimino mi cuenta",
      "borrar mi cuenta",
      "darme de baja"
    ],
    "pregunta": "¿Cómo elimino mi cuenta?",
    "respuesta": "Escríbenos desde soporte y eliminaremos tu cuenta y tus datos asociados."
  },
  {
    "id": 50,
    "keywords": [
      "como contacto soporte",
      "hablar con soporte humano",
      "ayuda de una persona"
    ],
    "pregunta": "¿Cómo contacto a soporte humano?",
    "respuesta": "Si este asistente no resuelve tu duda, escribe a nuestro correo de soporte para que un miembro del equipo te ayude."
  }
];
