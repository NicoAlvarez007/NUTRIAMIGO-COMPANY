/* Catálogo de ingredientes. Valores por 100 g del alimento tal como se pesa (estado: cocido, crudo, seco o líquido).
   Aproximados: ver docs/fuentes-nutricion.md. Las etiquetas son lo que filtra (dieta, alergias), no el texto. */
(function (global) {
  const item = (es, esPl, en, enPl, de, dePl) => ({ es: [es, esPl], en: [en, enPl], de: [de, dePl], item: true });
  const cont = (es, esPl, en, enPl, de, dePl) => ({ es: [es, esPl], en: [en, enPl], de: [de, dePl], item: false });

  const UNIDADES = {
    pechuga: item('pechuga mediana', 'pechugas medianas', 'medium breast', 'medium breasts', 'mittlere Brust', 'mittlere Brüste'),
    muslo: item('muslo mediano', 'muslos medianos', 'medium thigh', 'medium thighs', 'mittlerer Schenkel', 'mittlere Schenkel'),
    filete: item('filete mediano', 'filetes medianos', 'medium fillet', 'medium fillets', 'mittleres Filet', 'mittlere Filets'),
    palma: cont('porción del tamaño de la palma', 'porciones del tamaño de la palma', 'palm-sized portion', 'palm-sized portions', 'handtellergroße Portion', 'handtellergroße Portionen'),
    lata: cont('lata pequeña', 'latas pequeñas', 'small can', 'small cans', 'kleine Dose', 'kleine Dosen'),
    punado: cont('puñado', 'puñados', 'handful', 'handfuls', 'Handvoll', 'Handvoll'),
    huevo: item('huevo', 'huevos', 'egg', 'eggs', 'Ei', 'Eier'),
    taza: cont('taza', 'tazas', 'cup', 'cups', 'Tasse', 'Tassen'),
    cda: cont('cucharada', 'cucharadas', 'tablespoon', 'tablespoons', 'Esslöffel', 'Esslöffel'),
    vaso: cont('vaso', 'vasos', 'glass', 'glasses', 'Glas', 'Gläser'),
    pote: cont('pote pequeño', 'potes pequeños', 'small tub', 'small tubs', 'kleiner Becher', 'kleine Becher'),
    tajada: cont('tajada', 'tajadas', 'slice', 'slices', 'Scheibe', 'Scheiben'),
    rebanada: cont('rebanada', 'rebanadas', 'slice', 'slices', 'Scheibe', 'Scheiben'),
    arepa: item('arepa mediana', 'arepas medianas', 'medium arepa', 'medium arepas', 'mittlere Arepa', 'mittlere Arepas'),
    platano: item('plátano mediano', 'plátanos medianos', 'medium plantain', 'medium plantains', 'mittlere Kochbanane', 'mittlere Kochbananen'),
    papa: item('papa mediana', 'papas medianas', 'medium potato', 'medium potatoes', 'mittlere Kartoffel', 'mittlere Kartoffeln'),
    papac: item('papa criolla', 'papas criollas', 'creole potato', 'creole potatoes', 'Criolla-Kartoffel', 'Criolla-Kartoffeln'),
    batata: item('batata mediana', 'batatas medianas', 'medium sweet potato', 'medium sweet potatoes', 'mittlere Süßkartoffel', 'mittlere Süßkartoffeln'),
    mazorca: item('mazorca', 'mazorcas', 'ear of corn', 'ears of corn', 'Maiskolben', 'Maiskolben'),
    tortilla: item('tortilla', 'tortillas', 'tortilla', 'tortillas', 'Tortilla', 'Tortillas'),
    yuca: cont('trozo de yuca', 'trozos de yuca', 'piece of cassava', 'pieces of cassava', 'Stück Maniok', 'Stücke Maniok'),
    tomate: item('tomate mediano', 'tomates medianos', 'medium tomato', 'medium tomatoes', 'mittlere Tomate', 'mittlere Tomaten'),
    cebolla: item('cebolla mediana', 'cebollas medianas', 'medium onion', 'medium onions', 'mittlere Zwiebel', 'mittlere Zwiebeln'),
    zanahoria: item('zanahoria mediana', 'zanahorias medianas', 'medium carrot', 'medium carrots', 'mittlere Karotte', 'mittlere Karotten'),
    pepino: item('pepino mediano', 'pepinos medianos', 'medium cucumber', 'medium cucumbers', 'mittlere Gurke', 'mittlere Gurken'),
    pimenton: item('pimentón mediano', 'pimentones medianos', 'medium bell pepper', 'medium bell peppers', 'mittlere Paprika', 'mittlere Paprika'),
    calabacin: item('calabacín mediano', 'calabacines medianos', 'medium zucchini', 'medium zucchinis', 'mittlere Zucchini', 'mittlere Zucchini'),
    remolacha: item('remolacha mediana', 'remolachas medianas', 'medium beetroot', 'medium beetroots', 'mittlere Rote Bete', 'mittlere Rote Bete'),
    hojas: cont('taza de hojas', 'tazas de hojas', 'cup of leaves', 'cups of leaves', 'Tasse Blätter', 'Tassen Blätter'),
    banano: item('banano mediano', 'bananos medianos', 'medium banana', 'medium bananas', 'mittlere Banane', 'mittlere Bananen'),
    manzana: item('manzana mediana', 'manzanas medianas', 'medium apple', 'medium apples', 'mittlerer Apfel', 'mittlere Äpfel'),
    naranja: item('naranja mediana', 'naranjas medianas', 'medium orange', 'medium oranges', 'mittlere Orange', 'mittlere Orangen'),
    mandarina: item('mandarina', 'mandarinas', 'tangerine', 'tangerines', 'Mandarine', 'Mandarinen'),
    guayaba: item('guayaba mediana', 'guayabas medianas', 'medium guava', 'medium guavas', 'mittlere Guave', 'mittlere Guaven'),
    pera: item('pera mediana', 'peras medianas', 'medium pear', 'medium pears', 'mittlere Birne', 'mittlere Birnen'),
    kiwi: item('kiwi', 'kiwis', 'kiwi', 'kiwis', 'Kiwi', 'Kiwis'),
    aguacate: item('aguacate mediano', 'aguacates medianos', 'medium avocado', 'medium avocados', 'mittlere Avocado', 'mittlere Avocados'),
    scoop: cont('medida (scoop)', 'medidas (scoop)', 'scoop', 'scoops', 'Messlöffel', 'Messlöffel')
  };

  const POR_GRUPO = {
    proteina: { min: 60, max: 320, base: 120 },
    carbohidrato: { min: 50, max: 800, base: 130 },
    verdura: { min: 60, max: 300, base: 120 },
    fruta: { min: 50, max: 350, base: 120 },
    grasa: { min: 5, max: 40, base: 10 },
    lacteo_o_alt: { min: 100, max: 400, base: 200 },
    extra: { min: 5, max: 20, base: 10 }
  };

  /* id, es, en, de, grupo, kcal, prot, carb, grasa, estado, etiquetas, precio, usos, unidad, gramos/unidad, cocciones, ajustes */
  const FILAS = [
    ['pechuga_pollo', 'pechuga de pollo', 'chicken breast', 'Hähnchenbrust', 'proteina', 165, 31, 0, 3.6, 'cocido', 'carne ave', 'medio', 'P', 'pechuga', 120, 'plancha horno sudado salteado guisado sopa frio', { max: 300 }],
    ['muslo_pollo', 'muslo de pollo sin piel', 'skinless chicken thigh', 'Hähnchenschenkel ohne Haut', 'proteina', 179, 24.8, 0, 8.2, 'cocido', 'carne ave', 'bajo', 'P', 'muslo', 90, 'horno sudado guisado sopa', {}],
    ['res_magra', 'carne de res magra', 'lean beef', 'mageres Rindfleisch', 'proteina', 185, 29, 0, 7.5, 'cocido', 'carne res', 'alto', 'P', 'palma', 100, 'plancha salteado guisado horno', {}],
    ['res_molida', 'carne molida de res', 'ground beef', 'Rinderhackfleisch', 'proteina', 217, 26.1, 0, 11.8, 'cocido', 'carne res', 'medio', 'P', 'palma', 100, 'salteado guisado', {}],
    ['cerdo_lomo', 'lomo de cerdo', 'pork loin', 'Schweinelende', 'proteina', 190, 27, 0, 8, 'cocido', 'carne cerdo', 'medio', 'P', 'palma', 100, 'plancha horno salteado guisado', {}],
    ['salmon', 'salmón', 'salmon', 'Lachs', 'proteina', 206, 22, 0, 12, 'cocido', 'pescado', 'alto', 'P', 'filete', 120, 'plancha horno', { min: 80, max: 250, base: 130 }],
    ['tilapia', 'tilapia', 'tilapia', 'Tilapia', 'proteina', 128, 26, 0, 2.7, 'cocido', 'pescado', 'medio', 'P', 'filete', 110, 'plancha horno sudado guisado', {}],
    ['atun_lata', 'atún en agua', 'canned tuna in water', 'Thunfisch in Wasser', 'proteina', 116, 26, 0, 0.8, 'cocido', 'pescado', 'bajo', 'P', 'lata', 100, 'frio', { min: 60, max: 200, base: 100 }],
    ['camaron', 'camarones', 'shrimp', 'Garnelen', 'proteina', 99, 24, 0.2, 0.3, 'cocido', 'marisco', 'alto', 'P', null, 0, 'plancha salteado sudado guisado', { max: 250 }],
    ['huevo', 'huevo', 'egg', 'Ei', 'proteina', 155, 13, 1.1, 11, 'cocido', 'huevo', 'bajo', 'P D', 'huevo', 50, 'frio revuelto tortilla cocido', { min: 50, max: 200, base: 100, paso: 50 }],
    ['tofu', 'tofu', 'tofu', 'Tofu', 'proteina', 144, 17.3, 2.8, 8.7, 'crudo', 'soya', 'medio', 'P D', 'palma', 100, 'plancha salteado revuelto guisado frio tortilla', { min: 80, max: 300, base: 150 }],
    ['tempeh', 'tempeh', 'tempeh', 'Tempeh', 'proteina', 192, 20.3, 7.6, 10.8, 'crudo', 'soya', 'alto', 'P', 'palma', 100, 'plancha salteado horno', { min: 60, max: 250, base: 100 }],
    ['lentejas', 'lentejas', 'lentils', 'Linsen', 'proteina', 116, 9, 20, 0.4, 'cocido', 'legumbre', 'bajo', 'P', 'taza', 200, 'guisado sopa frio', { min: 100, max: 400, base: 180 }],
    ['garbanzos', 'garbanzos', 'chickpeas', 'Kichererbsen', 'proteina', 164, 8.9, 27.4, 2.6, 'cocido', 'legumbre', 'bajo', 'P', 'taza', 165, 'guisado sopa frio salteado', { min: 100, max: 400, base: 160 }],
    ['frijoles', 'frijoles', 'beans', 'Bohnen', 'proteina', 132, 8.9, 23.7, 0.5, 'cocido', 'legumbre', 'bajo', 'P', 'taza', 175, 'guisado sopa frio', { min: 100, max: 400, base: 170 }],
    ['proteina_arveja', 'proteína de arveja', 'pea protein', 'Erbsenprotein', 'proteina', 380, 80, 5, 6, 'seco', 'procesado', 'alto', 'D', 'scoop', 30, '', { min: 15, max: 60, base: 30 }],
    ['jamon_pavo', 'jamón de pavo', 'turkey ham', 'Putenschinken', 'proteina', 110, 16, 3, 3.5, 'crudo', 'carne ave procesado', 'medio', 'D', 'tajada', 25, '', { min: 25, max: 100, base: 50 }],

    ['arroz_blanco', 'arroz blanco', 'white rice', 'weißer Reis', 'carbohidrato', 130, 2.7, 28.2, 0.3, 'cocido', '', 'bajo', 'C', 'taza', 160, '', {}],
    ['arroz_integral', 'arroz integral', 'brown rice', 'Naturreis', 'carbohidrato', 123, 2.7, 25.6, 1, 'cocido', '', 'medio', 'C', 'taza', 195, '', {}],
    ['arepa', 'arepa', 'arepa', 'Arepa', 'carbohidrato', 200, 4.5, 42, 1.5, 'cocido', '', 'bajo', 'C B', 'arepa', 80, '', { min: 40, max: 300, base: 100 }],
    ['platano_maduro', 'plátano maduro', 'ripe plantain', 'reife Kochbanane', 'carbohidrato', 122, 1.3, 31.9, 0.4, 'cocido', '', 'bajo', 'C B', 'platano', 170, '', { min: 60, max: 350, base: 120 }],
    ['platano_verde', 'plátano verde', 'green plantain', 'grüne Kochbanane', 'carbohidrato', 116, 0.8, 31, 0.2, 'cocido', '', 'bajo', 'C', 'platano', 170, '', { min: 60, max: 350, base: 120 }],
    ['yuca', 'yuca', 'cassava', 'Maniok', 'carbohidrato', 160, 1.4, 38.1, 0.3, 'cocido', '', 'bajo', 'C', 'yuca', 100, '', { min: 60, max: 400, base: 120 }],
    ['papa', 'papa', 'potato', 'Kartoffel', 'carbohidrato', 87, 1.9, 20.1, 0.1, 'cocido', '', 'bajo', 'C', 'papa', 150, '', { max: 600 }],
    ['papa_criolla', 'papa criolla', 'creole potato', 'Criolla-Kartoffel', 'carbohidrato', 85, 2, 19, 0.2, 'cocido', '', 'bajo', 'C B', 'papac', 40, '', { max: 500 }],
    ['batata', 'batata', 'sweet potato', 'Süßkartoffel', 'carbohidrato', 90, 2, 20.7, 0.2, 'cocido', '', 'medio', 'C B', 'batata', 130, '', { max: 500 }],
    ['avena', 'avena', 'oats', 'Haferflocken', 'carbohidrato', 379, 13.2, 67.7, 6.5, 'seco', 'gluten', 'bajo', 'B', 'taza', 80, '', { min: 25, max: 150, base: 50 }],
    ['pan_integral', 'pan integral', 'whole-wheat bread', 'Vollkornbrot', 'carbohidrato', 250, 12, 43, 3.5, 'cocido', 'gluten procesado', 'medio', 'B', 'rebanada', 30, '', { min: 30, max: 200, base: 60 }],
    ['pasta', 'pasta', 'pasta', 'Pasta', 'carbohidrato', 158, 5.8, 30.9, 0.9, 'cocido', 'gluten', 'bajo', 'C', 'taza', 140, '', { min: 80, max: 450, base: 150 }],
    ['quinoa', 'quinua', 'quinoa', 'Quinoa', 'carbohidrato', 120, 4.4, 21.3, 1.9, 'cocido', '', 'alto', 'C', 'taza', 185, '', { min: 80, max: 450, base: 150 }],
    ['maiz', 'maíz', 'corn', 'Mais', 'carbohidrato', 96, 3.4, 21, 1.5, 'cocido', '', 'bajo', 'C', 'mazorca', 100, '', { min: 60, max: 200, base: 100 }],
    ['tortilla_maiz', 'tortilla de maíz', 'corn tortilla', 'Maistortilla', 'carbohidrato', 218, 5.7, 44.6, 2.9, 'cocido', '', 'bajo', 'C B', 'tortilla', 30, '', { min: 30, max: 200, base: 60 }],

    ['tomate', 'tomate', 'tomato', 'Tomate', 'verdura', 18, 0.9, 3.9, 0.2, 'crudo', '', 'bajo', 'V', 'tomate', 120, '', {}],
    ['cebolla', 'cebolla', 'onion', 'Zwiebel', 'verdura', 40, 1.1, 9.3, 0.1, 'crudo', '', 'bajo', 'V', 'cebolla', 110, '', { min: 30, max: 150, base: 50 }],
    ['zanahoria', 'zanahoria', 'carrot', 'Karotte', 'verdura', 41, 0.9, 9.6, 0.2, 'crudo', '', 'bajo', 'V', 'zanahoria', 70, '', {}],
    ['brocoli', 'brócoli', 'broccoli', 'Brokkoli', 'verdura', 35, 2.4, 7.2, 0.4, 'cocido', '', 'medio', 'V', 'taza', 150, '', {}],
    ['espinaca', 'espinaca', 'spinach', 'Spinat', 'verdura', 23, 2.9, 3.6, 0.4, 'crudo', '', 'medio', 'V', 'hojas', 30, '', { max: 200, base: 60 }],
    ['lechuga', 'lechuga', 'lettuce', 'Salat', 'verdura', 15, 1.4, 2.9, 0.2, 'crudo', '', 'bajo', 'V', 'hojas', 50, '', { max: 200, base: 60 }],
    ['pepino', 'pepino', 'cucumber', 'Gurke', 'verdura', 15, 0.7, 3.6, 0.1, 'crudo', '', 'bajo', 'V', 'pepino', 200, '', {}],
    ['pimenton', 'pimentón', 'bell pepper', 'Paprika', 'verdura', 31, 1, 6, 0.3, 'crudo', '', 'medio', 'V', 'pimenton', 120, '', {}],
    ['champinones', 'champiñones', 'mushrooms', 'Champignons', 'verdura', 22, 3.1, 3.3, 0.3, 'crudo', '', 'medio', 'V', 'taza', 70, '', {}],
    ['calabacin', 'calabacín', 'zucchini', 'Zucchini', 'verdura', 17, 1.2, 3.1, 0.3, 'crudo', '', 'medio', 'V', 'calabacin', 200, '', {}],
    ['coliflor', 'coliflor', 'cauliflower', 'Blumenkohl', 'verdura', 23, 1.8, 4.1, 0.5, 'cocido', '', 'medio', 'V', 'taza', 120, '', {}],
    ['habichuela', 'habichuela', 'green beans', 'grüne Bohnen', 'verdura', 35, 1.9, 7.9, 0.3, 'cocido', '', 'bajo', 'V', 'taza', 125, '', {}],
    ['repollo', 'repollo', 'cabbage', 'Kohl', 'verdura', 25, 1.3, 5.8, 0.1, 'crudo', '', 'bajo', 'V', 'taza', 90, '', {}],
    ['remolacha', 'remolacha', 'beetroot', 'Rote Bete', 'verdura', 44, 1.7, 10, 0.2, 'cocido', '', 'bajo', 'V', 'remolacha', 80, '', {}],
    ['ahuyama', 'ahuyama', 'pumpkin', 'Kürbis', 'verdura', 20, 0.7, 4.9, 0.1, 'cocido', '', 'bajo', 'V', 'taza', 200, '', {}],

    ['banano', 'banano', 'banana', 'Banane', 'fruta', 89, 1.1, 22.8, 0.3, 'crudo', '', 'bajo', 'F', 'banano', 120, '', {}],
    ['manzana', 'manzana', 'apple', 'Apfel', 'fruta', 52, 0.3, 13.8, 0.2, 'crudo', '', 'medio', 'F', 'manzana', 180, '', {}],
    ['naranja', 'naranja', 'orange', 'Orange', 'fruta', 47, 0.9, 11.8, 0.1, 'crudo', '', 'bajo', 'F', 'naranja', 130, '', {}],
    ['fresas', 'fresas', 'strawberries', 'Erdbeeren', 'fruta', 32, 0.7, 7.7, 0.3, 'crudo', '', 'alto', 'F', 'taza', 150, '', {}],
    ['papaya', 'papaya', 'papaya', 'Papaya', 'fruta', 43, 0.5, 10.8, 0.3, 'crudo', '', 'bajo', 'F', 'taza', 140, '', {}],
    ['mango', 'mango', 'mango', 'Mango', 'fruta', 60, 0.8, 15, 0.4, 'crudo', '', 'medio', 'F', 'taza', 165, '', {}],
    ['pina', 'piña', 'pineapple', 'Ananas', 'fruta', 50, 0.5, 13.1, 0.1, 'crudo', '', 'bajo', 'F', 'taza', 165, '', {}],
    ['uvas', 'uvas', 'grapes', 'Trauben', 'fruta', 69, 0.7, 18.1, 0.2, 'crudo', '', 'medio', 'F', 'taza', 150, '', {}],
    ['mandarina', 'mandarina', 'tangerine', 'Mandarine', 'fruta', 53, 0.8, 13.3, 0.3, 'crudo', '', 'bajo', 'F', 'mandarina', 90, '', {}],
    ['sandia', 'sandía', 'watermelon', 'Wassermelone', 'fruta', 30, 0.6, 7.6, 0.2, 'crudo', '', 'bajo', 'F', 'taza', 150, '', {}],
    ['guayaba', 'guayaba', 'guava', 'Guave', 'fruta', 68, 2.6, 14.3, 1, 'crudo', '', 'bajo', 'F', 'guayaba', 90, '', {}],
    ['mora', 'mora', 'blackberries', 'Brombeeren', 'fruta', 43, 1.4, 9.6, 0.5, 'crudo', '', 'alto', 'F', 'taza', 145, '', {}],
    ['pera', 'pera', 'pear', 'Birne', 'fruta', 57, 0.4, 15.2, 0.1, 'crudo', '', 'medio', 'F', 'pera', 180, '', {}],
    ['kiwi', 'kiwi', 'kiwi', 'Kiwi', 'fruta', 61, 1.1, 14.7, 0.5, 'crudo', '', 'alto', 'F', 'kiwi', 70, '', {}],

    ['aguacate', 'aguacate', 'avocado', 'Avocado', 'grasa', 160, 2, 8.5, 14.7, 'crudo', '', 'medio', 'G', 'aguacate', 200, '', { min: 30, max: 150, base: 60 }],
    ['aceite_oliva', 'aceite de oliva', 'olive oil', 'Olivenöl', 'grasa', 884, 0, 0, 100, 'liquido', '', 'medio', 'G', 'cda', 14, '', { min: 5, max: 25, base: 10, paso: 5 }],
    ['almendras', 'almendras', 'almonds', 'Mandeln', 'grasa', 579, 21.2, 21.6, 49.9, 'seco', 'frutos_secos', 'alto', 'G S', 'punado', 30, '', { min: 10, max: 50, base: 25 }],
    ['nueces', 'nueces', 'walnuts', 'Walnüsse', 'grasa', 654, 15.2, 13.7, 65.2, 'seco', 'frutos_secos', 'alto', 'G S', 'punado', 30, '', { min: 10, max: 50, base: 25 }],
    ['mani', 'maní', 'peanuts', 'Erdnüsse', 'grasa', 567, 25.8, 16.1, 49.2, 'seco', 'mani', 'bajo', 'G S', 'punado', 30, '', { min: 10, max: 50, base: 25 }],
    ['mantequilla_mani', 'mantequilla de maní', 'peanut butter', 'Erdnussbutter', 'grasa', 588, 25, 20, 50, 'crudo', 'mani procesado', 'medio', 'G', 'cda', 16, '', { min: 10, max: 40, base: 20 }],
    ['chia', 'semillas de chía', 'chia seeds', 'Chiasamen', 'grasa', 486, 16.5, 42.1, 30.7, 'seco', '', 'medio', 'G S', 'cda', 12, '', { min: 5, max: 30, base: 15 }],

    ['leche_entera', 'leche entera', 'whole milk', 'Vollmilch', 'lacteo_o_alt', 61, 3.2, 4.8, 3.3, 'liquido', 'lacteo lactosa', 'bajo', 'L', 'vaso', 250, '', {}],
    ['leche_deslactosada', 'leche deslactosada', 'lactose-free milk', 'laktosefreie Milch', 'lacteo_o_alt', 50, 3.4, 4.8, 1.6, 'liquido', 'lacteo', 'medio', 'L', 'vaso', 250, '', {}],
    ['leche_avena', 'leche de avena', 'oat milk', 'Hafermilch', 'lacteo_o_alt', 48, 1, 6.5, 1.5, 'liquido', 'gluten', 'medio', 'L', 'vaso', 250, '', {}],
    ['leche_soya', 'leche de soya', 'soy milk', 'Sojamilch', 'lacteo_o_alt', 33, 2.9, 1.7, 1.6, 'liquido', 'soya', 'bajo', 'L', 'vaso', 250, '', {}],
    ['leche_almendra', 'leche de almendras', 'almond milk', 'Mandelmilch', 'lacteo_o_alt', 17, 0.6, 0.6, 1.1, 'liquido', 'frutos_secos', 'alto', 'L', 'vaso', 250, '', {}],
    ['yogur_natural', 'yogur natural', 'plain yogurt', 'Naturjoghurt', 'lacteo_o_alt', 61, 3.5, 4.7, 3.3, 'crudo', 'lacteo lactosa', 'medio', 'L D', 'pote', 150, '', { min: 100, max: 350, base: 150 }],
    ['yogur_griego', 'yogur griego', 'Greek yogurt', 'Griechischer Joghurt', 'lacteo_o_alt', 73, 10, 3.9, 1.9, 'crudo', 'lacteo lactosa', 'alto', 'L D', 'pote', 150, '', { min: 100, max: 350, base: 150 }],
    ['yogur_vegetal', 'yogur vegetal de soya', 'soy yogurt', 'Sojajoghurt', 'lacteo_o_alt', 60, 3.5, 6, 2, 'crudo', 'soya procesado', 'alto', 'L D', 'pote', 150, '', { min: 100, max: 350, base: 150 }],
    ['queso_campesino', 'queso campesino', 'fresh farmer cheese', 'Frischkäse', 'lacteo_o_alt', 280, 18, 3, 22, 'crudo', 'lacteo lactosa', 'medio', 'D S', 'tajada', 30, '', { min: 20, max: 100, base: 40 }],
    ['queso_vegano', 'queso vegano', 'vegan cheese', 'veganer Käse', 'lacteo_o_alt', 270, 1, 20, 22, 'crudo', 'procesado frutos_secos', 'alto', 'D S', 'tajada', 30, '', { min: 20, max: 80, base: 30 }],

    ['panela', 'panela', 'panela (unrefined cane sugar)', 'Panela (Rohrzucker)', 'extra', 350, 0.5, 90, 0.1, 'seco', 'azucar', 'bajo', 'X', 'cda', 15, '', { min: 5, max: 20, base: 10 }],
    ['miel', 'miel', 'honey', 'Honig', 'extra', 304, 0.3, 82.4, 0, 'liquido', 'miel azucar', 'medio', 'X', 'cda', 21, '', { min: 5, max: 20, base: 10 }]
  ];

  const lista = FILAS.map((f) => {
    const [id, es, en, de, grupo, kcal, prot, carb, grasa, estado, etiquetas, precio, usos, unidad, gramos, cocciones, ajustes] = f;
    const def = POR_GRUPO[grupo];
    const liquido = estado === 'liquido';
    return {
      id,
      nombre: { es, en, de },
      grupo,
      kcal, prot, carb, grasa,
      estado,
      etiquetas: etiquetas ? etiquetas.split(' ') : [],
      precio,
      usos: usos.split(' '),
      medida: unidad ? { unidad, gramos } : null,
      cocciones: cocciones ? cocciones.split(' ') : [],
      min: ajustes.min !== undefined ? ajustes.min : def.min,
      max: ajustes.max !== undefined ? ajustes.max : def.max,
      base: ajustes.base !== undefined ? ajustes.base : def.base,
      paso: ajustes.paso !== undefined ? ajustes.paso : (liquido ? 10 : 5)
    };
  });

  const ETIQUETAS = ['carne', 'ave', 'res', 'cerdo', 'pescado', 'marisco', 'huevo', 'lacteo', 'lactosa', 'miel',
    'gluten', 'frutos_secos', 'mani', 'soya', 'legumbre', 'procesado', 'azucar'];

  const api = { lista, UNIDADES, ETIQUETAS, porId: Object.fromEntries(lista.map((i) => [i.id, i])) };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else global.NA_INGREDIENTES = api;
})(typeof window !== 'undefined' ? window : globalThis);
