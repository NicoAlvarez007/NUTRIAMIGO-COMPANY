(function () {
  const $ = (id) => document.getElementById(id);
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);

  function mostrar(texto) {
    $('mensaje').textContent = texto;
    $('mensaje').hidden = !texto;
  }

  document.addEventListener('DOMContentLoaded', () => {
    $('gsForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      mostrar('');
      const boton = e.target.querySelector('button[type="submit"]');
      boton.disabled = true;
      try {
        const datos = await window.api.post('./auth/google-simulado', {
          nombre: $('gsNombre').value.trim(),
          email: $('gsCorreo').value.trim()
        }, { silencioso: true });
        window.location.href = `.${datos.siguiente}`;
      } catch (err) {
        mostrar(err.message || t('err.interno', 'Error interno'));
      } finally {
        boton.disabled = false;
      }
    });

    window.api.get('./api/me', { silencioso: true }).then((yo) => {
      if (yo.role === 'admin') $('pieAdmin').hidden = false;
    }).catch(() => { /* sin sesión: no pasa nada */ });
  });
})();
