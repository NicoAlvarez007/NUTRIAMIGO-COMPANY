/* Recordatorios push — nivel básico.
   Funciona solo mientras esta pestaña sigue abierta: usa la Notification API
   del navegador con un setInterval. Para que funcione con la pestaña cerrada
   haría falta la Push API real (VAPID keys + service worker + backend con
   web-push), que queda fuera de este nivel básico. */

const NUTRIAMIGO_RECORDATORIOS_CHECK_MS = 5 * 60 * 1000;     // revisa cada 5 min
const NUTRIAMIGO_AGUA_INTERVALO_MS = 2 * 60 * 60 * 1000;     // recuerda agua cada 2 horas
const NUTRIAMIGO_ENTRENO_HORA = 18;                          // aviso diario de entreno, 6pm hora local

function nutriamigoNotificar(titulo, cuerpo) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    new Notification(titulo, { body: cuerpo, icon: './assets/logo.png' });
  } catch (e) {
    console.error('No se pudo mostrar la notificación', e);
  }
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  if (!user || (!user.recordarAgua && !user.recordarEntreno)) return;
  if (!('Notification' in window) || Notification.permission !== 'granted') return;

  let ultimaAguaTS = Date.now(); // no molestar apenas se abre la pestaña
  let ultimoEntrenoFecha = '';

  setInterval(() => {
    const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
    const actual = window.__nutriamigoUser || user;
    const ahora = Date.now();

    if (actual.recordarAgua && ahora - ultimaAguaTS >= NUTRIAMIGO_AGUA_INTERVALO_MS) {
      ultimaAguaTS = ahora;
      nutriamigoNotificar(
        t('rec.aguaTitulo', 'Hora de tomar agua 💧'),
        t('rec.aguaCuerpo', 'Han pasado 2 horas. Toma un vaso de agua y regístralo en tu panel.')
      );
    }

    const hoy = new Date().toISOString().slice(0, 10);
    if (actual.recordarEntreno && new Date().getHours() === NUTRIAMIGO_ENTRENO_HORA && ultimoEntrenoFecha !== hoy) {
      ultimoEntrenoFecha = hoy;
      nutriamigoNotificar(
        t('rec.entrenoTitulo', '¿Ya entrenaste hoy? 🏋️'),
        t('rec.entrenoCuerpo', 'No olvides tu rutina de hoy en NutriAmigo.')
      );
    }
  }, NUTRIAMIGO_RECORDATORIOS_CHECK_MS);
});
