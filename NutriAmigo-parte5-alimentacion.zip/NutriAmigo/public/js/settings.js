function construirModalConfiguracion() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'settingsModal';
  overlay.hidden = true;
  overlay.innerHTML = `
    <div class="modal">
      <h3 data-i18n="settings.title">Configuración</h3>
      <p class="section-sub" data-i18n="settings.subtitle">Cambia tus datos, tu tema o tu cuenta.</p>
      <form id="settingsForm">
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label data-i18n="settings.nombre">Nombre</label><input type="text" id="cfgNombre"></div>
          <div class="field"><label data-i18n="settings.apellido">Apellido</label><input type="text" id="cfgApellido"></div>
        </div>
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label data-i18n="settings.peso">Peso (kg)</label><input type="number" id="cfgPeso" step="0.1" min="30" max="250"></div>
          <div class="field"><label data-i18n="settings.estatura">Estatura (cm)</label><input type="number" id="cfgEstatura" min="120" max="220"></div>
        </div>
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label data-i18n="settings.edad">Edad</label><input type="number" id="cfgEdad" min="15" max="90"></div>
          <div class="field">
            <label data-i18n="settings.actividad">Nivel de actividad</label>
            <select id="cfgActividad">
              <option value="sedentario" data-i18n="actividad.sedentario">Sedentario</option>
              <option value="ligero" data-i18n="actividad.ligero">Ligero</option>
              <option value="moderado" data-i18n="actividad.moderado">Moderado</option>
              <option value="activo" data-i18n="actividad.activo">Activo</option>
              <option value="muy_activo" data-i18n="actividad.muyActivo">Muy activo</option>
            </select>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.objetivo">Objetivo</label>
          <div class="pill-group" id="cfgObjetivoGroup">
            <button type="button" class="pill" data-objetivo="definir" data-i18n="objetivo.definir">Definir</button>
            <button type="button" class="pill" data-objetivo="mantener" data-i18n="objetivo.mantener">Mantener</button>
            <button type="button" class="pill" data-objetivo="volumen" data-i18n="objetivo.volumen">Subir de peso</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.tipoPerfil">Tipo de perfil</label>
          <div class="pill-group" id="cfgPerfilGroup">
            <button type="button" class="pill" data-perfil="privado" data-i18n="perfil.privado">Privado</button>
            <button type="button" class="pill" data-perfil="publico" data-i18n="perfil.publico">Público</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.tema">Tema</label>
          <div class="pill-group" id="temaGroup">
            <button type="button" class="pill" data-tema="claro" data-i18n="tema.claro">Claro</button>
            <button type="button" class="pill" data-tema="dark" data-i18n="tema.oscuro">Oscuro</button>
            <button type="button" class="pill" data-tema="auto" data-i18n="tema.auto">Automático</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.idioma">Idioma</label>
          <div class="pill-group" id="idiomaGroup">
            <button type="button" class="pill" data-lang="es">Español</button>
            <button type="button" class="pill" data-lang="en">English</button>
            <button type="button" class="pill" data-lang="de">Deutsch</button>
          </div>
        </div>
        <div class="field">
          <button type="button" class="pill" id="avisarPlanToggle" data-i18n="settings.avisarPlan">Avisarme cuando actualice mi plan</button>
        </div>
        <div class="field">
          <label data-i18n="settings.recordatorios">Recordatorios</label>
          <div class="pill-group">
            <button type="button" class="pill" id="recordarAguaToggle" data-i18n="settings.recordarAgua">💧 Tomar agua cada 2 horas</button>
            <button type="button" class="pill" id="recordarEntrenoToggle" data-i18n="settings.recordarEntreno">🏋️ Entrenar (aviso diario)</button>
          </div>
          <p class="section-sub" style="margin-top:6px;" data-i18n="settings.recordatoriosAyuda">Solo funcionan mientras tengas esta pestaña abierta en tu navegador.</p>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" id="closeSettingsBtn" data-i18n="settings.cancelar">Cancelar</button>
          <button type="submit" class="btn btn-primary" data-i18n="settings.guardar">Guardar</button>
        </div>
      </form>
      <button type="button" id="deleteAccountBtn" style="width:100%;margin-top:16px;background:none;border:none;color:#c5533b;font-size:13px;font-weight:600;cursor:pointer;" data-i18n="settings.borrarCuenta">Borrar cuenta</button>
      <div class="settings-contact">
        <span data-i18n="settings.contactanos">Contáctanos:</span>
        <a href="https://wa.me/573000000000" target="_blank" rel="noopener">WhatsApp</a>
        <a href="https://instagram.com/nutriamigo" target="_blank" rel="noopener">Instagram</a>
        <a href="https://tiktok.com/@nutriamigo" target="_blank" rel="noopener">TikTok</a>
        <span>nutriamigo@gmail.com</span>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  return overlay;
}

function marcarTemaCfg(tema) {
  document.querySelectorAll('#temaGroup .pill').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tema === tema);
  });
}

function aplicarTema(tema) {
  if (window.NutriTema) window.NutriTema.set(tema);
  marcarTemaCfg(tema);
}

let objetivoCfg = 'mantener';
let perfilCfg = 'privado';

function marcarObjetivoCfg(valor) {
  objetivoCfg = valor;
  document.querySelectorAll('#cfgObjetivoGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.objetivo === valor));
}

function marcarPerfilCfg(valor) {
  perfilCfg = valor;
  document.querySelectorAll('#cfgPerfilGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.perfil === valor));
}

function marcarIdiomaCfg(valor) {
  document.querySelectorAll('#idiomaGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.lang === valor));
}

document.addEventListener('nutriamigo:user-ready', () => {
  const settingsBtn = document.getElementById('settingsBtn');
  if (!settingsBtn) return;

  const overlay = construirModalConfiguracion();

  document.querySelectorAll('#temaGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => aplicarTema(btn.dataset.tema));
  });
  document.querySelectorAll('#cfgObjetivoGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => marcarObjetivoCfg(btn.dataset.objetivo));
  });
  document.querySelectorAll('#cfgPerfilGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => marcarPerfilCfg(btn.dataset.perfil));
  });
  document.querySelectorAll('#idiomaGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => {
      marcarIdiomaCfg(btn.dataset.lang);
      if (window.NutriIdioma) window.NutriIdioma.set(btn.dataset.lang);
    });
  });

  document.getElementById('avisarPlanToggle').addEventListener('click', (e) => {
    e.target.classList.toggle('active');
  });

  ['recordarAguaToggle', 'recordarEntrenoToggle'].forEach(id => {
    document.getElementById(id).addEventListener('click', async (e) => {
      const activando = !e.target.classList.contains('active');
      if (activando && 'Notification' in window && Notification.permission === 'default') {
        await Notification.requestPermission();
      }
      if (activando && 'Notification' in window && Notification.permission !== 'granted') {
        return; // el usuario negó el permiso: no activamos el toggle
      }
      e.target.classList.toggle('active');
    });
  });

  document.getElementById('closeSettingsBtn').addEventListener('click', () => { overlay.hidden = true; });

  settingsBtn.addEventListener('click', async () => {
    document.getElementById('profileMenu').classList.remove('open');
    marcarTemaCfg(window.NutriTema ? window.NutriTema.get() : 'claro');
    marcarIdiomaCfg(window.NutriIdioma ? window.NutriIdioma.get() : 'es');
    document.getElementById('avisarPlanToggle').classList.toggle(
      'active',
      !window.__nutriamigoUser || window.__nutriamigoUser.avisarActualizacionPlan !== false
    );
    document.getElementById('recordarAguaToggle').classList.toggle('active', !!(window.__nutriamigoUser && window.__nutriamigoUser.recordarAgua));
    document.getElementById('recordarEntrenoToggle').classList.toggle('active', !!(window.__nutriamigoUser && window.__nutriamigoUser.recordarEntreno));

    try {
      const data = await api.get('./api/biometrics');
      if (data) {
        document.getElementById('cfgNombre').value = data.nombre || '';
        document.getElementById('cfgApellido').value = data.apellido || '';
        document.getElementById('cfgPeso').value = data.peso || '';
        document.getElementById('cfgEstatura').value = data.estatura || '';
        document.getElementById('cfgEdad').value = data.edad || '';
        if (data.actividad) document.getElementById('cfgActividad').value = data.actividad;
        marcarObjetivoCfg(data.objetivo || 'mantener');
        overlay.dataset.sexo = data.sexo || '';
        overlay.dataset.correo = data.correo || '';
        const botonDefinir = document.querySelector('#cfgObjetivoGroup .pill[data-objetivo="definir"]');
        if (botonDefinir) botonDefinir.disabled = data.edad >= 15 && data.edad <= 17;
      }
    } catch (err) {
      console.error('No se pudieron cargar tus datos para Configuración', err);
    }

    try {
      const perfil = await api.get('./api/profile-visibility');
      marcarPerfilCfg(perfil && perfil.publico ? 'publico' : 'privado');
    } catch (err) {
      console.error('No se pudo cargar la visibilidad del perfil', err);
      marcarPerfilCfg('privado');
    }

    overlay.hidden = false;
  });

  document.getElementById('settingsForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post('./api/biometrics', {
        nombre: document.getElementById('cfgNombre').value.trim(),
        apellido: document.getElementById('cfgApellido').value.trim(),
        correo: overlay.dataset.correo || '',
        peso: parseFloat(document.getElementById('cfgPeso').value) || null,
        estatura: parseFloat(document.getElementById('cfgEstatura').value) || null,
        edad: parseInt(document.getElementById('cfgEdad').value, 10) || null,
        actividad: document.getElementById('cfgActividad').value,
        sexo: overlay.dataset.sexo || null,
        objetivo: objetivoCfg
      });
      await api.post('./api/profile-visibility', { publico: perfilCfg === 'publico' });
      await api.post('./api/avisar-actualizacion-plan', {
        valor: document.getElementById('avisarPlanToggle').classList.contains('active')
      });
      await api.post('./api/recordatorios', {
        agua: document.getElementById('recordarAguaToggle').classList.contains('active'),
        entreno: document.getElementById('recordarEntrenoToggle').classList.contains('active')
      });
    } catch (err) {
      console.error('No se pudieron guardar tus cambios', err);
      return;
    }
    window.location.reload();
  });

  document.getElementById('deleteAccountBtn').addEventListener('click', async () => {
    const msg = window.NutriIdioma
      ? window.NutriIdioma.t('confirm.borrarCuenta', '¿Seguro que quieres borrar tu cuenta? Esta acción no se puede deshacer.')
      : '¿Seguro que quieres borrar tu cuenta? Esta acción no se puede deshacer.';
    if (!confirm(msg)) return;
    try {
      await api.delete('./api/account');
    } catch (err) {
      console.error('No se pudo borrar la cuenta', err);
      return;
    }
    window.location.href = './index.html';
  });
});
