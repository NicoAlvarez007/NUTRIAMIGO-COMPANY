document.addEventListener('DOMContentLoaded', () => {
  const sections = document.querySelectorAll('.section[id]');
  const navLinks = document.querySelectorAll('.nav-link, .nav-mobile a');

  const setActiveLink = (id) => {
    navLinks.forEach(link => link.classList.toggle('active', link.dataset.section === id));
  };

  const spy = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting) setActiveLink(entry.target.id); });
  }, { rootMargin: '-45% 0px -50% 0px', threshold: 0 });

  sections.forEach(sec => spy.observe(sec));

  const navToggle = document.getElementById('navToggle');
  const navMobile = document.getElementById('navMobile');

  const fijarMenu = (abierto) => {
    navMobile.classList.toggle('open', abierto);
    navToggle.setAttribute('aria-expanded', String(abierto));
  };
  navToggle.addEventListener('click', () => fijarMenu(!navMobile.classList.contains('open')));
  navMobile.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => fijarMenu(false));
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && navMobile.classList.contains('open')) {
      fijarMenu(false);
      navToggle.focus();
    }
  });
  document.addEventListener('click', (e) => {
    if (navMobile.classList.contains('open') && !navMobile.contains(e.target) && !navToggle.contains(e.target)) fijarMenu(false);
  });
});
