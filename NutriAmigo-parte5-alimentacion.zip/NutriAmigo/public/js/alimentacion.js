/* Página de Alimentación: plan semanal generado en el navegador (js/generador-comidas.js),
   marcas "Ya lo hice", ayuno intermitente, lista de compras y registro "Mi día". */
(function () {
  const G = window.NutriGenerador;
  const R = window.NutriPlanRender;
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);
  const lang = () => (window.NutriIdioma ? window.NutriIdioma.get() : 'es');
  const $ = (id) => document.getElementById(id);
  const esc = (s) => escapeHtml(s);
  const num = (n, dec) => Number(n).toLocaleString({ es: 'es-CO', en: 'en-US', de: 'de-DE' }[lang()] || 'es-CO', dec === undefined ? {} : { minimumFractionDigits: dec, maximumFractionDigits: dec });

  let user = null;
  let bio = {};
  let prefs = null;
  let perfil = null;
  let plan = null;
  let hoyISO = '';
  let hoyDia = 'lunes';
  let diaActivo = 'lunes';
  let completions = [];
  let kmHoy = 0;
  let foodLog = { items: [], totales: { kcal: 0, proteina: 0, carbohidratos: 0, grasa: 0 } };
  let historial = [];
  let cambios = {};
  let opcionVista = {};
  let seleccionCatalogo = null;
  let relojAyuno = null;

  const premium = () => !!(user && user.isPremium);

  /* ---------- Almacenamiento local (solo conveniencias) ---------- */
  const claveLocal = (nombre) => `nutriamigo_${nombre}_${user ? user.id : 0}_${R.lunesDe(hoyISO)}`;
  function leerLocal(nombre, defecto) {
    try { const v = localStorage.getItem(claveLocal(nombre)); return v ? JSON.parse(v) : defecto; } catch (e) { return defecto; }
  }
  function guardarLocal(nombre, valor) {
    try { localStorage.setItem(claveLocal(nombre), JSON.stringify(valor)); } catch (e) { /* almacenamiento no disponible */ }
  }

  /* ---------- Plan ---------- */
  function kcalExtraHoy() { return R.kcalPorKm(kmHoy, bio.peso); }

  function construirPlan() {
    perfil = R.construirPerfilDePlan(bio, prefs, premium());
    plan = null;
    $('planError').hidden = true;
    if (!perfil) return;
    const opciones = { semilla: R.semillaDeSemana(user.id, hoyISO), kcalExtra: { [hoyDia]: kcalExtraHoy() }, cambios };
    try {
      plan = G.generarPlanSemanal(perfil, opciones);
    } catch (err) {
      if (perfil.ayunoProtocolo) {
        try { perfil = Object.assign({}, perfil, { ayunoProtocolo: null }); plan = G.generarPlanSemanal(perfil, opciones); plan.ayunoIgnorado = true; } catch (e2) { plan = null; }
      }
      if (!plan) {
        console.error('No se pudo armar el plan', err);
        const caja = $('planError');
        caja.hidden = false;
        caja.textContent = t('a.errorPlan', 'No pudimos armar un plan con tantas restricciones a la vez. Quita alguna alergia o restricción en Personalizar e inténtalo de nuevo.');
      }
    }
  }

  /* ---------- Resumen y meta ---------- */
  function renderResumen() {
    const el = $('planSummary');
    const secciones = ['metaPanel', 'weekTabs', 'daySlots', 'miDia', 'todayBar', 'ayunoCard'];
    if (!bio.peso) {
      el.innerHTML = `${t('plan.sinDatos', 'Aún no has completado tus datos.')} <a href="./onboarding.html" class="link-green">${t('plan.completalosAqui', 'Complétalos aquí')}</a> ${t('plan.paraPlanCalculado', 'para un plan calculado para ti.')}`;
      secciones.forEach((id) => { $(id).hidden = true; });
      return;
    }
    const genero = bio.sexo === 'hombre' ? t('plan.hombre', 'hombre') : t('plan.mujer', 'mujer');
    el.innerHTML = `${t('plan.calculadoPara', 'Plan calculado para:')} <b>${genero}</b>, <b>${esc(bio.peso)} kg</b>, <b>${esc(bio.estatura)} cm</b>, ${t('plan.actividad', 'actividad')} <b>${labelActividad(bio.actividad)}</b>, ${t('plan.objetivo', 'objetivo')} <b>${labelObjetivo(bio.objetivo || 'mantener')}</b>. ${t('a.cambiaCadaSemana', 'El plan cambia cada semana.')}`;
    $('weekTabs').hidden = false;
    $('daySlots').hidden = false;
    $('miDia').hidden = false;
  }

  function renderMeta() {
    const panel = $('metaPanel');
    if (!bio.peso || !plan) { panel.hidden = true; return; }
    const d = desgloseMeta(bio);
    const dia = plan.semana.find((x) => x.dia === diaActivo);
    const extra = dia.kcalExtra;
    const macros = calcularMacros(dia.metaKcal, bio.objetivo);
    const trozo = (valor, etiqueta, extraTxt) => `<div class="meta-item"><b>${valor}</b><span>${etiqueta}</span>${extraTxt ? `<small>${extraTxt}</small>` : ''}</div>`;
    $('metaGrid').innerHTML = [
      trozo(`${num(dia.metaKcal)} kcal`, t('a.metaDelDia', 'Meta del día'), extra ? `${num(d.meta)} + ${num(extra)} ${t('a.porEntreno', 'por caminar o correr hoy')}` : ''),
      trozo(`${macros.proteina.gramos} g`, `${t('macro.proteina', 'Proteína')} (${macros.proteina.pct}%)`),
      trozo(`${macros.carbohidratos.gramos} g`, `${t('macro.carbos', 'Carbohidratos')} (${macros.carbohidratos.pct}%)`),
      trozo(`${macros.grasas.gramos} g`, `${t('macro.grasas', 'Grasas')} (${macros.grasas.pct}%)`)
    ].join('');
    const pasos = [
      `${t('a.paso.bmr', 'Gasto en reposo (fórmula Mifflin-St Jeor)')}: <b>${num(d.bmr)} kcal</b>`,
      `${t('a.paso.actividad', 'Por tu nivel de actividad')} ×${num(d.factor, d.factor % 1 ? 3 : 1)}: <b>${num(d.gasto)} kcal</b>`,
      `${t('a.paso.objetivo', 'Ajuste por tu objetivo')} (${labelObjetivo(bio.objetivo || 'mantener')}): <b>${d.ajuste > 0 ? '+' : ''}${num(d.ajuste)} kcal</b>`,
      `${t('a.paso.redondeo', 'Redondeado a la decena')}: <b>${num(d.redondeada)} kcal</b>`
    ];
    if (d.pisoAplicado) pasos.push(`${t('a.paso.piso', 'Mínimo de seguridad aplicado')}: <b>${num(d.piso)} kcal</b>`);
    if (extra) pasos.push(`${t('a.paso.extra', 'Caminar o correr hoy')} (${num(kmHoy, 1)} km): <b>+${num(extra)} kcal</b>`);
    $('metaHow').innerHTML = `<ol class="meta-pasos">${pasos.map((p) => `<li>${p}</li>`).join('')}</ol><p class="field-help">${t('a.paso.nota', 'Son estimaciones generales y no reemplazan a un profesional de la salud.')}</p>`;
    panel.hidden = false;
  }

  /* ---------- Ayuno ---------- */
  function minutosAhora() { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); }
  function duracion(min) {
    const h = Math.floor(min / 60); const m = min % 60;
    return h ? `${h} h ${m} min` : `${m} min`;
  }

  function renderAyuno() {
    const caja = $('ayunoCard');
    if (relojAyuno) { clearInterval(relojAyuno); relojAyuno = null; }
    const guardado = prefs && prefs.ayunoProtocolo;
    if (!bio.peso || !premium() || !guardado) { caja.hidden = true; return; }
    if (!plan || !plan.protocolo) {
      let motivo = t('a.ayuno.meta', 'Con tu meta calórica, este protocolo exigiría comidas demasiado grandes. Elige uno con más comidas en Personalizar.');
      const permiso = G.ayunoPermitido({ edad: bio.edad, estatura: bio.estatura, peso: bio.peso });
      if (!permiso.ok) motivo = permiso.motivo === 'menor' ? t('a.ayuno.menor', 'El ayuno intermitente no está disponible para menores de 18 años.') : t('a.ayuno.imc', 'El ayuno intermitente no está disponible con un IMC menor de 18,5.');
      caja.innerHTML = `<b>${t('a.ayuno', 'Ayuno intermitente')}</b><p>${motivo}</p>`;
      caja.hidden = false;
      return;
    }
    const inicio = perfil.ayunoInicio || '12:00';
    const pintar = () => {
      const est = G.estadoAyuno(plan.protocolo, inicio, minutosAhora());
      const [hh, mm] = inicio.split(':').map(Number);
      const finMin = (hh * 60 + mm + G.PROTOCOLOS[plan.protocolo].ventanaH * 60) % 1440;
      const ventana = `${inicio}–${String(Math.floor(finMin / 60)).padStart(2, '0')}:${String(finMin % 60).padStart(2, '0')}`;
      const estado = est.enAyuno
        ? `<span class="ayuno-pill ayuno-si">${t('a.ayuno.enAyuno', 'Ahora estás en ayuno')}</span> ${t('a.ayuno.abre', 'Puedes comer desde las')} ${est.abre} (${t('a.ayuno.en', 'en')} ${duracion(est.minutos)})`
        : `<span class="ayuno-pill ayuno-no">${t('a.ayuno.puedesComer', 'Ahora puedes comer')}</span> ${t('a.ayuno.cierra', 'La ventana cierra a las')} ${est.cierra} (${t('a.ayuno.en', 'en')} ${duracion(est.minutos)})`;
      caja.innerHTML = `<b>${t('a.ayuno', 'Ayuno intermitente')} ${plan.protocolo}</b> · ${t('a.ayuno.ventana', 'ventana de comida')} ${ventana}<p>${estado}</p>`;
    };
    pintar();
    caja.hidden = false;
    relojAyuno = setInterval(pintar, 30000);
  }

  /* ---------- Días y comidas ---------- */
  function renderTabs() {
    $('weekTabs').innerHTML = G.DIAS.map((d) => {
      const hoyMarca = d === hoyDia ? `<span class="hoy-punto" aria-hidden="true"></span><span class="visually-hidden"> (${t('a.hoy', 'hoy')})</span>` : '';
      return `<button type="button" class="week-tab ${d === diaActivo ? 'active' : ''}" data-dia="${d}">${labelDia(d, false)}${hoyMarca}</button>`;
    }).join('');
  }

  function claveItem(dia, comida, op) { return `alimentacion-${dia}-${comida}-${op}`; }
  function claveMarcada(dia, comida, op) {
    const nueva = claveItem(dia, comida, op);
    if (completions.includes(nueva)) return nueva;
    const antigua = `alimentacion-${dia}-${comida}`;
    return op === 1 && completions.includes(antigua) ? antigua : null;
  }

  function htmlComida(dia, c) {
    const vista = `${dia.dia}|${c.comida}`;
    const op = opcionVista[vista] || 1;
    const plato = c.opciones[op - 1];
    const esHoy = dia.dia === hoyDia;
    const hecho = !!claveMarcada(dia.dia, c.comida, op);
    const hora = c.hora ? `<span class="slot-hora">${c.hora}</span>` : '';
    const porcion = plan.protocolo && plan.factorPorcion >= 1.1 ? `<span class="porcion-badge" title="${t('a.porcionAyuda', 'Porción más grande porque comes en menos comidas')}">×${num(plan.factorPorcion, 1)}</span>` : '';
    const lock = premium() ? '' : `<a class="lock-note" href="./premium.html">🔒 ${t('a.cantidadesPremium', 'Cantidades disponibles con Premium')}</a>`;
    const botonHecho = `<button type="button" class="done-toggle ${hecho ? 'done' : ''}" data-hecho="${dia.dia}|${c.comida}|${op}" ${esHoy ? '' : 'disabled'} ${esHoy ? '' : `title="${t('a.soloHoy', 'Solo puedes marcar las comidas de hoy')}"`}>${hecho ? t('plan.hechoHoy', '✓ Hecho hoy') : t('plan.yaLoHice', 'Ya lo hice')}</button>`;
    return `
    <div class="slot-card" data-comida="${c.comida}">
      <div class="slot-card-header">
        <h4>${labelSlot(c.comida)} ${hora}</h4>
        ${botonHecho}
      </div>
      <div class="seg" role="group" aria-label="${t('a.opciones', 'Opciones')}">
        ${[1, 2].map((n) => `<button type="button" class="seg-btn ${n === op ? 'on' : ''}" aria-pressed="${n === op}" data-vista="${vista}" data-op="${n}">${t('plan.opcion', 'Opción')} ${n}</button>`).join('')}
      </div>
      <h5 class="plato-nombre">${esc(R.nombrePlato(plato))} ${porcion}</h5>
      <p class="plato-macros">${num(plato.kcal)} kcal · ${t('a.prot', 'prot.')} ${num(plato.prot, 0)} g · ${t('a.carb', 'carb.')} ${num(plato.carb, 0)} g · ${t('a.grasa', 'grasa')} ${num(plato.grasa, 0)} g <small>(${t('a.meta', 'meta')} ${num(plato.kcalMeta)} kcal)</small></p>
      ${R.htmlIngredientes(plato, { premium: premium(), medidas: perfil.mostrarMedidas !== false })}
      ${lock}
      <div class="slot-acciones">
        <button type="button" class="btn btn-ghost btn-small" data-cambiar="${dia.dia}|${c.comida}|${op}">🔄 ${t('a.cambiar', 'Cambiar esta comida')}${premium() ? '' : ' 🔒'}</button>
        ${esHoy ? `<button type="button" class="btn btn-ghost btn-small" data-aMiDia="${c.comida}|${op}">＋ ${t('a.agregarAMiDia', 'Agregar a Mi día')}</button>` : ''}
      </div>
    </div>`;
  }

  function renderDia() {
    const wrap = $('daySlots');
    const barra = $('todayBar');
    if (!bio.peso || !plan) { wrap.innerHTML = ''; barra.hidden = true; return; }
    const dia = plan.semana.find((d) => d.dia === diaActivo);
    barra.hidden = false;
    const esHoy = diaActivo === hoyDia;
    $('todayNote').textContent = esHoy ? t('a.hoyNota', 'Hoy: marca lo que vas comiendo.') : t('a.otroDiaNota', 'Solo puedes marcar las comidas de hoy. Este día es para planear.');
    $('resetBtn').hidden = !esHoy;
    wrap.innerHTML = dia.comidas.map((c) => htmlComida(dia, c)).join('');
  }

  /* ---------- Mi día ---------- */
  function renderMiDia() {
    if (!bio.peso) return;
    const meta = plan ? plan.semana.find((d) => d.dia === hoyDia).metaKcal : calcularMetaCalorica(bio);
    const tot = foodLog.totales;
    const pct = meta ? Math.min(100, Math.round((tot.kcal / meta) * 100)) : 0;
    $('miDiaResumen').innerHTML = `
      <div class="barra"><div class="barra-llena ${tot.kcal > meta ? 'sobre' : ''}" style="width:${pct}%"></div></div>
      <p><b>${num(tot.kcal)}</b> / ${num(meta)} kcal · ${t('a.prot', 'prot.')} ${num(tot.proteina, 0)} g · ${t('a.carb', 'carb.')} ${num(tot.carbohidratos, 0)} g · ${t('a.grasa', 'grasa')} ${num(tot.grasa, 0)} g</p>`;
    $('miDiaLista').innerHTML = foodLog.items.length
      ? foodLog.items.map((i) => `<li><span><b>${labelSlot(i.comida)}</b> · ${esc(i.nombre)}${i.gramos ? ` (${num(i.gramos, 0)} g)` : ''}</span><span>${num(i.kcal)} kcal <button type="button" class="icon-btn" data-borrar="${i.id}" aria-label="${t('a.quitar', 'Quitar')}">✕</button></span></li>`).join('')
      : `<li class="vacio">${t('a.sinRegistros', 'Aún no has anotado nada hoy.')}</li>`;
    $('miDiaHistorial').innerHTML = historial.length
      ? historial.map((h) => `<div class="hist-fila"><span>${esc(h.fecha)}</span><span>${num(h.kcal)} kcal · ${t('a.prot', 'prot.')} ${num(h.proteina, 0)} g</span></div>`).join('')
      : `<p class="vacio">${t('a.sinHistorial', 'Todavía no hay registros de los últimos días.')}</p>`;
  }

  function renderComidaSelect() {
    const sel = $('mdComida');
    const actual = sel.value;
    sel.innerHTML = G.COMIDAS.map((c) => `<option value="${c}">${labelSlot(c)}</option>`).join('');
    if (actual) sel.value = actual;
  }

  async function recargarMiDia() {
    foodLog = await api.get('./api/food-log');
    historial = await api.get('./api/food-log/historial');
    renderMiDia();
  }

  async function agregarRegistro(cuerpo) {
    try {
      foodLog = await api.post('./api/food-log', cuerpo);
      historial = await api.get('./api/food-log/historial');
      renderMiDia();
      return true;
    } catch (err) { return false; }
  }

  function buscarAlimentos() {
    const lista = G.buscarIngredientes($('mdBuscar').value, lang());
    $('mdSugerencias').innerHTML = lista.map((i) => `<li><button type="button" data-ing="${i.id}">${esc(R.nombreIngrediente(i.id))}</button></li>`).join('');
    if (!$('mdBuscar').value.trim()) { seleccionCatalogo = null; $('mdGramosFila').hidden = true; }
  }

  function elegirAlimento(id) {
    const ing = G.INGREDIENTES.porId[id];
    seleccionCatalogo = id;
    $('mdGramos').value = ing.base;
    $('mdSeleccion').textContent = R.nombreIngrediente(id);
    $('mdGramosFila').hidden = false;
    $('mdSugerencias').innerHTML = '';
  }

  /* ---------- Acciones ---------- */
  async function alternar(clave) {
    const r = await api.post('./api/completions', { itemKey: clave });
    if (r.completado) completions.push(clave); else completions = completions.filter((k) => k !== clave);
  }

  async function marcar(dia, comida, op) {
    try {
      const actual = claveMarcada(dia, comida, op);
      if (actual) await alternar(actual);
      else {
        const otra = claveMarcada(dia, comida, op === 1 ? 2 : 1);
        if (otra) await alternar(otra);
        await alternar(claveItem(dia, comida, op));
      }
    } catch (err) { console.error('No se pudo registrar la comida', err); }
    renderDia();
  }

  async function reiniciar() {
    if (!window.confirm(t('a.confirmReiniciar', '¿Quitar todas las marcas de comidas de hoy?'))) return;
    try {
      await api.post('./api/completions/reiniciar', { ambito: 'alimentacion' });
      completions = completions.filter((k) => !k.startsWith('alimentacion-'));
    } catch (err) { console.error('No se pudo reiniciar', err); }
    renderDia();
  }

  function cambiarComida(dia, comida, op) {
    if (!premium()) { window.location.href = './premium.html'; return; }
    const k = `${dia}|${comida}|${op}`;
    cambios[k] = (cambios[k] || 0) + 1;
    guardarLocal('cambios', cambios);
    construirPlan();
    renderDia();
    renderMeta();
  }

  /* ---------- Lista de compras ---------- */
  function renderCompras() {
    if (!plan) return;
    const ambas = $('shoppingAmbas').checked;
    const lista = G.listaDeCompras(plan, { opciones: ambas ? [1, 2] : [1] });
    const marcados = leerLocal('compras', []);
    const nombreSeccion = { verduras: t('a.sec.verduras', 'Verduras'), frutas: t('a.sec.frutas', 'Frutas'), proteinas: t('a.sec.proteinas', 'Proteínas'), granos: t('a.sec.granos', 'Granos y tubérculos'), lacteos: t('a.sec.lacteos', 'Lácteos y alternativas'), otros: t('a.sec.otros', 'Grasas y otros') };
    const precio = { economico: t('a.precio.economico', '🟢 Económica'), moderado: t('a.precio.moderado', '🟡 Moderada'), alto: t('a.precio.alto', '🔴 Costosa') }[lista.indicePrecio];
    $('shoppingSub').innerHTML = `${t('a.compraSub', 'Para toda la semana')} · ${t('a.indicePrecio', 'Compra estimada')}: <b>${precio}</b>`;
    $('shoppingBody').innerHTML = lista.secciones.map((s) => `
      <h4>${nombreSeccion[s.id]}</h4>
      <ul class="compras-lista">${s.items.map((i) => {
        const nombre = mayus(i.nombre[lang()] || i.nombre.es);
        const cant = premium() ? `<span class="compras-cant">${esc(G.textoCantidad(i.id, i.gramos, lang(), false))}</span>` : '';
        const eco = perfil.economico && i.economico ? `<span class="eco-badge">${t('a.baratoEtiqueta', 'económico')}</span>` : '';
        return `<li><label><input type="checkbox" data-compra="${i.id}" ${marcados.includes(i.id) ? 'checked' : ''}> <span>${esc(nombre)}</span> ${eco}</label>${cant}</li>`;
      }).join('')}</ul>`).join('') + (premium() ? '' : `<a class="lock-note" href="./premium.html">🔒 ${t('a.cantidadesPremium', 'Cantidades disponibles con Premium')}</a>`);
  }
  const mayus = (s) => s.charAt(0).toUpperCase() + s.slice(1);

  function textoLista() {
    const ambas = $('shoppingAmbas').checked;
    const lista = G.listaDeCompras(plan, { opciones: ambas ? [1, 2] : [1] });
    return lista.secciones.map((s) => s.items.map((i) => `- ${mayus(i.nombre[lang()] || i.nombre.es)}${premium() ? ` ${G.textoCantidad(i.id, i.gramos, lang(), false)}` : ''}`).join('\n')).join('\n');
  }

  /* ---------- Personalizar ---------- */
  const DIETA_PROTEINAS = { omnivoro: ['pollo', 'pescado', 'carne'], pescetariano: ['pescado'], vegetariano: [], vegano: [] };

  function dietaElegida() {
    const b = document.querySelector('#dietaGroup .pill.active');
    return b ? b.dataset.dieta : 'omnivoro';
  }

  function sincronizarProteinas() {
    const permitidas = DIETA_PROTEINAS[dietaElegida()];
    document.querySelectorAll('#proteinasGroup .pill').forEach((b) => {
      const ok = permitidas.includes(b.dataset.proteina);
      b.disabled = !ok;
      if (!ok) b.classList.remove('active');
    });
    $('proteinasField').hidden = permitidas.length === 0;
  }

  function poblarHoras() {
    const sel = $('ayunoInicioSel');
    if (sel.options.length) return;
    for (let m = 8 * 60; m <= 14 * 60; m += 30) {
      const v = String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
      sel.append(new Option(v, v));
    }
  }

  function cargarFormulario() {
    const p = prefs || {};
    const dieta = R.dietaDe(p);
    document.querySelectorAll('#dietaGroup .pill').forEach((b) => { b.classList.toggle('active', b.dataset.dieta === dieta); b.setAttribute('aria-checked', String(b.dataset.dieta === dieta)); });
    document.querySelectorAll('#proteinasGroup .pill').forEach((b) => b.classList.toggle('active', (p.proteinas || []).includes(b.dataset.proteina)));
    sincronizarProteinas();
    document.querySelectorAll('#alergiasGroup input').forEach((c) => { c.checked = (p.alergias || []).includes(c.value); });
    $('restriccionesTexto').value = p.restriccionesTexto || '';
    $('medidasChk').checked = p.mostrarMedidas !== false;
    $('economicoChk').checked = !!p.economico;
    poblarHoras();
    const permiso = G.ayunoPermitido({ edad: bio.edad, estatura: bio.estatura, peso: bio.peso });
    $('ayunoSel').value = permiso.ok ? (p.ayunoProtocolo || '') : '';
    $('ayunoSel').disabled = !permiso.ok;
    $('ayunoInicioSel').disabled = !permiso.ok;
    $('ayunoInicioSel').value = p.ayunoInicio || '12:00';
    $('ayunoAyuda').textContent = permiso.ok
      ? t('a.ayunoAyuda', 'Reparte tus calorías en menos comidas, dentro de una ventana. Consulta con un profesional si tienes dudas.')
      : (permiso.motivo === 'menor' ? t('a.ayuno.menor', 'El ayuno intermitente no está disponible para menores de 18 años.') : t('a.ayuno.imc', 'El ayuno intermitente no está disponible con un IMC menor de 18,5.'));
    $('personalizeError').hidden = true;
  }

  async function guardarPreferencias(ev) {
    ev.preventDefault();
    const dieta = dietaElegida();
    const elegidas = Array.from(document.querySelectorAll('#proteinasGroup .pill.active')).map((b) => b.dataset.proteina);
    const cuerpo = {
      dieta,
      proteinas: dieta === 'vegano' ? ['vegano'] : dieta === 'vegetariano' ? ['vegetariano'] : elegidas,
      alergias: Array.from(document.querySelectorAll('#alergiasGroup input:checked')).map((c) => c.value),
      restriccionesTexto: $('restriccionesTexto').value.trim(),
      mostrarMedidas: $('medidasChk').checked,
      economico: $('economicoChk').checked,
      ayunoProtocolo: $('ayunoSel').value || null,
      ayunoInicio: $('ayunoInicioSel').value || '12:00'
    };
    try {
      await api.post('./api/preferences', cuerpo, { silencioso: true });
    } catch (err) {
      const caja = $('personalizeError');
      caja.textContent = err.message;
      caja.hidden = false;
      return;
    }
    prefs = Object.assign({}, prefs, cuerpo);
    cambios = {};
    guardarLocal('cambios', cambios);
    cerrarModal($('personalizeModal'));
    renderTodo(true);
  }

  function abrirModal(m) { m.hidden = false; document.body.classList.add('modal-open'); }
  function cerrarModal(m) { m.hidden = true; document.body.classList.remove('modal-open'); }

  /* ---------- Pintado general ---------- */
  function renderTodo(reconstruir) {
    if (reconstruir) construirPlan();
    renderResumen();
    if (!bio.peso) return;
    renderMeta();
    renderAyuno();
    renderTabs();
    renderDia();
    renderComidaSelect();
    renderMiDia();
  }

  function descargarPDF() {
    if (!plan) return;
    $('printableBody').innerHTML = R.construirHtmlComidas(plan, perfil, bio.objetivo || 'mantener', { premium: premium() });
    window.print();
  }

  /* ---------- Eventos ---------- */
  function conectarEventos() {
    $('weekTabs').addEventListener('click', (e) => {
      const b = e.target.closest('.week-tab');
      if (!b) return;
      diaActivo = b.dataset.dia;
      renderTabs(); renderDia(); renderMeta();
    });

    $('daySlots').addEventListener('click', (e) => {
      const seg = e.target.closest('[data-op]');
      if (seg) { opcionVista[seg.dataset.vista] = Number(seg.dataset.op); renderDia(); return; }
      const hecho = e.target.closest('[data-hecho]');
      if (hecho && !hecho.disabled) { const [d, c, o] = hecho.dataset.hecho.split('|'); marcar(d, c, Number(o)); return; }
      const cambiar = e.target.closest('[data-cambiar]');
      if (cambiar) { const [d, c, o] = cambiar.dataset.cambiar.split('|'); cambiarComida(d, c, Number(o)); return; }
      const aMiDia = e.target.closest('[data-aMiDia]');
      if (aMiDia) {
        const [c, o] = aMiDia.dataset.amidia.split('|');
        const plato = plan.semana.find((d) => d.dia === hoyDia).comidas.find((x) => x.comida === c).opciones[Number(o) - 1];
        agregarRegistro({ comida: c, nombre: R.nombrePlato(plato), kcal: plato.kcal, proteina: plato.prot, carbohidratos: plato.carb, grasa: plato.grasa });
      }
    });

    $('resetBtn').addEventListener('click', reiniciar);
    $('downloadMealsBtn').addEventListener('click', descargarPDF);

    $('personalizeBtn').addEventListener('click', () => {
      if (!premium()) { window.location.href = './premium.html'; return; }
      cargarFormulario();
      abrirModal($('personalizeModal'));
    });
    $('closeModalBtn').addEventListener('click', () => cerrarModal($('personalizeModal')));
    $('personalizeForm').addEventListener('submit', guardarPreferencias);
    $('dietaGroup').addEventListener('click', (e) => {
      const b = e.target.closest('.pill');
      if (!b) return;
      document.querySelectorAll('#dietaGroup .pill').forEach((x) => { x.classList.toggle('active', x === b); x.setAttribute('aria-checked', String(x === b)); });
      sincronizarProteinas();
    });
    $('proteinasGroup').addEventListener('click', (e) => {
      const b = e.target.closest('.pill');
      if (b && !b.disabled) b.classList.toggle('active');
    });

    $('shoppingBtn').addEventListener('click', () => { renderCompras(); abrirModal($('shoppingModal')); });
    $('shoppingClose').addEventListener('click', () => cerrarModal($('shoppingModal')));
    $('shoppingAmbas').addEventListener('change', renderCompras);
    $('shoppingBody').addEventListener('change', (e) => {
      const c = e.target.closest('[data-compra]');
      if (!c) return;
      const m = new Set(leerLocal('compras', []));
      if (c.checked) m.add(c.dataset.compra); else m.delete(c.dataset.compra);
      guardarLocal('compras', [...m]);
    });
    $('shoppingCopy').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(textoLista()); window.mostrarAviso(t('a.copiado', 'Lista copiada'), 'info'); } catch (err) { window.mostrarAviso(t('a.noCopiado', 'No se pudo copiar la lista'), 'error'); }
    });
    document.querySelectorAll('.modal-overlay').forEach((o) => o.addEventListener('click', (e) => { if (e.target === o) cerrarModal(o); }));

    $('mdBuscar').addEventListener('input', buscarAlimentos);
    $('mdSugerencias').addEventListener('click', (e) => { const b = e.target.closest('[data-ing]'); if (b) elegirAlimento(b.dataset.ing); });
    $('mdAgregarCat').addEventListener('click', async () => {
      const gramos = Number($('mdGramos').value);
      if (!seleccionCatalogo || !(gramos > 0)) return;
      const m = G.macrosDe(seleccionCatalogo, gramos);
      const ok = await agregarRegistro({ comida: $('mdComida').value, nombre: R.nombreIngrediente(seleccionCatalogo), gramos, kcal: m.kcal, proteina: m.prot, carbohidratos: m.carb, grasa: m.grasa });
      if (ok) { $('mdBuscar').value = ''; seleccionCatalogo = null; $('mdGramosFila').hidden = true; }
    });
    $('mdAgregarLibre').addEventListener('click', async () => {
      const ok = await agregarRegistro({ comida: $('mdComida').value, nombre: $('mdNombre').value, kcal: $('mdKcal').value, proteina: $('mdProt').value, carbohidratos: $('mdCarb').value, grasa: $('mdGrasa').value });
      if (ok) ['mdNombre', 'mdKcal', 'mdProt', 'mdCarb', 'mdGrasa'].forEach((id) => { $(id).value = ''; });
    });
    $('miDiaLista').addEventListener('click', async (e) => {
      const b = e.target.closest('[data-borrar]');
      if (!b) return;
      try { foodLog = await api.delete(`./api/food-log/${b.dataset.borrar}`); historial = await api.get('./api/food-log/historial'); renderMiDia(); } catch (err) { console.error(err); }
    });

    document.addEventListener('nutriamigo:lang-changed', () => { renderTodo(false); if (!$('shoppingModal').hidden) renderCompras(); });
  }

  async function cargarDatos() {
    const seguro = async (fn, defecto) => { try { return await fn(); } catch (err) { console.error(err); return defecto; } };
    bio = (await seguro(() => api.get('./api/biometrics'), {})) || {};
    prefs = await seguro(() => api.get('./api/preferences', { silencioso: true }), null);
    completions = await seguro(() => api.get('./api/completions'), []);
    const log = await seguro(() => api.get('./api/daily-log'), null);
    kmHoy = (log && log.km_recorridos) || 0;
    foodLog = await seguro(() => api.get('./api/food-log'), foodLog);
    historial = await seguro(() => api.get('./api/food-log/historial'), []);
  }

  document.addEventListener('nutriamigo:user-ready', async (e) => {
    user = e.detail;
    if (!user) return;
    hoyISO = user.today || new Date().toISOString().slice(0, 10);
    hoyDia = R.diaDeFecha(hoyISO);
    diaActivo = hoyDia;
    conectarEventos();
    await cargarDatos();
    cambios = leerLocal('cambios', {});
    renderTodo(true);
  });
})();
