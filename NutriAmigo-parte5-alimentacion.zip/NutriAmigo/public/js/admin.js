(function () {
  const $ = (id) => document.getElementById(id);

  function h(tag, attrs, ...hijos) {
    const e = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (v === true) e.setAttribute(k, '');
      else if (v !== false && v != null) e.setAttribute(k, v);
    });
    hijos.flat().forEach(c => { if (c != null) e.append(c.nodeType ? c : document.createTextNode(c)); });
    return e;
  }

  const METODOS = { GET: 'get', POST: 'post', DELETE: 'delete' };

  async function api(url, metodo = 'GET', cuerpo) {
    const opciones = { silencioso: true };
    const llamada = METODOS[metodo];
    return llamada === 'post' ? window.api.post(url, cuerpo, opciones) : window.api[llamada](url, opciones);
  }

  function avisar(texto, error) {
    const a = $('aviso');
    a.textContent = texto;
    a.className = 'admin-aviso' + (error ? ' error' : '');
    a.hidden = !texto;
    if (texto) a.scrollIntoView({ block: 'nearest' });
  }

  async function ejecutar(fn) {
    try { await fn(); } catch (err) { avisar(err.message, true); }
  }

  function formatearBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(1) + ' MB';
  }

  function formatearDuracion(seg) {
    const d = Math.floor(seg / 86400), hh = Math.floor(seg % 86400 / 3600), m = Math.floor(seg % 3600 / 60);
    return (d ? d + ' d ' : '') + hh + ' h ' + m + ' min';
  }

  function fechaLegible(iso) {
    if (!iso) return '—';
    const f = new Date(iso);
    return Number.isNaN(f.getTime()) ? iso : f.toLocaleString('es-CO');
  }

  /* ---------- Fecha simulada ---------- */
  async function vistaFecha(cont) {
    const estado = await api('./api/admin/fecha');
    const info = h('p', { class: 'nota' });
    const entrada = h('input', { type: 'date', id: 'fechaSim', 'aria-label': 'Fecha simulada', value: estado.simulada || estado.hoy });

    const pintar = (s) => {
      info.textContent = s.simulada ? 'Fecha simulada activa: ' + s.simulada + '. Solo afecta a tu cuenta de administrador.'
        : 'Sin fecha simulada. Hoy es ' + estado.hoy + '.';
    };
    pintar(estado);

    async function cambiar(cuerpo, msg) {
      await ejecutar(async () => {
        const r = await api('./api/admin/fecha', 'POST', cuerpo);
        pintar(r);
        if (r.simulada) entrada.value = r.simulada;
        avisar(msg + ' Recarga las otras pestañas de la app para ver el efecto.');
      });
    }

    cont.append(h('section', { class: 'admin-card' },
      h('h2', {}, 'Fecha simulada'),
      info,
      h('div', { class: 'admin-fila' },
        entrada,
        h('button', { type: 'button', class: 'btn btn-primary', onclick: () => cambiar({ fecha: entrada.value }, 'Fecha aplicada.') }, 'Aplicar'),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => cambiar({ sumarDias: 1 }, 'Avanzaste 1 día.') }, '+1 día'),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => cambiar({ sumarDias: 7 }, 'Avanzaste 7 días.') }, '+7 días'),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => cambiar({ reset: true }, 'Volviste a la fecha real.') }, 'Volver a hoy')
      )
    ));
  }

  /* ---------- Usuarios ---------- */
  function vistaUsuarios(cont) {
    let pagina = 1;
    let termino = '';
    const lista = h('div', { class: 'usuarios-lista' });
    const pie = h('div', { class: 'admin-fila' });
    const detalle = h('div');
    const buscador = h('input', { type: 'search', 'aria-label': 'Buscar usuarios', placeholder: 'Nombre, correo o usuario', maxlength: '80' });

    async function cargar() {
      await ejecutar(async () => {
        const r = await api('./api/admin/usuarios?pagina=' + pagina + '&q=' + encodeURIComponent(termino));
        lista.replaceChildren(...(r.items.length ? r.items.map(filaUsuario) : [h('p', { class: 'nota' }, 'Sin resultados.')]));
        pie.replaceChildren(
          h('button', { type: 'button', class: 'btn btn-ghost', disabled: r.pagina <= 1, onclick: () => { pagina--; cargar(); } }, 'Anterior'),
          h('span', {}, 'Página ' + r.pagina + ' de ' + r.paginas + ' · ' + r.total + ' cuentas'),
          h('button', { type: 'button', class: 'btn btn-ghost', disabled: r.pagina >= r.paginas, onclick: () => { pagina++; cargar(); } }, 'Siguiente')
        );
      });
    }

    function filaUsuario(u) {
      return h('div', { class: 'usuario-item' },
        h('div', {},
          h('strong', {}, u.nombre, u.rol === 'admin' ? h('span', { class: 'etiqueta' }, 'Admin') : null,
            u.premium ? h('span', { class: 'etiqueta' }, 'Premium') : null,
            u.suspendida ? h('span', { class: 'etiqueta rojo' }, 'Suspendida') : null),
          h('span', { class: 'meta' }, (u.correo || u.usuario || 'sin correo') + ' · alta ' + fechaLegible(u.creada))),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => abrirDetalle(u.id) }, 'Ver detalle'));
    }

    async function abrirDetalle(id) {
      await ejecutar(async () => {
        const u = await api('./api/admin/usuarios/' + id);
        const motivo = h('input', { type: 'text', 'aria-label': 'Motivo de la suspensión', placeholder: 'Motivo de la suspensión', maxlength: '200' });
        const salida = h('div');
        const dato = (t, v) => [h('dt', {}, t), h('dd', {}, v == null || v === '' ? '—' : String(v))];

        const acciones = h('div', { class: 'admin-fila' });
        if (u.rol !== 'admin') {
          if (u.suspendida) {
            acciones.append(h('button', { type: 'button', class: 'btn btn-primary', onclick: () => ejecutar(async () => {
              await api('./api/admin/usuarios/' + id + '/reactivar', 'POST'); avisar('Cuenta reactivada.'); abrirDetalle(id); cargar();
            }) }, 'Reactivar'));
          } else {
            acciones.append(motivo, h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => ejecutar(async () => {
              if (!motivo.value.trim()) throw new Error('Escribe el motivo de la suspensión.');
              await api('./api/admin/usuarios/' + id + '/suspender', 'POST', { motivo: motivo.value }); avisar('Cuenta suspendida.'); abrirDetalle(id); cargar();
            }) }, 'Suspender'));
          }
        }
        acciones.append(h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => ejecutar(async () => {
          if (!confirm('¿Generar una contraseña temporal para ' + u.nombre + '? La actual dejará de funcionar.')) return;
          const r = await api('./api/admin/usuarios/' + id + '/restablecer-contrasena', 'POST');
          salida.replaceChildren(h('p', { class: 'nota' }, 'Contraseña temporal (solo se muestra ahora):'), h('span', { class: 'clave-temporal' }, r.temporal));
          avisar('Contraseña restablecida.');
        }) }, 'Restablecer contraseña'));
        if (u.rol !== 'admin') {
          acciones.append(h('button', { type: 'button', class: 'btn btn-peligro', onclick: () => ejecutar(async () => {
            if (!confirm('¿Eliminar la cuenta de ' + u.nombre + ' y todos sus datos? No se puede deshacer.')) return;
            await api('./api/admin/usuarios/' + id, 'DELETE'); avisar('Cuenta eliminada.'); detalle.replaceChildren(); cargar();
          }) }, 'Eliminar cuenta'));
        }

        detalle.replaceChildren(h('section', { class: 'admin-card' },
          h('h2', {}, 'Detalle de ' + u.nombre),
          h('dl', { class: 'detalle-grid' },
            dato('ID', u.id), dato('Correo', u.correo), dato('Usuario', u.usuario), dato('Rol', u.rol),
            dato('Acceso con', u.proveedor), dato('Tiene contraseña', u.tieneContrasena ? 'Sí' : 'No'),
            dato('Premium', u.premium ? 'Sí' : 'No'), dato('Suspendida', u.suspendida ? 'Sí: ' + (u.motivoSuspension || '') : 'No'),
            dato('Alta', fechaLegible(u.creada)), dato('Zona horaria', u.zonaHoraria),
            dato('Completó su registro', u.tieneDatos ? 'Sí' : 'No'), dato('Autorización de adulto', u.consentimientoAdulto ? 'Registrada' : 'No aplica')),
          acciones, salida));
        detalle.scrollIntoView({ block: 'nearest' });
      });
    }

    buscador.addEventListener('input', () => {
      clearTimeout(buscador._t);
      buscador._t = setTimeout(() => { termino = buscador.value.trim(); pagina = 1; cargar(); }, 300);
    });

    cont.append(h('section', { class: 'admin-card' }, h('h2', {}, 'Usuarios'), h('div', { class: 'admin-fila' }, buscador), lista, pie), detalle);
    cargar();
  }

  /* ---------- Interruptores de funciones ---------- */
  async function vistaFunciones(cont) {
    const etiquetas = { chat: 'Chat de la comunidad', reels: 'Reels', amigos: 'Amigos', anuncios: 'Anuncios (versión gratuita)' };
    const estado = await api('./api/admin/funciones');
    const card = h('section', { class: 'admin-card' }, h('h2', {}, 'Interruptores de funciones'),
      h('p', { class: 'nota' }, 'Si apagas una función, las páginas muestran “Función no disponible por ahora”.'));

    Object.keys(etiquetas).forEach(clave => {
      const boton = h('button', { type: 'button', class: 'btn btn-ghost', role: 'switch' });
      const pintar = () => { boton.textContent = estado[clave] ? 'Activa' : 'Apagada'; boton.setAttribute('aria-checked', String(!!estado[clave])); boton.setAttribute('aria-pressed', String(!!estado[clave])); };
      boton.addEventListener('click', () => ejecutar(async () => {
        const r = await api('./api/admin/funciones/' + clave, 'POST', { activo: !estado[clave] });
        Object.assign(estado, r); pintar(); avisar(etiquetas[clave] + (estado[clave] ? ' activada.' : ' apagada.'));
      }));
      pintar();
      card.append(h('div', { class: 'interruptor-fila' }, h('span', {}, etiquetas[clave]), boton));
    });
    cont.append(card);
  }

  /* ---------- Estado del servidor ---------- */
  async function vistaServidor(cont) {
    const e = await api('./api/admin/estado');
    const dato = (v, t) => h('div', { class: 'estado-dato' }, h('b', {}, String(v)), h('span', {}, t));
    const lista = (items, vacio, fn) => h('div', { class: 'log-lista' }, items.length ? items.map(fn) : [h('div', {}, vacio)]);

    cont.append(
      h('section', { class: 'admin-card' }, h('h2', {}, 'Estado del servidor'),
        h('div', { class: 'estado-grid' },
          dato(e.version, 'Versión'), dato(e.node, 'Node'), dato(formatearDuracion(e.uptimeSegundos), 'Tiempo activo'),
          dato(e.usuarios, 'Usuarios'), dato(e.premium, 'Premium'), dato(e.suspendidos, 'Suspendidos'),
          dato(formatearBytes(e.bytesBase), 'Base de datos'), dato(formatearBytes(e.bytesUploads), 'Carpeta uploads'))),
      h('section', { class: 'admin-card' }, h('h2', {}, 'Últimos errores (máx. 20)'),
        lista(e.errores, 'Sin errores registrados.', x => h('div', {}, fechaLegible(x.creado_en) + ' — ' + x.detalle))),
      h('section', { class: 'admin-card' }, h('h2', {}, 'Últimas acciones'),
        lista(e.acciones, 'Sin acciones registradas.', x => h('div', {}, fechaLegible(x.creado_en) + ' — ' + x.accion + (x.detalle ? ' (' + x.detalle + ')' : '')))));
  }

  /* ---------- Idioma/tema y funciones de partes posteriores ---------- */
  function vistaPruebas(cont) {
    const idioma = h('div', { class: 'admin-fila' }, ['es', 'en', 'de'].map(l =>
      h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => { window.NutriIdioma.set(l); avisar('Idioma cambiado a ' + l.toUpperCase() + '.'); } }, l.toUpperCase())));
    const tema = h('div', { class: 'admin-fila' }, [['claro', 'Tema claro'], ['dark', 'Tema oscuro'], ['auto', 'Automático']].map(([v, t]) =>
      h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => {
        window.NutriTema.set(v);
        avisar(t + ' aplicado.');
      } }, t)));

    const pendientes = [
      ['Reiniciar el día', 'Borra marcas, agua, km y sueño/ánimo de la fecha actual.', 'Parte 4'],
      ['Modo sin conexión', 'Simula que no hay internet para probar el comportamiento.', 'Parte 11'],
      ['Premium', 'Activar/desactivar Premium, simular pago aprobado o rechazado.', 'Parte 10'],
      ['Racha', 'Ver racha y protectores; dar, quitar o fijar la racha.', 'Parte 4'],
      ['Rango y logros', 'Subir/bajar rango; desbloquear o borrar logros.', 'Parte 8'],
      ['Datos de ejemplo', 'Historial de 90 días, agua, km y fotos de ejemplo.', 'Parte 7'],
      ['Moderación', 'Reels y reportes; borrar contenido y suspender autores.', 'Parte 9'],
      ['Preguntas sin respuesta del bot', 'Lista con conteo.', 'Parte 11'],
      ['Avisos y notificaciones', 'Probar aviso en pantalla y notificación del navegador.', 'Parte 7'],
      ['Versión Química', 'Abrir /quimica/.', 'Parte 12']
    ];

    cont.append(
      h('section', { class: 'admin-card' }, h('h2', {}, 'Idioma y tema'), h('p', { class: 'nota' }, 'Para revisar traducciones rápido.'), idioma, tema),
      h('section', { class: 'admin-card' }, h('h2', {}, 'Herramientas de otras partes'),
        h('div', { class: 'prox-grid' }, pendientes.map(([nombre, desc, parte]) =>
          h('div', { class: 'prox-item' }, h('strong', {}, nombre), h('small', {}, desc),
            h('button', { type: 'button', class: 'btn btn-ghost', disabled: true, 'aria-disabled': 'true' }, 'Disponible en la ' + parte))))));
  }

  /* ---------- Probar el generador de comidas (Parte 5) ---------- */
  function vistaGenerador(cont) {
    const G = window.NutriGenerador;
    const campo = (etiqueta, el) => h('label', { class: 'admin-campo' }, h('span', {}, etiqueta), el);
    const kcal = h('input', { type: 'number', min: '1000', max: '4000', step: '50', value: '2200' });
    const prot = h('input', { type: 'number', min: '30', max: '300', step: '5', value: '130' });
    const dieta = h('select', {}, G.DIETAS.map(d => h('option', { value: d }, d)));
    const alergias = h('input', { type: 'text', placeholder: 'lactosa, gluten, huevo, frutos_secos, soya, marisco' });
    const texto = h('input', { type: 'text', placeholder: 'Ej. no como cerdo' });
    const ayuno = h('select', {}, [['', 'Sin ayuno'], ['14:10', '14:10'], ['16:8', '16:8'], ['18:6', '18:6']].map(([v, n]) => h('option', { value: v }, n)));
    const eco = h('input', { type: 'checkbox' });
    const semilla = h('input', { type: 'text', value: 'admin' });
    const salida = h('div', { class: 'admin-resultado' });

    function generar() {
      const perfil = {
        metaKcal: Number(kcal.value), proteinaG: Number(prot.value), dieta: dieta.value,
        alergias: alergias.value.split(',').map(x => x.trim()).filter(x => G.ALERGIAS.includes(x)),
        restriccionesTexto: texto.value, economico: eco.checked, ayunoProtocolo: ayuno.value || null, ayunoInicio: '12:00', proteinasElegidas: []
      };
      salida.textContent = '';
      try {
        const plan = G.generarPlanSemanal(perfil, { semilla: semilla.value });
        const v = G.validarPlan(plan, perfil);
        const prohibidas = [...G.etiquetasProhibidas(perfil)].join(', ') || 'ninguna';
        salida.append(h('p', { class: v.ok ? 'nota' : 'error' },
          (v.ok ? 'Plan válido: ningún plato usa etiquetas prohibidas. ' : 'HAY ' + v.errores.length + ' VIOLACIONES: ' + JSON.stringify(v.errores.slice(0, 3)) + '. ')
          + 'Etiquetas prohibidas: ' + prohibidas + '.' + (plan.ayunoIgnorado ? ' (Ayuno ignorado: la meta es muy alta para ese protocolo.)' : '')));
        plan.semana.forEach(d => {
          salida.append(h('h3', {}, d.dia + ' — ' + d.metaKcal + ' kcal'));
          d.comidas.forEach(c => c.opciones.forEach(p => {
            const desvio = Math.round((p.kcal - p.kcalMeta) / p.kcalMeta * 1000) / 10;
            salida.append(h('div', {}, c.comida + (c.hora ? ' ' + c.hora : '') + ' · op.' + p.opcion + ' · ' + p.nombre.es + ' — ' + p.kcal + '/' + p.kcalMeta + ' kcal (' + desvio + '%), prot ' + p.prot + '/' + p.protMeta + ' g · '
              + p.ingredientes.map(i => i.id + ' ' + i.gramos).join(', ')));
          }));
        });
      } catch (err) {
        salida.append(h('p', { class: 'error' }, 'No se pudo armar el plan (' + (err.code || 'error') + '): ' + (err.detalle || err.message)));
      }
    }

    cont.append(h('section', { class: 'admin-card' },
      h('h2', {}, 'Probar el generador de comidas'),
      h('p', { class: 'nota' }, 'Arma una semana con los datos que pongas, sin tocar ninguna cuenta. Cambia la semilla para ver otra semana.'),
      campo('Meta kcal', kcal), campo('Proteína (g)', prot), campo('Dieta', dieta), campo('Alergias (separadas por coma)', alergias),
      campo('Otras restricciones', texto), campo('Ayuno', ayuno), campo('Plan económico', eco), campo('Semilla', semilla),
      h('div', { class: 'admin-fila' },
        h('button', { type: 'button', class: 'btn btn-primary', onclick: generar }, 'Generar'),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => { semilla.value = 'admin-' + Math.floor(Math.random() * 10000); generar(); } }, 'Otra semilla')),
      salida));
  }

  const VISTAS = [
    ['fecha', 'Fecha simulada', vistaFecha],
    ['usuarios', 'Usuarios', vistaUsuarios],
    ['funciones', 'Funciones', vistaFunciones],
    ['generador', 'Generador de comidas', vistaGenerador],
    ['servidor', 'Servidor', vistaServidor],
    ['pruebas', 'Idioma y más', vistaPruebas]
  ];

  async function mostrar(clave) {
    avisar('');
    document.querySelectorAll('.admin-tab').forEach(b => b.setAttribute('aria-selected', String(b.dataset.vista === clave)));
    const cont = $('contenido');
    cont.replaceChildren();
    const vista = VISTAS.find(v => v[0] === clave);
    try { await vista[2](cont); } catch (err) { avisar(err.message, true); }
    try { sessionStorage.setItem('admin_vista', clave); } catch (e) { /* sin almacenamiento */ }
  }

  document.addEventListener('DOMContentLoaded', () => {
    VISTAS.forEach(([clave, nombre]) => {
      $('tabs').append(h('button', { type: 'button', class: 'admin-tab', role: 'tab', 'data-vista': clave, 'aria-selected': 'false', onclick: () => mostrar(clave) }, nombre));
    });
    $('salirBtn').addEventListener('click', async () => {
      try { await window.api.post('./auth/logout', undefined, { silencioso: true }); } catch (e) { console.error('No se pudo cerrar sesión', e); }
      location.href = './index.html';
    });
    let inicial = 'fecha';
    try { inicial = sessionStorage.getItem('admin_vista') || 'fecha'; } catch (e) { /* sin almacenamiento */ }
    mostrar(VISTAS.some(v => v[0] === inicial) ? inicial : 'fecha');
  });
})();
