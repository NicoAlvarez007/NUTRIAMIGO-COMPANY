(function () {
  var tema = 'claro';
  try {
    var guardado = localStorage.getItem('nutriamigo_theme');
    if (guardado === 'dark' || guardado === 'claro') tema = guardado;
    else if (guardado === 'auto') tema = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'claro';
  } catch (e) { /* almacenamiento no disponible: se usa el tema claro */ }
  document.documentElement.setAttribute('data-theme', tema);
})();
