/* ==========================================================================
   Generador de comidas de NutriAmigo (sin servidor, sin textos fijos de platos).
   Un plato = plantilla + ingredientes del catálogo + cantidades calculadas para
   cumplir las calorías y la proteína de esa comida. Es una función pura: la misma
   entrada (perfil + semilla) produce siempre el mismo plan.
   Funciona en el navegador (window.NutriGenerador) y en Node (require) para las pruebas.
   ========================================================================== */
(function (global) {
  const isNode = typeof module !== 'undefined' && module.exports;
  const ING = isNode ? require('../data/ingredientes.js') : global.NA_INGREDIENTES;
  const PLANT = isNode ? require('../data/plantillas-comidas.js') : global.NA_PLANTILLAS;

  const DIAS = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'];
  const COMIDAS = ['desayuno', 'almuerzo', 'media_tarde', 'cena'];
  const PESOS = { desayuno: 0.25, almuerzo: 0.35, media_tarde: 0.10, cena: 0.30 };
  const TOLERANCIA = 0.07;
  const PROTOCOLOS = { '14:10': { ventanaH: 10, comidas: ['desayuno', 'almuerzo', 'media_tarde', 'cena'] },
    '16:8': { ventanaH: 8, comidas: ['almuerzo', 'media_tarde', 'cena'] },
    '18:6': { ventanaH: 6, comidas: ['almuerzo', 'cena'] } };
  const DIETAS = ['omnivoro', 'pescetariano', 'vegetariano', 'vegano'];
  const ALERGIAS = ['lactosa', 'gluten', 'huevo', 'frutos_secos', 'soya', 'marisco'];

  /* ---------- Azar con semilla ---------- */
  function hashTexto(s) {
    let h = 2166136261;
    for (let i = 0; i < s.length; i += 1) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function crearRng(...partes) {
    let a = hashTexto(partes.join('|')) || 1;
    return function rng() {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function elegirPonderado(items, pesoDe, rng) {
    const pesos = items.map(pesoDe);
    const total = pesos.reduce((a, b) => a + b, 0);
    if (!(total > 0)) return null;
    let r = rng() * total;
    for (let i = 0; i < items.length; i += 1) { r -= pesos[i]; if (r <= 0) return items[i]; }
    return items[items.length - 1];
  }

  /* ---------- Restricciones ---------- */
  const SIN_ACENTO = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const PALABRAS = [
    [/\b(cerdo|puerco|chancho|pork|schwein\w*)\b/, ['cerdo']],
    [/\b(res|vacuno|beef|rind\w*)\b|carne de res/, ['res']],
    [/\b(pollo|ave|aves|pavo|chicken|turkey|huhn|hahnchen|puten?\w*|gefluegel)\b/, ['ave']],
    [/\b(pescado|pescados|fish|fisch\w*|atun|salmon|tilapia|tuna|lachs|thunfisch)\b/, ['pescado']],
    [/\b(marisco|mariscos|camaron|camarones|shrimp|seafood|garnelen?|meeresfruchte)\b/, ['marisco']],
    [/\b(carne|carnes|meat|fleisch)\b/, ['carne']],
    [/\b(huevo|huevos|egg|eggs|eier?)\b/, ['huevo']],
    [/\b(lactosa|lactose|laktose)\b/, ['lactosa']],
    [/\b(leche|lacteo|lacteos|dairy|milk|milch\w*|queso|quesos|cheese|kase|yogur|yogurt|joghurt)\b/, ['lacteo', 'lactosa']],
    [/\b(gluten)\b/, ['gluten']],
    [/\b(mani|cacahuate|cacahuetes?|peanuts?|erdnuss\w*|erdnusse)\b/, ['mani']],
    [/\b(nueces|nuez|almendras?|frutos secos|nuts?|nuss\w*|nusse|mandeln)\b/, ['frutos_secos']],
    [/\b(soya|soja|soy|tofu)\b/, ['soya']],
    [/\b(miel|honey|honig)\b/, ['miel']],
    [/\b(legumbres?|lentejas?|frijoles?|garbanzos?|beans|lentils|hulsenfruchte|linsen|bohnen)\b/, ['legumbre']]
  ];
  const DIETA_ETIQUETAS = {
    omnivoro: [],
    pescetariano: ['carne'],
    vegetariano: ['carne', 'pescado', 'marisco'],
    vegano: ['carne', 'pescado', 'marisco', 'huevo', 'lacteo', 'lactosa', 'miel']
  };
  const ALERGIA_ETIQUETAS = {
    lactosa: ['lactosa'], gluten: ['gluten'], huevo: ['huevo'], frutos_secos: ['frutos_secos', 'mani'],
    soya: ['soya'], marisco: ['marisco']
  };

  function etiquetasDeTexto(texto) {
    const t = SIN_ACENTO(texto);
    const out = new Set();
    PALABRAS.forEach(([re, tags]) => { if (re.test(t)) tags.forEach((x) => out.add(x)); });
    return out;
  }

  /* Conjunto de etiquetas que NO pueden aparecer en ningún plato. */
  function etiquetasProhibidas(perfil) {
    const out = new Set();
    (DIETA_ETIQUETAS[perfil.dieta] || []).forEach((x) => out.add(x));
    (perfil.alergias || []).forEach((a) => (ALERGIA_ETIQUETAS[a] || []).forEach((x) => out.add(x)));
    etiquetasDeTexto(perfil.restriccionesTexto).forEach((x) => out.add(x));
    return out;
  }
  function permitido(ing, prohibidas) { return !ing.etiquetas.some((e) => prohibidas.has(e)); }

  /* ---------- Reparto de calorías y ayuno ---------- */
  function slotsDelDia(protocolo) {
    return PROTOCOLOS[protocolo] ? PROTOCOLOS[protocolo].comidas.slice() : COMIDAS.slice();
  }

  /* Reparte "total" entre las comidas según sus pesos; la última absorbe el redondeo para que la suma sea exacta. */
  function repartir(total, slots, decimales = 0) {
    const sumaPesos = slots.reduce((a, s) => a + PESOS[s], 0);
    const f = 10 ** decimales;
    const out = {};
    let acumulado = 0;
    slots.forEach((s, i) => {
      if (i === slots.length - 1) out[s] = Math.round((total - acumulado) * f) / f;
      else { out[s] = Math.round(total * PESOS[s] / sumaPesos * f) / f; acumulado += out[s]; }
    });
    return out;
  }
  function factorPorcion(protocolo) {
    const slots = slotsDelDia(protocolo);
    return 1 / slots.reduce((a, s) => a + PESOS[s], 0);
  }

  function aMinutos(hhmm) { const [h, m] = String(hhmm || '12:00').split(':').map(Number); return h * 60 + m; }
  function aHHMM(min) {
    const m = ((Math.round(min) % 1440) + 1440) % 1440;
    return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
  }
  /* Horas de cada comida repartidas dentro de la ventana (la última termina antes de que cierre), a múltiplos de 30 min. */
  function horasDeComidas(protocolo, inicio) {
    const p = PROTOCOLOS[protocolo];
    if (!p) return null;
    const ini = aMinutos(inicio);
    const n = p.comidas.length;
    const util = p.ventanaH * 60 - 60;
    const out = {};
    p.comidas.forEach((c, i) => {
      const bruto = ini + (n === 1 ? 0 : (util * i) / (n - 1));
      out[c] = aHHMM(Math.round(bruto / 30) * 30);
    });
    return out;
  }
  /* ¿Está ahora dentro de la ventana de comida? Maneja ventanas que cruzan la medianoche. */
  function estadoAyuno(protocolo, inicio, ahoraMin) {
    const p = PROTOCOLOS[protocolo];
    if (!p) return null;
    const largo = p.ventanaH * 60;
    const desdeInicio = (((ahoraMin - aMinutos(inicio)) % 1440) + 1440) % 1440;
    if (desdeInicio < largo) return { enAyuno: false, minutos: largo - desdeInicio, cierra: aHHMM(aMinutos(inicio) + largo) };
    return { enAyuno: true, minutos: 1440 - desdeInicio, abre: aHHMM(aMinutos(inicio)) };
  }
  const KCAL_MAX_COMIDA = 1350;
  const META_MAX = 4000;
  /* El protocolo solo es viable si la comida más grande no pasa de ~1500 kcal. */
  function ayunoViable(metaKcal, protocolo) {
    if (!PROTOCOLOS[protocolo]) return true;
    return metaKcal * PESOS.almuerzo / PROTOCOLOS[protocolo].comidas.reduce((a, s) => a + PESOS[s], 0) <= KCAL_MAX_COMIDA;
  }
  function ayunoPermitido({ edad, estatura, peso }) {
    if (!(edad >= 18)) return { ok: false, motivo: 'menor' };
    if (estatura > 0 && peso > 0 && peso / ((estatura / 100) ** 2) < 18.5) return { ok: false, motivo: 'imc_bajo' };
    return { ok: true };
  }

  /* ---------- Roles y selección de ingredientes ---------- */
  function parseRol(texto) {
    const m = /^([A-Z])(\d?)(?:=(.+))?$/.exec(texto);
    return { clave: texto.split('=')[0], codigo: m[1], ids: m[3] ? m[3].split(',') : null };
  }
  const PRINCIPALES = new Set(['P', 'D', 'C', 'B']);
  const EXPONENTE = { carbohidrato: 1, proteina: 0.8, verdura: 0.4, grasa: 0.5, fruta: 0.8, lacteo_o_alt: 0.8, extra: 0.3 };

  function candidatosDeRol(rol, plantilla, ctx, esPrincipalCoccion) {
    let lista = rol.ids ? rol.ids.map((id) => ING.porId[id]).filter(Boolean) : ING.lista.filter((i) => i.usos.includes(rol.codigo));
    lista = lista.filter((i) => permitido(i, ctx.prohibidas) && !ctx.excluidos.has(i.id));
    if (esPrincipalCoccion && plantilla.coccion) lista = lista.filter((i) => i.cocciones.includes(plantilla.coccion));
    if (rol.codigo === 'P' && ctx.categoriasElegidas && ctx.categoriasElegidas.size) {
      lista = lista.filter((i) => {
        const animal = ['ave', 'res', 'cerdo', 'pescado', 'marisco'].filter((t) => i.etiquetas.includes(t));
        return animal.length === 0 || animal.some((t) => ctx.categoriasElegidas.has(t));
      });
    }
    if (ctx.economico) {
      const barato = lista.filter((i) => i.precio !== 'alto');
      if (barato.length) lista = barato;
    }
    return lista;
  }

  function pesoIngrediente(ing, rol, ctx) {
    let w = 1 / (1 + (ctx.usoIngredientes[ing.id] || 0)) ** 2;
    if (ctx.economico) w *= ing.precio === 'bajo' ? 4 : ing.precio === 'medio' ? 1.5 : 0.3;
    if (rol.codigo === 'P' && ctx.categoriasElegidas && ctx.categoriasElegidas.size) {
      const animal = ing.etiquetas.some((t) => ['ave', 'res', 'cerdo', 'pescado', 'marisco'].includes(t));
      if (!animal) w *= 0.5;
    }
    return w;
  }

  /* ---------- Cantidades ---------- */
  function totales(items) {
    const t = { kcal: 0, prot: 0, carb: 0, grasa: 0 };
    items.forEach(({ ing, g }) => {
      t.kcal += ing.kcal * g / 100; t.prot += ing.prot * g / 100; t.carb += ing.carb * g / 100; t.grasa += ing.grasa * g / 100;
    });
    return t;
  }
  const alPaso = (g, ing) => Math.round(g / ing.paso) * ing.paso;
  const acotar = (g, ing) => Math.min(ing.max, Math.max(ing.min, g));

  function resolverCantidades(elegidos, kcalMeta, protMeta) {
    const items = elegidos.map(({ ing, rol }) => ({ ing, rol, g: acotar(alPaso(ing.base, ing), ing) }));
    const kcalBase = totales(items).kcal || 1;
    const escala = kcalMeta / kcalBase;
    items.forEach((it) => {
      it.pref = acotar(it.ing.base * Math.pow(escala, EXPONENTE[it.ing.grupo] || 0.8), it.ing);
      it.g = acotar(alPaso(it.pref, it.ing), it.ing);
    });
    const costo = () => {
      const t = totales(items);
      let c = ((t.kcal - kcalMeta) / kcalMeta) ** 2 * 400;
      if (protMeta > 0 && t.prot < protMeta) c += ((protMeta - t.prot) / protMeta) ** 2 * 12;
      if (protMeta > 0 && t.prot > protMeta * 1.6) c += ((t.prot - protMeta * 1.6) / protMeta) ** 2 * 4;
      items.forEach((it) => { c += 0.1 * ((it.g - it.pref) / it.pref) ** 2; });
      return c;
    };
    let actual = costo();
    for (let vuelta = 0; vuelta < 400; vuelta += 1) {
      let mejor = null;
      items.forEach((it, i) => {
        [-16, -8, -4, -2, -1, 1, 2, 4, 8, 16].forEach((k) => {
          const nuevo = acotar(it.g + k * it.ing.paso, it.ing);
          if (nuevo === it.g) return;
          const previo = it.g;
          it.g = nuevo;
          const c = costo();
          it.g = previo;
          if (c < actual - 1e-9 && (!mejor || c < mejor.c)) mejor = { i, g: nuevo, c };
        });
      });
      if (!mejor) break;
      items[mejor.i].g = mejor.g;
      actual = mejor.c;
    }
    return items;
  }

  function redondear1(n) { return Math.round(n * 10) / 10; }
  function nombreIng(ing, lang) { return ing.nombre[lang] || ing.nombre.es; }
  function mayuscula(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  function nombreDelPlato(plantilla, mapa) {
    const out = {};
    ['es', 'en', 'de'].forEach((lang) => {
      out[lang] = mayuscula(plantilla.nombre[lang].replace(/\{(\w+)\}/g, (_, clave) => (mapa[clave] ? nombreIng(mapa[clave], lang) : '')));
    });
    return out;
  }

  /* Plantillas cuyos roles tienen al menos un ingrediente permitido para este perfil. */
  function plantillasViables(ctx, comida) {
    if (!ctx.viables) ctx.viables = {};
    if (!ctx.viables[comida]) {
      ctx.viables[comida] = PLANT.lista.filter((p) => {
        if (!p.comidas.includes(comida)) return false;
        const roles = p.roles.map(parseRol);
        const iP = roles.findIndex((r) => r.codigo === 'P' || r.codigo === 'D');
        return roles.every((r, i) => candidatosDeRol(r, p, ctx, i === iP).length > 0);
      });
    }
    return ctx.viables[comida];
  }

  /* ---------- Un plato ---------- */
  function armarPlato(ctx, params) {
    const { comida, kcalMeta, protMeta, dia, opcion, estado } = params;
    const MAX_INTENTOS = 40;
    let ultimoError = 'sin_plantillas';
    for (let intento = 0; intento < MAX_INTENTOS; intento += 1) {
      const rng = crearRng(ctx.semilla, dia, comida, opcion, intento);
      const relajar = intento >= 14 ? 1 : 0;
      const relajarMas = intento >= 28 ? 1 : 0;
      const plantillas = plantillasViables(ctx, comida).filter((p) => relajar || !estado.plantillasDelDia.has(p.id));
      const plantilla = elegirPonderado(plantillas, (p) => 1 / (1 + (estado.usoPlantillas[comida + p.id] || 0)) ** 2, rng);
      if (!plantilla) { ultimoError = 'sin_plantillas'; continue; }

      const roles = plantilla.roles.map(parseRol);
      const principalCoccion = roles.findIndex((r) => r.codigo === 'P' || r.codigo === 'D');
      const usados = new Set();
      const elegidos = [];
      let fallo = false;
      for (let i = 0; i < roles.length && !fallo; i += 1) {
        const rol = roles[i];
        let lista = candidatosDeRol(rol, plantilla, ctx, i === principalCoccion).filter((c) => !usados.has(c.id));
        if (PRINCIPALES.has(rol.codigo) && !relajar) {
          const sin = lista.filter((c) => !params.evitarIds.has(c.id) && !(rol.codigo === 'P' && c.id === estado.proteinaPrevia));
          if (sin.length) lista = sin;
          else if (params.evitarIds.size) { fallo = true; break; }
        }
        if (!relajarMas && !PRINCIPALES.has(rol.codigo)) {
          const sin = lista.filter((c) => !params.evitarIds.has(c.id));
          if (sin.length) lista = sin;
        }
        const ing = elegirPonderado(lista, (c) => pesoIngrediente(c, rol, ctx), rng);
        if (!ing) { fallo = true; break; }
        usados.add(ing.id);
        elegidos.push({ ing, rol });
      }
      if (fallo) { ultimoError = 'sin_ingredientes'; continue; }

      const clave = plantilla.id + '|' + elegidos.map((e) => e.ing.id).sort().join(',');
      if (!relajar && estado.platosDeLaSemana.has(comida + clave)) continue;

      const items = resolverCantidades(elegidos, kcalMeta, protMeta);
      const t = totales(items);
      if (Math.abs(t.kcal - kcalMeta) / kcalMeta > TOLERANCIA) { ultimoError = 'fuera_de_rango'; continue; }

      const mapa = {};
      elegidos.forEach((e, i) => { mapa[roles[i].clave.split('=')[0]] = e.ing; });
      const principal = elegidos.find((e) => e.rol.codigo === 'P' || e.rol.codigo === 'D');
      return {
        plantilla: plantilla.id, comida, opcion, clave,
        nombre: nombreDelPlato(plantilla, mapa),
        ingredientes: items.map((it) => ({ id: it.ing.id, rol: it.rol.codigo, gramos: it.g })),
        kcal: Math.round(t.kcal), prot: redondear1(t.prot), carb: redondear1(t.carb), grasa: redondear1(t.grasa),
        kcalMeta, protMeta: redondear1(protMeta),
        _principal: principal ? principal.ing.id : null
      };
    }
    const err = new Error('no_se_pudo_armar');
    err.code = 'no_se_pudo_armar';
    err.detalle = ultimoError + ' · ' + dia + ' ' + comida;
    throw err;
  }

  function contexto(perfil, semilla) {
    const categorias = new Set();
    (perfil.proteinasElegidas || []).forEach((p) => {
      if (p === 'pollo') categorias.add('ave');
      if (p === 'pescado') { categorias.add('pescado'); categorias.add('marisco'); }
      if (p === 'carne') { categorias.add('res'); categorias.add('cerdo'); }
    });
    return {
      semilla: String(semilla),
      prohibidas: etiquetasProhibidas(perfil),
      excluidos: new Set(perfil.excluidos || []),
      economico: !!perfil.economico,
      categoriasElegidas: categorias,
      usoIngredientes: {}
    };
  }

  /* ---------- Plan semanal ---------- */
  function generarPlanSemanal(perfil, opciones = {}) {
    const dias = opciones.dias || DIAS;
    const semilla = opciones.semilla === undefined ? 'nutriamigo' : opciones.semilla;
    const extra = opciones.kcalExtra || {};
    const cambios = opciones.cambios || {};
    const ctx = contexto(perfil, semilla);
    const metaBase = Math.min(Math.round(perfil.metaKcal), META_MAX);
    const protocolo = PROTOCOLOS[perfil.ayunoProtocolo] && ayunoViable(metaBase, perfil.ayunoProtocolo) ? perfil.ayunoProtocolo : null;
    const slots = slotsDelDia(protocolo);
    const horas = protocolo ? horasDeComidas(protocolo, perfil.ayunoInicio || '12:00') : null;
    const factor = protocolo ? factorPorcion(protocolo) : 1;
    const usoPlantillas = {};
    const platosDeLaSemana = new Set();
    const previa = [null, null];
    const semana = [];

    dias.forEach((dia) => {
      const metaDia = Math.min(Math.round(metaBase + (extra[dia] || 0)), META_MAX + 800);
      const protDia = (perfil.proteinaG || 0) * metaDia / perfil.metaKcal;
      const kcalPorComida = repartir(metaDia, slots);
      const protPorComida = repartir(protDia, slots, 1);
      const plantillasDelDia = new Set();
      const comidas = slots.map((comida) => {
        const platos = [];
        const principalesOpcion1 = new Set();
        for (let opcion = 0; opcion < 2; opcion += 1) {
          const estado = { plantillasDelDia, usoPlantillas, platosDeLaSemana, proteinaPrevia: previa[opcion] };
          const cambio = cambios[`${dia}|${comida}|${opcion + 1}`] || 0;
          const plato = armarPlato(ctx, {
            comida, kcalMeta: kcalPorComida[comida], protMeta: protPorComida[comida], dia, opcion: `${opcion}.${cambio}`,
            estado, evitarIds: opcion === 1 ? principalesOpcion1 : new Set()
          });
          plato.opcion = opcion + 1;
          if (opcion === 0) plato.ingredientes.filter((i) => ['P', 'D', 'C', 'B'].includes(i.rol)).forEach((i) => principalesOpcion1.add(i.id));
          plantillasDelDia.add(plato.plantilla);
          usoPlantillas[comida + plato.plantilla] = (usoPlantillas[comida + plato.plantilla] || 0) + 1;
          platosDeLaSemana.add(comida + plato.clave);
          plato.ingredientes.forEach((i) => { ctx.usoIngredientes[i.id] = (ctx.usoIngredientes[i.id] || 0) + 1; });
          if (plato._principal && ['P'].includes((plato.ingredientes.find((i) => i.id === plato._principal) || {}).rol)) previa[opcion] = plato._principal;
          delete plato._principal;
          platos.push(plato);
        }
        return { comida, hora: horas ? horas[comida] : null, kcalMeta: kcalPorComida[comida], protMeta: protPorComida[comida], opciones: platos };
      });
      semana.push({ dia, metaKcal: metaDia, kcalExtra: Math.round(extra[dia] || 0), comidas });
    });

    return { semana, protocolo, ayunoIgnorado: !!perfil.ayunoProtocolo && !protocolo, metaRecortada: perfil.metaKcal > META_MAX, factorPorcion: protocolo ? redondear1(factor) : 1, semilla: String(semilla) };
  }

  /* Valida que ningún plato incluya etiquetas prohibidas ni ingredientes inexistentes. */
  function validarPlan(plan, perfil) {
    const prohibidas = etiquetasProhibidas(perfil);
    const errores = [];
    plan.semana.forEach((d) => d.comidas.forEach((c) => c.opciones.forEach((p) => {
      p.ingredientes.forEach((i) => {
        const ing = ING.porId[i.id];
        if (!ing) { errores.push({ dia: d.dia, comida: c.comida, opcion: p.opcion, id: i.id, motivo: 'desconocido' }); return; }
        ing.etiquetas.forEach((e) => { if (prohibidas.has(e)) errores.push({ dia: d.dia, comida: c.comida, opcion: p.opcion, id: i.id, motivo: e }); });
      });
    })));
    return { ok: errores.length === 0, errores };
  }

  /* ---------- Medidas caseras ---------- */
  const GLIFOS = { 0.25: '¼', 0.5: '½', 0.75: '¾' };
  function glifo(v) {
    const ent = Math.floor(v + 1e-9);
    const fr = Math.round((v - ent) * 100) / 100;
    let f = '';
    if (Math.abs(fr - 0.33) < 0.02) f = '⅓';
    else if (Math.abs(fr - 0.67) < 0.02) f = '⅔';
    else if (GLIFOS[fr]) f = GLIFOS[fr];
    return (ent > 0 || !f ? String(ent) : '') + f;
  }
  function valorCercano(u) {
    if (u < 0.2) return null;
    let cands;
    if (u < 1) cands = [0.25, 1 / 3, 0.5, 2 / 3, 0.75, 1];
    else if (u < 4) cands = [1, 1.25, 1.5, 1.75, 2, 2.5, 3, 3.5, 4].filter((x) => x === Math.round(x) || x % 0.5 === 0 || x < 2);
    else cands = [Math.round(u)];
    return cands.reduce((a, b) => (Math.abs(b - u) < Math.abs(a - u) ? b : a));
  }
  /* "≈ 1½ pechugas medianas" o null si la medida casera no es razonable para esa cantidad. */
  function medidaCasera(id, gramos, lang) {
    const ing = ING.porId[id];
    if (!ing || !ing.medida) return null;
    const unidad = ING.UNIDADES[ing.medida.unidad];
    const u = gramos / ing.medida.gramos;
    const v = valorCercano(u);
    if (!v) return null;
    if (Math.abs(v * ing.medida.gramos - gramos) / gramos > 0.2) return null;
    const par = unidad[lang] || unidad.es;
    const g = glifo(v);
    if (v === 1) return `1 ${par[0]}`;
    if (v < 1) return lang === 'es' && unidad.item ? `${g} de ${par[0]}` : `${g} ${par[0]}`;
    return `${g} ${par[1]}`;
  }
  /* Texto de una cantidad: "120 g" o "120 g (≈ 1 pechuga mediana)". */
  function textoCantidad(id, gramos, lang, conMedidas) {
    const ing = ING.porId[id];
    const base = `${gramos} ${ing && ing.estado === 'liquido' ? 'ml' : 'g'}`;
    if (!conMedidas) return base;
    const casera = medidaCasera(id, gramos, lang || 'es');
    return casera ? `${base} (≈ ${casera})` : base;
  }

  /* ---------- Lista de compras ---------- */
  const SECCIONES = { verdura: 'verduras', fruta: 'frutas', proteina: 'proteinas', carbohidrato: 'granos', lacteo_o_alt: 'lacteos', grasa: 'otros', extra: 'otros' };
  const ORDEN_SECCIONES = ['verduras', 'frutas', 'proteinas', 'granos', 'lacteos', 'otros'];
  function listaDeCompras(plan, { opciones = [1], dias = null } = {}) {
    const suma = {};
    plan.semana.filter((d) => !dias || dias.includes(d.dia)).forEach((d) => d.comidas.forEach((c) => c.opciones.forEach((p) => {
      if (!opciones.includes(p.opcion)) return;
      p.ingredientes.forEach((i) => { suma[i.id] = (suma[i.id] || 0) + i.gramos; });
    })));
    const secciones = ORDEN_SECCIONES.map((id) => ({ id, items: [] }));
    let puntos = 0; let n = 0;
    Object.keys(suma).forEach((id) => {
      const ing = ING.porId[id];
      const gramos = Math.ceil(suma[id] / 10) * 10;
      const sec = secciones.find((s) => s.id === SECCIONES[ing.grupo]);
      sec.items.push({ id, nombre: ing.nombre, gramos, precio: ing.precio, economico: ing.precio === 'bajo', estado: ing.estado });
      puntos += ing.precio === 'bajo' ? 1 : ing.precio === 'medio' ? 2 : 3; n += 1;
    });
    secciones.forEach((s) => s.items.sort((a, b) => a.nombre.es.localeCompare(b.nombre.es, 'es')));
    const media = n ? puntos / n : 0;
    return { secciones: secciones.filter((s) => s.items.length), indicePrecio: media < 1.6 ? 'economico' : media < 2.3 ? 'moderado' : 'alto', total: n };
  }

  /* Macros de un ingrediente del catálogo para "Mi día". */
  function macrosDe(id, gramos) {
    const ing = ING.porId[id];
    if (!ing) return null;
    const f = gramos / 100;
    return { kcal: Math.round(ing.kcal * f), prot: redondear1(ing.prot * f), carb: redondear1(ing.carb * f), grasa: redondear1(ing.grasa * f) };
  }
  function buscarIngredientes(texto, lang) {
    const t = SIN_ACENTO(texto).trim();
    if (!t) return [];
    return ING.lista.filter((i) => SIN_ACENTO(i.nombre[lang] || i.nombre.es).includes(t) || SIN_ACENTO(i.nombre.es).includes(t)).slice(0, 8);
  }

  const api = {
    DIAS, COMIDAS, PESOS, PROTOCOLOS, META_MAX, KCAL_MAX_COMIDA, DIETAS, ALERGIAS, TOLERANCIA,
    INGREDIENTES: ING, PLANTILLAS: PLANT,
    crearRng, etiquetasProhibidas, etiquetasDeTexto, slotsDelDia, repartir, factorPorcion,
    horasDeComidas, estadoAyuno, ayunoPermitido, ayunoViable, generarPlanSemanal, validarPlan,
    medidaCasera, textoCantidad, listaDeCompras, macrosDe, buscarIngredientes
  };
  if (isNode) module.exports = api; else global.NutriGenerador = api;
})(typeof window !== 'undefined' ? window : globalThis);
