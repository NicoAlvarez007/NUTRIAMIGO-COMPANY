function normalizar(texto) {
  return texto
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[¿?¡!.,]/g, '')
    .trim();
}

/* Junta las keywords en español con las de inglés/alemán (si existen en
   data/faq.i18n.js) para que el bot reconozca la pregunta sin importar
   en qué idioma la escriba la persona. */
function keywordsCompletas(faq) {
  const extra = [];
  if (typeof FAQ_TRANSLATIONS !== 'undefined') {
    ['en', 'de'].forEach(lang => {
      const t = FAQ_TRANSLATIONS[lang] && FAQ_TRANSLATIONS[lang][faq.id];
      if (t && t.keyword) extra.push(t.keyword);
    });
  }
  return faq.keywords.concat(extra);
}

function puntuarCoincidencia(mensaje, faq) {
  const msg = normalizar(mensaje);
  const msgWords = new Set(msg.split(/\s+/).filter(w => w.length > 2));
  let score = 0;

  keywordsCompletas(faq).forEach((kw) => {
    const k = normalizar(kw);

    if (msg.includes(k)) {
      score += k.split(' ').length * 3;
      return;
    }

    const kWords = k.split(/\s+/).filter(w => w.length > 2);
    const coincidencias = kWords.filter(w => msgWords.has(w)).length;
    if (coincidencias > 0) score += coincidencias;
  });

  return score;
}

function buscarRespuesta(mensaje, faqData) {
  let mejor = null;
  let mejorScore = 0;

  faqData.forEach((faq) => {
    const score = puntuarCoincidencia(mensaje, faq);
    if (score > mejorScore) {
      mejorScore = score;
      mejor = faq;
    }
  });

  return mejorScore > 0 ? mejor : null;
}

/* Devuelve la pregunta/respuesta de un FAQ en el idioma activo, si hay
   traducción disponible; si no, cae de vuelta al español. */
function textoFaqTraducido(faq) {
  const lang = window.NutriIdioma ? window.NutriIdioma.get() : 'es';
  if (lang === 'es' || typeof FAQ_TRANSLATIONS === 'undefined') return faq;
  const t = FAQ_TRANSLATIONS[lang] && FAQ_TRANSLATIONS[lang][faq.id];
  return t ? { ...faq, pregunta: t.pregunta, respuesta: t.respuesta } : faq;
}

document.addEventListener('DOMContentLoaded', async () => {
  const fab = document.getElementById('chatFab');
  const panel = document.getElementById('chatPanel');
  const closeBtn = document.getElementById('chatClose');
  const messagesEl = document.getElementById('chatMessages');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');

  if (!fab || !panel) return;

  let faqData = FAQ_DATA || [];

  let open = false;
  function togglePanel(forceOpen) {
    open = typeof forceOpen === 'boolean' ? forceOpen : !open;
    panel.hidden = !open;
    if (open) input.focus();
  }

  fab.addEventListener('click', () => togglePanel(true));
  closeBtn.addEventListener('click', () => togglePanel(false));

  function appendMessage(text, role) {
    const div = document.createElement('div');
    div.className = 'chat-msg ' + (role === 'user' ? 'chat-msg-user' : 'chat-msg-bot');
    div.textContent = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function sinCoincidenciaTexto() {
    const es = 'No tengo una respuesta preparada para eso todavía. Prueba con palabras como "premium", "objetivo", "comunidad" o "racha", o escribe a soporte para hablar con una persona.';
    return window.NutriIdioma ? window.NutriIdioma.t('chat.sinCoincidencia', es) : es;
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;

    appendMessage(text, 'user');
    input.value = '';

    const match = buscarRespuesta(text, faqData);
    const traducido = match ? textoFaqTraducido(match) : null;
    setTimeout(() => {
      appendMessage(traducido ? traducido.respuesta : sinCoincidenciaTexto(), 'bot');
    }, 300);
  });
});
