(function () {
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);
  const $ = (id) => document.getElementById(id);

  function destinoSolicitado() {
    const p = new URLSearchParams(location.search).get('siguiente');
    return p && /^[a-z0-9_-]+\.html$/i.test(p) ? './' + p : null;
  }

  function irA(siguiente) {
    const pedido = destinoSolicitado();
    const esDashboard = siguiente === '/dashboard.html';
    location.href = esDashboard && pedido ? pedido : '.' + siguiente;
  }

  function mostrarMensaje(texto) {
    const el = $('mensaje');
    el.textContent = texto;
    el.hidden = !texto;
  }

  function elegirPestana(registro) {
    $('tabLogin').setAttribute('aria-selected', String(!registro));
    $('tabRegistro').setAttribute('aria-selected', String(registro));
    $('panelLogin').hidden = registro;
    $('panelRegistro').hidden = !registro;
    mostrarMensaje('');
  }

  function nivelFuerza(pass) {
    if (pass.length < 8) return 1;
    let puntos = 0;
    if (pass.length >= 12) puntos++;
    if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) puntos++;
    if (/\d/.test(pass)) puntos++;
    if (/[^A-Za-z0-9]/.test(pass)) puntos++;
    return puntos >= 3 ? 3 : puntos >= 1 ? 2 : 1;
  }

  function pintarFuerza() {
    const pass = $('regPass').value;
    const caja = $('fuerza');
    if (!pass) {
      caja.dataset.nivel = '0';
      $('fuerzaTexto').innerHTML = '<span data-i18n="acceso.requisito">' + t('acceso.requisito', 'Mínimo 8 caracteres.') + '</span>';
      return;
    }
    const nivel = nivelFuerza(pass);
    caja.dataset.nivel = String(nivel);
    const textos = {
      1: t('acceso.fuerza.debil', 'Débil'),
      2: t('acceso.fuerza.media', 'Media'),
      3: t('acceso.fuerza.fuerte', 'Fuerte')
    };
    $('fuerzaTexto').textContent = t('acceso.fuerza.label', 'Seguridad de la contraseña') + ': ' + textos[nivel];
  }

  async function enviar(url, cuerpo) {
    try {
      return await window.api.post(url, cuerpo, { silencioso: true });
    } catch (err) {
      mostrarMensaje(err.message);
      return null;
    }
  }

  async function enviarFormulario(form, accion) {
    const boton = form.querySelector('button[type="submit"]');
    boton.disabled = true;
    try { await accion(); } finally { boton.disabled = false; }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    $('tabLogin').addEventListener('click', () => elegirPestana(false));
    $('tabRegistro').addEventListener('click', () => elegirPestana(true));
    if (location.hash === '#registro') elegirPestana(true);

    document.querySelectorAll('[data-mostrar]').forEach(chk => {
      chk.addEventListener('change', () => {
        chk.dataset.mostrar.split(',').forEach(id => { $(id).type = chk.checked ? 'text' : 'password'; });
      });
    });

    $('olvideBtn').addEventListener('click', () => { $('olvideTexto').hidden = !$('olvideTexto').hidden; });
    $('regPass').addEventListener('input', pintarFuerza);
    document.addEventListener('nutriamigo:lang-changed', pintarFuerza);

    if (new URLSearchParams(location.search).get('error') === 'google') {
      mostrarMensaje(t('acceso.err.google', 'No se pudo iniciar sesión con Google'));
    }

    $('panelLogin').addEventListener('submit', (e) => {
      e.preventDefault();
      mostrarMensaje('');
      enviarFormulario($('panelLogin'), async () => {
        const datos = await enviar('./auth/login', { identificador: $('loginId').value.trim(), password: $('loginPass').value });
        if (datos) irA(datos.siguiente);
      });
    });

    $('panelRegistro').addEventListener('submit', (e) => {
      e.preventDefault();
      mostrarMensaje('');
      const correo = $('regCorreo').value.trim();
      const pass = $('regPass').value;
      if (!correo || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(correo)) return mostrarMensaje(t('err.correo_invalido', 'Escribe un correo válido'));
      if (pass.length < 8) return mostrarMensaje(t('err.contrasena_corta', 'La contraseña debe tener al menos 8 caracteres'));
      if (pass !== $('regPass2').value) return mostrarMensaje(t('acceso.err.noCoincide', 'Las contraseñas no coinciden'));
      if (!$('regTerminos').checked) return mostrarMensaje(t('acceso.err.terminos', 'Debes aceptar los Términos y Condiciones'));
      enviarFormulario($('panelRegistro'), async () => {
        const datos = await enviar('./auth/registro', { email: correo, password: pass });
        if (datos) irA(datos.siguiente);
      });
    });

    try {
      const yo = await window.api.get('./api/me', { silencioso: true });
      irA(yo.suspended ? '/suspendida.html' : yo.hasBiometrics ? '/dashboard.html' : '/onboarding.html');
    } catch (err) { /* sin sesión o sin servidor: se queda en el formulario */ }
  });
})();
