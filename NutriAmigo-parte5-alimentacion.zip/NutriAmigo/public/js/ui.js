/* Comportamientos de interfaz compartidos: tema, modales y pestañas */
(function () {
  /* ---------- Tema: claro (por defecto), oscuro o automático según el sistema ---------- */
  const CLAVE_TEMA = 'nutriamigo_theme';
  const mqOscuro = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function temaGuardado() {
    try { return localStorage.getItem(CLAVE_TEMA) || 'claro'; } catch (e) { return 'claro'; }
  }
  function aplicarTemaActual() {
    const pref = temaGuardado();
    const real = pref === 'auto' ? (mqOscuro && mqOscuro.matches ? 'dark' : 'claro') : pref;
    document.documentElement.setAttribute('data-theme', real);
  }
  function fijarTema(pref) {
    if (!['claro', 'dark', 'auto'].includes(pref)) pref = 'claro';
    try { localStorage.setItem(CLAVE_TEMA, pref); } catch (e) { /* almacenamiento no disponible */ }
    aplicarTemaActual();
    document.dispatchEvent(new CustomEvent('nutriamigo:theme-changed', { detail: pref }));
  }
  window.NutriTema = { get: temaGuardado, set: fijarTema };
  if (mqOscuro && mqOscuro.addEventListener) {
    mqOscuro.addEventListener('change', () => { if (temaGuardado() === 'auto') aplicarTemaActual(); });
  }

  /* ---------- Modales: foco atrapado, Escape, clic fuera, arrastre hacia abajo ---------- */
  const SELECTOR_MODAL = '.modal-overlay, .app-profile-menu';
  const SELECTOR_FOCO = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  const abiertos = [];
  let contadorId = 0;

  const esMenuPerfil = (o) => o.classList.contains('app-profile-menu');
  const estaAbierto = (o) => esMenuPerfil(o) ? o.classList.contains('open') : !o.hidden;
  const cuerpoDe = (o) => o.querySelector('.modal, .app-profile-card') || o;

  function enfocables(contenedor) {
    return Array.from(contenedor.querySelectorAll(SELECTOR_FOCO)).filter(el => el.getClientRects().length > 0);
  }

  function cerrar(o) {
    if (esMenuPerfil(o)) o.classList.remove('open');
    else o.hidden = true;
  }

  function prepararHoja(o) {
    const cuerpo = cuerpoDe(o);
    if (cuerpo === o) return;
    if (!cuerpo.getAttribute('role')) cuerpo.setAttribute('role', 'dialog');
    cuerpo.setAttribute('aria-modal', 'true');
    if (!cuerpo.hasAttribute('aria-label') && !cuerpo.hasAttribute('aria-labelledby')) {
      const titulo = cuerpo.querySelector('h3, h2');
      if (titulo) {
        if (!titulo.id) titulo.id = 'modal-titulo-' + (++contadorId);
        cuerpo.setAttribute('aria-labelledby', titulo.id);
      }
    }
    if (!cuerpo.querySelector(':scope > .sheet-handle')) {
      const asa = document.createElement('div');
      asa.className = 'sheet-handle';
      asa.setAttribute('aria-hidden', 'true');
      cuerpo.insertBefore(asa, cuerpo.firstChild);
      activarArrastre(o, cuerpo, asa);
    }
  }

  function activarArrastre(overlay, cuerpo, asa) {
    let inicio = null;
    asa.addEventListener('pointerdown', (e) => {
      inicio = e.clientY;
      asa.setPointerCapture(e.pointerId);
      cuerpo.style.transition = 'none';
    });
    asa.addEventListener('pointermove', (e) => {
      if (inicio === null) return;
      const dy = Math.max(0, e.clientY - inicio);
      cuerpo.style.transform = `translateY(${dy}px)`;
    });
    const soltar = (e) => {
      if (inicio === null) return;
      const dy = e.clientY - inicio;
      inicio = null;
      cuerpo.style.transition = '';
      cuerpo.style.transform = '';
      if (dy > 90) cerrar(overlay);
    };
    asa.addEventListener('pointerup', soltar);
    asa.addEventListener('pointercancel', soltar);
  }

  function alAbrir(o) {
    o._abierto = true;
    o._previo = document.activeElement;
    abiertos.push(o);
    document.body.classList.add('modal-open');
    prepararHoja(o);
    const cuerpo = cuerpoDe(o);
    if (!cuerpo.hasAttribute('tabindex')) cuerpo.setAttribute('tabindex', '-1');
    requestAnimationFrame(() => {
      const lista = enfocables(cuerpo);
      (lista[0] || cuerpo).focus({ preventScroll: true });
    });
  }

  function alCerrar(o) {
    o._abierto = false;
    const i = abiertos.indexOf(o);
    if (i >= 0) abiertos.splice(i, 1);
    if (!abiertos.length) document.body.classList.remove('modal-open');
    const cuerpo = cuerpoDe(o);
    cuerpo.style.transform = '';
    if (o._previo && document.contains(o._previo)) o._previo.focus({ preventScroll: true });
    o.dispatchEvent(new CustomEvent('nutriamigo:modal-cerrado'));
  }

  function sincronizar(o) {
    const abierto = estaAbierto(o);
    if (abierto && !o._abierto) alAbrir(o);
    else if (!abierto && o._abierto) alCerrar(o);
  }

  function registrar(o) {
    if (o._registrado) return;
    o._registrado = true;
    new MutationObserver(() => sincronizar(o)).observe(o, { attributes: true, attributeFilter: ['hidden', 'class'] });
    o.addEventListener('click', (e) => { if (e.target === o) cerrar(o); });
    sincronizar(o);
  }

  function registrarTodos(raiz) {
    if (raiz.matches && raiz.matches(SELECTOR_MODAL)) registrar(raiz);
    if (raiz.querySelectorAll) raiz.querySelectorAll(SELECTOR_MODAL).forEach(registrar);
  }

  document.addEventListener('keydown', (e) => {
    const tope = abiertos[abiertos.length - 1];
    if (!tope) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      cerrar(tope);
      return;
    }
    if (e.key !== 'Tab') return;
    const lista = enfocables(cuerpoDe(tope));
    if (!lista.length) { e.preventDefault(); return; }
    const primero = lista[0];
    const ultimo = lista[lista.length - 1];
    if (e.shiftKey && (document.activeElement === primero || !cuerpoDe(tope).contains(document.activeElement))) {
      e.preventDefault();
      ultimo.focus();
    } else if (!e.shiftKey && document.activeElement === ultimo) {
      e.preventDefault();
      primero.focus();
    }
  });

  /* ---------- Pestañas de días: el día activo queda visible ---------- */
  function centrarActiva(contenedor) {
    const activa = contenedor.querySelector('.active');
    if (!activa) return;
    const destino = activa.offsetLeft - (contenedor.clientWidth - activa.offsetWidth) / 2;
    contenedor.scrollLeft = Math.max(0, destino);
  }

  function observarPestanas() {
    document.querySelectorAll('.week-tabs').forEach(contenedor => {
      if (contenedor._observado) return;
      contenedor._observado = true;
      new MutationObserver(() => centrarActiva(contenedor))
        .observe(contenedor, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
      centrarActiva(contenedor);
    });
  }

  /* ---------- Comunidad en móvil: lista de amigos y chat, una vista a la vez ---------- */
  document.addEventListener('click', (e) => {
    const amigo = e.target.closest && e.target.closest('.friend-item');
    if (amigo) {
      const panel = amigo.closest('.community-shell');
      if (panel) panel.classList.add('friend-open');
      return;
    }
    const volver = e.target.closest && e.target.closest('#friendBackBtn');
    if (volver) {
      const panel = volver.closest('.community-shell');
      if (panel) panel.classList.remove('friend-open');
    }
  }, true);

  function iniciar() {
    registrarTodos(document);
    observarPestanas();
    new MutationObserver((cambios) => {
      cambios.forEach(c => c.addedNodes.forEach(n => { if (n.nodeType === 1) registrarTodos(n); }));
      observarPestanas();
    }).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();
