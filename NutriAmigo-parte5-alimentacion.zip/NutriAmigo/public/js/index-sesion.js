document.addEventListener('DOMContentLoaded', async () => {
  try {
    const yo = await window.api.get('./api/me', { silencioso: true });
    const destino = yo.suspended ? './suspendida.html' : yo.hasBiometrics ? './dashboard.html' : './onboarding.html';
    document.querySelectorAll('[data-sesion-cta]').forEach((enlace) => {
      enlace.href = destino;
      enlace.setAttribute('data-i18n', 'nav.irPanel');
      enlace.textContent = window.NutriIdioma ? window.NutriIdioma.t('nav.irPanel', 'Ir a mi panel') : 'Ir a mi panel';
    });
  } catch (err) { /* sin sesión: la portada se muestra igual */ }
});
