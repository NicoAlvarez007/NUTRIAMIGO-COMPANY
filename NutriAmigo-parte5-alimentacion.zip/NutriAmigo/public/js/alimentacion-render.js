/* Ayudas compartidas por Alimentación y el resumen PDF del dashboard: arman el perfil del generador,
   la semilla de la semana y el HTML de un plan. El plan en sí lo calcula js/generador-comidas.js. */
(function () {
  const G = window.NutriGenerador;
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);
  const lang = () => (window.NutriIdioma ? window.NutriIdioma.get() : 'es');
  const esc = (s) => (typeof escapeHtml === 'function' ? escapeHtml(s) : String(s));
  const mayus = (s) => s.charAt(0).toUpperCase() + s.slice(1);

  function diaDeFecha(iso) {
    return G.DIAS[(new Date(`${iso}T00:00:00Z`).getUTCDay() + 6) % 7];
  }
  function lunesDe(iso) {
    const d = new Date(`${iso}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
    return d.toISOString().slice(0, 10);
  }
  /* El plan cambia cada semana (de lunes a domingo) y es distinto para cada persona. */
  function semillaDeSemana(userId, hoyISO) { return `${userId || 0}|${lunesDe(hoyISO)}`; }

  function dietaDe(prefs) {
    if (prefs && prefs.dieta) return prefs.dieta;
    const p = (prefs && prefs.proteinas) || [];
    if (p.includes('vegano')) return 'vegano';
    if (p.includes('vegetariano')) return 'vegetariano';
    return 'omnivoro';
  }

  /* Calorías que se suman por caminar/correr hoy: km × peso × 0,75, con tope de 800. */
  function kcalPorKm(km, peso) { return Math.min(800, Math.round((km || 0) * (peso || 0) * 0.75)); }

  /* Perfil para el generador. Sin Premium no se aplican preferencias guardadas. */
  function construirPerfilDePlan(bio, prefs, premium) {
    const meta = calcularMetaCalorica(bio);
    if (!meta) return null;
    const macros = calcularMacros(meta, bio.objetivo);
    const p = premium && prefs ? prefs : {};
    const ayunoOk = G.ayunoPermitido({ edad: bio.edad, estatura: bio.estatura, peso: bio.peso }).ok;
    return {
      metaKcal: meta,
      proteinaG: macros.proteina.gramos,
      dieta: premium ? dietaDe(prefs) : 'omnivoro',
      alergias: p.alergias || [],
      restriccionesTexto: p.restriccionesTexto || '',
      proteinasElegidas: (p.proteinas || []).filter((x) => ['pollo', 'pescado', 'carne'].includes(x)),
      economico: !!p.economico,
      mostrarMedidas: p.mostrarMedidas !== false,
      ayunoProtocolo: premium && ayunoOk && p.ayunoProtocolo ? p.ayunoProtocolo : null,
      ayunoInicio: p.ayunoInicio || '12:00'
    };
  }

  function nombrePlato(plato) { return plato.nombre[lang()] || plato.nombre.es; }
  function nombreIngrediente(id) {
    const ing = G.INGREDIENTES.porId[id];
    return mayus(ing.nombre[lang()] || ing.nombre.es);
  }
  function textoMacros(p) {
    return `${p.kcal} kcal · ${t('a.prot', 'prot.')} ${Math.round(p.prot)} g`;
  }

  /* Lista de ingredientes de un plato: con cantidades (Premium) o solo con nombres. */
  function htmlIngredientes(plato, { premium, medidas }) {
    const filas = plato.ingredientes.map((i) => {
      const cant = premium ? `<b>${esc(G.textoCantidad(i.id, i.gramos, lang(), medidas))}</b>` : '';
      return `<li><span>${esc(nombreIngrediente(i.id))}</span>${cant}</li>`;
    }).join('');
    return `<ul class="ing-list">${filas}</ul>`;
  }

  /* Resumen en texto plano de un plato para el PDF. */
  function resumenPlato(plato, { premium, medidas }) {
    const ings = plato.ingredientes.map((i) => (premium
      ? `${nombreIngrediente(i.id).toLowerCase()} ${G.textoCantidad(i.id, i.gramos, lang(), medidas)}`
      : nombreIngrediente(i.id).toLowerCase())).join(', ');
    return `${esc(nombrePlato(plato))} (${textoMacros(plato)}) — ${esc(ings)}`;
  }

  /* Plan semanal para imprimir (PDF) en el idioma activo. */
  function construirHtmlComidas(plan, perfil, objetivo, { premium }) {
    const medidas = perfil.mostrarMedidas !== false;
    let html = `<h3>${t('plan.pdfAlimTitulo', 'Plan de alimentación — Objetivo:')} ${labelObjetivo(objetivo)}</h3>`;
    html += `<p><b>${t('a.metaDiaria', 'Meta diaria')}:</b> ${perfil.metaKcal} kcal · ${t('a.prot', 'prot.')} ${perfil.proteinaG} g</p>`;
    if (perfil.dieta && perfil.dieta !== 'omnivoro') html += `<p><b>${t('a.dieta', 'Dieta')}:</b> ${t('a.dieta.' + perfil.dieta, perfil.dieta)}</p>`;
    if (perfil.alergias.length) html += `<p><b>${t('a.alergias', 'Alergias e intolerancias')}:</b> ${perfil.alergias.map((a) => t('a.al.' + a, a)).join(', ')}</p>`;
    if (perfil.restriccionesTexto) html += `<p><b>${t('plan.pdfRestricciones', 'Restricciones:')}</b> ${esc(perfil.restriccionesTexto)}</p>`;
    if (plan.protocolo) html += `<p><b>${t('a.ayuno', 'Ayuno intermitente')}:</b> ${plan.protocolo}</p>`;
    plan.semana.forEach((d) => {
      html += `<h4>${labelDia(d.dia, true)} — ${d.metaKcal} kcal</h4><ul>`;
      d.comidas.forEach((c) => {
        const hora = c.hora ? ` (${c.hora})` : '';
        const opciones = c.opciones.map((p) => `${t('plan.opcion', 'Opción')} ${p.opcion}: ${resumenPlato(p, { premium, medidas })}`);
        html += `<li><b>${labelSlot(c.comida)}${hora}:</b> ${opciones.join('<br>')}</li>`;
      });
      html += '</ul>';
    });
    if (!premium) html += `<p><i>${t('a.pdfSinCantidades', 'Las cantidades de cada ingrediente están disponibles con Premium.')}</i></p>`;
    return html;
  }

  /* Plan del PDF del dashboard: arma el plan con los datos y preferencias de la persona. */
  function construirHtmlPlanDeUsuario(bio, prefs, user) {
    const perfil = construirPerfilDePlan(bio, prefs, !!(user && user.isPremium));
    if (!perfil) return '';
    const hoyISO = (user && user.today) || new Date().toISOString().slice(0, 10);
    try {
      const plan = G.generarPlanSemanal(perfil, { semilla: semillaDeSemana(user && user.id, hoyISO) });
      return construirHtmlComidas(plan, perfil, bio.objetivo, { premium: !!(user && user.isPremium) });
    } catch (err) {
      console.error('No se pudo armar el plan para el PDF', err);
      return '';
    }
  }

  window.NutriPlanRender = {
    diaDeFecha, lunesDe, semillaDeSemana, dietaDe, kcalPorKm, construirPerfilDePlan,
    nombrePlato, nombreIngrediente, textoMacros, htmlIngredientes, construirHtmlComidas, construirHtmlPlanDeUsuario
  };
})();
