let pasoActual = 1;
let sexoElegido = null;
let objetivoElegido = null;

const tOb = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);

function edadIngresada() {
  return parseInt(document.getElementById('obEdad').value, 10);
}

/* De 15 a 17 años no se permite el objetivo "definir". */
function esMenorDeEdad() {
  const edad = edadIngresada();
  return edad >= 15 && edad <= 17;
}

function aplicarRestriccionMenor() {
  const menor = esMenorDeEdad();
  const botonDefinir = document.querySelector('#objetivoGroup .pill[data-objetivo="definir"]');
  if (botonDefinir) {
    botonDefinir.disabled = menor;
    botonDefinir.setAttribute('aria-disabled', String(menor));
  }
  if (menor && objetivoElegido === 'definir') {
    objetivoElegido = null;
    document.querySelectorAll('#objetivoGroup .pill').forEach(b => b.classList.remove('active'));
  }
}

function mostrarSugerenciaIMC() {
  const peso = parseFloat(document.getElementById('obPeso').value);
  const estatura = parseFloat(document.getElementById('obEstatura').value);
  const imc = calcularIMC({ peso, estatura });
  if (!imc) return;

  const sugerencia = sugerirObjetivo(imc);
  if (!sugerencia) return;
  if (esMenorDeEdad() && sugerencia.objetivo === 'definir') {
    document.getElementById('aiSuggestion').hidden = true;
    return;
  }

  document.getElementById('aiSuggestionTitle').textContent = `Sugerencia: ${sugerencia.titulo}`;
  document.getElementById('aiSuggestionText').textContent = `Tu IMC es ${imc.toFixed(1)} (${categoriaIMC(imc)}). ${sugerencia.texto}`;
  document.getElementById('aiSuggestion').hidden = false;

  if (!objetivoElegido) {
    objetivoElegido = sugerencia.objetivo;
    document.querySelectorAll('#objetivoGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.objetivo === objetivoElegido));
  }
}

/* De 15 a 17 años se agrega el paso 5 (autorización del adulto) antes del objetivo. */
function ordenPasos() {
  return esMenorDeEdad() ? [1, 2, 3, 5, 4] : [1, 2, 3, 4];
}

function siguientePaso() {
  const orden = ordenPasos();
  return orden[Math.min(orden.length - 1, orden.indexOf(pasoActual) + 1)];
}

function pasoAnterior() {
  const orden = ordenPasos();
  return orden[Math.max(0, orden.indexOf(pasoActual) - 1)];
}

function mostrarPaso(n) {
  document.querySelectorAll('.onboarding-step').forEach(s => {
    s.hidden = parseInt(s.dataset.step, 10) !== n;
  });
  if (n === 4) {
    aplicarRestriccionMenor();
    document.getElementById('obAvisoMenor').hidden = !esMenorDeEdad();
  }
  const orden = ordenPasos();
  const posicion = orden.indexOf(n);
  document.querySelectorAll('.step-dot').forEach(d => {
    const step = parseInt(d.dataset.step, 10);
    const lugar = orden.indexOf(step);
    d.hidden = lugar === -1;
    d.style.order = String(lugar === -1 ? 9 : lugar);
    d.classList.toggle('active', step === n);
    d.classList.toggle('done', lugar !== -1 && lugar < posicion);
  });
  pasoActual = n;
}

const CAMPOS_PASO = {
  1: ['obNombre', 'obApellido'],
  2: ['obPeso', 'obEstatura'],
  3: ['obEdad', 'obActividad'],
  5: ['obAdultoNombre', 'obAdultoParentesco', 'obAdultoContacto']
};

function textoT(clave, esp) {
  return window.NutriIdioma ? window.NutriIdioma.t(clave, esp) : esp;
}

function limpiarErrores(paso) {
  const bloque = document.querySelector(`.onboarding-step[data-step="${paso}"]`);
  if (!bloque) return;
  const msg = bloque.querySelector('.field-error');
  if (msg) msg.remove();
  bloque.querySelectorAll('[aria-invalid]').forEach(el => { el.removeAttribute('aria-invalid'); el.removeAttribute('aria-describedby'); });
}

function mostrarError(paso, clave, esp) {
  limpiarErrores(paso);
  const bloque = document.querySelector(`.onboarding-step[data-step="${paso}"]`);
  const acciones = bloque.querySelector('.onboarding-actions');
  const msg = document.createElement('p');
  msg.className = 'field-error';
  msg.id = `error-paso-${paso}`;
  msg.setAttribute('role', 'alert');
  msg.textContent = textoT(clave, esp);
  acciones.parentNode.insertBefore(msg, acciones);

  let primero = null;
  (CAMPOS_PASO[paso] || []).forEach(id => {
    const campo = document.getElementById(id);
    if (campo && !campo.value.trim()) {
      campo.setAttribute('aria-invalid', 'true');
      campo.setAttribute('aria-describedby', msg.id);
      if (!primero) primero = campo;
    }
  });
  if (primero) primero.focus();
}

function validarPaso1() {
  return document.getElementById('obNombre').value.trim() && document.getElementById('obApellido').value.trim();
}
function validarPaso2() {
  return document.getElementById('obPeso').value && document.getElementById('obEstatura').value;
}
function validarPaso3() {
  return sexoElegido && document.getElementById('obEdad').value && document.getElementById('obActividad').value;
}
function validarPaso5() {
  return ['obAdultoNombre', 'obAdultoParentesco', 'obAdultoContacto'].every(id => document.getElementById(id).value.trim())
    && document.getElementById('obAdultoAcepta').checked;
}

function consentimientoAdulto() {
  if (!esMenorDeEdad()) return undefined;
  return {
    nombre: document.getElementById('obAdultoNombre').value.trim(),
    parentesco: document.getElementById('obAdultoParentesco').value.trim(),
    contacto: document.getElementById('obAdultoContacto').value.trim(),
    acepta: document.getElementById('obAdultoAcepta').checked
  };
}

async function guardarContrasenaOpcional() {
  const msg = document.getElementById('obClaveMsg');
  msg.textContent = '';
  try {
    await api.post('./api/cuenta/contrasena', { nueva: document.getElementById('obNuevaClave').value }, { silencioso: true });
    msg.textContent = textoT('ob.contrasenaGuardada', 'Contraseña guardada');
    document.getElementById('obNuevaClave').value = '';
  } catch (err) {
    msg.textContent = err.message;
  }
}

/* Con la cuenta ya creada: si tiene datos se salta el registro; si no, se rellena con lo que se sabe. */
async function cargarCuenta() {
  let cuenta;
  try {
    cuenta = await api.get('./api/me', { silencioso: true });
  } catch (err) {
    if (err.status === 401) window.location.href = './acceso.html?siguiente=onboarding.html';
    else console.error('No se pudo verificar la sesión', err);
    return;
  }
  if (cuenta.suspended) { window.location.href = './suspendida.html'; return; }
  if (cuenta.hasBiometrics) { window.location.href = './dashboard.html'; return; }

  document.getElementById('obCorreo').value = cuenta.email || '';
  if (cuenta.authProvider === 'google' && cuenta.name) {
    const partes = cuenta.name.trim().split(/\s+/);
    document.getElementById('obNombre').value = partes.shift() || '';
    document.getElementById('obApellido').value = partes.join(' ');
  }
  document.getElementById('crearClaveBox').hidden = !(cuenta.authProvider === 'google' && !cuenta.hasPassword);
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('#sexoGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => {
      sexoElegido = btn.dataset.sexo;
      document.querySelectorAll('#sexoGroup .pill').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  document.querySelectorAll('#objetivoGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => {
      objetivoElegido = btn.dataset.objetivo;
      document.querySelectorAll('#objetivoGroup .pill').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  document.querySelectorAll('[data-next]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (pasoActual === 1 && !validarPaso1()) { mostrarError(1, 'ob.err.nombre', 'Ingresa tu nombre y tu apellido.'); return; }
      if (pasoActual === 2 && !validarPaso2()) { mostrarError(2, 'ob.err.medidas', 'Ingresa tu peso y tu altura.'); return; }
      if (pasoActual === 3 && !validarPaso3()) { mostrarError(3, 'ob.err.perfil', 'Completa género, edad y nivel de actividad.'); return; }
      if (pasoActual === 3 && edadIngresada() < 15) { mostrarError(3, 'err.edad_minima', 'NutriAmigo está disponible desde los 15 años'); return; }
      if (pasoActual === 5 && !validarPaso5()) { mostrarError(5, 'ob.err.adulto', 'Completa todos los datos del adulto y marca la casilla'); return; }
      if (pasoActual === 3) mostrarSugerenciaIMC();
      mostrarPaso(siguientePaso());
    });
  });

  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.addEventListener('click', () => mostrarPaso(pasoAnterior()));
  });

  document.getElementById('onboardingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!objetivoElegido) { mostrarError(4, 'ob.err.objetivo', 'Elige un objetivo.'); return; }

    try {
      await api.post('./api/biometrics', {
        nombre: document.getElementById('obNombre').value.trim(),
        apellido: document.getElementById('obApellido').value.trim(),
        correo: document.getElementById('obCorreo').value.trim(),
        peso: parseFloat(document.getElementById('obPeso').value),
        estatura: parseFloat(document.getElementById('obEstatura').value),
        sexo: sexoElegido,
        edad: edadIngresada(),
        actividad: document.getElementById('obActividad').value,
        objetivo: objetivoElegido,
        consentimiento: consentimientoAdulto()
      }, { silencioso: true });
    } catch (err) {
      console.error('No se pudieron guardar tus datos', err);
      const paso = err.code === 'consentimiento_requerido' && esMenorDeEdad() ? 5 : 4;
      mostrarPaso(paso);
      mostrarError(paso, `err.${err.code || 'interno'}`, err.message || 'No se pudieron guardar tus datos. Revisa tu conexión e inténtalo de nuevo.');
      return;
    }

    window.location.href = './dashboard.html';
  });

  document.querySelectorAll('.onboarding-step input, .onboarding-step select').forEach(campo => {
    campo.addEventListener('input', () => limpiarErrores(pasoActual));
  });
  document.querySelectorAll('.onboarding-step .pill').forEach(pill => {
    pill.addEventListener('click', () => limpiarErrores(pasoActual));
  });

  mostrarPaso(1);

  document.getElementById('obGuardarClave').addEventListener('click', guardarContrasenaOpcional);
  cargarCuenta();
});
