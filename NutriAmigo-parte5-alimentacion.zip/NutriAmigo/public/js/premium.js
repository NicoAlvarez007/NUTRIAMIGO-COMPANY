async function cambiarPlan(activar) {
  try {
    await api.post(activar ? './api/premium/activate' : './api/premium/deactivate');
  } catch (err) {
    console.error('No se pudo cambiar de plan', err);
    return;
  }
  window.location.href = './dashboard.html';
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  const activateBtn = document.getElementById('activateBtn');
  const freePlanBtn = document.getElementById('freePlanBtn');
  const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);

  if (!user) {
    activateBtn.disabled = false;
    activateBtn.textContent = t('prem.activar', 'Activar Premium');
    activateBtn.addEventListener('click', () => { window.location.href = './acceso.html?siguiente=premium.html'; });
    return;
  }

  if (user.isPremium) {
    activateBtn.disabled = true;
    activateBtn.textContent = t('prem.yaTienes', 'Ya tienes Premium');
    freePlanBtn.disabled = false;
    freePlanBtn.textContent = t('prem.cambiarGratis', 'Cambiar a Gratis');
    freePlanBtn.addEventListener('click', () => cambiarPlan(false));
  } else {
    activateBtn.disabled = false;
    activateBtn.textContent = t('prem.activar', 'Activar Premium');
    activateBtn.addEventListener('click', () => cambiarPlan(true));
    freePlanBtn.disabled = true;
    freePlanBtn.textContent = t('prem.tuPlanActual', 'Tu plan actual');
  }
});
