document.addEventListener('DOMContentLoaded', async () => {
  try {
    const yo = await window.api.get('./api/me', { silencioso: true });
    if (!yo.suspended) { window.location.href = './dashboard.html'; return; }
    document.getElementById('motivo').textContent = yo.suspendedReason || '—';
    const enlace = document.getElementById('contacto');
    enlace.textContent = yo.contactEmail;
    enlace.href = `mailto:${yo.contactEmail}`;
  } catch (err) {
    if (err.status === 401) window.location.href = './acceso.html';
  }

  document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
      await window.api.post('./auth/logout', undefined, { silencioso: true });
    } catch (err) {
      console.error('No se pudo cerrar sesión', err);
    }
    window.location.href = './index.html';
  });
});
