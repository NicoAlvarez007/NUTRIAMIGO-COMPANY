const DIAS = ['lunes','martes','miercoles','jueves','viernes','sabado','domingo'];
function diaDeHoy() {
  return DIAS[(new Date().getDay() + 6) % 7];
}
const DIA_LABEL = { lunes:'Lun', martes:'Mar', miercoles:'Mié', jueves:'Jue', viernes:'Vie', sabado:'Sáb', domingo:'Dom' };
const DIA_LABEL_LARGO = { lunes:'Lunes', martes:'Martes', miercoles:'Miércoles', jueves:'Jueves', viernes:'Viernes', sabado:'Sábado', domingo:'Domingo' };
const SLOT_LABEL = { desayuno:'Desayuno', almuerzo:'Almuerzo', media_tarde:'Media tarde', cena:'Cena' };
const OBJETIVO_LABEL = { definir: 'Definir', mantener: 'Mantener', volumen: 'Subir de peso' };
const ENFOQUE_LABEL = { piernas: 'piernas', brazos: 'brazos', espalda: 'espalda', cuerpo_completo: 'cuerpo completo' };
const ACTIVIDAD_LABEL = { sedentario: 'sedentario', ligero: 'ligero', moderado: 'moderado', activo: 'activo', muy_activo: 'muy activo' };

/* Devuelve el idioma activo ('es' por defecto si i18n.js aún no cargó). */
function idiomaActivo() {
  return window.NutriIdioma ? window.NutriIdioma.get() : 'es';
}

/* Traduce un texto de entrenamiento (data/workouts.js) al idioma activo. */
function traducirEntrenamiento(texto) {
  const lang = idiomaActivo();
  if (lang === 'es' || typeof WORKOUTS_TRANSLATIONS === 'undefined') return texto;
  return (WORKOUTS_TRANSLATIONS[lang] && WORKOUTS_TRANSLATIONS[lang][texto]) || texto;
}

/* Etiquetas (día, franja, objetivo, actividad, enfoque) traducidas según
   el idioma activo, reutilizando el diccionario de js/i18n.js. */
function labelDia(dia, largo) {
  const es = largo ? DIA_LABEL_LARGO[dia] : DIA_LABEL[dia];
  return window.NutriIdioma ? window.NutriIdioma.t((largo ? 'diaLargo.' : 'dia.') + dia, es) : es;
}
function labelSlot(slot) {
  return window.NutriIdioma ? window.NutriIdioma.t('slot.' + slot, SLOT_LABEL[slot]) : SLOT_LABEL[slot];
}
function labelObjetivo(objetivo) {
  const clave = { definir: 'objetivo.definir', mantener: 'objetivo.mantener', volumen: 'objetivo.volumen' }[objetivo];
  return window.NutriIdioma && clave ? window.NutriIdioma.t(clave, OBJETIVO_LABEL[objetivo] || objetivo) : (OBJETIVO_LABEL[objetivo] || objetivo);
}
function labelActividad(actividad) {
  const clave = { sedentario: 'actividad.sedentario', ligero: 'actividad.ligero', moderado: 'actividad.moderado', activo: 'actividad.activo', muy_activo: 'actividad.muyActivo' }[actividad];
  return window.NutriIdioma && clave ? window.NutriIdioma.t(clave, ACTIVIDAD_LABEL[actividad] || actividad) : (ACTIVIDAD_LABEL[actividad] || actividad);
}
function labelEnfoque(enfoque) {
  const clave = { piernas: 'enfoque.piernas', brazos: 'enfoque.brazos', espalda: 'enfoque.espalda', cuerpo_completo: 'enfoque.cuerpoCompleto' }[enfoque];
  return window.NutriIdioma && clave ? window.NutriIdioma.t(clave, ENFOQUE_LABEL[enfoque] || enfoque) : (ENFOQUE_LABEL[enfoque] || enfoque);
}

/* Escapa HTML para evitar XSS al insertar texto libre del usuario (restricciones) */
function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[ch]));
}

const PROTEINA_CLAVE_LABEL = { pollo: 'proteina.pollo', pescado: 'proteina.pescado', carne: 'proteina.carne', vegetariano: 'proteina.vegetariano', vegano: 'proteina.vegano' };
const PROTEINA_LABEL_ES = { pollo: 'Pollo', pescado: 'Pescado', carne: 'Carne de res', vegetariano: 'Vegetariano', vegano: 'Vegano' };
function labelProteina(p) {
  return window.NutriIdioma ? window.NutriIdioma.t(PROTEINA_CLAVE_LABEL[p], PROTEINA_LABEL_ES[p] || p) : (PROTEINA_LABEL_ES[p] || p);
}

/* Se mantiene por compatibilidad (llamadas existentes en español). */

function aplicarEnfoque(texto, enfoqueMuscular) {
  if (!enfoqueMuscular || enfoqueMuscular === 'cuerpo_completo') return texto;
  if (/Fuerza|Strength|Kraft|Accesorios|Accessory|Zusatzübungen|Enfoque muscular|Muscle focus|Muskelfokus/i.test(texto)) {
    const lang = idiomaActivo();
    const prefijo = window.NutriIdioma ? window.NutriIdioma.t('plan.enfoqueTexto', 'Fuerza — enfoque en') : 'Fuerza — enfoque en';
    return `${prefijo} ${labelEnfoque(enfoqueMuscular)}`;
  }
  return texto;
}

function aplicarActividad(texto, actividad) {
  const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
  if (actividad === 'sedentario') return `${texto}${t('plan.actEmpiezaSuave', ' (empieza suave: reduce a la mitad las series si es tu primera semana)')}`;
  if (actividad === 'ligero') return `${texto}${t('plan.actIntensidadModerada', ' (intensidad moderada, sube el peso o el ritmo cada 2 semanas)')}`;
  if (actividad === 'activo' || actividad === 'muy_activo') return `${texto}${t('plan.actExigeMas', ' (puedes exigir más: agrega una serie extra o acorta los descansos)')}`;
  return texto;
}

function construirHtmlEntrenamiento(objetivo, enfoqueMuscular, actividad) {
  const plan = WORKOUTS_DATA[objetivo] || WORKOUTS_DATA.mantener;
  const t = window.NutriIdioma ? window.NutriIdioma.t : (k, es) => es;
  let html = `<h3>${t('plan.pdfEntrTitulo', 'Plan de entrenamiento — Objetivo:')} ${labelObjetivo(objetivo)}</h3>`;
  if (enfoqueMuscular) html += `<p><b>${t('plan.pdfEnfoque', 'Enfoque muscular:')}</b> ${labelEnfoque(enfoqueMuscular)}</p>`;

  DIAS.forEach(d => {
    html += `<h4>${labelDia(d, true)}</h4><ul>`;
    plan[d].forEach((op, i) => {
      const traducido = traducirEntrenamiento(op);
      html += `<li><b>${t('plan.opcion', 'Opción')} ${i + 1}:</b> ${aplicarActividad(aplicarEnfoque(traducido, enfoqueMuscular), actividad)}</li>`;
    });
    html += `</ul>`;
  });
  return html;
}
