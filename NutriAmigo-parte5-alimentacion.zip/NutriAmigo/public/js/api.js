/* Cliente único para hablar con el servidor: agrega X-Requested-With, convierte
   los errores en { code, field, message, status } y los muestra como aviso. */
(function () {
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);

  function crearError({ code, field, message, status, minutos }) {
    const traducido = t(`err.${code}`, message).replace('{min}', minutos === undefined ? '' : String(minutos));
    const err = new Error(traducido);
    err.code = code;
    err.field = field;
    err.status = status;
    err.message = traducido;
    return err;
  }

  async function pedir(metodo, url, cuerpo, opciones) {
    const silencioso = !!(opciones && opciones.silencioso);
    const init = { method: metodo, headers: { 'X-Requested-With': 'nutriamigo' }, credentials: 'same-origin' };
    if (cuerpo !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(cuerpo);
    }

    let res;
    try {
      res = await window.fetch(url, init);
    } catch (errorDeRed) {
      const err = crearError({ code: 'red', message: 'No hay conexión con el servidor. Revisa tu red e inténtalo de nuevo.', status: 0 });
      if (!silencioso) window.mostrarAviso(err.message, 'error');
      throw err;
    }

    let datos = null;
    try {
      datos = await res.json();
    } catch (e) { /* respuesta sin cuerpo JSON */ }

    if (!res.ok) {
      const err = crearError({
        code: (datos && datos.code) || 'interno',
        field: datos && datos.field,
        message: (datos && datos.error) || 'Error interno',
        status: res.status,
        minutos: datos && datos.minutos
      });
      if (!silencioso) window.mostrarAviso(err.message, 'error');
      throw err;
    }
    return datos;
  }

  window.api = {
    get: (url, opciones) => pedir('GET', url, undefined, opciones),
    post: (url, cuerpo, opciones) => pedir('POST', url, cuerpo === undefined ? {} : cuerpo, opciones),
    delete: (url, opciones) => pedir('DELETE', url, undefined, opciones)
  };
})();
