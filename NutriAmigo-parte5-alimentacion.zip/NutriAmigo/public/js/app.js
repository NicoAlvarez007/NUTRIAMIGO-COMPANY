function tr(clave, es) {
  return window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es;
}

function mostrarSinServidor() {
  if (document.getElementById('sinServidor')) return;
  const capa = document.createElement('div');
  capa.className = 'sin-servidor';
  capa.id = 'sinServidor';
  capa.setAttribute('role', 'alert');
  const caja = document.createElement('div');
  const p = document.createElement('p');
  p.textContent = tr('err.sinServidor', 'No se pudo conectar con NutriAmigo. Inicia el servidor con INICIAR.bat y abre http://localhost:3000');
  const boton = document.createElement('button');
  boton.type = 'button';
  boton.className = 'btn btn-primary';
  boton.textContent = tr('err.reintentar', 'Reintentar');
  boton.addEventListener('click', () => window.location.reload());
  caja.append(p, boton);
  capa.appendChild(caja);
  document.body.appendChild(capa);
}

/* Devuelve { estado: 'ok' | 'sin_sesion' | 'sin_servidor', user }. No inventa ningún usuario. */
async function cargarPerfil() {
  try {
    const user = await api.get('./api/me', { silencioso: true });
    return { estado: 'ok', user };
  } catch (err) {
    if (err.status === 401) return { estado: 'sin_sesion' };
    console.error('No se pudo cargar el perfil', err);
    return { estado: 'sin_servidor' };
  }
}

function irAAcceso() {
  const pagina = window.location.pathname.split('/').pop();
  const destino = /^[a-z0-9_-]+\.html$/i.test(pagina) ? `?siguiente=${encodeURIComponent(pagina)}` : '';
  window.location.href = `./acceso.html${destino}`;
}

function formatearFecha(iso) {
  const [anio, mes, dia] = iso.split('-');
  return `${dia}/${mes}/${anio}`;
}

function pintarBannerFechaSimulada(user) {
  if (!user.simDate || document.getElementById('simBanner')) return;
  const banner = document.createElement('div');
  banner.className = 'sim-banner';
  banner.id = 'simBanner';
  banner.setAttribute('role', 'status');
  const texto = document.createElement('span');
  texto.textContent = `${tr('cuenta.fechaSimulada', 'Fecha simulada:')} ${formatearFecha(user.simDate)}`;
  const boton = document.createElement('button');
  boton.type = 'button';
  boton.textContent = tr('cuenta.quitar', 'Quitar');
  boton.addEventListener('click', async () => {
    try {
      await api.post('./api/admin/fecha', { reset: true }, { silencioso: true });
    } catch (err) {
      console.error('No se pudo quitar la fecha simulada', err);
    }
    window.location.reload();
  });
  banner.append(texto, boton);
  document.body.insertBefore(banner, document.body.firstChild);
}

function agregarEnlaceAdmin(user) {
  if (user.role !== 'admin' || document.getElementById('adminLink')) return;
  const ajustes = document.getElementById('settingsBtn');
  if (!ajustes) return;
  const enlace = document.createElement('a');
  enlace.id = 'adminLink';
  enlace.href = './admin.html';
  enlace.setAttribute('data-i18n', 'profile.admin');
  enlace.textContent = tr('profile.admin', 'Panel de administrador');
  ajustes.parentNode.insertBefore(enlace, ajustes);
}

const RANGO_ICONO = { bronce: '🥉', plata: '🥈', oro: '🥇', platino: '💎' };
const RANGO_CLAVE_LABEL = { bronce: 'rango.bronce', plata: 'rango.plata', oro: 'rango.oro', platino: 'rango.platino' };
const RANGO_LABEL_ES = { bronce: 'Bronce', plata: 'Plata', oro: 'Oro', platino: 'Platino' };

function pintarPerfil(user) {
  const avatarEls = document.querySelectorAll('[data-user-avatar]');
  const nameEls = document.querySelectorAll('[data-user-name]');
  const streakEls = document.querySelectorAll('[data-user-streak]');
  const premiumEls = document.querySelectorAll('[data-premium-only]');
  const badgeEls = document.querySelectorAll('[data-plan-badge]');
  const rankEls = document.querySelectorAll('[data-rank-badge]');

  nameEls.forEach(el => { el.textContent = user.name; });
  streakEls.forEach(el => { el.textContent = user.streak; });

  avatarEls.forEach(el => {
    if (user.avatar) {
      el.innerHTML = `<img src="${user.avatar}" alt="${user.name}">`;
    } else {
      el.textContent = user.name.slice(0, 2).toUpperCase();
    }
  });

  if (user.rango) {
    const nombreRango = window.NutriIdioma ? window.NutriIdioma.t(RANGO_CLAVE_LABEL[user.rango], RANGO_LABEL_ES[user.rango]) : RANGO_LABEL_ES[user.rango];
    rankEls.forEach(el => {
      el.textContent = RANGO_ICONO[user.rango] || '';
      el.className = 'rank-badge rank-' + user.rango;
      el.title = nombreRango;
    });
  }

  badgeEls.forEach(el => {
    el.textContent = user.isPremium ? 'Premium' : 'Gratis';
    el.classList.toggle('is-premium', !!user.isPremium);
  });

  premiumEls.forEach(el => { el.hidden = !user.isPremium; });
  document.querySelectorAll('[data-free-only]').forEach(el => { el.hidden = user.isPremium; });
}

function initProfileMenu() {
  const btn = document.getElementById('profileBtn');
  const menu = document.getElementById('profileMenu');
  if (!btn || !menu) return;

  btn.addEventListener('click', () => menu.classList.toggle('open'));
  menu.addEventListener('click', (e) => {
    if (e.target === menu) menu.classList.remove('open');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') menu.classList.remove('open');
  });

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      try {
        await api.post('./auth/logout', undefined, { silencioso: true });
      } catch (err) {
        console.error('No se pudo cerrar sesión en el servidor', err);
      }
      window.location.href = './index.html';
    });
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  initProfileMenu();

  const esPaginaPublica = window.location.pathname.endsWith('premium.html');
  const resultado = await cargarPerfil();

  if (resultado.estado === 'sin_servidor') {
    mostrarSinServidor();
    return;
  }

  const user = resultado.user;
  if (!user) {
    if (esPaginaPublica) {
      window.__nutriamigoUser = null;
      document.dispatchEvent(new CustomEvent('nutriamigo:user-ready', { detail: null }));
      return;
    }
    irAAcceso();
    return;
  }

  if (user.suspended) {
    window.location.href = './suspendida.html';
    return;
  }

  if (!user.hasBiometrics) {
    window.location.href = './onboarding.html';
    return;
  }

  try {
    pintarPerfil(user);
    agregarEnlaceAdmin(user);
    pintarBannerFechaSimulada(user);
  } catch (err) {
    console.error('No se pudo pintar el perfil', err);
  }

  window.__nutriamigoUser = user;
  document.dispatchEvent(new CustomEvent('nutriamigo:user-ready', { detail: user }));
});
