let workoutsData = null;
let objetivoActivo = 'mantener';
let diaActivo = diaDeHoy();
let enfoqueMuscular = '';
let biometria = {};
let completionsHoy = [];

function renderObjetivoLabel() {
  document.getElementById('objetivoActualLabel').textContent = labelObjetivo(objetivoActivo);
}

function renderResumen() {
  const el = document.getElementById('planSummary');
  const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
  if (!biometria.peso) {
    el.innerHTML = `${t('plan.sinDatos', 'Aún no has completado tus datos.')} <a href="./onboarding.html" style="color:var(--green-600);font-weight:600;">${t('plan.completalosAqui', 'Complétalos aquí')}</a> ${t('plan.paraPlanCalculado', 'para un plan calculado para ti.')}`;
    return;
  }
  const genero = biometria.sexo === 'hombre' ? t('plan.hombre', 'hombre') : t('plan.mujer', 'mujer');
  el.innerHTML = `${t('plan.calculadoPara', 'Plan calculado para:')} <b>${genero}</b>, <b>${biometria.peso} kg</b>, <b>${biometria.estatura} cm</b>, ${t('plan.actividad', 'actividad')} <b>${biometria.actividad ? labelActividad(biometria.actividad) : '—'}</b>, ${t('plan.objetivo', 'objetivo')} <b>${labelObjetivo(objetivoActivo)}</b>.`;
}

function renderTabs() {
  const wrap = document.getElementById('weekTabs');
  wrap.innerHTML = DIAS.map(d =>
    `<button class="week-tab ${d === diaActivo ? 'active' : ''}" data-dia="${d}">${labelDia(d, false)}</button>`
  ).join('');
  wrap.querySelectorAll('.week-tab').forEach(btn => {
    btn.addEventListener('click', () => { diaActivo = btn.dataset.dia; renderTabs(); renderDay(); });
  });
}

function renderDay() {
  const wrap = document.getElementById('daySlots');
  const t = (key, es) => (window.NutriIdioma ? window.NutriIdioma.t(key, es) : es);
  const opciones = workoutsData[objetivoActivo][diaActivo];
  const itemKey = `entrenamiento-${diaActivo}`;
  const hecho = completionsHoy.includes(itemKey);
  wrap.innerHTML = `
    <div class="slot-card" style="grid-column: 1 / -1;">
      <div class="slot-card-header">
        <h4>${t('entr.rutinaDelDia', 'Rutina del día')}</h4>
        <button type="button" class="done-toggle ${hecho ? 'done' : ''}" data-item-key="${itemKey}">${hecho ? t('plan.hechoHoy', '✓ Hecho hoy') : t('plan.yaLoHice', 'Ya lo hice')}</button>
      </div>
      ${opciones.map((op, i) => `<div class="slot-option"><b>${t('plan.opcion', 'Opción')} ${i + 1}</b>${aplicarActividad(aplicarEnfoque(traducirEntrenamiento(op), enfoqueMuscular), biometria.actividad)}</div>`).join('')}
    </div>
  `;
  document.querySelector('.done-toggle').addEventListener('click', () => marcarCompletado(itemKey));
}

async function marcarCompletado(itemKey) {
  try {
    const data = await api.post('./api/completions', { itemKey });
    if (data.completado) completionsHoy.push(itemKey);
    else completionsHoy = completionsHoy.filter(k => k !== itemKey);
  } catch (err) {
    console.error('No se pudo registrar como completado', err);
  }
  renderDay();
}

async function cargarCompletions() {
  try {
    completionsHoy = await api.get('./api/completions');
  } catch (err) {
    console.error('No se pudieron cargar tus tareas completadas', err);
  }
}

function renderKcal() {
  const kcal = calcularMetaCalorica({ ...biometria, objetivo: objetivoActivo });
  const card = document.getElementById('kcalCard');
  if (kcal) {
    card.style.display = 'block';
    document.getElementById('kcalValue').textContent = kcal.toLocaleString('es-CO') + ' kcal';
  } else {
    card.style.display = 'none';
  }
}

function descargarPDF() {
  document.getElementById('printableBody').innerHTML = construirHtmlEntrenamiento(objetivoActivo, enfoqueMuscular, biometria.actividad);
  window.print();
}

async function cargarBiometria() {
  try {
    const data = await api.get('./api/biometrics');
    if (data) {
      biometria = { peso: data.peso, estatura: data.estatura, sexo: data.sexo, edad: data.edad, actividad: data.actividad };
      if (data.objetivo) objetivoActivo = data.objetivo;
    }
  } catch (err) {
    console.error('No se pudieron cargar tus datos base', err);
  }
}

async function cargarPreferencias() {
  try {
    const prefs = await api.get('./api/preferences', { silencioso: true });
    if (prefs) {
      if (prefs.enfoqueMuscular) enfoqueMuscular = prefs.enfoqueMuscular;
      if (prefs.frecuenciaSemanal) document.getElementById('frecuenciaSemanal').value = prefs.frecuenciaSemanal;
      if (prefs.distanciaKm) document.getElementById('distanciaKm').value = prefs.distanciaKm;
      if (prefs.enfoqueMuscular) document.getElementById('enfoqueMuscular').value = prefs.enfoqueMuscular;
    }
  } catch (err) {
    console.error('No se pudieron cargar tus preferencias', err);
  }
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  workoutsData = WORKOUTS_DATA;

  renderObjetivoLabel();
  renderResumen();
  renderTabs();
  renderDay();
  renderKcal();

  document.addEventListener('nutriamigo:lang-changed', () => {
    renderObjetivoLabel();
    renderResumen();
    renderTabs();
    renderDay();
  });

  document.getElementById('downloadWorkoutBtn').addEventListener('click', descargarPDF);

  const modal = document.getElementById('personalizeModal');
  document.getElementById('personalizeBtn').addEventListener('click', () => {
    if (!user.isPremium) { window.location.href = './premium.html'; return; }
    modal.hidden = false;
  });
  document.getElementById('closeModalBtn').addEventListener('click', () => { modal.hidden = true; });

  document.getElementById('personalizeForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    enfoqueMuscular = document.getElementById('enfoqueMuscular').value;

    try {
      await api.post('./api/preferences', {
        frecuenciaSemanal: parseInt(document.getElementById('frecuenciaSemanal').value, 10),
        distanciaKm: parseFloat(document.getElementById('distanciaKm').value) || null,
        enfoqueMuscular
      });
    } catch (err) {
      console.error('No se pudieron guardar las preferencias', err);
      return;
    }

    modal.hidden = true;
    renderDay();
  });

  (async () => {
    try {
      await cargarBiometria();
      await cargarPreferencias();
      await cargarCompletions();
    } catch (err) {
      console.error('No se pudieron cargar tus datos guardados', err);
    }
    renderObjetivoLabel();
    renderResumen();
    renderDay();
    renderKcal();
  })();
});
