const os = require('os');
const fs = require('fs');
const path = require('path');

/* Inicia el servidor en un puerto libre, con NODE_ENV=test y una base temporal. */
async function iniciarServidor({ rutaDb, env } = {}) {
  const carpeta = rutaDb ? null : fs.mkdtempSync(path.join(os.tmpdir(), 'nutriamigo-'));
  const base = rutaDb || path.join(carpeta, 'prueba.db');
  const { crearServidor } = require('../server/server');
  const servidor = crearServidor({
    env: Object.assign({
      NODE_ENV: 'test', PORT: '0', SESSION_SECRET: 'secreto-de-prueba', NUTRIAMIGO_DB: base
    }, env || {}),
    escribirEnv: false
  });
  const { puerto } = await servidor.iniciar();
  const url = `http://127.0.0.1:${puerto}`;

  /* Cliente HTTP mínimo que conserva la cookie de sesión. */
  function cliente() {
    let cookie = '';
    async function pedir(metodo, ruta, cuerpo, cabeceras = {}) {
      const init = { method: metodo, headers: Object.assign({}, cabeceras), redirect: 'manual' };
      if (cookie) init.headers.Cookie = cookie;
      if (cuerpo !== undefined) {
        if (typeof cuerpo === 'string') init.body = cuerpo;
        else {
          init.body = JSON.stringify(cuerpo);
          init.headers['Content-Type'] = init.headers['Content-Type'] || 'application/json';
        }
      }
      const res = await fetch(url + ruta, init);
      const nueva = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
      if (nueva.length) cookie = nueva.map((c) => c.split(';')[0]).join('; ');
      let datos = null;
      const texto = await res.text();
      try { datos = JSON.parse(texto); } catch (e) { datos = texto; }
      return { status: res.status, datos, cabeceras: res.headers };
    }
    return {
      get: (r, h) => pedir('GET', r, undefined, h),
      post: (r, c, h) => pedir('POST', r, c, h),
      delete: (r, h) => pedir('DELETE', r, undefined, h),
      get cookie() { return cookie; },
      set cookie(v) { cookie = v; }
    };
  }

  async function detener() {
    await servidor.detener();
    if (carpeta) fs.rmSync(carpeta, { recursive: true, force: true });
  }

  return { servidor, url, cliente, detener, rutaDb: base };
}

async function iniciarSesion(cli, datos) {
  return cli.post('/__test/login', datos || {});
}

const BIOMETRIA_VALIDA = {
  nombre: 'Ana', apellido: 'Ruiz', peso: 70, estatura: 170, sexo: 'mujer',
  edad: 25, actividad: 'moderado', objetivo: 'mantener'
};

module.exports = { iniciarServidor, iniciarSesion, BIOMETRIA_VALIDA };
