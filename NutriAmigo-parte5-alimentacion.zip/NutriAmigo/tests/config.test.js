const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { cargarConfig } = require('../server/config');

function entorno(extra) {
  const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-'));
  return { carpeta, rutaEnv: path.join(carpeta, '.env'), env: Object.assign({}, extra) };
}

test('genera y guarda SESSION_SECRET si falta (desarrollo)', () => {
  const { carpeta, rutaEnv, env } = entorno({ NODE_ENV: 'development', SESSION_SECRET: '' });
  const config = cargarConfig({ rutaEnv, env });
  assert.equal(config.SESSION_SECRET.length, 96);
  assert.match(fs.readFileSync(rutaEnv, 'utf8'), /^SESSION_SECRET=[0-9a-f]{96}$/m);
  fs.rmSync(carpeta, { recursive: true, force: true });
});

test('trata el valor de ejemplo como vacío', () => {
  const { carpeta, rutaEnv, env } = entorno({ NODE_ENV: 'development', SESSION_SECRET: 'cualquier_cadena_larga_y_aleatoria' });
  const config = cargarConfig({ rutaEnv, env });
  assert.notEqual(config.SESSION_SECRET, 'cualquier_cadena_larga_y_aleatoria');
  fs.rmSync(carpeta, { recursive: true, force: true });
});

test('en producción sin secreto se niega a arrancar', () => {
  const { carpeta, rutaEnv, env } = entorno({ NODE_ENV: 'production', SESSION_SECRET: '' });
  assert.throws(() => cargarConfig({ rutaEnv, env }), /SESSION_SECRET/);
  assert.equal(fs.existsSync(rutaEnv), false);
  fs.rmSync(carpeta, { recursive: true, force: true });
});

test('valores por defecto y validación', () => {
  const { carpeta, rutaEnv, env } = entorno({ NODE_ENV: 'test', SESSION_SECRET: 'x'.repeat(20) });
  const c = cargarConfig({ rutaEnv, env });
  assert.equal(c.PORT, 3000);
  assert.equal(c.COOKIE_SECURE, false);
  assert.equal(c.ADMIN_USER, 'administrador');
  assert.equal(c.ADMIN_PASSWORD, '12345678');
  assert.equal(c.ALLOW_FREE_PREMIUM_SWITCH, true);
  assert.equal(c.GOOGLE_CONFIGURADO, false);
  assert.throws(() => cargarConfig({ rutaEnv, env: { NODE_ENV: 'test', SESSION_SECRET: 'x', PORT: 'abc' } }), /PORT/);
  assert.throws(() => cargarConfig({ rutaEnv, env: { NODE_ENV: 'otro', SESSION_SECRET: 'x' } }), /NODE_ENV/);
  fs.rmSync(carpeta, { recursive: true, force: true });
});
