const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const session = require('express-session');
const { abrir } = require('../server/db');
const { crearStore } = require('../server/lib/sesionSqlite');

test('store: guarda, lee, renueva, borra y limpia vencidas', (t) => {
  const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), 'nutriamigo-store-'));
  const db = abrir(path.join(carpeta, 's.db'), { copiarAntigua: false });
  const store = crearStore(session, db, { intervaloLimpiezaMs: 60000 });
  t.after(() => { store.cerrar(); db.close(); fs.rmSync(carpeta, { recursive: true, force: true }); });

  const vigente = { cookie: { originalMaxAge: 60000, expires: new Date(Date.now() + 60000).toISOString() }, passport: { user: 1 } };
  store.set('a', vigente, () => {});
  store.get('a', (err, sess) => { assert.equal(err, null); assert.equal(sess.passport.user, 1); });

  const vencida = { cookie: { expires: new Date(Date.now() - 1000).toISOString() } };
  store.set('b', vencida, () => {});
  store.get('b', (err, sess) => assert.equal(sess, null));

  store.set('c', vencida, () => {});
  store.limpiar();
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM sessions WHERE sid = 'c'").get().n, 0);

  store.touch('a', { cookie: { expires: new Date(Date.now() + 120000).toISOString() } }, () => {});
  assert.ok(db.prepare("SELECT expires FROM sessions WHERE sid = 'a'").get().expires > Date.now() + 100000);

  store.destroy('a', () => {});
  store.get('a', (err, sess) => assert.equal(sess, null));
});
