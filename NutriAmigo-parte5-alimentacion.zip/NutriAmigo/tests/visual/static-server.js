/* Servidor estático mínimo para las pruebas visuales: sirve el proyecto y responde 404 a /api y /auth,
   así la página entra sola en su modo sin servidor con datos de prueba. */
const http = require('http');
const fs = require('fs');
const path = require('path');

const RAIZ = path.join(__dirname, '..', '..', 'public');
const TIPOS = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.woff2': 'font/woff2'
};

function crear() {
  return http.createServer((req, res) => {
    const ruta = decodeURIComponent(req.url.split('?')[0]);
    if (ruta.startsWith('/api/') || ruta.startsWith('/auth/')) { res.writeHead(404); res.end('{}'); return; }
    if (ruta === '/socket.io/socket.io.js') { res.writeHead(200, { 'Content-Type': TIPOS['.js'] }); res.end(''); return; }
    let archivo = path.join(RAIZ, ruta === '/' ? 'index.html' : ruta);
    if (!archivo.startsWith(RAIZ) || archivo.includes(`${path.sep}node_modules${path.sep}`) ) { res.writeHead(403); res.end(); return; }
    fs.readFile(archivo, (err, datos) => {
      if (err) { res.writeHead(404); res.end('No encontrado'); return; }
      res.writeHead(200, { 'Content-Type': TIPOS[path.extname(archivo)] || 'application/octet-stream' });
      res.end(datos);
    });
  });
}

module.exports = { crear };
