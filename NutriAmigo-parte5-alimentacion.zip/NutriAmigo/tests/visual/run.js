/* Recorrido visual: 7 páginas x 3 tamaños x 2 temas.
   Uso: npm run test:visual   (variable BASE_URL opcional para probar contra otro servidor) */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { crear } = require('./static-server');

const CAPTURAS = path.join(__dirname, 'capturas');
const TAMANOS = [
  { nombre: 'movil', width: 390, height: 844 },
  { nombre: 'tableta', width: 820, height: 1180 },
  { nombre: 'escritorio', width: 1280, height: 800 }
];
const PAGINAS = ['index', 'dashboard', 'alimentacion', 'entrenamiento', 'comunidad', 'premium', 'onboarding'];
const TEMAS = ['claro', 'dark'];

const hoy = new Date();
const dia = (n) => { const d = new Date(hoy); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); };
const ESTADO = {
  user: { id: 'prueba', name: 'Camila Rodríguez', email: 'camila@ejemplo.com', avatar: null, isPremium: false },
  streak: 6,
  bio: { nombre: 'Camila', apellido: 'Rodríguez', correo: 'camila@ejemplo.com', peso: 68, estatura: 168, sexo: 'mujer', edad: 29, actividad: 'moderado', objetivo: 'definir' },
  progress: [28, 21, 14, 7, 0].map((n, i) => ({ peso: 71 - i * 0.8, fecha: dia(n) })),
  friends: [{ id: 1, nombre: 'Andrés Felipe', created_at: hoy.toISOString() }, { id: 2, nombre: 'Laura con un nombre bastante largo para probar el ajuste', created_at: hoy.toISOString() }],
  reels: [
    { id: 1, autor: 'Laura', texto: 'Hoy completé mi rutina de piernas y preparé el almuerzo de toda la semana. ¡Se siente increíble!', imagen_url: null, upvotes: 4, downvotes: 0, likes: 2, created_at: hoy.toISOString() },
    { id: 2, autor: 'AutorConUnNombreMuyLargoSinEspaciosParaProbarElDesbordamientoDeTexto', texto: 'https://ejemplo.com/enlace-muy-largo-sin-espacios-que-podria-desbordar-la-tarjeta-en-pantallas-pequenas', imagen_url: null, upvotes: 1, downvotes: 0, likes: 0, created_at: hoy.toISOString() }
  ],
  friendMessages: { 1: [{ autor: 'Andrés Felipe', texto: '¿Vamos a entrenar mañana?', created_at: hoy.toISOString() }] }
};

function medir() {
  const ancho = window.innerWidth;
  const fuera = [];
  const pequenos = [];
  const visible = (el) => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const contenido = (el) => {
    for (let p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      const o = getComputedStyle(p).overflowX;
      if (o === 'auto' || o === 'scroll' || o === 'hidden' || o === 'clip') return true;
    }
    return false;
  };
  const describir = (el) => `${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}${el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).join('.') : ''}`;
  document.querySelectorAll('body *').forEach(el => {
    if (!visible(el) || el.closest('.printable-summary')) return;
    const r = el.getBoundingClientRect();
    if (r.right > ancho + 1 && !contenido(el)) fuera.push(`${describir(el)} right=${Math.round(r.right)}`);
    if (el.matches('a[href], button, input:not([type="hidden"]), select, textarea, [role="button"]') && (r.width < 43.5 || r.height < 43.5)) {
      if (el.closest('.sheet-handle')) return;
      pequenos.push(`${describir(el)} ${Math.round(r.width)}x${Math.round(r.height)}`);
    }
  });
  return { desborda: document.documentElement.scrollWidth > ancho, scrollWidth: document.documentElement.scrollWidth, ancho, fuera, pequenos };
}

function contraste() {
  const parse = (c) => { const m = c.match(/[\d.]+/g); return m ? m.map(Number) : [0, 0, 0, 1]; };
  const lum = ([r, g, b]) => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const fondoDe = (el) => {
    const capas = [];
    for (let p = el; p; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (cs.backgroundImage !== 'none') return null;
      const [r, g, b, a = 1] = parse(cs.backgroundColor);
      if (a > 0) capas.push([r, g, b, a]);
      if (a === 1) break;
    }
    let base = [255, 255, 255];
    capas.reverse().forEach(([r, g, b, a]) => { base = [r * a + base[0] * (1 - a), g * a + base[1] * (1 - a), b * a + base[2] * (1 - a)]; });
    return base;
  };
  const malos = [];
  document.querySelectorAll('body *').forEach(el => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || el.closest('.printable-summary')) return;
    const propio = Array.from(el.childNodes).some(n => n.nodeType === 3 && n.textContent.trim());
    if (!propio) return;
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    if (el.disabled || el.closest('[disabled]')) return;
    const fondo = fondoDe(el);
    if (!fondo) return;
    const [cr, cg, cb, ca = 1] = parse(cs.color);
    const texto = [cr * ca + fondo[0] * (1 - ca), cg * ca + fondo[1] * (1 - ca), cb * ca + fondo[2] * (1 - ca)];
    const l1 = lum(texto), l2 = lum(fondo);
    const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    const grande = parseFloat(cs.fontSize) >= 24 || (parseFloat(cs.fontSize) >= 18.66 && Number(cs.fontWeight) >= 700);
    if (ratio < (grande ? 3 : 4.5)) malos.push(`${el.tagName.toLowerCase()}${el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/)[0] : ''} "${el.textContent.trim().slice(0, 28)}" ${ratio.toFixed(2)}`);
  });
  return malos;
}


async function interacciones(navegador, base, fallos) {
  const premium = { ...ESTADO, user: { ...ESTADO.user, isPremium: true } };
  const carpeta = path.join(CAPTURAS, 'interacciones');
  fs.mkdirSync(carpeta, { recursive: true });
  const ok = (cond, msg) => { if (!cond) fallos.push(`interacción: ${msg}`); };
  const nuevoContexto = async (viewport, estado) => {
    const ctx = await navegador.newContext({ viewport, hasTouch: viewport.width < 768 });
    await ctx.addInitScript(({ estado }) => {
      try {
        localStorage.setItem('nutriamigo_theme', 'claro');
        if (!localStorage.getItem('nutriamigo_demo_state')) localStorage.setItem('nutriamigo_demo_state', JSON.stringify(estado));
      } catch (e) { /* sin almacenamiento */ }
    }, { estado });
    return ctx;
  };
  const abrir = async (ctx, nombre) => {
    const pg = await ctx.newPage();
    await pg.goto(`${base}/${nombre}.html`, { waitUntil: 'networkidle' });
    await pg.waitForTimeout(400);
    return pg;
  };

  const ctx = await nuevoContexto({ width: 390, height: 844 }, premium);

  /* Modal "Personalizar": hoja casi a pantalla completa, foco atrapado, Escape y devolución del foco */
  let pg = await abrir(ctx, 'alimentacion');
  await pg.click('#personalizeBtn');
  await pg.waitForTimeout(400);
  const modal = await pg.evaluate(() => {
    const m = document.querySelector('#personalizeModal .modal');
    const r = m.getBoundingClientRect();
    return { alto: r.height, abajo: Math.round(r.bottom), vh: innerHeight, dentro: !!document.activeElement.closest('.modal'), bloqueado: getComputedStyle(document.body).overflow === 'hidden' };
  });
  ok(modal.alto >= modal.vh * 0.85, `el modal Personalizar no ocupa casi toda la pantalla (${Math.round(modal.alto)} de ${modal.vh})`);
  ok(modal.dentro, 'al abrir el modal el foco no entra en él');
  ok(modal.bloqueado, 'el fondo se puede desplazar con el modal abierto');
  await pg.screenshot({ path: path.join(carpeta, 'modal-personalizar-movil.png') });
  for (let i = 0; i < 25; i++) await pg.keyboard.press('Tab');
  ok(await pg.evaluate(() => !!document.activeElement.closest('.modal')), 'el foco se sale del modal con Tab');
  await pg.keyboard.press('Escape');
  await pg.waitForTimeout(200);
  ok(await pg.evaluate(() => document.getElementById('personalizeModal').hidden), 'Escape no cierra el modal');
  ok(await pg.evaluate(() => document.activeElement.id === 'personalizeBtn'), 'el foco no vuelve al botón que abrió el modal');
  ok(await pg.evaluate(() => getComputedStyle(document.body).overflow !== 'hidden'), 'el fondo sigue bloqueado tras cerrar el modal');

  /* Hoja "Más", idioma, tema y configuración */
  await pg.click('#moreBtn');
  await pg.waitForTimeout(300);
  ok(await pg.evaluate(() => document.getElementById('moreBtn').getAttribute('aria-expanded') === 'true'), '"Más" no marca aria-expanded al abrir');
  await pg.screenshot({ path: path.join(carpeta, 'hoja-mas-movil.png') });
  await pg.click('#moreTema [data-tema="dark"]');
  ok(await pg.evaluate(() => document.documentElement.getAttribute('data-theme') === 'dark'), 'el tema oscuro no se aplica desde "Más"');
  await pg.click('#moreLang [data-lang="de"]');
  ok(await pg.evaluate(() => document.querySelector('.bn-label[data-i18n="bnav.mas"]').textContent.trim() === 'Mehr'), 'la barra inferior no se traduce al alemán');
  await pg.keyboard.press('Escape');
  await pg.waitForTimeout(200);
  ok(await pg.evaluate(() => document.getElementById('moreBtn').getAttribute('aria-expanded') === 'false'), '"Más" no marca aria-expanded al cerrar');
  await pg.click('#moreTema [data-tema="claro"]', { force: true }).catch(() => {});
  await pg.evaluate(() => { window.NutriTema.set('claro'); window.NutriIdioma.set('es'); });
  await pg.click('#moreBtn');
  await pg.click('#moreSettings');
  await pg.waitForTimeout(500);
  const ajustes = await pg.evaluate(() => { const o = [...document.querySelectorAll('.modal-overlay')].find(x => !x.hidden && x.id !== 'moreSheet'); return o ? { abierto: true, dentro: !!document.activeElement.closest('.modal') } : { abierto: false }; });
  ok(ajustes.abierto, 'Configuración no se abre desde "Más"');
  if (ajustes.abierto) await pg.screenshot({ path: path.join(carpeta, 'configuracion-movil.png') });
  await pg.close();

  /* Comunidad: lista de amigos y chat, una vista a la vez */
  pg = await abrir(ctx, 'comunidad');
  await pg.click('#communityTabs [data-tab="friends"]');
  await pg.waitForTimeout(300);
  await pg.click('.friend-item');
  await pg.waitForTimeout(300);
  const vista = await pg.evaluate(() => ({ chat: getComputedStyle(document.querySelector('.friend-chat')).display, lista: getComputedStyle(document.querySelector('.friends-list')).display }));
  ok(vista.chat !== 'none' && vista.lista === 'none', 'al elegir un amigo no se muestra solo el chat');
  await pg.screenshot({ path: path.join(carpeta, 'chat-amigo-movil.png') });
  await pg.click('#friendBackBtn');
  ok(await pg.evaluate(() => getComputedStyle(document.querySelector('.friends-list')).display !== 'none'), 'el botón volver no regresa a la lista de amigos');
  await pg.close();

  /* Portada: menú hamburguesa */
  pg = await abrir(ctx, 'index');
  await pg.click('#navToggle');
  ok(await pg.evaluate(() => document.getElementById('navToggle').getAttribute('aria-expanded') === 'true'), 'la hamburguesa no marca aria-expanded');
  await pg.screenshot({ path: path.join(carpeta, 'portada-menu-movil.png') });
  await pg.keyboard.press('Escape');
  ok(await pg.evaluate(() => !document.getElementById('navMobile').classList.contains('open')), 'Escape no cierra el menú de la portada');
  await pg.click('#navToggle');
  await pg.mouse.click(200, 700);
  ok(await pg.evaluate(() => !document.getElementById('navMobile').classList.contains('open')), 'pulsar fuera no cierra el menú de la portada');
  await pg.close();
  await ctx.close();

  /* Onboarding: error junto al campo, sin alert */
  const sinBio = { ...ESTADO }; delete sinBio.bio;
  const ctxOb = await nuevoContexto({ width: 390, height: 844 }, sinBio);
  pg = await abrir(ctxOb, 'onboarding');
  let hubo = false;
  pg.on('dialog', d => { hubo = true; d.dismiss(); });
  await pg.click('[data-step="1"] [data-next]');
  await pg.waitForTimeout(200);
  ok(!hubo, 'el onboarding sigue usando alert()');
  ok(await pg.evaluate(() => !!document.querySelector('.field-error')), 'el onboarding no muestra el error junto al campo');
  await pg.screenshot({ path: path.join(carpeta, 'onboarding-error-movil.png') });
  await ctxOb.close();

  /* Celular en horizontal: la barra inferior no supera el 20 % de la altura */
  const ctxH = await nuevoContexto({ width: 667, height: 375 }, premium);
  pg = await abrir(ctxH, 'dashboard');
  const barra = await pg.evaluate(() => { const b = document.querySelector('.bottom-nav'); return b ? { alto: b.getBoundingClientRect().height, vh: innerHeight } : null; });
  ok(barra && barra.alto <= barra.vh * 0.2, `la barra inferior en horizontal ocupa ${barra ? Math.round(barra.alto / barra.vh * 100) : '?'} % de la altura`);
  await pg.screenshot({ path: path.join(carpeta, 'dashboard-horizontal.png') });
  await ctxH.close();
}

(async () => {
  fs.rmSync(CAPTURAS, { recursive: true, force: true });
  fs.mkdirSync(CAPTURAS, { recursive: true });

  let servidor = null;
  let base = process.env.BASE_URL;
  if (!base) {
    servidor = crear();
    await new Promise(r => servidor.listen(0, '127.0.0.1', r));
    base = `http://127.0.0.1:${servidor.address().port}`;
  }

  const navegador = await chromium.launch();
  const fallos = [];
  const avisos = [];
  const registrar = (dest, id, lista) => lista.forEach(x => dest.push(`${id}: ${x}`));

  for (const tema of TEMAS) {
    for (const tam of TAMANOS) {
      const contexto = await navegador.newContext({ viewport: { width: tam.width, height: tam.height }, deviceScaleFactor: 1, hasTouch: tam.width < 768 });
      await contexto.addInitScript(({ estado, tema }) => {
        try {
          localStorage.setItem('nutriamigo_theme', tema);
          if (!localStorage.getItem('nutriamigo_demo_state') && !sessionStorage.getItem('sin_estado')) localStorage.setItem('nutriamigo_demo_state', JSON.stringify(estado));
        } catch (e) { /* sin almacenamiento */ }
      }, { estado: ESTADO, tema });

      for (const nombre of PAGINAS) {
        const pagina = await contexto.newPage();
        const errores = [];
        pagina.on('console', m => {
          if (m.type() !== 'error') return;
          const url = m.location().url || '';
          if (/\/(api|auth)\/|socket\.io/.test(url)) return;
          errores.push(`${m.text()} ${url}`);
        });
        pagina.on('pageerror', e => errores.push(String(e)));
        if (nombre === 'onboarding') await pagina.addInitScript(() => { try { const e = JSON.parse(localStorage.getItem('nutriamigo_demo_state') || '{}'); delete e.bio; localStorage.setItem('nutriamigo_demo_state', JSON.stringify(e)); } catch (x) { /* nada */ } });
        await pagina.goto(`${base}/${nombre}.html`, { waitUntil: 'networkidle' });
        await pagina.waitForTimeout(500);

        const variantes = nombre === 'comunidad' ? ['chat', 'reels', 'friends'] : [null];
        for (const variante of variantes) {
          if (variante) {
            if (!(await pagina.$('#communityTabs'))) throw new Error(`Sin pestañas en ${pagina.url()} (${tema}/${tam.nombre}); errores: ${errores.join(' | ')}`);
            await pagina.click(`#communityTabs [data-tab="${variante}"]`);
            await pagina.waitForTimeout(250);
          }
          const id = `${tema}/${tam.nombre}/${nombre}${variante ? '-' + variante : ''}`;
          const m = await pagina.evaluate(medir);
          if (m.desborda) fallos.push(`${id}: desbordamiento horizontal (scrollWidth ${m.scrollWidth} > ${m.ancho})`);
          registrar(fallos, id + ' fuera de pantalla', m.fuera.slice(0, 6));
          if (tam.width === 390) registrar(avisos, id + ' objetivo táctil < 44 px', m.pequenos.slice(0, 12));
          if (tema === 'dark') registrar(fallos, id + ' contraste', (await pagina.evaluate(contraste)).slice(0, 8));
          const carpeta = path.join(CAPTURAS, tema, tam.nombre);
          fs.mkdirSync(carpeta, { recursive: true });
          await pagina.screenshot({ path: path.join(carpeta, `${nombre}${variante ? '-' + variante : ''}.png`), fullPage: false });
        }
        errores.filter(e => !/favicon/i.test(e)).forEach(e => fallos.push(`${tema}/${tam.nombre}/${nombre}: consola: ${e}`));
        await pagina.close();
      }
      await contexto.close();
    }
  }

  await interacciones(navegador, base, fallos);

  await navegador.close();
  if (servidor) servidor.close();

  if (avisos.length) { console.log('\nObjetivos táctiles menores de 44 px (390 px):'); avisos.forEach(a => console.log('  -', a)); }
  if (fallos.length) {
    console.log('\nFALLOS:');
    fallos.forEach(f => console.log('  -', f));
    process.exit(1);
  }
  console.log(`\nRecorrido visual correcto. Capturas en ${path.relative(process.cwd(), CAPTURAS)}`);
  if (avisos.length) process.exit(1);
})().catch(err => { console.error(err); process.exit(1); });
