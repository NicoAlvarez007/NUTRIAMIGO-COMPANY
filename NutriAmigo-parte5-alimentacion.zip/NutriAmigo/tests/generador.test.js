const test = require('node:test');
const assert = require('node:assert');
const G = require('../public/js/generador-comidas.js');
const ING = require('../public/data/ingredientes.js');
const PLANT = require('../public/data/plantillas-comidas.js');

const base = { metaKcal: 2200, proteinaG: 130, dieta: 'omnivoro', alergias: [], proteinasElegidas: [], economico: false };
const platos = (plan) => plan.semana.flatMap((d) => d.comidas.flatMap((c) => c.opciones.map((p) => ({ d, c, p }))));

test('el catálogo tiene al menos 70 ingredientes con macros coherentes y nombres en 3 idiomas', () => {
  assert.ok(ING.lista.length >= 70);
  ING.lista.forEach((i) => {
    ['es', 'en', 'de'].forEach((l) => assert.ok(i.nombre[l], `${i.id} sin ${l}`));
    const atwater = 4 * i.prot + 4 * i.carb + 9 * i.grasa;
    assert.ok(Math.abs(i.kcal - atwater) <= Math.max(12, 0.2 * i.kcal), `${i.id}: ${i.kcal} vs ${atwater}`);
    assert.ok(['bajo', 'medio', 'alto'].includes(i.precio), i.id);
    if (i.medida) assert.ok(ING.UNIDADES[i.medida.unidad], `${i.id} unidad`);
  });
});

test('hay al menos 12 plantillas por comida, con nombre en 3 idiomas y roles resolubles', () => {
  G.COMIDAS.forEach((c) => assert.ok(PLANT.lista.filter((p) => p.comidas.includes(c)).length >= 12, c));
  PLANT.lista.forEach((p) => {
    ['es', 'en', 'de'].forEach((l) => assert.ok(p.nombre[l], p.id));
    const claves = p.roles.map((r) => r.split('=')[0]);
    ['es', 'en', 'de'].forEach((l) => (p.nombre[l].match(/\{(\w+)\}/g) || []).forEach((m) => assert.ok(claves.includes(m.slice(1, -1)), `${p.id} ${l} ${m}`)));
  });
});

test('mismas entradas, mismo plan; otra semilla, otro plan', () => {
  const a = G.generarPlanSemanal(base, { semilla: 'x' });
  const b = G.generarPlanSemanal(base, { semilla: 'x' });
  const c = G.generarPlanSemanal(base, { semilla: 'y' });
  assert.deepStrictEqual(a, b);
  assert.notDeepStrictEqual(a, c);
});

test('cada plato queda dentro de ±7 % de las calorías de su comida y las metas suman la meta del día exacta', () => {
  [1200, 1500, 1800, 2200, 2600, 3000, 3500].forEach((m) => {
    const plan = G.generarPlanSemanal({ ...base, metaKcal: m, proteinaG: Math.round(m * 0.25 / 4) }, { semilla: 's' + m });
    plan.semana.forEach((d) => {
      assert.strictEqual(d.comidas.reduce((a, c) => a + c.kcalMeta, 0), d.metaKcal);
      d.comidas.forEach((c) => c.opciones.forEach((p) => {
        assert.ok(Math.abs(p.kcal - p.kcalMeta) / p.kcalMeta <= G.TOLERANCIA, `${m} ${d.dia} ${c.comida}: ${p.kcal}/${p.kcalMeta}`);
      }));
    });
  });
});

test('ningún plato viola dieta, alergias ni texto libre (todas las combinaciones, varias semillas)', () => {
  const textos = ['', 'no como cerdo', 'sin gluten por favor', 'alergia a los mariscos y al maní', 'no me gusta el pescado'];
  const alergias = [[], ['lactosa'], ['gluten'], ['huevo'], ['frutos_secos'], ['soya'], ['marisco'], ['lactosa', 'huevo', 'soya']];
  let n = 0;
  G.DIETAS.forEach((dieta) => alergias.forEach((al) => textos.forEach((t) => {
    n += 1;
    const perfil = { ...base, dieta, alergias: al, restriccionesTexto: t, economico: n % 2 === 0 };
    const plan = G.generarPlanSemanal(perfil, { semilla: 'v' + n });
    const v = G.validarPlan(plan, perfil);
    assert.ok(v.ok, JSON.stringify([dieta, al, t, v.errores[0]]));
    const prohibidas = G.etiquetasProhibidas(perfil);
    platos(plan).forEach(({ p }) => p.ingredientes.forEach((i) => ING.porId[i.id].etiquetas.forEach((e) => assert.ok(!prohibidas.has(e)))));
  })));
});

test('el texto libre se interpreta en español, inglés y alemán', () => {
  assert.ok(G.etiquetasDeTexto('No como cerdo').has('cerdo'));
  assert.ok(G.etiquetasDeTexto('I am allergic to peanuts').has('mani'));
  assert.ok(G.etiquetasDeTexto('keine Milchprodukte').has('lacteo'));
  assert.ok(G.etiquetasDeTexto('sin lactosa').has('lactosa'));
  assert.ok(!G.etiquetasDeTexto('sin lactosa').has('lacteo'));
});

test('vegano no incluye animal, huevo, lácteo ni miel; vegetariano acepta huevo y lácteos', () => {
  const v = G.generarPlanSemanal({ ...base, dieta: 'vegano' }, { semilla: 'veg' });
  platos(v).forEach(({ p }) => p.ingredientes.forEach((i) => {
    const e = ING.porId[i.id].etiquetas;
    ['carne', 'pescado', 'marisco', 'huevo', 'lacteo', 'lactosa', 'miel'].forEach((t) => assert.ok(!e.includes(t), `${i.id} ${t}`));
  }));
  const vt = G.etiquetasProhibidas({ dieta: 'vegetariano' });
  assert.ok(!vt.has('huevo') && !vt.has('lacteo') && vt.has('carne') && vt.has('pescado'));
});

test('proteínas elegidas se respetan: solo pollo no trae res, cerdo ni pescado', () => {
  const plan = G.generarPlanSemanal({ ...base, proteinasElegidas: ['pollo'] }, { semilla: 'p' });
  platos(plan).forEach(({ p }) => p.ingredientes.forEach((i) => {
    const e = ING.porId[i.id].etiquetas;
    ['res', 'cerdo', 'pescado', 'marisco'].forEach((t) => assert.ok(!e.includes(t), `${i.id} ${t}`));
  }));
});

test('el modo económico no usa ingredientes de precio alto cuando hay alternativa', () => {
  const plan = G.generarPlanSemanal({ ...base, economico: true }, { semilla: 'eco' });
  const altos = platos(plan).flatMap(({ p }) => p.ingredientes).filter((i) => ING.porId[i.id].precio === 'alto').length;
  const total = platos(plan).flatMap(({ p }) => p.ingredientes).length;
  assert.ok(altos / total < 0.05, `${altos}/${total}`);
});

test('las dos opciones de una comida no comparten proteína ni carbohidrato principal', () => {
  const plan = G.generarPlanSemanal(base, { semilla: 'dif' });
  plan.semana.forEach((d) => d.comidas.forEach((c) => {
    const principales = (p) => p.ingredientes.filter((i) => ['P', 'D', 'C', 'B'].includes(i.rol)).map((i) => i.id);
    const a = principales(c.opciones[0]);
    principales(c.opciones[1]).forEach((id) => assert.ok(!a.includes(id), `${d.dia} ${c.comida}: ${id}`));
  }));
});

test('no se repite el mismo plato en la semana ni la misma proteína en comidas seguidas de una opción', () => {
  const plan = G.generarPlanSemanal(base, { semilla: 'rep' });
  const vistos = new Set();
  platos(plan).forEach(({ c, p }) => {
    const k = c.comida + '|' + p.clave;
    assert.ok(!vistos.has(k), k);
    vistos.add(k);
  });
  [0, 1].forEach((o) => {
    let previa = null;
    plan.semana.forEach((d) => d.comidas.forEach((c) => {
      const prot = c.opciones[o].ingredientes.find((i) => i.rol === 'P');
      if (prot) { assert.notStrictEqual(prot.id, previa, `${d.dia} ${c.comida}`); previa = prot.id; }
    }));
  });
});

test('el ayuno reparte las calorías entre menos comidas y la suma es exacta', () => {
  ['14:10', '16:8', '18:6'].forEach((protocolo) => {
    const plan = G.generarPlanSemanal({ ...base, ayunoProtocolo: protocolo, ayunoInicio: '12:00' }, { semilla: 'ay' });
    const esperadas = G.slotsDelDia(protocolo);
    plan.semana.forEach((d) => {
      assert.deepStrictEqual(d.comidas.map((c) => c.comida), esperadas);
      assert.strictEqual(d.comidas.reduce((a, c) => a + c.kcalMeta, 0), d.metaKcal);
    });
  });
  assert.strictEqual(G.slotsDelDia('18:6').length, 2);
  assert.ok(G.factorPorcion('18:6') > G.factorPorcion('16:8') && G.factorPorcion('16:8') > 1.1 && G.factorPorcion('14:10') === 1);
});

test('horas de las comidas dentro de la ventana (también si cruza la medianoche) y estado del ayuno', () => {
  assert.deepStrictEqual(G.horasDeComidas('18:6', '12:00'), { almuerzo: '12:00', cena: '17:00' });
  const h = G.horasDeComidas('16:8', '12:00');
  assert.strictEqual(h.almuerzo, '12:00');
  assert.ok(h.cena <= '19:00');
  assert.deepStrictEqual(G.estadoAyuno('16:8', '12:00', 13 * 60), { enAyuno: false, minutos: 7 * 60, cierra: '20:00' });
  assert.strictEqual(G.estadoAyuno('16:8', '12:00', 21 * 60).enAyuno, true);
  assert.strictEqual(G.estadoAyuno('16:8', '12:00', 21 * 60).minutos, 15 * 60);
  /* Ventana 14:00-00:00 (cruza la medianoche): a las 23:00 aún se puede comer; a la 01:00 ya es ayuno. */
  assert.deepStrictEqual(G.estadoAyuno('14:10', '14:00', 23 * 60), { enAyuno: false, minutos: 60, cierra: '00:00' });
  assert.deepStrictEqual(G.estadoAyuno('14:10', '14:00', 1 * 60), { enAyuno: true, minutos: 13 * 60, abre: '14:00' });
  assert.deepStrictEqual(G.estadoAyuno('16:8', '20:00', 2 * 60), { enAyuno: false, minutos: 2 * 60, cierra: '04:00' });
});

test('el ayuno no está permitido a menores ni con IMC bajo, y no es viable con metas enormes', () => {
  assert.deepStrictEqual(G.ayunoPermitido({ edad: 17, estatura: 170, peso: 60 }), { ok: false, motivo: 'menor' });
  assert.deepStrictEqual(G.ayunoPermitido({ edad: 30, estatura: 175, peso: 52 }), { ok: false, motivo: 'imc_bajo' });
  assert.deepStrictEqual(G.ayunoPermitido({ edad: 30, estatura: 175, peso: 70 }), { ok: true });
  assert.strictEqual(G.ayunoViable(3500, '18:6'), false);
  assert.strictEqual(G.ayunoViable(2000, '18:6'), true);
  const plan = G.generarPlanSemanal({ ...base, metaKcal: 3500, ayunoProtocolo: '18:6' }, { semilla: 'big' });
  assert.strictEqual(plan.ayunoIgnorado, true);
  assert.strictEqual(plan.semana[0].comidas.length, 4);
});

test('repartir: pesos 25/35/10/30 y la última comida absorbe el redondeo', () => {
  const r = G.repartir(2001, G.COMIDAS);
  assert.strictEqual(Object.values(r).reduce((a, b) => a + b, 0), 2001);
  assert.strictEqual(r.desayuno, 500);
  assert.strictEqual(r.almuerzo, 700);
});

test('medidas caseras: fracciones razonables, singular y plural, y nada absurdo', () => {
  assert.strictEqual(G.medidaCasera('pechuga_pollo', 120, 'es'), '1 pechuga mediana');
  assert.strictEqual(G.medidaCasera('pechuga_pollo', 180, 'es'), '1½ pechugas medianas');
  assert.strictEqual(G.medidaCasera('aguacate', 50, 'es'), '¼ de aguacate mediano');
  assert.strictEqual(G.medidaCasera('arroz_blanco', 80, 'es'), '½ taza');
  assert.strictEqual(G.medidaCasera('huevo', 100, 'en'), '2 eggs');
  assert.strictEqual(G.medidaCasera('arroz_blanco', 320, 'de'), '2 Tassen');
  assert.strictEqual(G.medidaCasera('camaron', 150, 'es'), null);
  assert.strictEqual(G.medidaCasera('aguacate', 6, 'es'), null);
  assert.strictEqual(G.textoCantidad('aceite_oliva', 10, 'es', false), '10 ml');
  assert.strictEqual(G.textoCantidad('pechuga_pollo', 120, 'es', true), '120 g (≈ 1 pechuga mediana)');
});

test('lista de compras: suma por ingrediente, agrupa por sección y calcula el índice de precio', () => {
  const plan = G.generarPlanSemanal(base, { semilla: 'lc' });
  const lista = G.listaDeCompras(plan);
  assert.ok(lista.secciones.length >= 4);
  const todo = lista.secciones.flatMap((s) => s.items);
  assert.strictEqual(new Set(todo.map((i) => i.id)).size, todo.length);
  const sumaA = {};
  plan.semana.forEach((d) => d.comidas.forEach((c) => c.opciones.filter((p) => p.opcion === 1).forEach((p) => p.ingredientes.forEach((i) => { sumaA[i.id] = (sumaA[i.id] || 0) + i.gramos; }))));
  todo.forEach((i) => assert.strictEqual(i.gramos, Math.ceil(sumaA[i.id] / 10) * 10));
  assert.ok(['economico', 'moderado', 'alto'].includes(lista.indicePrecio));
  const ambas = G.listaDeCompras(plan, { opciones: [1, 2] });
  assert.ok(ambas.total >= lista.total);
});

test('las calorías extra del día se suman a la meta de ese día', () => {
  const plan = G.generarPlanSemanal(base, { semilla: 'ex', kcalExtra: { miercoles: 300 } });
  assert.strictEqual(plan.semana.find((d) => d.dia === 'miercoles').metaKcal, 2500);
  assert.strictEqual(plan.semana.find((d) => d.dia === 'martes').metaKcal, 2200);
});

test('"cambiar esta comida" produce otro plato sin alterar el resto', () => {
  const a = G.generarPlanSemanal(base, { semilla: 'cm' });
  const b = G.generarPlanSemanal(base, { semilla: 'cm', cambios: { 'martes|almuerzo|1': 1 } });
  const ca = a.semana[1].comidas.find((c) => c.comida === 'almuerzo').opciones[0];
  const cb = b.semana[1].comidas.find((c) => c.comida === 'almuerzo').opciones[0];
  assert.notStrictEqual(ca.clave, cb.clave);
  assert.deepStrictEqual(a.semana[0], b.semana[0]);
});

test('un plan imposible lanza un error claro en lugar de devolver platos rotos', () => {
  const perfil = { ...base, dieta: 'vegano', alergias: ['soya', 'gluten', 'frutos_secos'], restriccionesTexto: 'sin legumbres, sin aguacate' };
  try {
    const plan = G.generarPlanSemanal(perfil, { semilla: 'imp' });
    assert.ok(G.validarPlan(plan, perfil).ok);
  } catch (e) {
    assert.strictEqual(e.code, 'no_se_pudo_armar');
  }
});
