# NutriAmigo

Aplicación web de nutrición y entrenamiento: la persona se registra, ingresa sus datos y recibe su IMC, su meta de calorías, sus macronutrientes y un plan semanal de alimentación y entrenamiento con **recomendación personalizada**. Incluye racha de constancia, registro de peso, agua y kilómetros, comunidad (chat, reels y amigos) y membresía Premium.

Navegador: HTML, CSS y JavaScript sin framework. Servidor: Node.js, Express, SQLite y Socket.io.

> **Antes de publicar en internet:** cambiar `ADMIN_PASSWORD`, poner `COOKIE_SECURE=true` con HTTPS y definir `SESSION_SECRET`.

## Instalar Node.js

Descarga la versión **LTS** (18 o superior) desde https://nodejs.org y ejecútala. Para comprobarlo, abre una terminal y escribe `node -v`.

## Iniciar

- **Windows:** doble clic en `INICIAR.bat`.
- **Mac / Linux:** `./iniciar.sh` (si no abre, ejecuta antes `chmod +x iniciar.sh`).

La primera vez instala las dependencias (necesita internet) y crea `server/.env` a partir de `.env.example`. Al terminar verás algo así:

```
✅ NutriAmigo está funcionando
   En este computador:  http://localhost:3000
   Desde tu celular (misma red Wi-Fi):  http://192.168.1.20:3000
```

También puedes iniciar a mano: `cd server`, `npm install`, `npm start` (o `npm run dev` para reiniciar solo al guardar cambios).

## Iniciar sesión sin credenciales de Google

Si `GOOGLE_CLIENT_ID` y `GOOGLE_CLIENT_SECRET` están vacíos y `NODE_ENV=development`, el botón "Continuar con Google" abre una cuenta de prueba local: te lleva al formulario de datos (onboarding) y de ahí a todas las páginas, con la base de datos real. En producción ese atajo no existe.

## Abrir desde el celular

El celular debe estar en la **misma red Wi-Fi** que el computador. Escribe en su navegador la dirección que aparece en "Desde tu celular". Si no abre, permite a Node.js a través del firewall del computador (en Windows aparece un aviso la primera vez: elige "Permitir acceso").

## Variables de `server/.env`

| Variable | Uso | Valor por defecto |
|---|---|---|
| `PORT` | Puerto del servidor | `3000` |
| `NODE_ENV` | `development`, `production` o `test` | `development` |
| `SESSION_SECRET` | Secreto de las cookies. Si está vacío se genera uno aleatorio y se guarda en `.env`. En `production` es obligatorio | vacío |
| `COOKIE_SECURE` | `true` solo si se sirve por HTTPS | `false` |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_CALLBACK_URL` | Inicio de sesión real con Google (opcional) | vacíos |
| `ADMIN_USER` | Usuario del administrador (se usa desde la Parte 3) | `administrador` |
| `ADMIN_PASSWORD` | Contraseña inicial del administrador (se usa desde la Parte 3) | `12345678` |
| `ALLOW_FREE_PREMIUM_SWITCH` | Permite activar o quitar Premium sin pago, solo mientras no exista la pantalla de pago | `true` |

## Estructura de carpetas

```
NutriAmigo/
├── docs/            documentos y prompts (no se sirven al navegador)
├── public/          todo lo que ve el navegador (lo único que sirve Express)
│   ├── *.html  css/  js/  data/  assets/  vendor/
│   └── manifest.json  service-worker.js
├── server/
│   ├── server.js    arranque
│   ├── config.js    lee y valida .env
│   ├── sockets.js   chat en tiempo real
│   ├── db/          conexión, migraciones (migrations/) y consultas (queries/)
│   ├── routes/      una ruta por tema
│   ├── middleware/  autenticación, validación, límites y seguridad
│   ├── lib/         validadores, calorías, sesiones, fechas, traducción
│   ├── data/        nutriamigo.db (no se sube a git)
│   ├── uploads/     fotos (no se sube a git)
│   └── .env.example
├── tests/           pruebas del servidor (estatico, validadores, migraciones...) y visuales
├── tools/           íconos PWA y fuentes locales
├── INICIAR.bat  iniciar.sh
└── README.md
```

La base de datos vive en `server/data/nutriamigo.db`. Si existe una anterior en `backend/nutriamigo.db`, se copia sola la primera vez. Los cambios de la base se hacen con migraciones numeradas en `server/db/migrations/`; nunca se borra la base del usuario.

## Bloqueo por intentos fallidos

Cinco contraseñas incorrectas seguidas para la misma cuenta la bloquean **15 minutos** (el mensaje dice cuántos minutos faltan). El bloqueo por equipo (dirección IP) llega a los 30 intentos fallidos, para que equivocarse con una cuenta no deje fuera a las demás. Los bloqueos se guardan en la base de datos: reiniciar el servidor no los quita. Para quitarlos al momento (con el servidor apagado o encendido), en la carpeta raíz ejecuta `npm run desbloquear` o `node tools/desbloquear.js`.

## Pruebas

```
cd server
npm install
npm test
```

(equivale a `node --test ../tests/`). Las pruebas usan una base temporal y no tocan tus datos.

## Seguridad en el servidor

- Solo se publica `public/`; `server/`, `docs/`, `tests/`, `.env` y la base dan 404.
- Sesiones guardadas en SQLite (sobreviven a reiniciar), cookie `httpOnly`, `sameSite=lax`.
- Cabeceras con `helmet` y política de contenido sin scripts en línea.
- Límites de peticiones y protección CSRF simple.
- Todos los datos se validan en el servidor con códigos de error traducibles (es / en / de).

## Diseño responsive (Parte 2)

- `public/css/responsive.css` concentra los ajustes por tamaño; `public/js/nav.js` genera la barra superior (≥ 768 px) y la barra inferior con la hoja "Más" (celular); `public/js/ui.js` maneja el tema (claro por defecto / oscuro / automático según el sistema) y los modales accesibles.
- Fuentes locales: con internet, ejecuta una vez en la carpeta raíz `npm install` y `npm run fuentes` (copia Manrope e Inter a `public/assets/fonts/` y completa `public/css/fonts.css`). Sin eso se usa la tipografía del sistema.
- Íconos PWA: `npm install --no-save sharp && npm run iconos`.
- Pruebas visuales: `npm install && npx playwright install chromium && npm run test:visual` (390, 820 y 1280 px, claro y oscuro; capturas en `tests/visual/capturas/`).


## Cuentas y panel de administrador (Parte 3)

- Registro e inicio de sesión con correo y contraseña en `acceso.html`. Facebook y Apple aparecen como "Próximamente".
- Google: con credenciales reales en `server/.env` se usa el de verdad; sin ellas, en desarrollo se abre `google-simulado.html` (una cuenta por correo). Se apaga con `GOOGLE_SIMULADO=false`.
- Administrador: usuario `administrador`, contraseña inicial `12345678`, definidos en `server/.env` (`ADMIN_USER`, `ADMIN_PASSWORD`). **Cámbiala antes de publicar**; al arrancar, la consola avisa mientras siga la de fábrica. El panel está en `/admin.html` (404 para quien no sea admin) y su enlace aparece en el menú de perfil.
- Sin servidor, las páginas muestran "No se pudo conectar" con botón Reintentar (ya no hay modo demo).
- De 15 a 17 años el registro pide la autorización de un adulto (queda guardada con fecha y hora); menores de 15 no pueden registrarse.
- Migración `005_cuentas`: columnas nuevas en `users` con índices únicos (SQLite no permite `UNIQUE` en `ALTER TABLE`). Las cuentas de correo usan un `google_id` interno `local:<uuid>` porque la columna sigue siendo `NOT NULL`.
- Pruebas: `cd server && npm install && npm test` (incluye `tests/cuentas.test.js`).


## Parte 5 — Alimentación

- `public/data/ingredientes.js` (80 ingredientes con macros, etiquetas, precio y medida casera) y `public/data/plantillas-comidas.js` (≥ 12 plantillas por comida, con nombre en es/en/de).
- `public/js/generador-comidas.js`: genera la semana en el navegador (puro y con semilla), ayuno intermitente, medidas caseras y lista de compras. También corre en Node para las pruebas.
- `public/js/alimentacion.js` + `alimentacion-render.js`: pantalla, "Ya lo hice" (clave `alimentacion-<día>-<comida>-<1|2>`), "Mi día", lista de compras, personalizar.
- Servidor: migración `006_alimentacion.js` (preferencias nuevas y tabla `food_log`), rutas `/api/food-log*`, `/api/completions/reiniciar`, y las marcas de alimentación solo se aceptan el día de hoy.
- Admin: pestaña "Generador de comidas" para probar perfiles sin tocar cuentas.
- Documento de fuentes: `docs/fuentes-nutricion.md`. Se eliminaron `data/meals.js` y `data/meals.i18n.js`.
