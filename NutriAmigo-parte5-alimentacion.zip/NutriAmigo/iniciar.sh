#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "No se encontró Node.js en este computador."
  echo "Descárgalo e instálalo desde https://nodejs.org (versión LTS) y vuelve a abrir este archivo."
  echo ""
  exit 1
fi

cd server || exit 1

if [ ! -d node_modules ]; then
  echo "Instalando dependencias (solo la primera vez, necesita internet)..."
  npm install || { echo "No se pudieron instalar las dependencias."; exit 1; }
fi

if [ ! -f .env ]; then
  cp .env.example .env
fi

npm start
