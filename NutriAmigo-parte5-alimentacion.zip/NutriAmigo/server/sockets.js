const { translateToAll } = require('./lib/traduccion');
const {
  SALAS_CHAT, validarMensajeSala, validarMensajeAmigo, validarId
} = require('./lib/validadores');

const MAX_MENSAJES_POR_MINUTO = 30;

/* Cuenta mensajes por conexión y avisa cuando se pasa del límite. */
function crearLimitador(socket) {
  let ventanaInicio = Date.now();
  let cuenta = 0;
  return () => {
    const ahora = Date.now();
    if (ahora - ventanaInicio > 60000) {
      ventanaInicio = ahora;
      cuenta = 0;
    }
    cuenta += 1;
    if (cuenta > MAX_MENSAJES_POR_MINUTO) {
      socket.emit('chat:error', { code: 'demasiadas_peticiones' });
      return false;
    }
    return true;
  };
}

/* Los sockets exigen sesión válida y cuenta activa; el autor sale siempre del servidor.
   La moderación completa del chat llega en la Parte 9. */
function iniciarSockets(io, q) {
  io.on('connection', (socket) => {
    const permitido = crearLimitador(socket);

    function usuarioActual(funcion) {
      const sesion = socket.request.user;
      const usuario = sesion ? q.getUserById(sesion.id) : null;
      if (!usuario) {
        socket.emit('chat:error', { code: 'no_autenticado' });
        return null;
      }
      if (usuario.suspended) {
        socket.emit('chat:error', { code: 'cuenta_suspendida' });
        return null;
      }
      if (funcion && !q.funcionActiva(funcion)) {
        socket.emit('chat:error', { code: 'funcion_desactivada' });
        return null;
      }
      return usuario;
    }

    socket.on('join', (sala) => {
      if (typeof sala !== 'string' || !SALAS_CHAT.includes(sala)) return;
      if (!usuarioActual('chat')) return;
      socket.join(sala);
    });

    socket.on('leave', (sala) => {
      if (typeof sala !== 'string' || !SALAS_CHAT.includes(sala)) return;
      socket.leave(sala);
    });

    socket.on('message', async (datos) => {
      const usuario = usuarioActual('chat');
      if (!usuario) return;
      const resultado = validarMensajeSala(datos);
      if (!resultado.ok) {
        socket.emit('chat:error', { code: resultado.code });
        return;
      }
      if (!permitido()) return;
      const { room, text, lang, showCountry, country } = resultado.valor;

      let translations = { [lang]: text };
      try {
        translations = await translateToAll(text, lang);
      } catch (err) {
        console.error('Error de traducción:', err.message);
      }

      io.to(room).emit('message', {
        author: usuario.name,
        country: showCountry ? country : null,
        sourceLang: lang,
        translations,
        timestamp: Date.now()
      });
    });

    socket.on('friend:join', (friendId) => {
      const id = validarId(friendId, 'friendId');
      if (!id.ok) return;
      const usuario = usuarioActual('amigos');
      if (!usuario || !q.getAmigo(usuario.id, id.valor)) return;
      socket.join(`friend-${id.valor}`);
    });

    socket.on('friend:message', (datos) => {
      const usuario = usuarioActual('amigos');
      if (!usuario) return;
      const resultado = validarMensajeAmigo(datos);
      if (!resultado.ok) {
        socket.emit('chat:error', { code: resultado.code });
        return;
      }
      if (!permitido()) return;
      const { friendId, texto } = resultado.valor;
      const autor = usuario.name;
      try {
        if (!q.getAmigo(usuario.id, friendId)) {
          socket.emit('chat:error', { code: 'amigo_no_encontrado' });
          return;
        }
        const mensajes = q.guardarMensajeAmigo(friendId, autor, texto);
        io.to(`friend-${friendId}`).emit('friend:message', mensajes[mensajes.length - 1]);
      } catch (err) {
        console.error('No se pudo guardar el mensaje de amigo:', err.message);
        socket.emit('chat:error', { code: 'interno' });
      }
    });
  });
}

module.exports = { iniciarSockets };
