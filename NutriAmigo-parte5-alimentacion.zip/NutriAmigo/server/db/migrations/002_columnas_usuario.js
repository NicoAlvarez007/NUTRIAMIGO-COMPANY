const COLUMNAS = [
  ['avisar_actualizacion_plan', 'INTEGER NOT NULL DEFAULT 1'],
  ['recordar_agua', 'INTEGER NOT NULL DEFAULT 0'],
  ['recordar_entreno', 'INTEGER NOT NULL DEFAULT 0']
];

function up(db) {
  const existentes = new Set(db.prepare('PRAGMA table_info(users)').all().map((c) => c.name));
  for (const [nombre, definicion] of COLUMNAS) {
    if (!existentes.has(nombre)) db.exec(`ALTER TABLE users ADD COLUMN ${nombre} ${definicion}`);
  }
}

module.exports = { up };
