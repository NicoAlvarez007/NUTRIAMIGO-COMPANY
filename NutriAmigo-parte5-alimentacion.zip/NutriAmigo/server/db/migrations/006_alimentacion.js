/* Parte 5: preferencias de alimentación (dieta, alergias, medidas, ahorro, ayuno) y registro "Mi día". */
const COLUMNAS = [
  ['dieta', 'TEXT'],
  ['alergias', 'TEXT'],
  ['mostrar_medidas', 'INTEGER'],
  ['economico', 'INTEGER NOT NULL DEFAULT 0'],
  ['ayuno_protocolo', 'TEXT'],
  ['ayuno_inicio', 'TEXT']
];

function up(db) {
  const existentes = new Set(db.prepare('PRAGMA table_info(preferences)').all().map((c) => c.name));
  COLUMNAS.forEach(([nombre, definicion]) => {
    if (!existentes.has(nombre)) db.exec(`ALTER TABLE preferences ADD COLUMN ${nombre} ${definicion}`);
  });

  db.exec(`CREATE TABLE IF NOT EXISTS food_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    fecha TEXT NOT NULL,
    comida TEXT NOT NULL,
    nombre TEXT NOT NULL,
    gramos REAL,
    kcal REAL NOT NULL,
    proteina REAL NOT NULL DEFAULT 0,
    carbohidratos REAL NOT NULL DEFAULT 0,
    grasa REAL NOT NULL DEFAULT 0,
    creado_en TEXT NOT NULL
  )`);
  db.exec('CREATE INDEX IF NOT EXISTS idx_food_log_usuario_fecha ON food_log (user_id, fecha)');

  /* Quien ya había elegido "vegano" o "vegetariano" entre las proteínas conserva esa dieta. */
  db.exec(`UPDATE preferences SET dieta = 'vegano'
    WHERE dieta IS NULL AND user_id IN (SELECT user_id FROM preferencias_proteinas WHERE proteina = 'vegano')`);
  db.exec(`UPDATE preferences SET dieta = 'vegetariano'
    WHERE dieta IS NULL AND user_id IN (SELECT user_id FROM preferencias_proteinas WHERE proteina = 'vegetariano')`);
}

module.exports = { up };
