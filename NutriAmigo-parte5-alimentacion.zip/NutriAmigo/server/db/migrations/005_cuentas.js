const crypto = require('crypto');

const ALFABETO_CODIGO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function codigoAmigo() {
  let s = '';
  for (let i = 0; i < 8; i += 1) s += ALFABETO_CODIGO[crypto.randomInt(ALFABETO_CODIGO.length)];
  return s;
}

const COLUMNAS = [
  ['username', 'TEXT'],
  ['password_hash', 'TEXT'],
  ['role', "TEXT NOT NULL DEFAULT 'user'"],
  ['suspended', 'INTEGER NOT NULL DEFAULT 0'],
  ['suspended_reason', 'TEXT'],
  ['auth_provider', 'TEXT'],
  ['tz', "TEXT DEFAULT 'America/Bogota'"],
  ['sim_date', 'TEXT'],
  ['friend_code', 'TEXT']
];

/* SQLite no permite columnas UNIQUE con ALTER TABLE: se agregan las columnas y la unicidad
   va en índices. users.google_id sigue siendo NOT NULL; las cuentas de correo y contraseña
   reciben un valor interno "local:<uuid>" (nunca se muestra ni se usa para entrar). */
function up(db) {
  const existentes = new Set(db.prepare('PRAGMA table_info(users)').all().map((c) => c.name));
  for (const [nombre, definicion] of COLUMNAS) {
    if (!existentes.has(nombre)) db.exec(`ALTER TABLE users ADD COLUMN ${nombre} ${definicion}`);
  }

  const usuarios = db.prepare(`
    SELECT u.id, u.email, u.google_id, b.correo AS correo_bio
    FROM users u LEFT JOIN biometrics b ON b.user_id = u.id ORDER BY u.id
  `).all();

  const correosUsados = new Set();
  const codigosUsados = new Set();
  const actualizar = db.prepare(
    'UPDATE users SET email = ?, auth_provider = COALESCE(auth_provider, ?), friend_code = COALESCE(friend_code, ?) WHERE id = ?'
  );

  for (const u of usuarios) {
    let correo = String(u.email || u.correo_bio || '').trim().toLowerCase() || null;
    if (correo && correosUsados.has(correo)) correo = null;
    if (correo) correosUsados.add(correo);

    let codigo;
    do { codigo = codigoAmigo(); } while (codigosUsados.has(codigo));
    codigosUsados.add(codigo);

    const proveedor = u.google_id && !String(u.google_id).startsWith('local:') ? 'google' : 'password';
    actualizar.run(correo, proveedor, codigo, u.id);
  }

  db.exec(`
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_email ON users(email COLLATE NOCASE) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_username ON users(username COLLATE NOCASE) WHERE username IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_friend_code ON users(friend_code) WHERE friend_code IS NOT NULL;

CREATE TABLE IF NOT EXISTS login_attempts (
  clave TEXT PRIMARY KEY,
  intentos INTEGER NOT NULL DEFAULT 0,
  bloqueado_hasta INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  accion TEXT NOT NULL,
  detalle TEXT,
  creado_en TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS feature_flags (
  clave TEXT PRIMARY KEY,
  activo INTEGER NOT NULL DEFAULT 1
);
INSERT OR IGNORE INTO feature_flags (clave, activo) VALUES ('chat', 1), ('reels', 1), ('amigos', 1), ('anuncios', 1);

CREATE TABLE IF NOT EXISTS guardian_consents (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  nombre TEXT NOT NULL,
  parentesco TEXT NOT NULL,
  contacto TEXT NOT NULL,
  aceptado_en TEXT NOT NULL
);
`);
}

module.exports = { up };
