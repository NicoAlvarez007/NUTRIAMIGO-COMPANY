/* Esquema original de NutriAmigo. Usa IF NOT EXISTS para que también sirva
   sobre bases de datos que ya existían antes del sistema de migraciones. */
function up(db) {
  db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  google_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  email TEXT,
  avatar TEXT,
  is_premium INTEGER NOT NULL DEFAULT 0,
  perfil_publico INTEGER NOT NULL DEFAULT 0,
  avisar_actualizacion_plan INTEGER NOT NULL DEFAULT 1,
  recordar_agua INTEGER NOT NULL DEFAULT 0,
  recordar_entreno INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS progress (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  fecha TEXT NOT NULL,
  peso REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS streaks (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  current_streak INTEGER NOT NULL DEFAULT 0,
  last_active_date TEXT
);

CREATE TABLE IF NOT EXISTS biometrics (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  nombre TEXT,
  apellido TEXT,
  correo TEXT,
  peso REAL,
  estatura REAL,
  sexo TEXT,
  edad INTEGER,
  actividad TEXT,
  objetivo TEXT
);

CREATE TABLE IF NOT EXISTS preferences (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  restricciones_texto TEXT,
  frecuencia_semanal INTEGER,
  distancia_km REAL,
  enfoque_muscular TEXT
);

CREATE TABLE IF NOT EXISTS preferencias_proteinas (
  user_id INTEGER NOT NULL REFERENCES users(id),
  proteina TEXT NOT NULL,
  PRIMARY KEY (user_id, proteina)
);

CREATE TABLE IF NOT EXISTS reels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  autor TEXT NOT NULL,
  texto TEXT NOT NULL,
  imagen_url TEXT,
  upvotes INTEGER NOT NULL DEFAULT 0,
  downvotes INTEGER NOT NULL DEFAULT 0,
  likes INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reel_votes (
  reel_id INTEGER NOT NULL REFERENCES reels(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  tipo TEXT NOT NULL,
  PRIMARY KEY (reel_id, user_id, tipo)
);

CREATE TABLE IF NOT EXISTS friends (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  nombre TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS friend_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  friend_id INTEGER NOT NULL REFERENCES friends(id),
  autor TEXT NOT NULL,
  texto TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS daily_logs (
  user_id INTEGER NOT NULL REFERENCES users(id),
  fecha TEXT NOT NULL,
  vasos_agua INTEGER NOT NULL DEFAULT 0,
  km_recorridos REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, fecha)
);

CREATE TABLE IF NOT EXISTS completions (
  user_id INTEGER NOT NULL REFERENCES users(id),
  item_key TEXT NOT NULL,
  fecha TEXT NOT NULL,
  PRIMARY KEY (user_id, item_key, fecha)
);
`);
}

module.exports = { up };
