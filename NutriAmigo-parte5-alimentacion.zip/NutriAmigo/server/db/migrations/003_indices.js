function up(db) {
  db.exec(`
CREATE INDEX IF NOT EXISTS idx_progress_usuario_fecha ON progress(user_id, fecha);
CREATE INDEX IF NOT EXISTS idx_completions_usuario_fecha ON completions(user_id, fecha);
CREATE INDEX IF NOT EXISTS idx_reels_id ON reels(id);
CREATE INDEX IF NOT EXISTS idx_friend_messages_amigo ON friend_messages(friend_id);
`);
}

module.exports = { up };
