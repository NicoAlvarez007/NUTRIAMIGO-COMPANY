const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { migrar } = require('./migrate');

/* Busca una base de datos de la versión anterior (backend/nutriamigo.db) y,
   solo la primera vez, la copia al lugar nuevo para no perder datos. */
function copiarBaseAntigua(rutaNueva) {
  if (fs.existsSync(rutaNueva)) return false;
  const raiz = path.join(__dirname, '..', '..');
  const candidatas = [
    path.join(raiz, 'backend', 'nutriamigo.db'),
    path.join(__dirname, '..', 'nutriamigo.db')
  ];
  const antigua = candidatas.find((ruta) => fs.existsSync(ruta));
  if (!antigua) return false;

  for (const sufijo of ['', '-wal', '-shm']) {
    if (fs.existsSync(antigua + sufijo)) fs.copyFileSync(antigua + sufijo, rutaNueva + sufijo);
  }
  console.log(`Se copió la base de datos anterior (${path.relative(raiz, antigua)}) a ${path.relative(raiz, rutaNueva)}.`);
  return true;
}

function abrir(ruta, { copiarAntigua = true } = {}) {
  fs.mkdirSync(path.dirname(ruta), { recursive: true });
  if (copiarAntigua) copiarBaseAntigua(ruta);

  const db = new Database(ruta);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  migrar(db);
  return db;
}

module.exports = { abrir, copiarBaseAntigua };
