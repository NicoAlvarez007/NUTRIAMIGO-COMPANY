/* Registro "Mi día": lo que la persona comió, con calorías y macros. */
function crear(db) {
  const SUMA = 'COALESCE(SUM(kcal), 0) AS kcal, COALESCE(SUM(proteina), 0) AS proteina, COALESCE(SUM(carbohidratos), 0) AS carbohidratos, COALESCE(SUM(grasa), 0) AS grasa';
  const redondear = (n) => Math.round(n * 10) / 10;

  function totalesDe(filas) {
    const t = filas.reduce((a, f) => ({ kcal: a.kcal + f.kcal, proteina: a.proteina + f.proteina, carbohidratos: a.carbohidratos + f.carbohidratos, grasa: a.grasa + f.grasa }),
      { kcal: 0, proteina: 0, carbohidratos: 0, grasa: 0 });
    return { kcal: Math.round(t.kcal), proteina: redondear(t.proteina), carbohidratos: redondear(t.carbohidratos), grasa: redondear(t.grasa) };
  }

  function listarComidas(userId, fecha) {
    const items = db.prepare('SELECT id, comida, nombre, gramos, kcal, proteina, carbohidratos, grasa FROM food_log WHERE user_id = ? AND fecha = ? ORDER BY id')
      .all(userId, fecha);
    return { fecha, items, totales: totalesDe(items) };
  }

  function contarComidas(userId, fecha) {
    return db.prepare('SELECT COUNT(*) AS n FROM food_log WHERE user_id = ? AND fecha = ?').get(userId, fecha).n;
  }

  function agregarComida(userId, fecha, d, ahora) {
    const r = db.prepare(`INSERT INTO food_log (user_id, fecha, comida, nombre, gramos, kcal, proteina, carbohidratos, grasa, creado_en)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(userId, fecha, d.comida, d.nombre, d.gramos, d.kcal, d.proteina, d.carbohidratos, d.grasa, ahora);
    return Number(r.lastInsertRowid);
  }

  function borrarComida(userId, id, fecha) {
    return db.prepare('DELETE FROM food_log WHERE id = ? AND user_id = ? AND fecha = ?').run(id, userId, fecha).changes > 0;
  }

  /* Totales por día de los últimos 7 días (incluido hoy), del más reciente al más antiguo. */
  function historialComidas(userId, desde, hasta) {
    return db.prepare(`SELECT fecha, ${SUMA}, COUNT(*) AS registros FROM food_log
      WHERE user_id = ? AND fecha >= ? AND fecha <= ? GROUP BY fecha ORDER BY fecha DESC`)
      .all(userId, desde, hasta)
      .map((f) => ({ fecha: f.fecha, registros: f.registros, kcal: Math.round(f.kcal), proteina: redondear(f.proteina), carbohidratos: redondear(f.carbohidratos), grasa: redondear(f.grasa) }));
  }

  return { listarComidas, contarComidas, agregarComida, borrarComida, historialComidas };
}

module.exports = { crear };
