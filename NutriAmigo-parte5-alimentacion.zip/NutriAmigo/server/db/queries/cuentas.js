const fs = require('fs');
const path = require('path');
const { ahoraISO } = require('../../lib/fechas');

const LIMITE_INTENTOS = 5;
const LIMITE_INTENTOS_IP = 30;
const BLOQUEO_MS = 15 * 60 * 1000;

function tamanoCarpeta(dir) {
  let total = 0;
  try {
    for (const nombre of fs.readdirSync(dir)) {
      const ruta = path.join(dir, nombre);
      const st = fs.statSync(ruta);
      total += st.isDirectory() ? tamanoCarpeta(ruta) : st.size;
    }
  } catch (e) { /* la carpeta puede no existir todavía */ }
  return total;
}

function crear(db) {
  /* ---------- Usuarios ---------- */
  const buscarPorEmail = (email) => db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').get(email);
  const buscarPorUsername = (usuario) => db.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE').get(usuario);

  function guardarContrasena(userId, hash) {
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, userId);
  }

  function actualizarNombre(userId, nombre) {
    db.prepare('UPDATE users SET name = ? WHERE id = ?').run(nombre, userId);
  }

  /* ---------- Bloqueo por intentos fallidos ---------- */
  function minutosDeBloqueo(claves) {
    const ahora = Date.now();
    let hasta = 0;
    for (const clave of claves) {
      const fila = db.prepare('SELECT * FROM login_attempts WHERE clave = ?').get(clave);
      if (!fila) continue;
      if (fila.bloqueado_hasta > ahora) hasta = Math.max(hasta, fila.bloqueado_hasta);
      else if (fila.bloqueado_hasta > 0) db.prepare('DELETE FROM login_attempts WHERE clave = ?').run(clave);
    }
    return hasta > ahora ? Math.max(1, Math.ceil((hasta - ahora) / 60000)) : 0;
  }

  function registrarFallo(claves) {
    const ahora = Date.now();
    let bloqueado = false;
    for (const clave of claves) {
      const fila = db.prepare('SELECT * FROM login_attempts WHERE clave = ?').get(clave);
      const intentos = (fila ? fila.intentos : 0) + 1;
      const limite = clave.startsWith('ip:') ? LIMITE_INTENTOS_IP : LIMITE_INTENTOS;
      const hasta = intentos >= limite ? ahora + BLOQUEO_MS : 0;
      if (hasta) bloqueado = true;
      db.prepare(`INSERT INTO login_attempts (clave, intentos, bloqueado_hasta) VALUES (?, ?, ?)
        ON CONFLICT(clave) DO UPDATE SET intentos = excluded.intentos, bloqueado_hasta = excluded.bloqueado_hasta`)
        .run(clave, intentos, hasta);
    }
    return bloqueado;
  }

  function limpiarIntentos(claves) {
    for (const clave of claves) db.prepare('DELETE FROM login_attempts WHERE clave = ?').run(clave);
  }

  /* ---------- Auditoría ---------- */
  function auditar(userId, accion, detalle) {
    db.prepare('INSERT INTO audit_log (user_id, accion, detalle, creado_en) VALUES (?, ?, ?, ?)')
      .run(userId || null, accion, detalle ? String(detalle).slice(0, 500) : null, ahoraISO());
  }

  /* ---------- Interruptores de funciones ---------- */
  function obtenerFunciones() {
    const funciones = {};
    db.prepare('SELECT clave, activo FROM feature_flags').all().forEach((f) => { funciones[f.clave] = !!f.activo; });
    return funciones;
  }

  function funcionActiva(clave) {
    const fila = db.prepare('SELECT activo FROM feature_flags WHERE clave = ?').get(clave);
    return fila ? !!fila.activo : true;
  }

  function cambiarFuncion(clave, activo) {
    db.prepare('UPDATE feature_flags SET activo = ? WHERE clave = ?').run(activo ? 1 : 0, clave);
  }

  /* ---------- Autorización del adulto responsable ---------- */
  function obtenerConsentimiento(userId) {
    return db.prepare('SELECT * FROM guardian_consents WHERE user_id = ?').get(userId) || null;
  }

  function guardarConsentimiento(userId, c) {
    db.prepare(`INSERT INTO guardian_consents (user_id, nombre, parentesco, contacto, aceptado_en)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET nombre = excluded.nombre, parentesco = excluded.parentesco,
        contacto = excluded.contacto, aceptado_en = excluded.aceptado_en`)
      .run(userId, c.nombre, c.parentesco, c.contacto, ahoraISO());
  }

  /* ---------- Fecha simulada (solo administrador) ---------- */
  function fijarFechaSimulada(userId, fecha) {
    db.prepare('UPDATE users SET sim_date = ? WHERE id = ?').run(fecha, userId);
  }

  /* ---------- Administrador ---------- */
  function obtenerAdministrador() {
    return db.prepare("SELECT * FROM users WHERE role = 'admin' ORDER BY id LIMIT 1").get() || null;
  }

  function crearAdministrador({ username, hash, codigo }) {
    const info = db.prepare(`INSERT INTO users (google_id, name, username, password_hash, role, auth_provider,
      is_premium, friend_code, created_at) VALUES ('local:administrador', 'Administrador', ?, ?, 'admin', 'password', 1, ?, ?)`)
      .run(username, hash, codigo, ahoraISO());
    const id = Number(info.lastInsertRowid);
    db.prepare(`INSERT OR IGNORE INTO biometrics (user_id, nombre, apellido, correo, peso, estatura, sexo, edad, actividad, objetivo)
      VALUES (?, 'Administrador', 'NutriAmigo', NULL, 70, 172, 'hombre', 30, 'moderado', 'mantener')`).run(id);
    return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  }

  function actualizarAdministrador(id, { username }) {
    if (username && !buscarPorUsername(username)) {
      db.prepare('UPDATE users SET username = ? WHERE id = ?').run(username, id);
    }
    db.prepare('UPDATE users SET is_premium = 1 WHERE id = ?').run(id);
  }

  /* ---------- Panel: usuarios ---------- */
  function listarUsuarios({ q = '', pagina = 1, porPagina = 20 }) {
    const limpio = q.replace(/[%_\\]/g, ' ').trim();
    const patron = `%${limpio}%`;
    const donde = limpio ? 'WHERE (name LIKE ? OR email LIKE ? OR username LIKE ?)' : '';
    const args = limpio ? [patron, patron, patron] : [];
    const total = db.prepare(`SELECT COUNT(*) AS n FROM users ${donde}`).get(...args).n;
    const filas = db.prepare(`SELECT id, name, email, username, role, is_premium, suspended, created_at
      FROM users ${donde} ORDER BY id DESC LIMIT ? OFFSET ?`).all(...args, porPagina, (pagina - 1) * porPagina);
    return {
      items: filas.map((f) => ({
        id: f.id, nombre: f.name, correo: f.email, usuario: f.username, rol: f.role,
        premium: !!f.is_premium, suspendida: !!f.suspended, creada: f.created_at
      })),
      total,
      pagina,
      paginas: Math.max(1, Math.ceil(total / porPagina))
    };
  }

  function detalleUsuario(id) {
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!u) return null;
    return {
      id: u.id, nombre: u.name, correo: u.email, usuario: u.username, rol: u.role,
      proveedor: u.auth_provider, premium: !!u.is_premium, suspendida: !!u.suspended,
      motivoSuspension: u.suspended_reason, creada: u.created_at, zonaHoraria: u.tz,
      tieneContrasena: !!u.password_hash,
      tieneDatos: !!db.prepare('SELECT 1 FROM biometrics WHERE user_id = ?').get(u.id),
      consentimientoAdulto: !!obtenerConsentimiento(u.id)
    };
  }

  function suspender(id, motivo) {
    db.prepare('UPDATE users SET suspended = 1, suspended_reason = ? WHERE id = ?').run(motivo, id);
  }

  function reactivar(id) {
    db.prepare('UPDATE users SET suspended = 0, suspended_reason = NULL WHERE id = ?').run(id);
  }

  /* ---------- Panel: estado del servidor ---------- */
  function estadoServidor({ rutaDb, carpetaUploads, version }) {
    const cuenta = (sql) => db.prepare(sql).get().n;
    let bytesBase = 0;
    try { bytesBase = fs.statSync(rutaDb).size; } catch (e) { /* base temporal */ }
    return {
      version,
      node: process.version,
      uptimeSegundos: Math.round(process.uptime()),
      usuarios: cuenta('SELECT COUNT(*) AS n FROM users'),
      premium: cuenta('SELECT COUNT(*) AS n FROM users WHERE is_premium = 1'),
      suspendidos: cuenta('SELECT COUNT(*) AS n FROM users WHERE suspended = 1'),
      bytesBase,
      bytesUploads: tamanoCarpeta(carpetaUploads),
      errores: db.prepare("SELECT creado_en, detalle FROM audit_log WHERE accion = 'error_500' ORDER BY id DESC LIMIT 20").all(),
      acciones: db.prepare("SELECT creado_en, accion, detalle, user_id FROM audit_log WHERE accion != 'error_500' ORDER BY id DESC LIMIT 20").all()
    };
  }

  return {
    buscarPorEmail, buscarPorUsername, guardarContrasena, actualizarNombre,
    minutosDeBloqueo, registrarFallo, limpiarIntentos, auditar,
    obtenerFunciones, funcionActiva, cambiarFuncion, obtenerConsentimiento, guardarConsentimiento,
    fijarFechaSimulada, obtenerAdministrador, crearAdministrador, actualizarAdministrador,
    listarUsuarios, detalleUsuario, suspender, reactivar, estadoServidor
  };
}

module.exports = { crear };
