function crear(db) {
  function getProgress(userId) {
    return db.prepare('SELECT fecha, peso FROM progress WHERE user_id = ? ORDER BY id ASC').all(userId);
  }

  function addProgress(userId, peso, fecha) {
    const existente = db.prepare('SELECT id FROM progress WHERE user_id = ? AND fecha = ?').get(userId, fecha);
    if (existente) {
      db.prepare('UPDATE progress SET peso = ? WHERE id = ?').run(peso, existente.id);
    } else {
      db.prepare('INSERT INTO progress (user_id, fecha, peso) VALUES (?, ?, ?)').run(userId, fecha, peso);
    }
    return getProgress(userId);
  }

  function clearProgress(userId) {
    db.prepare('DELETE FROM progress WHERE user_id = ?').run(userId);
  }

  function getDailyLog(userId, fecha) {
    return db.prepare('SELECT * FROM daily_logs WHERE user_id = ? AND fecha = ?').get(userId, fecha)
      || { user_id: userId, fecha, vasos_agua: 0, km_recorridos: 0 };
  }

  function guardarDailyLog(userId, fecha, vasosAgua, kmRecorridos) {
    const existente = db.prepare('SELECT user_id FROM daily_logs WHERE user_id = ? AND fecha = ?').get(userId, fecha);
    if (existente) {
      db.prepare('UPDATE daily_logs SET vasos_agua = ?, km_recorridos = ? WHERE user_id = ? AND fecha = ?')
        .run(vasosAgua, kmRecorridos, userId, fecha);
    } else {
      db.prepare('INSERT INTO daily_logs (user_id, fecha, vasos_agua, km_recorridos) VALUES (?, ?, ?, ?)')
        .run(userId, fecha, vasosAgua, kmRecorridos);
    }
    return getDailyLog(userId, fecha);
  }

  function getCompletions(userId, fecha) {
    return db.prepare('SELECT item_key FROM completions WHERE user_id = ? AND fecha = ?')
      .all(userId, fecha).map((fila) => fila.item_key);
  }

  function toggleCompletion(userId, itemKey, fecha) {
    const existente = db.prepare('SELECT 1 FROM completions WHERE user_id = ? AND item_key = ? AND fecha = ?')
      .get(userId, itemKey, fecha);
    if (existente) {
      db.prepare('DELETE FROM completions WHERE user_id = ? AND item_key = ? AND fecha = ?').run(userId, itemKey, fecha);
      return { completado: false };
    }
    db.prepare('INSERT INTO completions (user_id, item_key, fecha) VALUES (?, ?, ?)').run(userId, itemKey, fecha);
    return { completado: true };
  }

  const PATRON_AMBITO = { alimentacion: 'alimentacion-%', entrenamiento: 'entrenamiento-%', todo: '%' };

  /* Borra las marcas "Ya lo hice" de un día; devuelve cuántas quitó. */
  function reiniciarCompletions(userId, fecha, ambito) {
    return db.prepare('DELETE FROM completions WHERE user_id = ? AND fecha = ? AND item_key LIKE ?')
      .run(userId, fecha, PATRON_AMBITO[ambito] || PATRON_AMBITO.todo).changes;
  }

  function contarCompletionsTotal(userId) {
    return db.prepare('SELECT COUNT(*) AS total FROM completions WHERE user_id = ?').get(userId).total;
  }

  return {
    addProgress, getProgress, clearProgress, getDailyLog, guardarDailyLog,
    getCompletions, toggleCompletion, reiniciarCompletions, contarCompletionsTotal
  };
}

module.exports = { crear };
