const { ahoraISO } = require('../../lib/fechas');

function crear(db) {
  function obtenerReel(reelId) {
    return db.prepare('SELECT * FROM reels WHERE id = ?').get(reelId);
  }

  function crearReel(userId, autor, texto, imagenUrl) {
    const info = db.prepare(
      'INSERT INTO reels (user_id, autor, texto, imagen_url, created_at) VALUES (?, ?, ?, ?, ?)'
    ).run(userId, autor, texto, imagenUrl || null, ahoraISO());
    return obtenerReel(info.lastInsertRowid);
  }

  function listarReels() {
    return db.prepare('SELECT * FROM reels ORDER BY id DESC LIMIT 50').all();
  }

  function eliminarReel(reelId, userId) {
    const reel = db.prepare('SELECT * FROM reels WHERE id = ? AND user_id = ?').get(reelId, userId);
    if (!reel) return false;
    db.prepare('DELETE FROM reel_votes WHERE reel_id = ?').run(reelId);
    db.prepare('DELETE FROM reels WHERE id = ?').run(reelId);
    return true;
  }

  /* Devuelve null si el reel no existe. */
  function votarReel(reelId, userId, tipo) {
    if (!obtenerReel(reelId)) return null;
    const yaVoto = db.prepare('SELECT 1 FROM reel_votes WHERE reel_id = ? AND user_id = ? AND tipo = ?')
      .get(reelId, userId, tipo);
    if (yaVoto) return obtenerReel(reelId);

    db.prepare('INSERT INTO reel_votes (reel_id, user_id, tipo) VALUES (?, ?, ?)').run(reelId, userId, tipo);
    const columna = tipo === 'up' ? 'upvotes' : tipo === 'down' ? 'downvotes' : 'likes';
    db.prepare(`UPDATE reels SET ${columna} = ${columna} + 1 WHERE id = ?`).run(reelId);
    return obtenerReel(reelId);
  }

  function listarAmigos(userId) {
    return db.prepare('SELECT * FROM friends WHERE user_id = ? ORDER BY nombre ASC').all(userId);
  }

  function agregarAmigo(userId, nombre) {
    const info = db.prepare('INSERT INTO friends (user_id, nombre, created_at) VALUES (?, ?, ?)')
      .run(userId, nombre, ahoraISO());
    return db.prepare('SELECT * FROM friends WHERE id = ?').get(info.lastInsertRowid);
  }

  function getAmigo(userId, friendId) {
    return db.prepare('SELECT * FROM friends WHERE id = ? AND user_id = ?').get(friendId, userId);
  }

  function existeAmigo(friendId) {
    return !!db.prepare('SELECT 1 FROM friends WHERE id = ?').get(friendId);
  }

  function listarMensajesAmigo(friendId) {
    return db.prepare('SELECT * FROM friend_messages WHERE friend_id = ? ORDER BY id ASC').all(friendId);
  }

  function guardarMensajeAmigo(friendId, autor, texto) {
    db.prepare('INSERT INTO friend_messages (friend_id, autor, texto, created_at) VALUES (?, ?, ?, ?)')
      .run(friendId, autor, texto, ahoraISO());
    return listarMensajesAmigo(friendId);
  }

  function vaciarMensajesAmigo(friendId) {
    db.prepare('DELETE FROM friend_messages WHERE friend_id = ?').run(friendId);
  }

  return {
    crearReel, listarReels, votarReel, eliminarReel,
    listarAmigos, agregarAmigo, getAmigo, existeAmigo, listarMensajesAmigo, guardarMensajeAmigo, vaciarMensajesAmigo
  };
}

module.exports = { crear };
