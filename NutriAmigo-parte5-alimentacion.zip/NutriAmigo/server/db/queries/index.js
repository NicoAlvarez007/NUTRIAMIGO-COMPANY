const usuarios = require('./usuarios');
const progreso = require('./progreso');
const plan = require('./plan');
const comunidad = require('./comunidad');
const cuentas = require('./cuentas');
const comidas = require('./comidas');

/* Reúne todas las consultas en un solo objeto con los mismos nombres que tenía db.js. */
function crearConsultas(db) {
  return Object.assign({}, usuarios.crear(db), progreso.crear(db), plan.crear(db), comunidad.crear(db), cuentas.crear(db), comidas.crear(db));
}

module.exports = { crearConsultas };
