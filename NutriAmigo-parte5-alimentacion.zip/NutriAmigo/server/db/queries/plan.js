const PROTEINAS_VALIDAS = ['pollo', 'pescado', 'carne', 'vegetariano', 'vegano'];

/* vegano/vegetariano son excluyentes entre sí y con cualquier otra proteína;
   pollo/pescado/carne se pueden combinar. Devuelve una lista limpia. */
function normalizarProteinas(lista) {
  const limpio = [...new Set((lista || []).filter((p) => PROTEINAS_VALIDAS.includes(p)))];
  if (limpio.includes('vegano')) return ['vegano'];
  if (limpio.includes('vegetariano')) return ['vegetariano'];
  return limpio;
}

const COLUMNAS_PREFERENCIAS = {
  restriccionesTexto: 'restricciones_texto',
  frecuenciaSemanal: 'frecuencia_semanal',
  distanciaKm: 'distancia_km',
  enfoqueMuscular: 'enfoque_muscular',
  dieta: 'dieta',
  economico: 'economico',
  mostrarMedidas: 'mostrar_medidas',
  ayunoProtocolo: 'ayuno_protocolo',
  ayunoInicio: 'ayuno_inicio'
};

function crear(db) {
  function getBiometrics(userId) {
    return db.prepare('SELECT * FROM biometrics WHERE user_id = ?').get(userId) || null;
  }

  function saveBiometrics(userId, datos) {
    const valores = [datos.nombre, datos.apellido, datos.correo || null, datos.peso, datos.estatura,
      datos.sexo, datos.edad, datos.actividad, datos.objetivo];
    const existente = db.prepare('SELECT user_id FROM biometrics WHERE user_id = ?').get(userId);
    if (existente) {
      db.prepare(`UPDATE biometrics SET nombre=?, apellido=?, correo=?, peso=?, estatura=?, sexo=?,
        edad=?, actividad=?, objetivo=? WHERE user_id=?`).run(...valores, userId);
    } else {
      db.prepare(`INSERT INTO biometrics (user_id, nombre, apellido, correo, peso, estatura, sexo, edad, actividad, objetivo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(userId, ...valores);
    }
    return getBiometrics(userId);
  }

  const guardarProteinas = db.transaction((userId, lista) => {
    db.prepare('DELETE FROM preferencias_proteinas WHERE user_id = ?').run(userId);
    const insertar = db.prepare('INSERT INTO preferencias_proteinas (user_id, proteina) VALUES (?, ?)');
    lista.forEach((p) => insertar.run(userId, p));
  });

  /* Guardado parcial: solo se modifican los campos que llegan en `prefs`. */
  function savePreferences(userId, prefs) {
    const guardar = Object.assign({}, prefs);
    if (prefs.alergias !== undefined) guardar.alergiasJson = JSON.stringify(prefs.alergias);
    ['economico', 'mostrarMedidas'].forEach((c) => { if (typeof guardar[c] === 'boolean') guardar[c] = guardar[c] ? 1 : 0; });
    const columnas_ = Object.assign({ alergiasJson: 'alergias' }, COLUMNAS_PREFERENCIAS);
    const enviados = Object.keys(columnas_).filter((campo) => guardar[campo] !== undefined);

    if (enviados.length > 0) {
      const existente = db.prepare('SELECT user_id FROM preferences WHERE user_id = ?').get(userId);
      if (existente) {
        const asignaciones = enviados.map((campo) => `${columnas_[campo]} = ?`).join(', ');
        db.prepare(`UPDATE preferences SET ${asignaciones} WHERE user_id = ?`)
          .run(...enviados.map((campo) => guardar[campo]), userId);
      } else {
        const columnas = enviados.map((campo) => columnas_[campo]).join(', ');
        const marcas = enviados.map(() => '?').join(', ');
        db.prepare(`INSERT INTO preferences (user_id, ${columnas}) VALUES (?, ${marcas})`)
          .run(userId, ...enviados.map((campo) => guardar[campo]));
      }
    }

    if (prefs.proteinas !== undefined) {
      guardarProteinas(userId, normalizarProteinas(prefs.proteinas));
    }
  }

  function getPreferences(userId) {
    const fila = db.prepare('SELECT * FROM preferences WHERE user_id = ?').get(userId);
    const proteinas = db.prepare('SELECT proteina FROM preferencias_proteinas WHERE user_id = ?')
      .all(userId).map((r) => r.proteina);
    if (!fila && proteinas.length === 0) return null;
    return {
      proteinas,
      restriccionesTexto: fila ? fila.restricciones_texto : null,
      frecuenciaSemanal: fila ? fila.frecuencia_semanal : null,
      distanciaKm: fila ? fila.distancia_km : null,
      enfoqueMuscular: fila ? fila.enfoque_muscular : null,
      dieta: fila ? fila.dieta : null,
      alergias: fila && fila.alergias ? JSON.parse(fila.alergias) : [],
      mostrarMedidas: fila && fila.mostrar_medidas !== null ? fila.mostrar_medidas === 1 : true,
      economico: !!(fila && fila.economico),
      ayunoProtocolo: fila ? fila.ayuno_protocolo : null,
      ayunoInicio: fila ? fila.ayuno_inicio : null
    };
  }

  return { getBiometrics, saveBiometrics, savePreferences, getPreferences };
}

module.exports = { crear, normalizarProteinas };
