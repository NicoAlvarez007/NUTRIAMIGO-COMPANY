const fs = require('fs');
const path = require('path');

const CARPETA_MIGRACIONES = path.join(__dirname, 'migrations');

/* Aplica en orden las migraciones NNN_nombre.js que falten; cada una corre
   dentro de su propia transacción y queda registrada en schema_migrations. */
function migrar(db, carpeta = CARPETA_MIGRACIONES) {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    aplicada_en TEXT NOT NULL
  )`);

  const aplicadas = new Set(
    db.prepare('SELECT version FROM schema_migrations').all().map((fila) => fila.version)
  );

  const archivos = fs.readdirSync(carpeta)
    .filter((archivo) => /^\d{3}_.+\.js$/.test(archivo))
    .sort();

  const nuevas = [];
  for (const archivo of archivos) {
    const version = parseInt(archivo.slice(0, 3), 10);
    if (aplicadas.has(version)) continue;

    const migracion = require(path.join(carpeta, archivo));
    const nombre = archivo.slice(4, -3);

    db.exec('BEGIN');
    try {
      migracion.up(db);
      db.prepare('INSERT INTO schema_migrations (version, nombre, aplicada_en) VALUES (?, ?, ?)')
        .run(version, nombre, new Date().toISOString());
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      err.message = `Falló la migración ${archivo}: ${err.message}`;
      throw err;
    }
    nuevas.push(archivo);
  }
  return nuevas;
}

module.exports = { migrar, CARPETA_MIGRACIONES };
