const rateLimit = require('express-rate-limit');
const { MENSAJES } = require('../lib/validadores');

function manejador(req, res) {
  res.status(429).json({ error: MENSAJES.demasiadas_peticiones, code: 'demasiadas_peticiones' });
}

function crearLimites() {
  const base = { standardHeaders: true, legacyHeaders: false, handler: manejador };

  const general = rateLimit(Object.assign({}, base, { windowMs: 15 * 60 * 1000, limit: 300 }));

  // Solo cuentan los intentos fallidos: un inicio de sesión exitoso no gasta el cupo.
  const autenticacion = rateLimit(Object.assign({}, base, {
    windowMs: 15 * 60 * 1000,
    limit: 10,
    skipSuccessfulRequests: true
  }));

  // Se monta después de requireAuth, así que siempre existe req.user.
  const escrituraComunidad = rateLimit(Object.assign({}, base, {
    windowMs: 60 * 1000,
    limit: 30,
    keyGenerator: (req) => `usuario-${req.user.id}`
  }));

  return { general, autenticacion, escrituraComunidad };
}

module.exports = { crearLimites };
