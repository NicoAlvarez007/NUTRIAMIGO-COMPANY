const { MENSAJES } = require('../lib/validadores');

function responder(res, estado, code) {
  res.status(estado).json({ error: MENSAJES[code], code });
}

/* La cuenta suspendida puede entrar, pero no usar la comunidad ni publicar. */
function noSuspendida(req, res, next) {
  if (req.user && req.user.suspended) return responder(res, 403, 'cuenta_suspendida');
  return next();
}

function requireFuncion(q, clave) {
  return (req, res, next) => {
    if (q.funcionActiva(clave)) return next();
    return responder(res, 403, 'funcion_desactivada');
  };
}

function esAdmin(req) {
  return !!(req.user && req.user.role === 'admin');
}

function requireAdmin(req, res, next) {
  if (!req.user) return responder(res, 401, 'no_autenticado');
  if (!esAdmin(req)) return responder(res, 403, 'sin_permiso');
  return next();
}

/* Para páginas: quien no es administrador recibe 404, como si no existieran. */
function requireAdminPagina(req, res, next) {
  if (esAdmin(req)) return next();
  return res.status(404).type('text/plain').send('No encontrado');
}

module.exports = { noSuspendida, requireFuncion, requireAdmin, requireAdminPagina, esAdmin };
