const { MENSAJES, validarId } = require('../lib/validadores');

function enviarError(res, resultado, estado = 400) {
  const cuerpo = { error: resultado.error, code: resultado.code };
  if (resultado.field) cuerpo.field = resultado.field;
  res.status(estado).json(cuerpo);
}

function responderCodigo(res, estado, code, field) {
  enviarError(res, { error: MENSAJES[code] || 'Error', code, field }, estado);
}

/* Valida el cuerpo con `validador(body)` y deja el resultado limpio en req.datos. */
function validarCuerpo(validador) {
  return (req, res, next) => {
    const resultado = validador(req.body);
    if (!resultado.ok) return enviarError(res, resultado, 400);
    req.datos = resultado.valor;
    return next();
  };
}

/* Valida un parámetro de ruta como entero positivo y lo deja en req.ids[nombre]. */
function validarParametroId(nombre = 'id') {
  return (req, res, next) => {
    const resultado = validarId(req.params[nombre], nombre);
    if (!resultado.ok) return enviarError(res, resultado, 400);
    req.ids = Object.assign(req.ids || {}, { [nombre]: resultado.valor });
    return next();
  };
}

module.exports = { enviarError, responderCodigo, validarCuerpo, validarParametroId };
