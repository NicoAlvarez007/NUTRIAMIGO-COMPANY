const helmet = require('helmet');
const { MENSAJES } = require('../lib/validadores');

function crearHelmet(config) {
  return helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"],
        'style-src': ["'self'", "'unsafe-inline'"],
        'font-src': ["'self'", 'data:'],
        'img-src': ["'self'", 'data:', 'blob:', 'https:'],
        'connect-src': ["'self'", 'ws:', 'wss:'],
        'object-src': ["'none'"],
        'base-uri': ["'self'"],
        'frame-ancestors': ["'none'"]
      }
    },
    // Sin HTTPS estas cabeceras solo generan avisos en la consola del navegador.
    strictTransportSecurity: config.COOKIE_SECURE,
    crossOriginOpenerPolicy: false,
    originAgentCluster: false
  });
}

function sinCache(req, res, next) {
  res.set('Cache-Control', 'no-store');
  next();
}

const METODOS_SEGUROS = ['GET', 'HEAD', 'OPTIONS'];

/* Las escrituras a /api y /auth deben venir en JSON o con X-Requested-With. */
function proteccionCsrf(req, res, next) {
  if (METODOS_SEGUROS.includes(req.method)) return next();
  if (!/^\/(api|auth)(\/|$)/.test(req.path)) return next();

  const tipo = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (tipo === 'application/json' || req.headers['x-requested-with'] === 'nutriamigo') return next();

  return res.status(403).json({ error: MENSAJES.peticion_invalida, code: 'peticion_invalida' });
}

/* Rechaza con 404 cualquier intento de salirse de public/ con rutas como /../server. */
function bloquearRutasSospechosas(req, res, next) {
  let ruta;
  try {
    ruta = decodeURIComponent(req.path);
  } catch (e) {
    return res.status(404).end();
  }
  if (ruta.includes('..') || ruta.includes('\0') || ruta.includes('\\')) return res.status(404).end();
  return next();
}

module.exports = { crearHelmet, sinCache, proteccionCsrf, bloquearRutasSospechosas };
