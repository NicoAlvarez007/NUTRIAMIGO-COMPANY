const { MENSAJES } = require('../lib/validadores');

function requireAuth(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  res.status(401).json({ error: MENSAJES.no_autenticado, code: 'no_autenticado' });
}

module.exports = requireAuth;
