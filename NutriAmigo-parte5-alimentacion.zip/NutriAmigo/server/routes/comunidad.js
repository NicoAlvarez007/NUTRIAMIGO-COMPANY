const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { noSuspendida, requireFuncion } = require('../middleware/cuentas');
const { responderCodigo, validarCuerpo, validarParametroId } = require('../middleware/validar');
const { validarReel, validarVotoCuerpo } = require('../lib/validadores');

function crearRutasComunidad({ q, limites }) {
  const router = express.Router();
  router.use('/reels', requireAuth, noSuspendida, requireFuncion(q, 'reels'));

  router.get('/reels', (req, res) => {
    res.json(q.listarReels());
  });

  router.post('/reels', limites.escrituraComunidad, validarCuerpo(validarReel), (req, res) => {
    res.json(q.crearReel(req.user.id, req.user.name, req.datos.texto, req.datos.imagenUrl));
  });

  router.post('/reels/:id/voto', limites.escrituraComunidad, validarParametroId('id'),
    validarCuerpo(validarVotoCuerpo), (req, res) => {
      const reel = q.votarReel(req.ids.id, req.user.id, req.datos.tipo);
      if (!reel) return responderCodigo(res, 404, 'no_encontrado');
      return res.json(reel);
    });

  router.delete('/reels/:id', validarParametroId('id'), (req, res) => {
    if (!q.eliminarReel(req.ids.id, req.user.id)) return responderCodigo(res, 403, 'no_permitido');
    return res.json({ ok: true });
  });

  return router;
}

module.exports = { crearRutasComunidad };
