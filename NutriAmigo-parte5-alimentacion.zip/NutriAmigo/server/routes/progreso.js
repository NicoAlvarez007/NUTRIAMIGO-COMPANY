const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { validarCuerpo, validarParametroId, responderCodigo } = require('../middleware/validar');
const { validarProgreso, validarRegistroDiario, validarCompletion, validarReinicio, validarRegistroComida, MAX_REGISTROS_POR_DIA } = require('../lib/validadores');
const { hoy, diaSemanaDe, sumarDias, ahoraISO } = require('../lib/fechas');

function crearRutasProgreso({ q }) {
  const router = express.Router();
  router.use(requireAuth);

  router.get('/progress', (req, res) => {
    res.json(q.getProgress(req.user.id));
  });

  router.post('/progress', validarCuerpo(validarProgreso), (req, res) => {
    res.json(q.addProgress(req.user.id, req.datos.peso, hoy(req)));
  });

  router.delete('/progress', (req, res) => {
    q.clearProgress(req.user.id);
    res.json({ ok: true });
  });

  router.get('/daily-log', (req, res) => {
    res.json(q.getDailyLog(req.user.id, hoy(req)));
  });

  router.post('/daily-log', validarCuerpo(validarRegistroDiario), (req, res) => {
    const fecha = hoy(req);
    const actual = q.getDailyLog(req.user.id, fecha);
    const vasosAgua = req.datos.vasosAgua !== undefined ? req.datos.vasosAgua : actual.vasos_agua;
    const kmRecorridos = req.datos.kmRecorridos !== undefined ? req.datos.kmRecorridos : actual.km_recorridos;
    res.json(q.guardarDailyLog(req.user.id, fecha, vasosAgua, kmRecorridos));
  });

  router.get('/completions', (req, res) => {
    res.json(q.getCompletions(req.user.id, hoy(req)));
  });

  /* Las comidas solo se marcan el día que corresponde: el día local de la persona. */
  router.post('/completions', validarCuerpo(validarCompletion), (req, res) => {
    const fecha = hoy(req);
    const clave = req.datos.itemKey;
    if (clave.startsWith('alimentacion-') && clave.split('-')[1] !== diaSemanaDe(fecha)) {
      return responderCodigo(res, 400, 'solo_hoy', 'itemKey');
    }
    return res.json(q.toggleCompletion(req.user.id, clave, fecha));
  });

  router.post('/completions/reiniciar', validarCuerpo(validarReinicio), (req, res) => {
    res.json({ ok: true, borrados: q.reiniciarCompletions(req.user.id, hoy(req), req.datos.ambito) });
  });

  /* Registro "Mi día": solo se escribe y se borra el día de hoy; se puede consultar la última semana. */
  router.get('/food-log', (req, res) => {
    res.json(q.listarComidas(req.user.id, hoy(req)));
  });

  router.get('/food-log/historial', (req, res) => {
    const fin = hoy(req);
    res.json(q.historialComidas(req.user.id, sumarDias(fin, -6), fin));
  });

  router.post('/food-log', validarCuerpo(validarRegistroComida), (req, res) => {
    const fecha = hoy(req);
    if (q.contarComidas(req.user.id, fecha) >= MAX_REGISTROS_POR_DIA) return responderCodigo(res, 400, 'limite_registros');
    q.agregarComida(req.user.id, fecha, req.datos, ahoraISO());
    return res.json(q.listarComidas(req.user.id, fecha));
  });

  router.delete('/food-log/:id', validarParametroId('id'), (req, res) => {
    const fecha = hoy(req);
    if (!q.borrarComida(req.user.id, req.ids.id, fecha)) return responderCodigo(res, 404, 'no_encontrado');
    return res.json(q.listarComidas(req.user.id, fecha));
  });

  return router;
}

module.exports = { crearRutasProgreso };
