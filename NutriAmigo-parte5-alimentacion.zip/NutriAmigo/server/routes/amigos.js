const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { noSuspendida, requireFuncion } = require('../middleware/cuentas');
const { responderCodigo, validarCuerpo, validarParametroId } = require('../middleware/validar');
const { validarAmigo } = require('../lib/validadores');

function crearRutasAmigos({ q, limites }) {
  const router = express.Router();
  router.use('/friends', requireAuth, noSuspendida, requireFuncion(q, 'amigos'));

  router.get('/friends', (req, res) => {
    res.json(q.listarAmigos(req.user.id));
  });

  router.post('/friends', limites.escrituraComunidad, validarCuerpo(validarAmigo), (req, res) => {
    res.json(q.agregarAmigo(req.user.id, req.datos.nombre));
  });

  router.get('/friends/:id/messages', validarParametroId('id'), (req, res) => {
    const amigo = q.getAmigo(req.user.id, req.ids.id);
    if (!amigo) return responderCodigo(res, 404, 'amigo_no_encontrado');
    return res.json(q.listarMensajesAmigo(amigo.id));
  });

  router.delete('/friends/:id/messages', validarParametroId('id'), (req, res) => {
    const amigo = q.getAmigo(req.user.id, req.ids.id);
    if (!amigo) return responderCodigo(res, 404, 'amigo_no_encontrado');
    q.vaciarMensajesAmigo(amigo.id);
    return res.json({ ok: true });
  });

  return router;
}

module.exports = { crearRutasAmigos };
