(function () {
  const $ = (id) => document.getElementById(id);

  function h(tag, attrs, ...hijos) {
    const e = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (v === true) e.setAttribute(k, '');
      else if (v !== false && v != null) e.setAttribute(k, v);
    });
    hijos.flat().forEach(c => { if (c != null) e.append(c.nodeType ? c : document.createTextNode(c)); });
    return e;
  }

  const METODOS = { GET: 'get', POST: 'post', DELETE: 'delete' };

  async function api(url, metodo = 'GET', cuerpo) {
    const opciones = { silencioso: true };
    const llamada = METODOS[metodo];
    return llamada === 'post' ? window.api.post(url, cuerpo, opciones) : window.api[llamada](url, opciones);
  }

  function avisar(texto, error) {
    const a = $('aviso');
    a.textContent = texto;
    a.className = 'admin-aviso' + (error ? ' error' : '');
    a.hidden = !texto;
    if (texto) a.scrollIntoView({ block: 'nearest' });
  }

  async function ejecutar(fn) {
    try { await fn(); } catch (err) { avisar(err.message, true); }
  }

  function formatearBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(1) + ' MB';
  }

  function formatearDuracion(seg) {
    const d = Math.floor(seg / 86400), hh = Math.floor(seg % 86400 / 3600), m = Math.floor(seg % 3600 / 60);
    return (d ? d + ' d ' : '') + hh + ' h ' + m + ' min';
  }

  function fechaLegible(iso) {
    if (!iso) return '—';
    const f = new Date(iso);
    return Number.isNaN(f.getTime()) ? iso : f.toLocaleString('es-CO');
  }

  /* ---------- Fecha simulada ---------- */
  async function vistaFecha(cont) {
    const estado = await api('./api/admin/fecha');
    const info = h('p', { class: 'nota' });
    const entrada = h('input', { type: 'date', id: 'fechaSim', 'aria-label': 'Fecha simulada', value: estado.simulada || estado.hoy });

    const pintar = (s) => {
      info.textContent = s.simulada ? 'Fecha simulada activa: ' + s.simulada + '. Solo afecta a tu cuenta de administrador.'
        : 'Sin fecha simulada. Hoy es ' + estado.hoy + '.';
    };
    pintar(estado);

    async function cambiar(cuerpo, msg) {
      await ejecutar(async () => {
        const r = await api('./api/admin/fecha', 'POST', cuerpo);
        pintar(r);
        if (r.simulada) entrada.value = r.simulada;
        avisar(msg + ' Recarga las otras pestañas de la app para ver el efecto.');
      });
    }

    cont.append(h('section', { class: 'admin-card' },
      h('h2', {}, 'Fecha simulada'),
      info,
      h('div', { class: 'admin-fila' },
        entrada,
        h('button', { type: 'button', class: 'btn btn-primary', onclick: () => cambiar({ fecha: entrada.value }, 'Fecha aplicada.') }, 'Aplicar'),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => cambiar({ sumarDias: 1 }, 'Avanzaste 1 día.') }, '+1 día'),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => cambiar({ sumarDias: 7 }, 'Avanzaste 7 días.') }, '+7 días'),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => cambiar({ reset: true }, 'Volviste a la fecha real.') }, 'Volver a hoy')
      )
    ));
  }

  /* ---------- Usuarios ---------- */
  function vistaUsuarios(cont) {
    let pagina = 1;
    let termino = '';
    const lista = h('div', { class: 'usuarios-lista' });
    const pie = h('div', { class: 'admin-fila' });
    const detalle = h('div');
    const buscador = h('input', { type: 'search', 'aria-label': 'Buscar usuarios', placeholder: 'Nombre, correo o usuario', maxlength: '80' });

    async function cargar() {
      await ejecutar(async () => {
        const r = await api('./api/admin/usuarios?pagina=' + pagina + '&q=' + encodeURIComponent(termino));
        lista.replaceChildren(...(r.items.length ? r.items.map(filaUsuario) : [h('p', { class: 'nota' }, 'Sin resultados.')]));
        pie.replaceChildren(
          h('button', { type: 'button', class: 'btn btn-ghost', disabled: r.pagina <= 1, onclick: () => { pagina--; cargar(); } }, 'Anterior'),
          h('span', {}, 'Página ' + r.pagina + ' de ' + r.paginas + ' · ' + r.total + ' cuentas'),
          h('button', { type: 'button', class: 'btn btn-ghost', disabled: r.pagina >= r.paginas, onclick: () => { pagina++; cargar(); } }, 'Siguiente')
        );
      });
    }

    function filaUsuario(u) {
      return h('div', { class: 'usuario-item' },
        h('div', {},
          h('strong', {}, u.nombre, u.rol === 'admin' ? h('span', { class: 'etiqueta' }, 'Admin') : null,
            u.premium ? h('span', { class: 'etiqueta' }, 'Premium') : null,
            u.suspendida ? h('span', { class: 'etiqueta rojo' }, 'Suspendida') : null),
          h('span', { class: 'meta' }, (u.correo || u.usuario || 'sin correo') + ' · alta ' + fechaLegible(u.creada))),
        h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => abrirDetalle(u.id) }, 'Ver detalle'));
    }

    async function abrirDetalle(id) {
      await ejecutar(async () => {
        const u = await api('./api/admin/usuarios/' + id);
        const motivo = h('input', { type: 'text', 'aria-label': 'Motivo de la suspensión', placeholder: 'Motivo de la suspensión', maxlength: '200' });
        const salida = h('div');
        const dato = (t, v) => [h('dt', {}, t), h('dd', {}, v == null || v === '' ? '—' : String(v))];

        const acciones = h('div', { class: 'admin-fila' });
        if (u.rol !== 'admin') {
          if (u.suspendida) {
            acciones.append(h('button', { type: 'button', class: 'btn btn-primary', onclick: () => ejecutar(async () => {
              await api('./api/admin/usuarios/' + id + '/reactivar', 'POST'); avisar('Cuenta reactivada.'); abrirDetalle(id); cargar();
            }) }, 'Reactivar'));
          } else {
            acciones.append(motivo, h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => ejecutar(async () => {
              if (!motivo.value.trim()) throw new Error('Escribe el motivo de la suspensión.');
              await api('./api/admin/usuarios/' + id + '/suspender', 'POST', { motivo: motivo.value }); avisar('Cuenta suspendida.'); abrirDetalle(id); cargar();
            }) }, 'Suspender'));
          }
        }
        acciones.append(h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => ejecutar(async () => {
          if (!confirm('¿Generar una contraseña temporal para ' + u.nombre + '? La actual dejará de funcionar.')) return;
          const r = await api('./api/admin/usuarios/' + id + '/restablecer-contrasena', 'POST');
          salida.replaceChildren(h('p', { class: 'nota' }, 'Contraseña temporal (solo se muestra ahora):'), h('span', { class: 'clave-temporal' }, r.temporal));
          avisar('Contraseña restablecida.');
        }) }, 'Restablecer contraseña'));
        if (u.rol !== 'admin') {
          acciones.append(h('button', { type: 'button', class: 'btn btn-peligro', onclick: () => ejecutar(async () => {
            if (!confirm('¿Eliminar la cuenta de ' + u.nombre + ' y todos sus datos? No se puede deshacer.')) return;
            await api('./api/admin/usuarios/' + id, 'DELETE'); avisar('Cuenta eliminada.'); detalle.replaceChildren(); cargar();
          }) }, 'Eliminar cuenta'));
        }

        detalle.replaceChildren(h('section', { class: 'admin-card' },
          h('h2', {}, 'Detalle de ' + u.nombre),
          h('dl', { class: 'detalle-grid' },
            dato('ID', u.id), dato('Correo', u.correo), dato('Usuario', u.usuario), dato('Rol', u.rol),
            dato('Acceso con', u.proveedor), dato('Tiene contraseña', u.tieneContrasena ? 'Sí' : 'No'),
            dato('Premium', u.premium ? 'Sí' : 'No'), dato('Suspendida', u.suspendida ? 'Sí: ' + (u.motivoSuspension || '') : 'No'),
            dato('Alta', fechaLegible(u.creada)), dato('Zona horaria', u.zonaHoraria),
            dato('Completó su registro', u.tieneDatos ? 'Sí' : 'No'), dato('Autorización de adulto', u.consentimientoAdulto ? 'Registrada' : 'No aplica')),
          acciones, salida));
        detalle.scrollIntoView({ block: 'nearest' });
      });
    }

    buscador.addEventListener('input', () => {
      clearTimeout(buscador._t);
      buscador._t = setTimeout(() => { termino = buscador.value.trim(); pagina = 1; cargar(); }, 300);
    });

    cont.append(h('section', { class: 'admin-card' }, h('h2', {}, 'Usuarios'), h('div', { class: 'admin-fila' }, buscador), lista, pie), detalle);
    cargar();
  }

  /* ---------- Interruptores de funciones ---------- */
  async function vistaFunciones(cont) {
    const etiquetas = { chat: 'Chat de la comunidad', reels: 'Reels', amigos: 'Amigos', anuncios: 'Anuncios (versión gratuita)' };
    const estado = await api('./api/admin/funciones');
    const card = h('section', { class: 'admin-card' }, h('h2', {}, 'Interruptores de funciones'),
      h('p', { class: 'nota' }, 'Si apagas una función, las páginas muestran “Función no disponible por ahora”.'));

    Object.keys(etiquetas).forEach(clave => {
      const boton = h('button', { type: 'button', class: 'btn btn-ghost', role: 'switch' });
      const pintar = () => { boton.textContent = estado[clave] ? 'Activa' : 'Apagada'; boton.setAttribute('aria-checked', String(!!estado[clave])); boton.setAttribute('aria-pressed', String(!!estado[clave])); };
      boton.addEventListener('click', () => ejecutar(async () => {
        const r = await api('./api/admin/funciones/' + clave, 'POST', { activo: !estado[clave] });
        Object.assign(estado, r); pintar(); avisar(etiquetas[clave] + (estado[clave] ? ' activada.' : ' apagada.'));
      }));
      pintar();
      card.append(h('div', { class: 'interruptor-fila' }, h('span', {}, etiquetas[clave]), boton));
    });
    cont.append(card);
  }

  /* ---------- Estado del servidor ---------- */
  async function vistaServidor(cont) {
    const e = await api('./api/admin/estado');
    const dato = (v, t) => h('div', { class: 'estado-dato' }, h('b', {}, String(v)), h('span', {}, t));
    const lista = (items, vacio, fn) => h('div', { class: 'log-lista' }, items.length ? items.map(fn) : [h('div', {}, vacio)]);

    cont.append(
      h('section', { class: 'admin-card' }, h('h2', {}, 'Estado del servidor'),
        h('div', { class: 'estado-grid' },
          dato(e.version, 'Versión'), dato(e.node, 'Node'), dato(formatearDuracion(e.uptimeSegundos), 'Tiempo activo'),
          dato(e.usuarios, 'Usuarios'), dato(e.premium, 'Premium'), dato(e.suspendidos, 'Suspendidos'),
          dato(formatearBytes(e.bytesBase), 'Base de datos'), dato(formatearBytes(e.bytesUploads), 'Carpeta uploads'))),
      h('section', { class: 'admin-card' }, h('h2', {}, 'Últimos errores (máx. 20)'),
        lista(e.errores, 'Sin errores registrados.', x => h('div', {}, fechaLegible(x.creado_en) + ' — ' + x.detalle))),
      h('section', { class: 'admin-card' }, h('h2', {}, 'Últimas acciones'),
        lista(e.acciones, 'Sin acciones registradas.', x => h('div', {}, fechaLegible(x.creado_en) + ' — ' + x.accion + (x.detalle ? ' (' + x.detalle + ')' : '')))));
  }

  /* ---------- Idioma/tema y funciones de partes posteriores ---------- */
  function vistaPruebas(cont) {
    const idioma = h('div', { class: 'admin-fila' }, ['es', 'en', 'de'].map(l =>
      h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => { window.NutriIdioma.set(l); avisar('Idioma cambiado a ' + l.toUpperCase() + '.'); } }, l.toUpperCase())));
    const tema = h('div', { class: 'admin-fila' }, [['claro', 'Tema claro'], ['dark', 'Tema oscuro'], ['auto', 'Automático']].map(([v, t]) =>
      h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => {
        window.NutriTema.set(v);
        avisar(t + ' aplicado.');
      } }, t)));

    const boton = (texto, accion, clase) => h('button', { type: 'button', class: clase || 'btn btn-ghost', onclick: () => ejecutar(accion) }, texto);
    const herramientas = h('section', { class: 'admin-card' },
      h('h2', {}, 'Herramientas de prueba (Parte 7)'),
      h('p', { class: 'nota' }, 'Actúan sobre tu propia cuenta de administrador. La fecha simulada también cuenta.'),
      h('div', { class: 'admin-fila' },
        boton('Reiniciar el día', async () => {
          if (!confirm('¿Borrar las marcas, el agua, los km y el sueño de hoy?')) return;
          const r = await api('./api/admin/reiniciar-dia', 'POST', {});
          avisar('Día ' + r.fecha + ' reiniciado: ' + r.marcas + ' marcas, ' + r.diario + ' registro diario, ' + r.sueno + ' sueño.');
        }),
        boton('Cargar datos de ejemplo', async () => {
          if (!confirm('Esto reemplaza tu historial de peso, agua, km, sueño y fotos por datos de ejemplo. ¿Seguir?')) return;
          await api('./api/admin/datos-ejemplo', 'POST', {});
          avisar('Datos de ejemplo cargados: 90 días de peso, 30 de agua y km, 14 de sueño y 3 fotos.');
        }),
        boton('Borrar datos de ejemplo', async () => {
          if (!confirm('Esto borra TODO tu historial de peso, agua, km, sueño y fotos de administrador. ¿Seguir?')) return;
          await api('./api/admin/datos-ejemplo', 'DELETE');
          avisar('Datos de ejemplo borrados.');
        }, 'btn btn-peligro')),
      h('div', { class: 'admin-fila' },
        boton('Probar aviso en pantalla', async () => {
          if (window.mostrarAviso) window.mostrarAviso('Así se ve un aviso dentro de la página.', 'info', 6000);
          if (window.mostrarAvisoConAcciones) window.mostrarAvisoConAcciones('Así se ve un aviso con botones.', [{ texto: 'Aceptar', principal: true, alHacerClic: async () => {} }, { texto: 'Cancelar', alHacerClic: async () => {} }]);
        }),
        boton('Probar notificación del navegador', async () => {
          if (!('Notification' in window)) { avisar('Este navegador no soporta notificaciones.', true); return; }
          if (Notification.permission === 'default') await Notification.requestPermission();
          if (Notification.permission === 'granted') new Notification('NutriAmigo', { body: 'Notificación de prueba.', icon: './assets/logo.png' });
          else avisar('El permiso de notificaciones está bloqueado: los recordatorios se mostrarán dentro de la página.');
        })));

    const pendientes = [
      ['Modo sin conexión', 'Simula que no hay internet para probar el comportamiento.', 'Parte 11'],
      ['Premium', 'Activar/desactivar Premium, simular pago aprobado o rechazado.', 'Parte 10'],
      ['Racha', 'Ver racha y protectores; dar, quitar o fijar la racha.', 'Parte 4'],
      ['Rango y logros', 'Subir/bajar rango; desbloquear o borrar logros.', 'Parte 8'],
      ['Moderación', 'Reels y reportes; borrar contenido y suspender autores.', 'Parte 9'],
      ['Preguntas sin respuesta del bot', 'Lista con conteo.', 'Parte 11'],
      ['Versión Química', 'Abrir /quimica/.', 'Parte 12']
    ];

    cont.append(
      herramientas,
      h('section', { class: 'admin-card' }, h('h2', {}, 'Idioma y tema'), h('p', { class: 'nota' }, 'Para revisar traducciones rápido.'), idioma, tema),
      h('section', { class: 'admin-card' }, h('h2', {}, 'Herramientas de otras partes'),
        h('div', { class: 'prox-grid' }, pendientes.map(([nombre, desc, parte]) =>
          h('div', { class: 'prox-item' }, h('strong', {}, nombre), h('small', {}, desc),
            h('button', { type: 'button', class: 'btn btn-ghost', disabled: true, 'aria-disabled': 'true' }, 'Disponible en la ' + parte))))));
  }

  /* ---------- Probar el generador de rutinas ---------- */
  function vistaRutinas(cont) {
    const campo = (etiqueta, control) => h('label', { class: 'campo-admin' }, h('span', {}, etiqueta), control);
    const sel = (id, opciones, valor) => h('select', { id }, opciones.map(([v, t]) => h('option', { value: v, selected: v === valor }, t)));
    const num = (id, valor, min, max, paso) => h('input', { type: 'number', id, value: String(valor), min: String(min), max: String(max), step: String(paso || 1) });

    const objetivo = sel('rObjetivo', [['definir', 'Definir'], ['mantener', 'Mantener'], ['volumen', 'Volumen']], 'mantener');
    const frecuencia = sel('rFrecuencia', [1, 2, 3, 4, 5, 6, 7].map(n => [String(n), n + ' días']), '3');
    const nivel = sel('rNivel', [['principiante', 'Principiante'], ['intermedio', 'Intermedio'], ['avanzado', 'Avanzado']], 'principiante');
    const lugar = sel('rLugar', [['casa', 'Casa'], ['gimnasio', 'Gimnasio']], 'casa');
    const enfoque = sel('rEnfoque', [['', 'Cuerpo completo'], ['piernas', 'Piernas'], ['brazos', 'Brazos'], ['espalda', 'Espalda']], '');
    const distancia = num('rDistancia', 0, 0, 100, 0.5);
    const edad = num('rEdad', 30, 15, 90);
    const semana = num('rSemana', 1, 1, 52);
    const semilla = num('rSemilla', 1, 1, 9999);
    const salida = h('div');

    function generar() {
      const perfil = {
        objetivo: objetivo.value, frecuencia: Number(frecuencia.value), nivel: nivel.value, lugar: lugar.value,
        enfoque: enfoque.value || null, distanciaKm: Number(distancia.value) || null, edad: Number(edad.value),
        semanaNumero: Number(semana.value), semilla: Number(semilla.value)
      };
      const sem = window.GeneradorRutinas.generarSemana(perfil);
      const plan = window.GeneradorRutinas.planDistancia(perfil, 8);
      const nombre = (id) => (window.GeneradorRutinas.ejercicioPorId(id).nombre.es);
      const linea = (it) => nombre(it.id) + ' — ' + (it.unidad === 'min' ? it.minutos + ' min' + (it.km ? ' (' + it.km + ' km)' : '')
        : it.series + ' × ' + (it.unidad === 'seg' ? it.segundos + ' s' : it.repeticiones + ' rep') + (it.descansoSeg ? ', descanso ' + it.descansoSeg + ' s' : ''));

      salida.replaceChildren(
        h('section', { class: 'admin-card' },
          h('h2', {}, 'Semana ' + sem.semanaNumero + (sem.descarga ? ' (descarga)' : '')),
          h('p', { class: 'nota' }, sem.resumen.diasEntrenamiento + ' días de entrenamiento · meta ' + sem.resumen.kmSemana + ' km · avisos: ' + (sem.avisos.join(', ') || 'ninguno')),
          sem.dias.map(d => h('details', { class: 'ejercicio' },
            h('summary', {}, h('span', { class: 'ejercicio-nombre' }, d.dia + ' — ' + d.tipoSesion + (d.entrena ? '' : ' (descanso activo)')), h('span', { class: 'ejercicio-cantidad' }, d.duracionMin + ' min')),
            h('ul', {}, [].concat(
              d.calentamiento.map(it => h('li', {}, 'Calentamiento: ' + nombre(it.id))),
              d.principal.map(it => h('li', {}, linea(it))),
              d.cardio ? [h('li', {}, 'Cardio: ' + linea(d.cardio))] : [],
              d.enfriamiento.map(it => h('li', {}, 'Enfriamiento: ' + nombre(it.id)))))))),
        plan.length ? h('section', { class: 'admin-card' }, h('h2', {}, 'Plan de distancia (8 semanas)'),
          h('p', {}, plan.map(s => 'S' + s.semana + ': ' + s.km + ' km' + (s.descarga ? ' (descarga)' : '')).join(' · '))) : null);
    }

    const boton = h('button', { type: 'button', class: 'btn btn-primary', onclick: generar }, 'Generar');
    cont.append(h('section', { class: 'admin-card' }, h('h2', {}, 'Probar generador de rutinas'),
      h('p', { class: 'nota' }, 'Misma entrada, misma semana: cambia la semilla para ver otra selección.'),
      h('div', { class: 'admin-fila' },
        campo('Objetivo', objetivo), campo('Frecuencia', frecuencia), campo('Nivel', nivel), campo('Lugar', lugar), campo('Enfoque', enfoque)),
      h('div', { class: 'admin-fila' },
        campo('Distancia (km)', distancia), campo('Edad', edad), campo('Semana del plan', semana), campo('Semilla', semilla), boton)), salida);
    generar();
  }

  const VISTAS = [
    ['fecha', 'Fecha simulada', vistaFecha],
    ['usuarios', 'Usuarios', vistaUsuarios],
    ['funciones', 'Funciones', vistaFunciones],
    ['servidor', 'Servidor', vistaServidor],
    ['rutinas', 'Rutinas', vistaRutinas],
    ['pruebas', 'Idioma y más', vistaPruebas]
  ];

  async function mostrar(clave) {
    avisar('');
    document.querySelectorAll('.admin-tab').forEach(b => b.setAttribute('aria-selected', String(b.dataset.vista === clave)));
    const cont = $('contenido');
    cont.replaceChildren();
    const vista = VISTAS.find(v => v[0] === clave);
    try { await vista[2](cont); } catch (err) { avisar(err.message, true); }
    try { sessionStorage.setItem('admin_vista', clave); } catch (e) { /* sin almacenamiento */ }
  }

  document.addEventListener('DOMContentLoaded', () => {
    VISTAS.forEach(([clave, nombre]) => {
      $('tabs').append(h('button', { type: 'button', class: 'admin-tab', role: 'tab', 'data-vista': clave, 'aria-selected': 'false', onclick: () => mostrar(clave) }, nombre));
    });
    $('salirBtn').addEventListener('click', async () => {
      try { await window.api.post('./auth/logout', undefined, { silencioso: true }); } catch (e) { console.error('No se pudo cerrar sesión', e); }
      location.href = './index.html';
    });
    let inicial = 'fecha';
    try { inicial = sessionStorage.getItem('admin_vista') || 'fecha'; } catch (e) { /* sin almacenamiento */ }
    mostrar(VISTAS.some(v => v[0] === inicial) ? inicial : 'fecha');
  });
})();
