/* Avisos dentro de la página (globos). Sustituyen a alert() y a las
   notificaciones del navegador cuando están bloqueadas. */
(function () {
  function contenedor() {
    let el = document.getElementById('avisos');
    if (!el) {
      el = document.createElement('div');
      el.id = 'avisos';
      el.className = 'avisos';
      el.setAttribute('role', 'status');
      el.setAttribute('aria-live', 'polite');
      document.body.appendChild(el);
    }
    return el;
  }

  function mostrarAviso(texto, tipo, duracionMs) {
    if (!texto) return;
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => mostrarAviso(texto, tipo, duracionMs));
      return;
    }
    const clase = ['error', 'exito', 'info'].includes(tipo) ? tipo : 'info';

    const aviso = document.createElement('div');
    aviso.className = `aviso aviso-${clase}`;
    if (clase === 'error') aviso.setAttribute('role', 'alert');

    const mensaje = document.createElement('span');
    mensaje.className = 'aviso-texto';
    mensaje.textContent = texto;

    const cerrar = document.createElement('button');
    cerrar.type = 'button';
    cerrar.className = 'aviso-cerrar';
    cerrar.textContent = '×';
    const etiqueta = window.NutriIdioma ? window.NutriIdioma.t('aviso.cerrar', 'Cerrar aviso') : 'Cerrar aviso';
    cerrar.setAttribute('aria-label', etiqueta);

    const quitar = () => aviso.remove();
    cerrar.addEventListener('click', quitar);
    aviso.append(mensaje, cerrar);
    contenedor().appendChild(aviso);
    setTimeout(quitar, duracionMs || 5000);
  }

  /* Aviso fijo arriba de la pantalla con botones (por ejemplo Aceptar / Cancelar). No se cierra solo. */
  function mostrarAvisoConAcciones(texto, botones) {
    if (!texto || !document.body) return null;
    const barra = document.createElement('div');
    barra.className = 'aviso-superior';
    barra.setAttribute('role', 'alertdialog');
    barra.setAttribute('aria-live', 'assertive');
    const mensaje = document.createElement('p');
    mensaje.className = 'aviso-superior-texto';
    mensaje.textContent = texto;
    const acciones = document.createElement('div');
    acciones.className = 'aviso-superior-acciones';
    const quitar = () => barra.remove();
    (botones || []).forEach((b) => {
      const boton = document.createElement('button');
      boton.type = 'button';
      boton.className = b.principal ? 'btn btn-primary' : 'btn btn-ghost';
      boton.textContent = b.texto;
      boton.addEventListener('click', async () => {
        boton.disabled = true;
        try { await b.alHacerClic(); } finally { quitar(); }
      });
      acciones.appendChild(boton);
    });
    barra.append(mensaje, acciones);
    document.body.insertBefore(barra, document.body.firstChild);
    const primero = acciones.querySelector('button');
    if (primero) primero.focus();
    return quitar;
  }

  window.mostrarAviso = mostrarAviso;
  window.mostrarAvisoConAcciones = mostrarAvisoConAcciones;
})();
