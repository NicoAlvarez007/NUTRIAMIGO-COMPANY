/* Generador de rutinas: puro y determinístico (la misma entrada da siempre la misma semana).
   Funciona en el navegador (window.GeneradorRutinas) y en Node (module.exports) para las pruebas. */
(function (raiz) {
  const biblioteca = typeof module !== 'undefined' && module.exports
    ? require('../data/ejercicios.js')
    : { EJERCICIOS: raiz.EJERCICIOS, EQUIPO_CASA: raiz.EQUIPO_CASA };
  const EJERCICIOS = biblioteca.EJERCICIOS;
  const EQUIPO_CASA = biblioteca.EQUIPO_CASA;

  const DIAS = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'];
  const NIVELES = ['principiante', 'intermedio', 'avanzado'];
  const POR_ID = Object.fromEntries(EJERCICIOS.map((e) => [e.id, e]));

  const MAX_EJERCICIOS_FUERZA = 8;
  const MAX_MINUTOS_MENOR = 60;
  const MIN_REPS_MENOR = 8;
  const MINUTOS_CALENTAMIENTO = 5;
  const MINUTOS_ENFRIAMIENTO = 4;
  const SEGUNDOS_POR_REPETICION = 3;
  const SEGUNDOS_CAMBIO = 20;

  /* Días de la semana (0 = lunes) según la frecuencia, y la estructura de cada día. */
  const DIAS_POR_FRECUENCIA = {
    1: [2],
    2: [0, 3],
    3: [0, 2, 4],
    4: [0, 1, 3, 4],
    5: [0, 1, 2, 4, 5],
    6: [0, 1, 2, 3, 4, 5],
    7: [0, 1, 2, 3, 4, 5, 6]
  };

  const ESTRUCTURA = {
    1: ['completo_a'],
    2: ['completo_a', 'completo_b'],
    3: ['completo_a', 'completo_b', 'completo_c'],
    4: ['superior', 'inferior', 'superior', 'inferior'],
    5: ['empuje', 'piernas', 'tiron', 'completo_ligero', 'cardio_core'],
    6: ['empuje', 'tiron', 'piernas', 'empuje', 'tiron', 'piernas'],
    7: ['empuje', 'tiron', 'piernas', 'empuje', 'tiron', 'piernas', 'movilidad']
  };

  /* Cada ranura lista patrones alternativos, del preferido al menos preferido. */
  const RANURAS = {
    completo_a: [['sentadilla'], ['empuje_horizontal'], ['tiron_horizontal'], ['bisagra'], ['estabilidad']],
    completo_b: [['unilateral'], ['empuje_vertical', 'empuje_horizontal'], ['tiron_vertical', 'tiron_horizontal'], ['extension_cadera', 'bisagra'], ['flexion_tronco', 'antiextension']],
    completo_c: [['sentadilla'], ['empuje_horizontal'], ['tiron_horizontal', 'extension'], ['unilateral'], ['antiextension', 'estabilidad']],
    completo_ligero: [['sentadilla'], ['empuje_horizontal'], ['tiron_horizontal'], ['estabilidad']],
    superior: [['empuje_horizontal'], ['tiron_horizontal'], ['empuje_vertical'], ['tiron_vertical', 'extension'], ['flexion_codo'], ['extension_codo']],
    inferior: [['sentadilla'], ['bisagra'], ['unilateral'], ['extension_cadera', 'abduccion'], ['pantorrilla'], ['estabilidad', 'antiextension']],
    empuje: [['empuje_horizontal'], ['empuje_vertical'], ['empuje_horizontal'], ['extension_codo'], ['abduccion']],
    tiron: [['tiron_horizontal'], ['tiron_vertical', 'tiron_horizontal'], ['extension'], ['flexion_codo'], ['tiron_horizontal']],
    piernas: [['sentadilla'], ['bisagra'], ['unilateral'], ['extension_cadera', 'abduccion'], ['pantorrilla']],
    cardio_core: [['estabilidad'], ['antiextension', 'flexion_tronco'], ['rotacion', 'flexion_cadera']]
  };

  const NOMBRE_SESION = {
    completo_a: 'completoA', completo_b: 'completoB', completo_c: 'completoC', completo_ligero: 'completoLigero',
    superior: 'superior', inferior: 'inferior', empuje: 'empuje', tiron: 'tiron', piernas: 'piernas',
    cardio_core: 'cardioCore', movilidad: 'movilidad'
  };

  const GRUPOS_ENFOQUE = {
    piernas: ['piernas', 'gluteos'],
    brazos: ['brazos', 'hombros'],
    espalda: ['espalda']
  };

  /* Series, repeticiones y descanso por objetivo (tabla 2.2). */
  const OBJETIVOS = {
    definir: { seriesMin: 3, seriesMax: 4, seriesBase: 3, seriesCompuesto: 4, repsMin: 12, repsMax: 15, descansoAisl: 45, descansoComp: 60, cardioMin: 10, cardioMax: 20 },
    mantener: { seriesMin: 3, seriesMax: 3, seriesBase: 3, seriesCompuesto: 3, repsMin: 8, repsMax: 12, descansoAisl: 60, descansoComp: 90, cardioMin: 10, cardioMax: 10 },
    volumen: { seriesMin: 3, seriesMax: 5, seriesBase: 3, seriesCompuesto: 4, repsMin: 6, repsMax: 10, descansoAisl: 90, descansoComp: 120, cardioMin: 5, cardioMax: 5 }
  };

  function mulberry32(semilla) {
    let a = semilla >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function acotar(n, min, max) {
    return Math.min(max, Math.max(min, n));
  }

  function normalizarPerfil(p) {
    const perfil = p || {};
    const objetivo = OBJETIVOS[perfil.objetivo] ? perfil.objetivo : 'mantener';
    const edad = Number.isFinite(Number(perfil.edad)) ? Number(perfil.edad) : 30;
    const distancia = Number(perfil.distanciaKm);
    return {
      objetivo,
      frecuencia: acotar(Math.round(Number(perfil.frecuencia)) || 3, 1, 7),
      distanciaKm: Number.isFinite(distancia) && distancia > 0 ? Math.min(100, distancia) : null,
      enfoque: GRUPOS_ENFOQUE[perfil.enfoque] ? perfil.enfoque : null,
      nivel: NIVELES.includes(perfil.nivel) ? perfil.nivel : 'principiante',
      lugar: perfil.lugar === 'gimnasio' ? 'gimnasio' : 'casa',
      edad,
      menor: edad >= 15 && edad < 18,
      semanaNumero: Math.max(1, Math.floor(Number(perfil.semanaNumero)) || 1),
      semilla: Number.isFinite(Number(perfil.semilla)) ? Number(perfil.semilla) : 1
    };
  }

  /* ---------- Progresión semanal ---------- */
  function infoSemana(n) {
    const descarga = n % 4 === 0;
    const normales = (n - 1) - Math.floor((n - 1) / 4);
    return { n, descarga, progresion: descarga ? Math.max(0, normales - 1) : normales };
  }

  function repeticionesObjetivo(cfg, progresion, menor) {
    const reps = Math.min(cfg.repsMax, cfg.repsMin + progresion);
    return menor ? Math.max(MIN_REPS_MENOR, reps) : reps;
  }

  /* ---------- Plan de distancia ---------- */
  const BASE_KM = { principiante: 2, intermedio: 3.5, avanzado: 5 };
  const VELOCIDAD_KMH = { principiante: 5, intermedio: 8, avanzado: 9.5 };

  function redondearKm(km) {
    return Math.round(km * 10) / 10;
  }

  /* Meta de km de la semana n: +10 % sobre la última semana normal, con descarga cada 4.ª semana
     (70 % de la semana anterior) y sin pasar nunca de la meta final. */
  function kmDeSemana(n, nivel, distanciaFinal) {
    if (!distanciaFinal) return 0;
    const tope = distanciaFinal;
    let ultimaNormal = Math.min(BASE_KM[nivel] || BASE_KM.principiante, tope);
    let valor = ultimaNormal;
    for (let semana = 1; semana <= n; semana += 1) {
      if (semana === 1) {
        valor = ultimaNormal;
      } else if (semana % 4 === 0) {
        valor = Math.min(tope, ultimaNormal * 0.7);
      } else {
        ultimaNormal = Math.min(tope, ultimaNormal * 1.1);
        valor = ultimaNormal;
      }
    }
    return redondearKm(valor);
  }

  function planDistancia(perfilEntrada, semanas = 8) {
    const perfil = normalizarPerfil(perfilEntrada);
    if (!perfil.distanciaKm) return [];
    return Array.from({ length: semanas }, (_, i) => ({
      semana: i + 1,
      km: kmDeSemana(i + 1, perfil.nivel, perfil.distanciaKm),
      descarga: (i + 1) % 4 === 0
    }));
  }

  /* ---------- Selección de ejercicios ---------- */
  function permitido(ej, perfil) {
    if (!ej.lugar.includes(perfil.lugar)) return false;
    if (perfil.lugar === 'casa' && ej.equipo.some((e) => !EQUIPO_CASA.includes(e))) return false;
    if (perfil.menor && ej.flags.includes('esfuerzoMaximo')) return false;
    return true;
  }

  function nivelPermitido(ej, perfil) {
    if (perfil.nivel === 'principiante') return ej.nivel === 'principiante';
    if (perfil.nivel === 'intermedio') return ej.nivel !== 'avanzado';
    return true;
  }

  function candidatosFuerza(perfil) {
    return EJERCICIOS.filter((e) => (e.tipo === 'fuerza' || e.tipo === 'core') && permitido(e, perfil));
  }

  function ordenarPorAfinidad(lista, perfil, azar) {
    const objetivo = NIVELES.indexOf(perfil.nivel);
    return lista
      .map((e) => ({ e, distancia: Math.abs(NIVELES.indexOf(e.nivel) - objetivo), r: azar() }))
      .sort((a, b) => a.distancia - b.distancia || a.r - b.r)
      .map((x) => x.e);
  }

  function elegirParaRanura(patrones, candidatos, usados, perfil, azar) {
    for (const patron of patrones) {
      const delPatron = candidatos.filter((e) => e.patron === patron && !usados.has(e.id));
      const aptos = delPatron.filter((e) => nivelPermitido(e, perfil));
      const lista = aptos.length ? aptos : delPatron;
      if (lista.length) return ordenarPorAfinidad(lista, perfil, azar)[0];
    }
    return null;
  }

  function elegirExtraEnfoque(perfil, candidatos, usados, azar) {
    const grupo = GRUPOS_ENFOQUE[perfil.enfoque];
    if (!grupo) return null;
    const lista = candidatos.filter((e) => grupo.includes(e.musculo) && e.tipo === 'fuerza' && !usados.has(e.id));
    const aptos = lista.filter((e) => nivelPermitido(e, perfil));
    const fuente = aptos.length ? aptos : lista;
    return fuente.length ? ordenarPorAfinidad(fuente, perfil, azar)[0] : null;
  }

  /* ---------- Armado de una sesión ---------- */
  function itemFuerza(ej, perfil, cfg, semana, esEnfoque) {
    const compuesto = ej.flags.includes('compuesto');
    let series = compuesto ? cfg.seriesCompuesto : cfg.seriesBase;
    if (perfil.nivel === 'principiante') series -= 1;
    if (perfil.nivel === 'avanzado') series += 1;
    if (esEnfoque) series += 1;
    const tope = cfg.seriesMax + (perfil.nivel === 'avanzado' ? 1 : 0);
    series = acotar(series, 2, tope);
    if (semana.descarga) series = Math.max(2, Math.round(series * 0.7));

    const item = {
      id: ej.id,
      tipo: ej.tipo,
      series,
      descansoSeg: compuesto ? cfg.descansoComp : cfg.descansoAisl
    };
    if (ej.unidad === 'seg') {
      item.unidad = 'seg';
      item.segundos = acotar(20 + 5 * semana.progresion, 20, 60);
      item.descansoSeg = Math.min(item.descansoSeg, 45);
    } else {
      item.unidad = 'rep';
      item.repeticiones = repeticionesObjetivo(cfg, semana.progresion, perfil.menor);
      const extra = semana.progresion - (cfg.repsMax - cfg.repsMin);
      item.cargaSugeridaPct = extra > 0 ? 5 * Math.ceil(extra / 3) : 0;
    }
    if (esEnfoque) item.enfoque = true;
    return item;
  }

  function itemMovilidad(id, segundos) {
    const ej = POR_ID[id];
    return ej.unidad === 'rep'
      ? { id, tipo: 'movilidad', series: 1, unidad: 'rep', repeticiones: 8, descansoSeg: 0 }
      : { id, tipo: 'movilidad', series: 1, unidad: 'seg', segundos, descansoSeg: 0 };
  }

  function usable(id, perfil) {
    const ej = POR_ID[id];
    return ej && permitido(ej, perfil);
  }

  function armarCalentamiento(tipoSesion, perfil) {
    const superior = ['superior', 'empuje', 'tiron'].includes(tipoSesion);
    const inferior = ['inferior', 'piernas'].includes(tipoSesion);
    let ids;
    if (superior) ids = ['marcha_sitio', 'circulos_brazos', 'gato_vaca', 'rotacion_toracica'];
    else if (inferior) ids = ['marcha_sitio', 'circulos_cadera', 'balanceo_piernas', 'sentadilla_pausa'];
    else ids = ['marcha_sitio', 'circulos_brazos', 'circulos_cadera', 'inchworm'];
    return ids.filter((id) => usable(id, perfil)).map((id) => itemMovilidad(id, 45));
  }

  function armarEnfriamiento(tipoSesion, perfil) {
    const superior = ['superior', 'empuje', 'tiron'].includes(tipoSesion);
    const inferior = ['inferior', 'piernas'].includes(tipoSesion);
    let ids;
    if (superior) ids = ['estiramiento_pecho', 'estiramiento_hombro', 'estiramiento_triceps', 'postura_nino'];
    else if (inferior) ids = ['estiramiento_cuadriceps', 'estiramiento_isquios', 'estiramiento_gluteo', 'estiramiento_pantorrilla'];
    else ids = ['estiramiento_cuadriceps', 'estiramiento_pecho', 'estiramiento_gluteo', 'postura_nino'];
    return ids.filter((id) => usable(id, perfil)).map((id) => itemMovilidad(id, 40));
  }

  function itemCardio(perfil, cfg, semana, minutosForzados, kmSesion) {
    let id;
    if (kmSesion) id = perfil.nivel === 'principiante' ? 'intervalos_trote_caminata' : 'trote_suave';
    else if (perfil.objetivo === 'definir') id = perfil.lugar === 'gimnasio' ? 'bici_estatica' : 'intervalos_trote_caminata';
    else id = perfil.lugar === 'gimnasio' ? 'caminadora_inclinada' : 'caminata';

    let minutos = minutosForzados;
    if (!minutos) {
      const pasos = cfg.cardioMax - cfg.cardioMin;
      minutos = cfg.cardioMin + Math.min(pasos, semana.progresion * 2);
      if (semana.descarga) minutos = Math.max(5, Math.round(minutos * 0.7));
    }
    const item = { id, tipo: 'cardio', series: 1, unidad: 'min', minutos, descansoSeg: 0 };
    if (id === 'intervalos_trote_caminata') item.pauta = { trote: 1, caminata: 2 };
    if (kmSesion) item.km = kmSesion;
    return item;
  }

  function duracionSesion(sesion) {
    let segundos = (MINUTOS_CALENTAMIENTO + MINUTOS_ENFRIAMIENTO) * 60;
    sesion.principal.forEach((it) => {
      const porSerie = it.unidad === 'seg' ? it.segundos : it.repeticiones * SEGUNDOS_POR_REPETICION;
      segundos += it.series * (porSerie + it.descansoSeg) + SEGUNDOS_CAMBIO;
    });
    if (sesion.cardio) segundos += sesion.cardio.minutos * 60;
    return Math.round(segundos / 60);
  }

  function ajustarDuracionMenor(sesion) {
    while (duracionSesion(sesion) > MAX_MINUTOS_MENOR) {
      if (sesion.cardio && !sesion.cardio.km) { sesion.cardio = null; continue; }
      if (sesion.principal.length > 3) { sesion.principal.pop(); continue; }
      const mayor = sesion.principal.reduce((m, it) => (it.series > m.series ? it : m), sesion.principal[0]);
      if (mayor.series > 2) { mayor.series -= 1; continue; }
      if (sesion.cardio && sesion.cardio.km && sesion.cardio.minutos > 10) {
        const antes = sesion.cardio.minutos;
        sesion.cardio.minutos = Math.max(10, antes - 5);
        sesion.cardio.km = redondearKm(sesion.cardio.km * (sesion.cardio.minutos / antes));
        continue;
      }
      break;
    }
  }

  function armarSesionFuerza(tipo, indiceDia, perfil, cfg, semana, kmSesion) {
    const azar = mulberry32(perfil.semilla * 1009 + indiceDia * 131 + tipo.length);
    const candidatos = candidatosFuerza(perfil);
    const usados = new Set();
    const principal = [];
    const grupo = GRUPOS_ENFOQUE[perfil.enfoque] || [];

    RANURAS[tipo].forEach((patrones) => {
      const ej = elegirParaRanura(patrones, candidatos, usados, perfil, azar);
      if (!ej) return;
      usados.add(ej.id);
      principal.push(itemFuerza(ej, perfil, cfg, semana, grupo.includes(ej.musculo)));
    });

    if (perfil.enfoque && principal.length < MAX_EJERCICIOS_FUERZA) {
      const extra = elegirExtraEnfoque(perfil, candidatos, usados, azar);
      if (extra) {
        usados.add(extra.id);
        principal.push(itemFuerza(extra, perfil, cfg, semana, true));
      }
    }

    const ligero = tipo === 'completo_ligero';
    if (ligero) principal.forEach((it) => { it.series = Math.max(2, it.series - 1); });

    let cardio = null;
    if (tipo === 'cardio_core') cardio = itemCardio(perfil, cfg, semana, kmSesion ? null : Math.max(15, cfg.cardioMin + 5), kmSesion);
    else if (kmSesion) cardio = itemCardio(perfil, cfg, semana, null, kmSesion);
    else if (perfil.objetivo === 'definir' || (perfil.objetivo === 'mantener' && !ligero)) cardio = itemCardio(perfil, cfg, semana);
    else if (perfil.objetivo === 'volumen' && perfil.nivel !== 'principiante') cardio = itemCardio(perfil, cfg, semana);

    if (kmSesion && cardio) {
      const kmh = VELOCIDAD_KMH[perfil.nivel];
      cardio.minutos = Math.max(5, Math.round((kmSesion / kmh) * 60));
    }

    const sesion = {
      tipoSesion: tipo,
      nombreClave: NOMBRE_SESION[tipo],
      calentamiento: armarCalentamiento(tipo, perfil),
      principal,
      cardio,
      enfriamiento: armarEnfriamiento(tipo, perfil)
    };
    if (perfil.menor) ajustarDuracionMenor(sesion);
    sesion.duracionMin = duracionSesion(sesion);
    return sesion;
  }

  function armarDiaActivo(indiceDia, perfil, semana, esMovilidad) {
    const minutos = acotar(20 + 2 * semana.progresion, 20, 30);
    const caminata = { id: 'caminata', tipo: 'cardio', series: 1, unidad: 'min', minutos: esMovilidad ? 20 : minutos, descansoSeg: 0, cuentaParaKm: true };
    const estiramientos = ['gato_vaca', 'postura_nino', 'estiramiento_isquios', 'estiramiento_cuello']
      .filter((id) => usable(id, perfil)).map((id) => itemMovilidad(id, 40));
    const sesion = {
      tipoSesion: esMovilidad ? 'movilidad' : 'descanso_activo',
      nombreClave: esMovilidad ? 'movilidad' : 'descansoActivo',
      calentamiento: [],
      principal: [],
      cardio: caminata,
      enfriamiento: estiramientos
    };
    sesion.duracionMin = Math.round(caminata.minutos + (estiramientos.length * 40) / 60);
    return sesion;
  }

  /* ---------- Semana completa ---------- */
  function generarSemana(perfilEntrada) {
    const perfil = normalizarPerfil(perfilEntrada);
    const cfg = OBJETIVOS[perfil.objetivo];
    const semana = infoSemana(perfil.semanaNumero);
    const diasEntreno = DIAS_POR_FRECUENCIA[perfil.frecuencia];
    const estructura = ESTRUCTURA[perfil.frecuencia];

    const metaKm = kmDeSemana(perfil.semanaNumero, perfil.nivel, perfil.distanciaKm);
    const indicesFuerza = diasEntreno.filter((_, i) => estructura[i] !== 'movilidad');
    const sesionesCarrera = perfil.distanciaKm
      ? (() => {
          const c = acotar(Math.round(perfil.frecuencia / 2), 1, 3);
          const m = indicesFuerza.length;
          if (c === 1) return [indicesFuerza[Math.floor((m - 1) / 2)]];
          return Array.from({ length: c }, (_, k) => indicesFuerza[Math.round((k * (m - 1)) / (c - 1))]);
        })()
      : [];
    const kmPorSesion = sesionesCarrera.length ? redondearKm(metaKm / sesionesCarrera.length) : 0;

    const dias = DIAS.map((dia, indice) => {
      const posicion = diasEntreno.indexOf(indice);
      if (posicion === -1) {
        return { dia, indice, entrena: false, ...armarDiaActivo(indice, perfil, semana, false) };
      }
      const tipo = estructura[posicion];
      if (tipo === 'movilidad') {
        return { dia, indice, entrena: true, ...armarDiaActivo(indice, perfil, semana, true) };
      }
      const km = sesionesCarrera.includes(indice) ? kmPorSesion : 0;
      return { dia, indice, entrena: true, ...armarSesionFuerza(tipo, indice, perfil, cfg, semana, km) };
    });

    const avisos = [];
    if (perfil.menor) avisos.push('supervisionMenor');
    if (semana.descarga) avisos.push('semanaDescarga');

    return {
      perfil,
      semanaNumero: perfil.semanaNumero,
      descarga: semana.descarga,
      dias,
      resumen: {
        frecuencia: perfil.frecuencia,
        diasFuerza: dias.filter((d) => d.entrena && d.principal.length > 0).length,
        diasEntrenamiento: dias.filter((d) => d.entrena).length,
        diasDescansoActivo: dias.filter((d) => !d.entrena).length,
        kmSemana: metaKm,
        sesionesCarrera: sesionesCarrera.length
      },
      avisos
    };
  }

  /* Calorías estimadas: kcal ≈ MET × peso (kg) × horas. */
  function metDe(item) {
    if (item.tipo === 'movilidad') return 3.5;
    if (item.tipo === 'core') return 4;
    if (item.tipo === 'cardio') {
      if (item.id === 'caminata' || item.id === 'caminadora_inclinada') return 3.5;
      if (item.id === 'bici_estatica') return 5.5;
      return 6;
    }
    return 5;
  }

  function segundosDePaso(it) {
    if (it.unidad === 'min') return it.minutos * 60;
    const porSerie = it.unidad === 'seg' ? it.segundos : it.repeticiones * SEGUNDOS_POR_REPETICION;
    return it.series * (porSerie + it.descansoSeg);
  }

  /* Secuencia lineal de pasos para "Entrenar ahora": calentamiento, bloque principal, cardio y enfriamiento. */
  function pasosDeSesion(sesion) {
    const pasos = [];
    sesion.calentamiento.forEach((it) => pasos.push({ ...it, fase: 'calentamiento' }));
    sesion.principal.forEach((it) => pasos.push({ ...it, fase: 'principal' }));
    if (sesion.cardio) pasos.push({ ...sesion.cardio, fase: 'cardio' });
    sesion.enfriamiento.forEach((it) => pasos.push({ ...it, fase: 'enfriamiento' }));
    return pasos;
  }

  /* kcal ≈ MET promedio de la sesión × peso (kg) × horas reales. Es una estimación. */
  function kcalEstimadas(pesoKg, sesion, segundosReales) {
    const pasos = pasosDeSesion(sesion);
    const total = pasos.reduce((suma, it) => suma + segundosDePaso(it), 0);
    if (!pesoKg || !total || !segundosReales) return 0;
    const metPromedio = pasos.reduce((suma, it) => suma + metDe(it) * segundosDePaso(it), 0) / total;
    return Math.round(metPromedio * pesoKg * (segundosReales / 3600));
  }

  const API = {
    DIAS, NIVELES, OBJETIVOS, DIAS_POR_FRECUENCIA, ESTRUCTURA, MAX_EJERCICIOS_FUERZA, MAX_MINUTOS_MENOR, MIN_REPS_MENOR,
    normalizarPerfil, generarSemana, planDistancia, kmDeSemana, infoSemana, duracionSesion,
    pasosDeSesion, segundosDePaso, metDe, kcalEstimadas, ejercicioPorId: (id) => POR_ID[id]
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.GeneradorRutinas = API;
})(typeof window !== 'undefined' ? window : globalThis);
