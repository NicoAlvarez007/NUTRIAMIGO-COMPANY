(function () {
  var tema = 'claro';
  var letra = 'normal';
  try {
    var guardado = localStorage.getItem('nutriamigo_theme');
    if (guardado === 'dark' || guardado === 'claro') tema = guardado;
    else if (guardado === 'auto') tema = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'claro';
    var tamano = localStorage.getItem('nutriamigo_letra');
    if (tamano === 'grande' || tamano === 'muy_grande') letra = tamano;
  } catch (e) { /* almacenamiento no disponible: se usan los valores por defecto */ }
  document.documentElement.setAttribute('data-theme', tema);
  document.documentElement.setAttribute('data-letra', letra);
})();
