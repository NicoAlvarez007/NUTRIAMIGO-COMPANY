/* Dashboard: progreso (peso / IMC), hoy (agua y km), historial, sueño y ánimo, fotos y resumen en PDF. */
const tr = (clave, es, vars) => {
  let texto = window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es;
  Object.keys(vars || {}).forEach((k) => { texto = texto.split(`{${k}}`).join(String(vars[k])); });
  return texto;
};

const IDIOMAS_INTL = { es: 'es-CO', en: 'en', de: 'de' };
const BANDAS_IMC = [
  { desde: 10, hasta: 18.5, color: '--banda-bajo', clave: 'dash.imcBajo', es: 'Bajo peso (menos de 18,5)' },
  { desde: 18.5, hasta: 25, color: '--banda-ok', clave: 'dash.imcSaludable', es: 'Saludable (18,5 a 24,9)' },
  { desde: 25, hasta: 30, color: '--banda-sobre', clave: 'dash.imcSobrepeso', es: 'Sobrepeso (25 a 29,9)' },
  { desde: 30, hasta: 60, color: '--banda-obeso', clave: 'dash.imcObesidad', es: 'Obesidad (30 o más)' }
];
const CARITAS = [
  { valor: 1, emoji: '😞', clave: 'dash.animo1', es: 'Muy mal' },
  { valor: 2, emoji: '🙁', clave: 'dash.animo2', es: 'Mal' },
  { valor: 3, emoji: '😐', clave: 'dash.animo3', es: 'Normal' },
  { valor: 4, emoji: '🙂', clave: 'dash.animo4', es: 'Bien' },
  { valor: 5, emoji: '😄', clave: 'dash.animo5', es: 'Muy bien' }
];

let usuario = null;
let biometria = null;
let entradas = [];
let modo = 'peso';
let vista = 'semana';
let plan = null;
let prefs = null;
let infoSemana = null;
let vasosAgua = 0;
let animoElegido = null;
let guardarDiarioTimeout = null;
let metaAguaAvisada = false;
let fotos = [];
let ultimoResultado = null;

function locale() {
  return IDIOMAS_INTL[window.idiomaActivo ? window.idiomaActivo() : 'es'] || 'es-CO';
}

function numero(n, decimales = 1) {
  return new Intl.NumberFormat(locale(), { maximumFractionDigits: decimales }).format(n);
}

function fechaLarga(fecha) {
  const [y, m, d] = fecha.split('-').map(Number);
  return new Intl.DateTimeFormat(locale(), { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(y, m - 1, d));
}

function sumarDiasCliente(fecha, dias) {
  const d = new Date(`${fecha}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + dias);
  return d.toISOString().slice(0, 10);
}

function diasEntre(a, b) {
  return Math.round((new Date(`${b}T00:00:00Z`) - new Date(`${a}T00:00:00Z`)) / 86400000);
}

function hoyServidor() {
  return (usuario && usuario.today) || new Date().toISOString().slice(0, 10);
}

/* ---------- Progreso: peso e IMC ---------- */
function filtrarPorVista(lista, v) {
  const ordenadas = [...lista].sort((a, b) => a.fecha.localeCompare(b.fecha));
  const hoy = hoyServidor();
  if (v === 'semana' || v === 'mes') {
    const limite = sumarDiasCliente(hoy, v === 'semana' ? -7 : -30);
    return ordenadas.filter((e) => e.fecha >= limite && e.fecha <= hoy).map((e) => ({ fecha: e.fecha, peso: e.peso }));
  }
  const limite = sumarDiasCliente(hoy, -365);
  const porMes = {};
  ordenadas.filter((e) => e.fecha >= limite && e.fecha <= hoy).forEach((e) => {
    (porMes[e.fecha.slice(0, 7)] = porMes[e.fecha.slice(0, 7)] || []).push(e.peso);
  });
  return Object.keys(porMes).sort().map((mes) => ({
    fecha: `${mes}-01`,
    peso: Math.round((porMes[mes].reduce((s, x) => s + x, 0) / porMes[mes].length) * 10) / 10
  }));
}

function pintarLeyenda(esImc, hayMeta, hayTendencia) {
  const ul = document.getElementById('graficaLeyenda');
  const items = [[tr(esImc ? 'dash.leyendaImc' : 'dash.leyendaPeso', esImc ? 'Tu IMC' : 'Tu peso'), 'leyenda-linea']];
  if (hayTendencia) items.push([tr('dash.leyendaTendencia', 'Tendencia (promedio de 7 registros)'), 'leyenda-tendencia']);
  if (hayMeta) items.push([tr(esImc ? 'dash.leyendaMetaImc' : 'dash.leyendaMeta', esImc ? 'IMC de tu plan' : 'Peso de tu plan'), 'leyenda-meta']);
  ul.replaceChildren(...items.map(([texto, clase]) => {
    const li = document.createElement('li');
    const marca = document.createElement('span');
    marca.className = `leyenda-marca ${clase}`;
    marca.setAttribute('aria-hidden', 'true');
    li.append(marca, document.createTextNode(texto));
    return li;
  }));

  const imc = document.getElementById('imcLeyenda');
  imc.hidden = !esImc;
  if (esImc) {
    imc.replaceChildren(...BANDAS_IMC.map((b) => {
      const li = document.createElement('li');
      const marca = document.createElement('span');
      marca.className = 'leyenda-banda';
      marca.style.background = `var(${b.color})`;
      marca.setAttribute('aria-hidden', 'true');
      li.append(marca, document.createTextNode(tr(b.clave, b.es)));
      return li;
    }));
  }
}

function dibujarProgreso() {
  const canvas = document.getElementById('progressChart');
  const vacio = document.getElementById('progressEmpty');
  const esImc = modo === 'imc';
  const estatura = biometria && biometria.estatura;

  const puntos = filtrarPorVista(entradas, vista).map((e) => {
    const imc = estatura ? calcularIMC({ peso: e.peso, estatura }) : null;
    return { fecha: e.fecha, valor: esImc ? (imc === null ? null : Math.round(imc * 10) / 10) : e.peso };
  }).filter((p) => p.valor !== null);

  if (!puntos.length) {
    window.NutriGraficas.limpiar(canvas);
    canvas.parentElement.hidden = true;
    vacio.hidden = false;
    vacio.textContent = tr('dash.sinRegistros', 'Aún no tienes registros. Ingresa tu peso de hoy para empezar. Por ejemplo: 68,5.');
    document.getElementById('graficaLeyenda').replaceChildren();
    document.getElementById('imcLeyenda').hidden = true;
    return;
  }
  canvas.parentElement.hidden = false;
  vacio.hidden = true;

  let meta = null;
  if (biometria && biometria.peso) {
    if (!esImc) meta = biometria.peso;
    else if (estatura) meta = Math.round(calcularIMC({ peso: biometria.peso, estatura }) * 10) / 10;
  }
  const tendencia = puntos.length >= 3;
  window.NutriGraficas.linea(canvas, {
    puntos,
    meta,
    tendencia,
    bandas: esImc ? BANDAS_IMC : null,
    unidad: esImc ? '' : 'kg',
    formatoValor: (v) => numero(v, 1),
    locale: locale(),
    estiloFecha: vista === 'año' ? 'mes' : 'dia',
    ariaLabel: `${tr(esImc ? 'dash.graficaImc' : 'dash.graficaPeso', esImc ? 'Gráfica de tu IMC en el tiempo' : 'Gráfica de tu peso en el tiempo')}. ${tr('dash.ultimoValor', 'Último valor')}: ${numero(puntos[puntos.length - 1].valor, 1)}`
  });
  pintarLeyenda(esImc, meta !== null, tendencia);
}

async function cargarProgreso() {
  try {
    const datos = await api.get('./api/progress');
    entradas = Array.isArray(datos) ? datos : datos.progreso || [];
    dibujarProgreso();
  } catch (err) {
    console.error('No se pudo cargar tu progreso', err);
  }
}

function marcarSeleccion(selector, atributo, valor) {
  document.querySelectorAll(selector).forEach((b) => {
    const activo = b.dataset[atributo] === valor;
    b.classList.toggle('active', activo);
    b.setAttribute('aria-selected', String(activo));
  });
}

async function registrarPeso(ev) {
  ev.preventDefault();
  const input = document.getElementById('progressPeso');
  const peso = parseFloat(input.value.replace(',', '.'));
  if (!peso) return;
  let r;
  try {
    r = await api.post('./api/progress', { peso });
  } catch (err) {
    console.error('No se pudo guardar el registro de peso', err);
    return;
  }
  input.value = '';
  entradas = r.progreso;
  dibujarProgreso();
  renderLogros();

  if (r.requiereCambioPlan) {
    const { de, a } = r.requiereCambioPlan;
    window.mostrarAvisoConAcciones(tr('dash.cambioPlanPregunta', 'Vas a cambiar tu plan de {de} kg a {a} kg', { de: numero(de), a: numero(a) }), [
      {
        texto: tr('dash.aceptar', 'Aceptar'),
        principal: true,
        alHacerClic: async () => {
          try {
            await api.post('./api/plan/aceptar-cambio', { peso: a });
            await recargarPlan();
            window.mostrarAviso(tr('dash.planActualizado', 'Actualizamos tu plan: tu peso pasó de {de} kg a {a} kg.', { de: numero(de), a: numero(a) }), 'exito');
          } catch (err) {
            console.error('No se pudo aceptar el cambio de plan', err);
          }
        }
      },
      { texto: tr('dash.cancelar', 'Cancelar'), alHacerClic: async () => {} }
    ]);
  } else if (r.planActualizado) {
    await recargarPlan();
    window.mostrarAviso(tr('dash.planActualizado', 'Actualizamos tu plan: tu peso pasó de {de} kg a {a} kg.', { de: numero(r.de), a: numero(r.a) }), 'exito');
  }
}

async function borrarHistorial() {
  if (!window.confirm(tr('dash.confirmBorrarHistorial', '¿Borrar todo tu historial de peso? Tu plan y tus fotos no se borran.'))) return;
  try {
    await api.delete('./api/progress');
  } catch (err) {
    console.error('No se pudo borrar el historial', err);
    return;
  }
  cargarProgreso();
}

function exportarProgresoCSV() {
  if (!entradas.length) {
    window.mostrarAviso(tr('dash.sinRegistrosExportar', 'Aún no tienes registros de peso para exportar.'), 'info');
    return;
  }
  const filas = [`${tr('dash.csvFecha', 'Fecha')},${tr('dash.csvPeso', 'Peso (kg)')}`];
  [...entradas].sort((a, b) => a.fecha.localeCompare(b.fecha)).forEach((e) => filas.push(`${e.fecha},${e.peso}`));
  const blob = new Blob([`\uFEFF${filas.join('\n')}`], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'historial-peso-nutriamigo.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* ---------- Resultados (IMC, calorías y macros) ---------- */
async function recargarPlan() {
  try {
    biometria = await api.get('./api/biometrics');
    plan = await api.get('./api/plan', { silencioso: true });
  } catch (err) {
    console.error('No se pudo cargar tu plan', err);
  }
  pintarResultados();
  pintarHoy();
  dibujarProgreso();
}

function pintarResultados() {
  const grid = document.getElementById('resultsGrid');
  const sinDatos = document.getElementById('noBioCard');
  if (!biometria) { grid.style.display = 'none'; sinDatos.style.display = 'block'; return; }

  const imc = calcularIMC(biometria);
  const kcal = calcularMetaCalorica(biometria);
  const macros = calcularMacros(kcal, biometria.objetivo);
  if (imc && kcal && macros) {
    ultimoResultado = { imc, kcal, macros, datos: biometria };
    grid.style.display = 'grid';
    sinDatos.style.display = 'none';
    document.getElementById('imcValue').textContent = imc.toFixed(1);
    document.getElementById('imcTag').textContent = categoriaIMC(imc);
    const sugerencia = sugerirObjetivo(imc);
    document.getElementById('aiSuggestionValue').textContent = sugerencia ? sugerencia.titulo : '—';
    const extra = plan ? plan.kcalExtraHoy : 0;
    document.getElementById('kcalValue').textContent = `${(kcal + extra).toLocaleString(locale())} kcal`;
    document.getElementById('macroProteina').textContent = `${macros.proteina.gramos} g (${macros.proteina.pct}%)`;
    document.getElementById('macroCarbs').textContent = `${macros.carbohidratos.gramos} g (${macros.carbohidratos.pct}%)`;
    document.getElementById('macroGrasas').textContent = `${macros.grasas.gramos} g (${macros.grasas.pct}%)`;
  }
  if (biometria.nombre) {
    document.querySelectorAll('[data-user-name]').forEach((el) => {
      el.textContent = `${biometria.nombre} ${biometria.apellido || ''}`.trim();
    });
  }
}

/* ---------- Hoy: agua, km y calorías cambiadas por entrenamiento ---------- */
function metaKmTexto() {
  try {
    if (prefs && prefs.distanciaKm && usuario.isPremium && infoSemana) {
      const semana = window.GeneradorRutinas.generarSemana(
        perfilDeEntrenamiento(biometria, prefs, true, infoSemana.semanaNumero, usuario.id)
      );
      const meta = semana.resumen.kmSemana;
      if (meta > 0) return tr('dash.kmMetaSemana', 'Meta de la semana: {meta} km. Llevas {km} km.', { meta: numero(meta), km: numero(infoSemana.km) });
    }
  } catch (err) {
    console.error('No se pudo calcular la meta de km', err);
  }
  return tr('dash.kmMetaSugerida', 'Meta sugerida para hoy: {meta} km.', { meta: numero(plan ? plan.kmMetaSugerida : 3) });
}

function pintarHoy() {
  if (!plan) return;
  const meta = plan.aguaMetaVasos;
  const pct = Math.min(100, Math.round((vasosAgua / meta) * 100));
  document.getElementById('waterCount').textContent = String(vasosAgua);
  const barra = document.getElementById('waterBar');
  barra.setAttribute('aria-valuenow', String(pct));
  barra.firstElementChild.style.width = `${pct}%`;
  document.getElementById('waterNote').textContent = vasosAgua >= meta
    ? tr('dash.aguaCumplida', '¡Cumpliste tu meta de agua de hoy!')
    : tr('dash.aguaMeta', 'Meta de hoy: {meta} vasos de 250 ml ({n} de {meta}).', { meta, n: vasosAgua });

  document.getElementById('kmNote').textContent = metaKmTexto();
  const extra = plan.kcalExtraHoy;
  document.getElementById('kcalExtraNote').textContent = tr('dash.kcalExtra', 'Calorías cambiadas por entrenamiento: +{n} kcal', { n: extra });
  const base = plan.kcalBase;
  document.getElementById('kcalMetaNote').textContent = base
    ? tr('dash.kcalMetaHoy', 'Meta de hoy: {base} + {n} = {total} kcal', { base: numero(base, 0), n: extra, total: numero(base + extra, 0) })
    : '';
}

async function cargarDiario() {
  try {
    const log = await api.get('./api/daily-log');
    vasosAgua = log.vasos_agua || 0;
    document.getElementById('kmInput').value = log.km_recorridos || '';
    metaAguaAvisada = plan ? vasosAgua >= plan.aguaMetaVasos : false;
    pintarHoy();
  } catch (err) {
    console.error('No se pudo cargar tu registro diario', err);
  }
}

async function guardarDiario(avisar) {
  const km = parseFloat(String(document.getElementById('kmInput').value).replace(',', '.')) || 0;
  try {
    await api.post('./api/daily-log', { vasosAgua, kmRecorridos: km });
    plan = await api.get('./api/plan', { silencioso: true });
    infoSemana = await api.get('./api/entrenamiento/semana', { silencioso: true }).catch(() => infoSemana);
    pintarHoy();
    pintarResultados();
    cargarHistorial();
    if (avisar) window.mostrarAviso(tr('dash.registroGuardado', 'Registro de hoy guardado.'), 'exito');
  } catch (err) {
    console.error('No se pudo guardar tu registro diario', err);
  }
}

function programarGuardadoDiario() {
  if (guardarDiarioTimeout) clearTimeout(guardarDiarioTimeout);
  guardarDiarioTimeout = setTimeout(() => guardarDiario(false), 500);
}

function cambiarVasos(delta) {
  vasosAgua = Math.max(0, Math.min(40, vasosAgua + delta));
  pintarHoy();
  if (plan && vasosAgua >= plan.aguaMetaVasos && !metaAguaAvisada) {
    metaAguaAvisada = true;
    window.mostrarAviso(tr('dash.aguaCumplida', '¡Cumpliste tu meta de agua de hoy!'), 'exito');
  }
  if (plan && vasosAgua < plan.aguaMetaVasos) metaAguaAvisada = false;
  programarGuardadoDiario();
}

/* ---------- Historial de agua y km ---------- */
function etiquetaDia(fecha, opciones) {
  const [y, m, d] = fecha.split('-').map(Number);
  return new Intl.DateTimeFormat(locale(), opciones).format(new Date(y, m - 1, d));
}

async function cargarHistorial() {
  try {
    const dias = await api.get('./api/historial-diario?dias=7', { silencioso: true });
    const etiquetas = dias.map((d) => etiquetaDia(d.fecha, { weekday: 'short' }));
    window.NutriGraficas.barras(document.getElementById('waterChart'), {
      etiquetas, valores: dias.map((d) => d.vasos), meta: plan ? plan.aguaMetaVasos : null, unidad: tr('dash.vasos', 'vasos'),
      formatoValor: (v) => numero(v, 0), ariaLabel: tr('dash.graficaAgua', 'Vasos de agua de los últimos 7 días')
    });
    window.NutriGraficas.barras(document.getElementById('kmChart'), {
      etiquetas, valores: dias.map((d) => d.km), color: 'alt', unidad: 'km',
      formatoValor: (v) => numero(v, 1), ariaLabel: tr('dash.graficaKm', 'Kilómetros de los últimos 7 días')
    });
    const mes = await api.get('./api/resumen-mensual', { silencioso: true });
    document.getElementById('resumenMensual').textContent = mes.diasConRegistro
      ? tr('dash.resumenMes', 'Últimos 30 días: promedio de {v} vasos y {k} km por día registrado. Mejor día de agua: {mv}. Mejor día de km: {mk}.', {
        v: numero(mes.promedioVasos), k: numero(mes.promedioKm),
        mv: mes.mejorVasos ? `${fechaLarga(mes.mejorVasos.fecha)} (${mes.mejorVasos.valor})` : '—',
        mk: mes.mejorKm ? `${fechaLarga(mes.mejorKm.fecha)} (${numero(mes.mejorKm.valor)} km)` : '—'
      })
      : tr('dash.resumenMesVacio', 'Cuando registres agua y kilómetros verás aquí tu resumen del mes.');
  } catch (err) {
    console.error('No se pudo cargar el historial diario', err);
  }
}

/* ---------- Sueño y ánimo ---------- */
function construirCaritas() {
  const grupo = document.getElementById('moodGroup');
  grupo.replaceChildren(...CARITAS.map((c) => {
    const etiqueta = document.createElement('label');
    etiqueta.className = 'animo-opcion';
    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'animo';
    radio.value = String(c.valor);
    radio.checked = animoElegido === c.valor;
    radio.addEventListener('change', () => { animoElegido = c.valor; });
    const emoji = document.createElement('span');
    emoji.className = 'animo-emoji';
    emoji.setAttribute('aria-hidden', 'true');
    emoji.textContent = c.emoji;
    const texto = document.createElement('span');
    texto.className = 'animo-texto';
    texto.textContent = tr(c.clave, c.es);
    etiqueta.append(radio, emoji, texto);
    return etiqueta;
  }));
}

function mensajeSueno(promedio) {
  if (promedio < 6) return tr('dash.suenoPoco', 'Esta semana dormiste poco en promedio ({h} h). Dormir más suele ayudar a sentirte mejor.', { h: numero(promedio) });
  if (promedio > 9.5) return tr('dash.suenoMucho', 'Esta semana dormiste bastante en promedio ({h} h). Si te sientes cansado seguido, habla con un profesional de salud.', { h: numero(promedio) });
  return tr('dash.suenoBien', 'Esta semana dormiste {h} h en promedio, un rango habitual para muchas personas adultas.', { h: numero(promedio) });
}

async function cargarBienestar() {
  try {
    const datos = await api.get('./api/wellbeing?dias=14', { silencioso: true });
    if (datos.hoy) {
      document.getElementById('sleepInput').value = datos.hoy.horas;
      animoElegido = datos.hoy.animo;
    }
    construirCaritas();
    const registros = datos.registros;
    const canvas = document.getElementById('sleepChart');
    canvas.parentElement.hidden = !registros.length;
    if (registros.length) {
      window.NutriGraficas.barras(canvas, {
        etiquetas: registros.map((r) => etiquetaDia(r.fecha, { day: 'numeric', month: 'short' })),
        valores: registros.map((r) => r.horas), unidad: 'h', color: 'alt', formatoValor: (v) => numero(v, 1),
        ariaLabel: tr('dash.graficaSueno', 'Horas de sueño de los últimos 14 días')
      });
    } else {
      window.NutriGraficas.limpiar(canvas);
    }
    const ultimos7 = registros.filter((r) => diasEntre(r.fecha, hoyServidor()) <= 6);
    document.getElementById('sleepSummary').textContent = ultimos7.length
      ? mensajeSueno(ultimos7.reduce((s, r) => s + r.horas, 0) / ultimos7.length)
      : tr('dash.suenoVacio', 'Guarda tu sueño y tu ánimo para ver un resumen sencillo aquí.');
  } catch (err) {
    console.error('No se pudo cargar tu sueño y ánimo', err);
  }
}

async function guardarBienestar(ev) {
  ev.preventDefault();
  const msg = document.getElementById('wellbeingMsg');
  const horas = parseFloat(String(document.getElementById('sleepInput').value).replace(',', '.'));
  if (!Number.isFinite(horas) || !animoElegido) {
    msg.textContent = tr('dash.completaAnimo', 'Escribe tus horas de sueño y elige cómo te sientes.');
    return;
  }
  try {
    await api.post('./api/wellbeing', { horas, animo: animoElegido }, { silencioso: true });
    msg.textContent = tr('dash.guardado', 'Guardado ✓');
    cargarBienestar();
  } catch (err) {
    msg.textContent = err.message;
  }
}

/* ---------- Fotos de progreso ---------- */
async function reducirFoto(archivo) {
  const imagen = await createImageBitmap(archivo, { imageOrientation: 'from-image' });
  const escala = Math.min(1, 1080 / Math.max(imagen.width, imagen.height));
  const lienzo = document.createElement('canvas');
  lienzo.width = Math.max(1, Math.round(imagen.width * escala));
  lienzo.height = Math.max(1, Math.round(imagen.height * escala));
  lienzo.getContext('2d').drawImage(imagen, 0, 0, lienzo.width, lienzo.height);
  if (imagen.close) imagen.close();
  return lienzo.toDataURL('image/jpeg', 0.82);
}

function fotoMsg(texto) {
  document.getElementById('fotosMsg').textContent = texto || '';
}

async function cargarFotos() {
  try {
    const datos = await api.get('./api/photos', { silencioso: true });
    fotos = datos.fotos;
    document.getElementById('fotosConsentimiento').hidden = datos.consentimiento;
    document.getElementById('fotosContenido').hidden = !datos.consentimiento;
    document.getElementById('fotosContador').textContent = tr('dash.fotosContador', '{n} de {max} fotos', { n: fotos.length, max: datos.limite });
    pintarGaleria();
    pintarComparacion(true);
  } catch (err) {
    console.error('No se pudieron cargar tus fotos', err);
  }
}

function pintarGaleria() {
  const galeria = document.getElementById('fotosGaleria');
  if (!fotos.length) {
    const p = document.createElement('p');
    p.className = 'hoy-nota';
    p.textContent = tr('dash.fotosVacio', 'Aún no tienes fotos. Sube la primera para ver tu cambio con el tiempo.');
    galeria.replaceChildren(p);
    return;
  }
  galeria.replaceChildren(...fotos.map((f) => {
    const caja = document.createElement('figure');
    caja.className = 'foto-item';
    const img = document.createElement('img');
    img.src = `./api/photos/${f.id}/file`;
    img.alt = tr('dash.fotoAlt', 'Foto de progreso del {fecha}', { fecha: fechaLarga(f.fecha) });
    img.loading = 'lazy';
    const pie = document.createElement('figcaption');
    pie.textContent = fechaLarga(f.fecha);
    const borrar = document.createElement('button');
    borrar.type = 'button';
    borrar.className = 'btn btn-ghost foto-borrar';
    borrar.textContent = tr('dash.borrarFoto', 'Borrar');
    borrar.setAttribute('aria-label', `${tr('dash.borrarFoto', 'Borrar')} ${fechaLarga(f.fecha)}`);
    borrar.addEventListener('click', () => borrarFoto(f));
    caja.append(img, pie, borrar);
    return caja;
  }));
}

function pintarComparacion(reiniciar) {
  const caja = document.getElementById('fotosComparar');
  caja.hidden = fotos.length < 2;
  if (fotos.length < 2) return;
  const selA = document.getElementById('fotoSelA');
  const selB = document.getElementById('fotoSelB');
  const previoA = selA.value;
  const previoB = selB.value;
  const opciones = () => fotos.map((f) => {
    const o = document.createElement('option');
    o.value = String(f.id);
    o.textContent = fechaLarga(f.fecha);
    return o;
  });
  selA.replaceChildren(...opciones());
  selB.replaceChildren(...opciones());
  const existe = (v) => fotos.some((f) => String(f.id) === v);
  selA.value = !reiniciar && existe(previoA) ? previoA : String(fotos[0].id);
  selB.value = !reiniciar && existe(previoB) ? previoB : String(fotos[fotos.length - 1].id);
  actualizarComparacion();
}

function actualizarComparacion() {
  const a = fotos.find((f) => String(f.id) === document.getElementById('fotoSelA').value);
  const b = fotos.find((f) => String(f.id) === document.getElementById('fotoSelB').value);
  const par = document.getElementById('compararPar');
  const resumen = document.getElementById('compararResumen');
  if (!a || !b) { par.replaceChildren(); resumen.textContent = ''; return; }

  par.replaceChildren(...[a, b].map((f) => {
    const fig = document.createElement('figure');
    fig.className = 'comparar-foto';
    const img = document.createElement('img');
    img.src = `./api/photos/${f.id}/file`;
    img.alt = tr('dash.fotoAlt', 'Foto de progreso del {fecha}', { fecha: fechaLarga(f.fecha) });
    const pie = document.createElement('figcaption');
    pie.textContent = `${fechaLarga(f.fecha)} · ${f.peso !== null ? `${numero(f.peso)} kg` : tr('dash.sinPesoCerca', 'sin peso cerca de esa fecha')}`;
    fig.append(img, pie);
    return fig;
  }));

  const dias = Math.abs(diasEntre(a.fecha, b.fecha));
  let texto = dias === 0
    ? tr('dash.mismoDia', 'Son del mismo día.')
    : tr('dash.diasEntre', '{n} días entre las dos fotos.', { n: dias });
  if (dias > 0 && a.peso !== null && b.peso !== null) {
    const [antes, despues] = a.fecha <= b.fecha ? [a, b] : [b, a];
    const diferencia = Math.round((despues.peso - antes.peso) * 10) / 10;
    texto += ` ${tr('dash.cambioPeso', 'Cambio de peso: {d} kg.', { d: `${diferencia > 0 ? '+' : ''}${numero(diferencia)}` })}`;
  }
  resumen.textContent = texto;
}

async function subirFoto(archivo) {
  fotoMsg('');
  if (!archivo) return;
  if (!/^image\//.test(archivo.type)) { fotoMsg(tr('err.foto_formato_invalido', 'La foto debe ser una imagen JPEG válida')); return; }
  const boton = document.getElementById('subirFotoBtn');
  boton.disabled = true;
  try {
    const imagen = await reducirFoto(archivo);
    await api.post('./api/photos', { imagen }, { silencioso: true });
    fotoMsg(tr('dash.fotoSubida', 'Foto guardada ✓'));
    await cargarFotos();
  } catch (err) {
    fotoMsg(err.message || tr('err.foto_formato_invalido', 'La foto debe ser una imagen JPEG válida'));
  } finally {
    boton.disabled = false;
    document.getElementById('fotoArchivo').value = '';
  }
}

async function borrarFoto(foto) {
  if (!window.confirm(tr('dash.confirmBorrarFoto', '¿Borrar esta foto? No se puede deshacer.'))) return;
  try {
    await api.delete(`./api/photos/${foto.id}`, { silencioso: true });
    fotoMsg(tr('dash.fotoBorrada', 'Foto borrada.'));
    await cargarFotos();
  } catch (err) {
    fotoMsg(err.message);
  }
}

/* ---------- PDF con etiquetas legibles ---------- */
function descargarResumenPDF() {
  if (!ultimoResultado) {
    window.mostrarAviso(tr('dash.completaDatos', 'Completa tus datos primero desde Configuración, en el menú de tu perfil.'), 'info');
    return;
  }
  const { imc, kcal, macros, datos } = ultimoResultado;
  const proteinas = (prefs && prefs.proteinas) || [];
  const restricciones = (prefs && prefs.restriccionesTexto) || '';
  const semana = infoSemana ? infoSemana.semanaNumero : 1;
  const genero = datos.sexo === 'hombre' ? tr('plan.hombre', 'hombre') : tr('plan.mujer', 'mujer');
  const extra = plan ? plan.kcalExtraHoy : 0;
  const e = escapeHtml;

  document.getElementById('printableBody').innerHTML = `
    <h3>${e(tr('pdf.tusDatos', 'Tus datos'))}</h3>
    <ul>
      ${datos.nombre ? `<li>${e(tr('pdf.nombre', 'Nombre'))}: ${e(datos.nombre)} ${e(datos.apellido || '')}</li>` : ''}
      ${datos.correo ? `<li>${e(tr('pdf.correo', 'Correo'))}: ${e(datos.correo)}</li>` : ''}
      <li>${e(tr('pdf.peso', 'Peso'))}: ${e(datos.peso)} kg — ${e(tr('pdf.estatura', 'Estatura'))}: ${e(datos.estatura)} cm</li>
      <li>${e(tr('pdf.genero', 'Género'))}: ${e(genero)} — ${e(tr('pdf.edad', 'Edad'))}: ${e(datos.edad)}</li>
      <li>${e(tr('pdf.actividad', 'Nivel de actividad'))}: ${e(labelActividad(datos.actividad))}</li>
      <li>${e(tr('pdf.objetivo', 'Objetivo'))}: ${e(labelObjetivo(datos.objetivo))}</li>
    </ul>
    <h3>${e(tr('pdf.resultado', 'Resultado'))}</h3>
    <ul>
      <li>${e(tr('dash.imc', 'Índice de masa corporal'))}: ${imc.toFixed(1)} (${e(categoriaIMC(imc))})</li>
      <li>${e(tr('dash.metaCalorica', 'Meta calórica diaria'))}: ${kcal} kcal${extra ? ` (+${extra} kcal ${e(tr('dash.porEntrenamiento', 'por entrenamiento hoy'))})` : ''}</li>
      <li>${e(tr('pdf.proteina', 'Proteína'))}: ${macros.proteina.gramos} g (${macros.proteina.pct}%)</li>
      <li>${e(tr('pdf.carbos', 'Carbohidratos'))}: ${macros.carbohidratos.gramos} g (${macros.carbohidratos.pct}%)</li>
      <li>${e(tr('pdf.grasas', 'Grasas'))}: ${macros.grasas.gramos} g (${macros.grasas.pct}%)</li>
    </ul>
    ${construirHtmlComidas(datos.objetivo, proteinas, restricciones)}
    ${construirHtmlEntrenamiento(window.GeneradorRutinas.generarSemana(perfilDeEntrenamiento(datos, prefs, !!usuario.isPremium, semana, usuario.id)))}
  `;
  window.print();
}

/* ---------- Logros (la Parte 8 los rehace) ---------- */
const LOGROS = [
  { id: 'racha3', icono: '🔥', nombre: '3 días de racha', check: (d) => d.streak >= 3 },
  { id: 'racha7', icono: '🏆', nombre: '7 días de racha', check: (d) => d.streak >= 7 },
  { id: 'primerPeso', icono: '⚖️', nombre: 'Primer registro de peso', check: (d) => d.totalProgreso >= 1 },
  { id: 'constanciaPeso', icono: '📈', nombre: '5 registros de peso', check: (d) => d.totalProgreso >= 5 },
  { id: 'cumplidor', icono: '✅', nombre: '10 tareas completadas', check: (d) => d.totalCompletions >= 10 },
  { id: 'premium', icono: '💎', nombre: 'Miembro Premium', check: (d) => d.isPremium }
];

function renderLogros() {
  const datos = {
    streak: usuario.streak || 0,
    totalProgreso: entradas.length,
    totalCompletions: usuario.totalCompletions || 0,
    isPremium: usuario.isPremium
  };
  document.getElementById('achievementsGrid').innerHTML = LOGROS.map((l) => `<div class="achievement-badge ${l.check(datos) ? 'unlocked' : ''}">
      <span class="achievement-icon">${l.icono}</span>
      <span class="achievement-name">${escapeHtml(l.nombre)}</span>
    </div>`).join('');
}

/* ---------- Arranque ---------- */
function repintarPorIdioma() {
  dibujarProgreso();
  pintarHoy();
  cargarHistorial();
  cargarBienestar();
  pintarGaleria();
  actualizarComparacion();
}

document.addEventListener('nutriamigo:user-ready', async (e) => {
  usuario = e.detail;

  const [bio, planDia, preferencias, semana] = await Promise.all([
    api.get('./api/biometrics', { silencioso: true }).catch(() => null),
    api.get('./api/plan', { silencioso: true }).catch(() => null),
    api.get('./api/preferences', { silencioso: true }).catch(() => null),
    api.get('./api/entrenamiento/semana', { silencioso: true }).catch(() => null)
  ]);
  biometria = bio;
  plan = planDia;
  prefs = preferencias;
  infoSemana = semana;

  pintarResultados();
  await cargarProgreso();
  await cargarDiario();
  cargarHistorial();
  cargarBienestar();
  cargarFotos();
  renderLogros();

  document.getElementById('downloadSummaryBtn').addEventListener('click', descargarResumenPDF);
  document.getElementById('exportProgressBtn').addEventListener('click', exportarProgresoCSV);
  document.getElementById('clearProgressBtn').addEventListener('click', borrarHistorial);
  document.getElementById('progressForm').addEventListener('submit', registrarPeso);
  document.querySelectorAll('#modoTabs .segmento').forEach((b) => b.addEventListener('click', () => {
    modo = b.dataset.modo;
    marcarSeleccion('#modoTabs .segmento', 'modo', modo);
    dibujarProgreso();
  }));
  document.querySelectorAll('#progressViewTabs .week-tab').forEach((b) => b.addEventListener('click', () => {
    vista = b.dataset.vista;
    marcarSeleccion('#progressViewTabs .week-tab', 'vista', vista);
    dibujarProgreso();
  }));

  document.getElementById('waterPlusBtn').addEventListener('click', () => cambiarVasos(1));
  document.getElementById('waterMinusBtn').addEventListener('click', () => cambiarVasos(-1));
  document.getElementById('saveDailyLogBtn').addEventListener('click', () => guardarDiario(true));
  document.getElementById('kmInput').addEventListener('change', programarGuardadoDiario);

  document.getElementById('wellbeingForm').addEventListener('submit', guardarBienestar);

  document.getElementById('fotosAcepto').addEventListener('change', (ev) => {
    document.getElementById('fotosContinuar').disabled = !ev.target.checked;
  });
  document.getElementById('fotosContinuar').addEventListener('click', async () => {
    try {
      await api.post('./api/settings', { fotosConsentimiento: true }, { silencioso: true });
      await cargarFotos();
    } catch (err) {
      fotoMsg(err.message);
    }
  });
  document.getElementById('subirFotoBtn').addEventListener('click', () => document.getElementById('fotoArchivo').click());
  document.getElementById('fotoArchivo').addEventListener('change', (ev) => subirFoto(ev.target.files[0]));
  document.getElementById('fotoSelA').addEventListener('change', actualizarComparacion);
  document.getElementById('fotoSelB').addEventListener('change', actualizarComparacion);

  document.addEventListener('nutriamigo:lang-changed', repintarPorIdioma);
  document.addEventListener('nutriamigo:plan-changed', recargarPlan);
});
