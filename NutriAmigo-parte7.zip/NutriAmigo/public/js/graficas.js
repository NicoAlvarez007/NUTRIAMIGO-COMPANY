/* Motor de gráficas propio (canvas, sin librerías ni CDN).
   - linea(): puntos con línea, tendencia (promedio móvil de 7 registros), meta y bandas de color de fondo.
   - barras(): barras por día con línea de meta opcional.
   Es nítido en pantallas de alta densidad, se ajusta al ancho, toma los colores de las variables CSS
   (y se vuelve a pintar al cambiar el tema), muestra tooltips al tocar y se puede recorrer con el teclado. */
(function () {
  const ESTADO = new Map();
  let observadorTamano = null;
  const ALTO_MIN = 190;
  const ALTO_MAX = 260;

  function css(nombre, respaldo) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(nombre).trim();
    return v || respaldo;
  }

  function colores() {
    return {
      linea: css('--green-500', '#34c281'),
      punto: css('--green-600', '#279d68'),
      texto: css('--text', '#263029'),
      suave: css('--text-soft', '#5c6b62'),
      rejilla: css('--line', '#d9ede1'),
      fondo: css('--white', '#ffffff'),
      meta: css('--color-meta', '#d98324'),
      tendencia: css('--color-tendencia', '#4f7cd9'),
      barraAlt: css('--color-barra-alt', '#4f7cd9')
    };
  }

  function formatoFecha(fecha, locale, estilo) {
    const [y, m, d] = fecha.split('-').map(Number);
    const opciones = estilo === 'mes' ? { month: 'short', year: '2-digit' } : { day: '2-digit', month: 'short' };
    return new Intl.DateTimeFormat(locale || 'es', opciones).format(new Date(y, m - 1, d));
  }

  function aMs(fecha) {
    const [y, m, d] = fecha.split('-').map(Number);
    return Date.UTC(y, m - 1, d);
  }

  /* Promedio móvil de hasta 7 registros (incluye el actual y los 6 anteriores). */
  function promedioMovil(valores, ventana = 7) {
    return valores.map((_, i) => {
      const trozo = valores.slice(Math.max(0, i - ventana + 1), i + 1);
      return trozo.reduce((s, v) => s + v, 0) / trozo.length;
    });
  }

  function prepararLienzo(canvas) {
    const caja = canvas.parentElement;
    const ancho = Math.max(240, Math.floor(caja.getBoundingClientRect().width) || 320);
    const alto = Math.round(Math.min(ALTO_MAX, Math.max(ALTO_MIN, ancho * 0.5)));
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(ancho * dpr);
    canvas.height = Math.round(alto * dpr);
    canvas.style.width = `${ancho}px`;
    canvas.style.height = `${alto}px`;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, ancho, alto);
    return { ctx, ancho, alto };
  }

  function tooltipDe(canvas) {
    let t = canvas.parentElement.querySelector('.graf-tooltip');
    if (!t) {
      t = document.createElement('div');
      t.className = 'graf-tooltip';
      t.hidden = true;
      canvas.parentElement.appendChild(t);
    }
    return t;
  }

  function anuncioDe(canvas) {
    let a = canvas.parentElement.querySelector('.graf-anuncio');
    if (!a) {
      a = document.createElement('span');
      a.className = 'graf-anuncio';
      a.setAttribute('aria-live', 'polite');
      canvas.parentElement.appendChild(a);
    }
    return a;
  }

  function mostrarTooltip(canvas, estado, indice) {
    const t = tooltipDe(canvas);
    if (indice === null || !estado.puntosPantalla[indice]) {
      t.hidden = true;
      estado.seleccion = null;
      return;
    }
    estado.seleccion = indice;
    const p = estado.puntosPantalla[indice];
    t.textContent = p.texto;
    t.hidden = false;
    const caja = canvas.parentElement.getBoundingClientRect();
    const lienzo = canvas.getBoundingClientRect();
    const ancho = t.offsetWidth;
    let x = p.x + (lienzo.left - caja.left) - ancho / 2;
    x = Math.max(4, Math.min(x, caja.width - ancho - 4));
    t.style.left = `${x}px`;
    t.style.top = `${Math.max(0, p.y + (lienzo.top - caja.top) - t.offsetHeight - 10)}px`;
    anuncioDe(canvas).textContent = p.texto;
    pintar(canvas);
  }

  function enlazarInteraccion(canvas, estado) {
    if (estado.enlazado) return;
    estado.enlazado = true;
    canvas.tabIndex = 0;
    const cercano = (ev) => {
      const r = canvas.getBoundingClientRect();
      const x = ev.clientX - r.left;
      let mejor = null;
      estado.puntosPantalla.forEach((p, i) => {
        const d = Math.abs(p.x - x);
        if (mejor === null || d < mejor.d) mejor = { d, i };
      });
      return mejor ? mejor.i : null;
    };
    canvas.addEventListener('pointerdown', (ev) => mostrarTooltip(canvas, estado, cercano(ev)));
    canvas.addEventListener('pointermove', (ev) => { if (ev.pointerType === 'mouse') mostrarTooltip(canvas, estado, cercano(ev)); });
    canvas.addEventListener('pointerleave', (ev) => { if (ev.pointerType === 'mouse') mostrarTooltip(canvas, estado, null); });
    canvas.addEventListener('keydown', (ev) => {
      const n = estado.puntosPantalla.length;
      if (!n) return;
      let i = estado.seleccion === null ? (ev.key === 'ArrowLeft' ? n : -1) : estado.seleccion;
      if (ev.key === 'ArrowRight') i = Math.min(n - 1, i + 1);
      else if (ev.key === 'ArrowLeft') i = Math.max(0, i - 1);
      else if (ev.key === 'Escape') { mostrarTooltip(canvas, estado, null); return; }
      else return;
      ev.preventDefault();
      mostrarTooltip(canvas, estado, i);
    });
    canvas.addEventListener('blur', () => mostrarTooltip(canvas, estado, null));
  }

  function registrar(canvas, estado) {
    const previo = ESTADO.get(canvas);
    estado.enlazado = previo ? previo.enlazado : false;
    estado.seleccion = null;
    ESTADO.set(canvas, estado);
    enlazarInteraccion(canvas, estado);
    if (!observadorTamano && 'ResizeObserver' in window) {
      observadorTamano = new ResizeObserver((entradas) => {
        entradas.forEach((e) => {
          const c = Array.from(ESTADO.keys()).find((k) => k.parentElement === e.target);
          if (c && Math.floor(e.contentRect.width) !== ESTADO.get(c).anchoPintado) pintar(c);
        });
      });
    }
    if (observadorTamano) observadorTamano.observe(canvas.parentElement);
    if (estado.ariaLabel) canvas.setAttribute('aria-label', estado.ariaLabel);
    canvas.setAttribute('role', 'img');
  }

  function pintar(canvas) {
    const estado = ESTADO.get(canvas);
    if (!estado) return;
    if (estado.tipo === 'linea') pintarLinea(canvas, estado);
    else pintarBarras(canvas, estado);
  }

  function ejeY(ctx, c, izq, der, arriba, abajo, min, max, formato) {
    ctx.font = `500 10.5px ${getComputedStyle(document.body).fontFamily || 'sans-serif'}`;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.lineWidth = 1;
    const marcas = 4;
    for (let i = 0; i <= marcas; i += 1) {
      const valor = min + ((max - min) * i) / marcas;
      const y = abajo - ((abajo - arriba) * i) / marcas;
      ctx.strokeStyle = c.rejilla;
      ctx.beginPath();
      ctx.moveTo(izq, y);
      ctx.lineTo(der, y);
      ctx.stroke();
      ctx.fillStyle = c.suave;
      ctx.fillText(formato(valor), izq - 6, y);
    }
  }

  /* ---------- Línea ---------- */
  function linea(canvas, opciones) {
    const puntos = (opciones.puntos || []).slice().sort((a, b) => a.fecha.localeCompare(b.fecha));
    registrar(canvas, Object.assign({ tipo: 'linea' }, opciones, { puntos }));
    pintar(canvas);
  }

  function pintarLinea(canvas, estado) {
    const { ctx, ancho, alto } = prepararLienzo(canvas);
    estado.anchoPintado = ancho;
    const c = colores();
    const o = estado;
    const pts = o.puntos;
    const fv = o.formatoValor || ((v) => String(Math.round(v * 10) / 10));
    const izq = 44;
    const der = ancho - 14;
    const arriba = 14;
    const abajo = alto - 30;

    const valores = pts.map((p) => p.valor);
    const tendencia = o.tendencia && pts.length > 1 ? promedioMovil(valores) : null;
    const extremos = valores.slice();
    if (o.meta) extremos.push(o.meta);
    if (o.bandas && o.bandas.length) o.bandas.forEach((b) => extremos.push(b.desde, b.hasta));
    let min = Math.min(...extremos);
    let max = Math.max(...extremos);
    if (o.bandas && o.bandas.length) {
      min = Math.min(...valores, o.bandas[0].desde);
      max = Math.max(...valores, o.bandas[o.bandas.length - 1].hasta);
      min = Math.max(min, Math.min(...valores) - 4);
      max = Math.min(max, Math.max(...valores) + 4);
    }
    const margen = (max - min) * 0.12 || 1;
    min -= margen;
    max += margen;

    const t0 = pts.length ? aMs(pts[0].fecha) : 0;
    const t1 = pts.length ? aMs(pts[pts.length - 1].fecha) : 1;
    const X = (i) => (pts.length < 2 || t1 === t0
      ? (izq + der) / 2
      : izq + ((aMs(pts[i].fecha) - t0) / (t1 - t0)) * (der - izq));
    const Y = (v) => abajo - ((v - min) / (max - min)) * (abajo - arriba);

    if (o.bandas) {
      o.bandas.forEach((b) => {
        const y1 = Math.max(arriba, Y(Math.min(b.hasta, max)));
        const y2 = Math.min(abajo, Y(Math.max(b.desde, min)));
        if (y2 <= y1) return;
        ctx.fillStyle = css(b.color, 'rgba(120,120,120,.12)');
        ctx.fillRect(izq, y1, der - izq, y2 - y1);
      });
    }

    ejeY(ctx, c, izq, der, arriba, abajo, min, max, fv);

    if (o.meta) {
      ctx.save();
      ctx.setLineDash([6, 4]);
      ctx.strokeStyle = c.meta;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(izq, Y(o.meta));
      ctx.lineTo(der, Y(o.meta));
      ctx.stroke();
      ctx.restore();
    }

    if (tendencia) {
      ctx.save();
      ctx.setLineDash([2, 4]);
      ctx.strokeStyle = c.tendencia;
      ctx.lineWidth = 2;
      ctx.beginPath();
      tendencia.forEach((v, i) => (i === 0 ? ctx.moveTo(X(i), Y(v)) : ctx.lineTo(X(i), Y(v))));
      ctx.stroke();
      ctx.restore();
    }

    ctx.strokeStyle = c.linea;
    ctx.lineWidth = 2.5;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    pts.forEach((p, i) => (i === 0 ? ctx.moveTo(X(i), Y(p.valor)) : ctx.lineTo(X(i), Y(p.valor))));
    ctx.stroke();

    estado.puntosPantalla = pts.map((p, i) => ({
      x: X(i),
      y: Y(p.valor),
      texto: `${p.etiqueta || formatoFecha(p.fecha, o.locale, o.estiloFecha)}: ${fv(p.valor)}${o.unidad ? ` ${o.unidad}` : ''}`
    }));

    estado.puntosPantalla.forEach((p, i) => {
      const activo = estado.seleccion === i;
      ctx.beginPath();
      ctx.arc(p.x, p.y, activo ? 6 : 4, 0, Math.PI * 2);
      ctx.fillStyle = activo ? c.texto : c.punto;
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = c.fondo;
      ctx.stroke();
    });

    /* Etiquetas del eje X sin encimarse: se saltan las que no caben. */
    ctx.font = `500 10.5px ${getComputedStyle(document.body).fontFamily || 'sans-serif'}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = c.suave;
    const anchoEtiqueta = 62;
    let ultimoX = -Infinity;
    const maxEtiquetas = Math.max(2, Math.floor((der - izq) / anchoEtiqueta));
    const paso = Math.max(1, Math.ceil(pts.length / maxEtiquetas));
    pts.forEach((p, i) => {
      const esUltimo = i === pts.length - 1;
      if (!(i % paso === 0 || esUltimo)) return;
      const x = X(i);
      if (x - ultimoX < anchoEtiqueta - 6) return;
      ultimoX = x;
      ctx.fillText(p.etiqueta || formatoFecha(p.fecha, o.locale, o.estiloFecha), Math.min(der - 18, Math.max(izq + 18, x)), alto - 10);
    });
  }

  /* ---------- Barras ---------- */
  function barras(canvas, opciones) {
    registrar(canvas, Object.assign({ tipo: 'barras' }, opciones));
    pintar(canvas);
  }

  function pintarBarras(canvas, estado) {
    const { ctx, ancho, alto } = prepararLienzo(canvas);
    estado.anchoPintado = ancho;
    const c = colores();
    const o = estado;
    const fv = o.formatoValor || ((v) => String(Math.round(v * 10) / 10));
    const izq = 38;
    const der = ancho - 10;
    const arriba = 14;
    const abajo = alto - 28;
    const n = o.valores.length;
    const maxDato = Math.max(...o.valores, o.meta || 0, 1);
    const max = maxDato * 1.15;
    const Y = (v) => abajo - (v / max) * (abajo - arriba);

    ejeY(ctx, c, izq, der, arriba, abajo, 0, max, fv);

    const bloque = (der - izq) / n;
    const anchoBarra = Math.min(34, bloque * 0.6);
    estado.puntosPantalla = [];
    o.valores.forEach((v, i) => {
      const x = izq + bloque * i + (bloque - anchoBarra) / 2;
      const activo = estado.seleccion === i;
      ctx.fillStyle = activo ? c.texto : (o.color === 'alt' ? c.barraAlt : c.linea);
      const h = Math.max(v > 0 ? 2 : 0, abajo - Y(v));
      ctx.fillRect(x, abajo - h, anchoBarra, h);
      estado.puntosPantalla.push({
        x: x + anchoBarra / 2,
        y: abajo - h,
        texto: `${o.etiquetas[i]}: ${fv(v)}${o.unidad ? ` ${o.unidad}` : ''}`
      });
    });

    if (o.meta) {
      ctx.save();
      ctx.setLineDash([6, 4]);
      ctx.strokeStyle = c.meta;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(izq, Y(o.meta));
      ctx.lineTo(der, Y(o.meta));
      ctx.stroke();
      ctx.restore();
    }

    ctx.font = `500 10.5px ${getComputedStyle(document.body).fontFamily || 'sans-serif'}`;
    ctx.textAlign = 'center';
    ctx.fillStyle = c.suave;
    o.etiquetas.forEach((et, i) => ctx.fillText(et, izq + bloque * i + bloque / 2, alto - 8));
  }

  function limpiar(canvas) {
    ESTADO.delete(canvas);
    const t = canvas.parentElement && canvas.parentElement.querySelector('.graf-tooltip');
    if (t) t.hidden = true;
  }

  new MutationObserver(() => ESTADO.forEach((_, c) => pintar(c)))
    .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'data-letra'] });

  window.NutriGraficas = { linea, barras, limpiar, promedioMovil, formatoFecha };
})();
