/* "Entrenar ahora": guía la sesión de hoy paso a paso, con temporizador de descanso, pausa y resumen.
   El avance se guarda en el navegador y solo se retoma el mismo día. */
(function () {
  const CLAVE_ESTADO = 'nutriamigo_entrenar_v1';
  const CLAVE_SONIDO = 'nutriamigo_entrenar_sonido';
  const CIRCUNFERENCIA = 2 * Math.PI * 52;
  const G = window.GeneradorRutinas;

  const $ = (id) => document.getElementById(id);
  const t = (clave, es, vars) => {
    let texto = window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es;
    Object.keys(vars || {}).forEach((k) => { texto = texto.split(`{${k}}`).join(String(vars[k])); });
    return texto;
  };

  let sesion = null;
  let opciones = null;
  let pasos = [];
  let idx = 0;
  let serie = 1;
  let vista = 'ejercicio';
  let pausado = false;
  let acumuladoMs = 0;
  let ultimoTick = 0;
  let descansoFin = 0;
  let descansoTotal = 0;
  let intervalo = null;
  let ultimoAnuncio = -1;
  let bloqueo = null;
  let ctxAudio = null;
  let abierto = false;

  /* ---------- Persistencia ---------- */
  function guardar() {
    try {
      localStorage.setItem(CLAVE_ESTADO, JSON.stringify({ fecha: opciones.fecha, dia: opciones.dia, idx, serie, acumuladoMs }));
    } catch (err) { /* almacenamiento no disponible */ }
  }

  function leerGuardado() {
    try {
      const g = JSON.parse(localStorage.getItem(CLAVE_ESTADO) || 'null');
      if (g && g.fecha === opciones.fecha && g.dia === opciones.dia && g.idx < pasos.length) return g;
    } catch (err) { /* dato dañado: se ignora */ }
    return null;
  }

  function borrarGuardado() {
    try { localStorage.removeItem(CLAVE_ESTADO); } catch (err) { /* sin almacenamiento */ }
  }

  function sonidoActivo() {
    try { return localStorage.getItem(CLAVE_SONIDO) === '1'; } catch (err) { return false; }
  }

  /* ---------- Pantalla activa, sonido y vibración ---------- */
  async function pedirPantalla() {
    if (!('wakeLock' in navigator)) return;
    try {
      bloqueo = await navigator.wakeLock.request('screen');
    } catch (err) {
      console.error('No se pudo mantener la pantalla activa', err);
    }
  }

  function soltarPantalla() {
    if (bloqueo) bloqueo.release().catch(() => {});
    bloqueo = null;
  }

  function pitido() {
    if (!sonidoActivo()) return;
    try {
      ctxAudio = ctxAudio || new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctxAudio.createOscillator();
      const ganancia = ctxAudio.createGain();
      osc.frequency.value = 880;
      ganancia.gain.value = 0.15;
      osc.connect(ganancia);
      ganancia.connect(ctxAudio.destination);
      osc.start();
      osc.stop(ctxAudio.currentTime + 0.25);
    } catch (err) {
      console.error('No se pudo reproducir el sonido', err);
    }
  }

  function vibrar() {
    if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
  }

  function anunciar(texto) {
    $('eaAnuncio').textContent = texto;
  }

  /* ---------- Textos ---------- */
  function paso() {
    return pasos[idx];
  }

  function textoObjetivo(p) {
    if (p.unidad === 'min') return t('ea.objMin', '{m} minutos', { m: p.minutos });
    if (p.unidad === 'seg') return t('ea.objSeg', '{s} segundos', { s: p.segundos });
    return t('ea.objReps', '{r} repeticiones', { r: p.repeticiones });
  }

  function nombreDe(p) {
    return window.nombreEjercicio ? window.nombreEjercicio(p.id) : p.id;
  }

  function pintarEjercicio() {
    const p = paso();
    const ej = G.ejercicioPorId(p.id);
    const idioma = window.idiomaActivo ? window.idiomaActivo() : 'es';
    $('eaFase').textContent = t(`ea.fase.${p.fase}`, p.fase);
    $('eaNombre').textContent = nombreDe(p);
    $('eaObjetivo').textContent = textoObjetivo(p) + (p.km ? ` · ${p.km} km` : '');
    $('eaSerie').textContent = p.series > 1 ? t('ea.serie', 'Serie {i}/{n}', { i: serie, n: p.series }) : '';
    $('eaPasos').replaceChildren(...(ej.pasos[idioma] || ej.pasos.es).map((texto) => {
      const li = document.createElement('li');
      li.textContent = texto;
      return li;
    }));
    const siguiente = pasos[idx + 1];
    $('eaSiguiente').textContent = siguiente ? `${t('ea.siguienteEs', 'Sigue:')} ${nombreDe(siguiente)}` : '';
    $('eaHecho').textContent = p.unidad === 'min' ? t('ea.terminado', 'Terminado') : t('ea.serieCompletada', 'Serie completada');
    $('eaAnterior').disabled = idx === 0;
    $('eaSiguienteBtn').disabled = idx >= pasos.length - 1;
    $('eaPosicion').textContent = t('ea.ejercicio', 'Ejercicio {i} de {n}', { i: idx + 1, n: pasos.length });

    const total = pasos.reduce((s, x) => s + x.series, 0);
    const hechas = pasos.slice(0, idx).reduce((s, x) => s + x.series, 0) + (serie - 1);
    const pct = Math.round((hechas / total) * 100);
    $('eaProgresoRelleno').style.width = `${pct}%`;
    $('eaProgreso').setAttribute('aria-valuenow', String(pct));
    anunciar(`${nombreDe(p)}. ${textoObjetivo(p)}`);
  }

  function mostrar(cual) {
    vista = cual;
    $('eaEjercicio').hidden = cual !== 'ejercicio';
    $('eaDescanso').hidden = cual !== 'descanso';
    $('eaResumen').hidden = cual !== 'resumen';
    $('eaPausa').hidden = cual === 'resumen';
    const foco = cual === 'ejercicio' ? $('eaHecho') : cual === 'descanso' ? $('eaOmitir') : $('eaCerrar');
    foco.focus();
  }

  /* ---------- Flujo ---------- */
  function irAEjercicio(nuevo, nuevaSerie) {
    idx = nuevo;
    serie = nuevaSerie || 1;
    guardar();
    pintarEjercicio();
    mostrar('ejercicio');
  }

  function empezarDescanso(segundos, siguienteTexto) {
    descansoTotal = segundos;
    descansoFin = Date.now() + segundos * 1000;
    ultimoAnuncio = -1;
    $('eaDespues').textContent = siguienteTexto;
    mostrar('descanso');
    actualizarDescanso();
  }

  function serieCompletada() {
    const p = paso();
    if (serie < p.series) {
      if (p.descansoSeg > 0) {
        serie += 1;
        guardar();
        empezarDescanso(p.descansoSeg, `${nombreDe(p)} · ${t('ea.serie', 'Serie {i}/{n}', { i: serie, n: p.series })}`);
      } else {
        irAEjercicio(idx, serie + 1);
      }
      return;
    }
    if (idx >= pasos.length - 1) { terminar(); return; }
    const siguiente = pasos[idx + 1];
    if (p.descansoSeg > 0 && p.fase === 'principal') {
      idx += 1;
      serie = 1;
      guardar();
      empezarDescanso(p.descansoSeg, `${t('ea.siguienteEs', 'Sigue:')} ${nombreDe(siguiente)}`);
    } else {
      irAEjercicio(idx + 1, 1);
    }
  }

  function terminarDescanso() {
    pintarEjercicio();
    mostrar('ejercicio');
  }

  function actualizarDescanso() {
    const restante = Math.max(0, Math.ceil((descansoFin - Date.now()) / 1000));
    $('eaTiempo').textContent = String(restante);
    const fraccion = descansoTotal ? restante / descansoTotal : 0;
    const anillo = $('eaAnillo');
    anillo.style.strokeDasharray = String(CIRCUNFERENCIA);
    anillo.style.strokeDashoffset = String(CIRCUNFERENCIA * (1 - fraccion));
    if ((restante % 10 === 0 || restante <= 3) && restante !== ultimoAnuncio && restante > 0) {
      ultimoAnuncio = restante;
      anunciar(t('ea.avisoDescanso', 'Faltan {s} segundos', { s: restante }));
    }
    if (restante === 0) {
      anunciar(t('ea.finDescanso', 'Descanso terminado'));
      pitido();
      vibrar();
      terminarDescanso();
    }
  }

  function tick() {
    const ahora = Date.now();
    if (!pausado) {
      acumuladoMs += ahora - ultimoTick;
      if (vista === 'descanso') actualizarDescanso();
    }
    ultimoTick = ahora;
  }

  /* ---------- Final ---------- */
  async function terminar() {
    detener();
    borrarGuardado();
    const segundos = Math.max(60, Math.round(acumuladoMs / 1000));
    $('eaResDuracion').textContent = `${Math.max(1, Math.round(segundos / 60))} ${t('ent.min', 'min')}`;
    $('eaResEjercicios').textContent = String(pasos.length);
    const kcal = G.kcalEstimadas(opciones.peso, sesion, segundos);
    if (kcal > 0) {
      $('eaResKcal').textContent = `≈ ${kcal} kcal`;
      $('eaResAviso').textContent = t('ea.kcalAviso', 'Es una estimación.');
    } else {
      $('eaResKcal').textContent = '—';
      $('eaResAviso').textContent = t('ea.sinPeso', 'Registra tu peso en tus datos para ver las calorías.');
    }
    $('eaResMarcado').textContent = '';
    mostrar('resumen');
    anunciar(t('ea.resumenTitulo', '¡Sesión terminada!'));
    const ok = await opciones.alTerminar();
    $('eaResMarcado').textContent = ok ? t('ea.marcado', 'Marcamos el día como hecho.') : t('ea.noMarcado', 'No se pudo marcar el día.');
  }

  function detener() {
    if (intervalo) clearInterval(intervalo);
    intervalo = null;
    soltarPantalla();
  }

  function cerrar() {
    detener();
    abierto = false;
    $('entrenarAhora').hidden = true;
    $('eaConfirmar').hidden = true;
    document.body.classList.remove('entrenando');
    document.removeEventListener('keydown', alTeclear);
    document.removeEventListener('visibilitychange', alCambiarVisibilidad);
  }

  /* ---------- Controles ---------- */
  function alternarPausa() {
    pausado = !pausado;
    $('eaPausa').textContent = pausado ? t('ea.reanudar', 'Reanudar') : t('ea.pausar', 'Pausar');
    if (pausado) {
      pausaInicio = Date.now();
      anunciar(t('ea.pausar', 'Pausar'));
    } else {
      descansoFin += Date.now() - pausaInicio;
      ultimoTick = Date.now();
    }
  }
  let pausaInicio = 0;

  function pedirSalir() {
    if (vista === 'resumen') { cerrar(); return; }
    $('eaConfirmar').hidden = false;
    $('eaSeguir').focus();
  }

  function alTeclear(ev) {
    if (!abierto) return;
    if (ev.key === 'Escape') {
      ev.preventDefault();
      if (!$('eaConfirmar').hidden) { $('eaConfirmar').hidden = true; $('eaHecho').focus(); } else pedirSalir();
      return;
    }
    if (ev.key !== 'Tab') return;
    const raiz = $('eaConfirmar').hidden ? $('entrenarAhora') : $('eaConfirmar');
    const enfocables = Array.from(raiz.querySelectorAll('button, input, [href]')).filter((e) => !e.disabled && !e.closest('[hidden]'));
    if (!enfocables.length) return;
    const primero = enfocables[0];
    const ultimo = enfocables[enfocables.length - 1];
    if (ev.shiftKey && document.activeElement === primero) { ev.preventDefault(); ultimo.focus(); }
    else if (!ev.shiftKey && document.activeElement === ultimo) { ev.preventDefault(); primero.focus(); }
  }

  function alCambiarVisibilidad() {
    if (document.visibilityState === 'visible' && abierto && !bloqueo) pedirPantalla();
  }

  let enlazado = false;
  function enlazar() {
    if (enlazado) return;
    enlazado = true;
    $('eaHecho').addEventListener('click', serieCompletada);
    $('eaOmitir').addEventListener('click', () => { descansoFin = Date.now(); actualizarDescanso(); });
    $('eaMasQuince').addEventListener('click', () => { descansoFin += 15000; descansoTotal += 15; actualizarDescanso(); });
    $('eaAnterior').addEventListener('click', () => { if (idx > 0) irAEjercicio(idx - 1, 1); });
    $('eaSiguienteBtn').addEventListener('click', () => { if (idx < pasos.length - 1) irAEjercicio(idx + 1, 1); });
    $('eaPausa').addEventListener('click', alternarPausa);
    $('eaSalir').addEventListener('click', pedirSalir);
    $('eaSeguir').addEventListener('click', () => { $('eaConfirmar').hidden = true; $('eaHecho').focus(); });
    $('eaSalirSi').addEventListener('click', () => { guardar(); cerrar(); });
    $('eaCerrar').addEventListener('click', cerrar);
    $('eaSonido').addEventListener('change', (ev) => {
      try { localStorage.setItem(CLAVE_SONIDO, ev.target.checked ? '1' : '0'); } catch (err) { /* sin almacenamiento */ }
    });
  }

  function abrir(config) {
    sesion = config.sesion;
    opciones = config;
    pasos = G.pasosDeSesion(sesion);
    if (!pasos.length) return;
    enlazar();

    const guardado = leerGuardado();
    idx = 0;
    serie = 1;
    acumuladoMs = 0;
    if (guardado) {
      idx = guardado.idx;
      serie = Math.min(guardado.serie, pasos[idx].series);
      acumuladoMs = guardado.acumuladoMs || 0;
      window.mostrarAviso(t('ea.retomamos', 'Retomamos tu sesión donde la dejaste.'), 'info');
    }
    pausado = false;
    $('eaPausa').textContent = t('ea.pausar', 'Pausar');
    $('eaSonido').checked = sonidoActivo();
    ultimoTick = Date.now();
    abierto = true;
    document.body.classList.add('entrenando');
    $('entrenarAhora').hidden = false;
    pintarEjercicio();
    mostrar('ejercicio');
    intervalo = setInterval(tick, 250);
    pedirPantalla();
    document.addEventListener('keydown', alTeclear);
    document.addEventListener('visibilitychange', alCambiarVisibilidad);
  }

  window.EntrenarAhora = { abrir };
})();
