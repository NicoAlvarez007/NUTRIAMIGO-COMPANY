function construirModalConfiguracion() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'settingsModal';
  overlay.hidden = true;
  overlay.innerHTML = `
    <div class="modal">
      <h3 data-i18n="settings.title">Configuración</h3>
      <p class="section-sub" data-i18n="settings.subtitle">Cambia tus datos, tu tema o tu cuenta.</p>
      <form id="settingsForm">
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label data-i18n="settings.nombre">Nombre</label><input type="text" id="cfgNombre"></div>
          <div class="field"><label data-i18n="settings.apellido">Apellido</label><input type="text" id="cfgApellido"></div>
        </div>
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label data-i18n="settings.peso">Peso (kg)</label><input type="number" id="cfgPeso" step="0.1" min="30" max="250"></div>
          <div class="field"><label data-i18n="settings.estatura">Estatura (cm)</label><input type="number" id="cfgEstatura" min="120" max="220"></div>
        </div>
        <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="field"><label for="cfgSexo" data-i18n="settings.sexo">Género</label>
            <select id="cfgSexo">
              <option value="mujer" data-i18n="plan.mujer">mujer</option>
              <option value="hombre" data-i18n="plan.hombre">hombre</option>
            </select>
          </div>
          <div class="field"><label for="cfgEdad" data-i18n="settings.edad">Edad</label><input type="number" id="cfgEdad" min="15" max="90"></div>
        </div>
        <div class="field-row" style="display:grid;grid-template-columns:1fr;gap:14px;">
          <div class="field">
            <label data-i18n="settings.actividad">Nivel de actividad</label>
            <select id="cfgActividad">
              <option value="sedentario" data-i18n="actividad.sedentario">Sedentario</option>
              <option value="ligero" data-i18n="actividad.ligero">Ligero</option>
              <option value="moderado" data-i18n="actividad.moderado">Moderado</option>
              <option value="activo" data-i18n="actividad.activo">Activo</option>
              <option value="muy_activo" data-i18n="actividad.muyActivo">Muy activo</option>
            </select>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.objetivo">Objetivo</label>
          <div class="pill-group" id="cfgObjetivoGroup">
            <button type="button" class="pill" data-objetivo="definir" data-i18n="objetivo.definir">Definir</button>
            <button type="button" class="pill" data-objetivo="mantener" data-i18n="objetivo.mantener">Mantener</button>
            <button type="button" class="pill" data-objetivo="volumen" data-i18n="objetivo.volumen">Subir de peso</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.tipoPerfil">Tipo de perfil</label>
          <div class="pill-group" id="cfgPerfilGroup">
            <button type="button" class="pill" data-perfil="privado" data-i18n="perfil.privado">Privado</button>
            <button type="button" class="pill" data-perfil="publico" data-i18n="perfil.publico">Público</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.tema">Tema</label>
          <div class="pill-group" id="temaGroup">
            <button type="button" class="pill" data-tema="claro" data-i18n="tema.claro">Claro</button>
            <button type="button" class="pill" data-tema="dark" data-i18n="tema.oscuro">Oscuro</button>
            <button type="button" class="pill" data-tema="auto" data-i18n="tema.auto">Automático</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.tamanoLetra">Tamaño de letra</label>
          <div class="pill-group" id="letraGroup">
            <button type="button" class="pill" data-letra="normal" data-i18n="settings.letraNormal">Normal</button>
            <button type="button" class="pill" data-letra="grande" data-i18n="settings.letraGrande">Grande</button>
            <button type="button" class="pill" data-letra="muy_grande" data-i18n="settings.letraMuyGrande">Muy grande</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.idioma">Idioma</label>
          <div class="pill-group" id="idiomaGroup">
            <button type="button" class="pill" data-lang="es">Español</button>
            <button type="button" class="pill" data-lang="en">English</button>
            <button type="button" class="pill" data-lang="de">Deutsch</button>
          </div>
        </div>
        <div class="field">
          <label data-i18n="settings.actualizacionPlan">Actualización del plan</label>
          <button type="button" class="pill" id="planAutoToggle" aria-pressed="false" data-i18n="settings.planAuto">Actualizar mi plan con mis registros de peso (cuando cambie 5 kg o más)</button>
          <button type="button" class="pill" id="planConfirmToggle" aria-pressed="false" data-i18n="settings.planConfirm">Preguntarme antes de cambiar mi plan</button>
          <p class="section-sub" data-i18n="settings.planAyuda">Si apagas la primera, tu plan solo cambia cuando tú lo cambies aquí.</p>
        </div>
        <div class="field">
          <label data-i18n="settings.recordatorios">Recordatorios</label>
          <div class="pill-group">
            <button type="button" class="pill" id="recordarAguaToggle" data-i18n="settings.recordarAgua">💧 Tomar agua cada 2 horas</button>
            <button type="button" class="pill" id="recordarComidasToggle" aria-pressed="false" data-i18n="settings.recordarComidas">🍽️ Comer (aviso diario)</button>
            <button type="button" class="pill" id="recordarEntrenoToggle" data-i18n="settings.recordarEntreno">🏋️ Entrenar (aviso diario)</button>
          </div>
          <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:10px;">
            <div class="field"><label for="horaAgua" data-i18n="settings.horaAgua">Agua desde las</label><input type="time" id="horaAgua" value="10:00"></div>
            <div class="field"><label for="horaComidas" data-i18n="settings.horaComidas">Comida a las</label><input type="time" id="horaComidas" value="13:00"></div>
          </div>
          <p class="section-sub" style="margin-top:6px;" data-i18n="settings.recordatoriosAyuda">Solo funcionan mientras tengas esta pestaña abierta en tu navegador.</p>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" id="closeSettingsBtn" data-i18n="settings.cancelar">Cancelar</button>
          <button type="submit" class="btn btn-primary" data-i18n="settings.guardar">Guardar</button>
        </div>
      </form>
      <button type="button" class="btn btn-ghost" id="exportDataBtn" style="width:100%;margin-top:16px;" data-i18n="settings.descargarDatos">Descargar mis datos</button>
      <button type="button" id="deleteAccountBtn" style="width:100%;margin-top:10px;background:none;border:none;color:#c5533b;font-size:13px;font-weight:600;cursor:pointer;" data-i18n="settings.borrarCuenta">Borrar cuenta</button>
      <div class="settings-contact">
        <span data-i18n="settings.contactanos">Contáctanos:</span>
        <a href="https://wa.me/573000000000" target="_blank" rel="noopener">WhatsApp</a>
        <a href="https://instagram.com/nutriamigo" target="_blank" rel="noopener">Instagram</a>
        <a href="https://tiktok.com/@nutriamigo" target="_blank" rel="noopener">TikTok</a>
        <span>nutriamigo@gmail.com</span>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  return overlay;
}

function marcarTemaCfg(tema) {
  document.querySelectorAll('#temaGroup .pill').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tema === tema);
  });
}

function aplicarTema(tema) {
  if (window.NutriTema) window.NutriTema.set(tema);
  marcarTemaCfg(tema);
}

let objetivoCfg = 'mantener';
let perfilCfg = 'privado';

function marcarObjetivoCfg(valor) {
  objetivoCfg = valor;
  document.querySelectorAll('#cfgObjetivoGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.objetivo === valor));
}

function marcarPerfilCfg(valor) {
  perfilCfg = valor;
  document.querySelectorAll('#cfgPerfilGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.perfil === valor));
}

function marcarIdiomaCfg(valor) {
  document.querySelectorAll('#idiomaGroup .pill').forEach(b => b.classList.toggle('active', b.dataset.lang === valor));
}

document.addEventListener('nutriamigo:user-ready', () => {
  const settingsBtn = document.getElementById('settingsBtn');
  if (!settingsBtn) return;

  const overlay = construirModalConfiguracion();

  document.querySelectorAll('#temaGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => { aplicarTema(btn.dataset.tema); api.post('./api/settings', { tema: btn.dataset.tema }, { silencioso: true }).catch(() => {}); });
  });
  document.querySelectorAll('#cfgObjetivoGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => marcarObjetivoCfg(btn.dataset.objetivo));
  });
  document.querySelectorAll('#cfgPerfilGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => marcarPerfilCfg(btn.dataset.perfil));
  });
  document.querySelectorAll('#idiomaGroup .pill').forEach(btn => {
    btn.addEventListener('click', () => {
      marcarIdiomaCfg(btn.dataset.lang);
      if (window.NutriIdioma) window.NutriIdioma.set(btn.dataset.lang);
      api.post('./api/settings', { idioma: btn.dataset.lang }, { silencioso: true }).catch(() => {});
    });
  });

  const marcarInterruptor = (id, activo) => {
    const el = document.getElementById(id);
    el.classList.toggle('active', activo);
    el.setAttribute('aria-pressed', String(activo));
  };
  const estaActivo = (id) => document.getElementById(id).classList.contains('active');
  const sincronizarPlanConfirm = () => {
    const boton = document.getElementById('planConfirmToggle');
    boton.disabled = !estaActivo('planAutoToggle');
  };
  ['planAutoToggle', 'planConfirmToggle', 'recordarComidasToggle'].forEach((id) => {
    document.getElementById(id).addEventListener('click', () => {
      marcarInterruptor(id, !estaActivo(id));
      sincronizarPlanConfirm();
    });
  });
  document.querySelectorAll('#letraGroup .pill').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#letraGroup .pill').forEach((b) => b.classList.toggle('active', b === btn));
      if (window.NutriLetra) window.NutriLetra.set(btn.dataset.letra);
    });
  });

  ['recordarAguaToggle', 'recordarEntrenoToggle'].forEach(id => {
    document.getElementById(id).addEventListener('click', async (e) => {
      const activando = !e.target.classList.contains('active');
      if (activando && 'Notification' in window && Notification.permission === 'default') {
        await Notification.requestPermission();
      }
      if (activando && 'Notification' in window && Notification.permission !== 'granted') {
        return; // el usuario negó el permiso: no activamos el toggle
      }
      e.target.classList.toggle('active');
    });
  });

  document.getElementById('closeSettingsBtn').addEventListener('click', () => { overlay.hidden = true; });

  settingsBtn.addEventListener('click', async () => {
    document.getElementById('profileMenu').classList.remove('open');
    marcarTemaCfg(window.NutriTema ? window.NutriTema.get() : 'claro');
    marcarIdiomaCfg(window.NutriIdioma ? window.NutriIdioma.get() : 'es');
    document.querySelectorAll('#letraGroup .pill').forEach((b) => b.classList.toggle('active', b.dataset.letra === (window.NutriLetra ? window.NutriLetra.get() : 'normal')));
    try {
      const aj = await api.get('./api/settings', { silencioso: true });
      marcarInterruptor('planAutoToggle', aj.planAutoUpdate);
      marcarInterruptor('planConfirmToggle', aj.planConfirm);
      marcarInterruptor('recordarComidasToggle', aj.recordarComidas);
      document.getElementById('horaAgua').value = aj.horaAgua;
      document.getElementById('horaComidas').value = aj.horaComidas;
      sincronizarPlanConfirm();
    } catch (err) {
      console.error('No se pudieron cargar tus ajustes', err);
    }
    document.getElementById('recordarAguaToggle').classList.toggle('active', !!(window.__nutriamigoUser && window.__nutriamigoUser.recordarAgua));
    document.getElementById('recordarEntrenoToggle').classList.toggle('active', !!(window.__nutriamigoUser && window.__nutriamigoUser.recordarEntreno));

    try {
      const data = await api.get('./api/biometrics');
      if (data) {
        document.getElementById('cfgNombre').value = data.nombre || '';
        document.getElementById('cfgApellido').value = data.apellido || '';
        document.getElementById('cfgPeso').value = data.peso || '';
        document.getElementById('cfgEstatura').value = data.estatura || '';
        document.getElementById('cfgEdad').value = data.edad || '';
        if (data.actividad) document.getElementById('cfgActividad').value = data.actividad;
        marcarObjetivoCfg(data.objetivo || 'mantener');
        overlay.dataset.sexo = data.sexo || '';
        if (data.sexo) document.getElementById('cfgSexo').value = data.sexo;
        overlay.dataset.correo = data.correo || '';
        const botonDefinir = document.querySelector('#cfgObjetivoGroup .pill[data-objetivo="definir"]');
        if (botonDefinir) botonDefinir.disabled = data.edad >= 15 && data.edad <= 17;
      }
    } catch (err) {
      console.error('No se pudieron cargar tus datos para Configuración', err);
    }

    try {
      const perfil = await api.get('./api/profile-visibility');
      marcarPerfilCfg(perfil && perfil.publico ? 'publico' : 'privado');
    } catch (err) {
      console.error('No se pudo cargar la visibilidad del perfil', err);
      marcarPerfilCfg('privado');
    }

    overlay.hidden = false;
  });

  document.getElementById('settingsForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post('./api/biometrics', {
        nombre: document.getElementById('cfgNombre').value.trim(),
        apellido: document.getElementById('cfgApellido').value.trim(),
        correo: overlay.dataset.correo || '',
        peso: parseFloat(document.getElementById('cfgPeso').value) || null,
        estatura: parseFloat(document.getElementById('cfgEstatura').value) || null,
        edad: parseInt(document.getElementById('cfgEdad').value, 10) || null,
        actividad: document.getElementById('cfgActividad').value,
        sexo: document.getElementById('cfgSexo').value || overlay.dataset.sexo || null,
        objetivo: objetivoCfg
      });
      await api.post('./api/profile-visibility', { publico: perfilCfg === 'publico' });
      await api.post('./api/settings', {
        planAutoUpdate: estaActivo('planAutoToggle'),
        planConfirm: estaActivo('planConfirmToggle'),
        recordarAgua: estaActivo('recordarAguaToggle'),
        recordarComidas: estaActivo('recordarComidasToggle'),
        horaAgua: document.getElementById('horaAgua').value || '10:00',
        horaComidas: document.getElementById('horaComidas').value || '13:00',
        tema: window.NutriTema ? window.NutriTema.get() : 'claro',
        idioma: window.NutriIdioma ? window.NutriIdioma.get() : 'es',
        tamanoLetra: window.NutriLetra ? window.NutriLetra.get() : 'normal'
      });
      await api.post('./api/recordatorios', {
        agua: document.getElementById('recordarAguaToggle').classList.contains('active'),
        entreno: document.getElementById('recordarEntrenoToggle').classList.contains('active')
      });
    } catch (err) {
      console.error('No se pudieron guardar tus cambios', err);
      return;
    }
    window.location.reload();
  });

  document.getElementById('exportDataBtn').addEventListener('click', async () => {
    try {
      const datos = await api.get('./api/account/export');
      const blob = new Blob([JSON.stringify(datos, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const enlace = document.createElement('a');
      enlace.href = url;
      enlace.download = 'mis-datos-nutriamigo.json';
      document.body.appendChild(enlace);
      enlace.click();
      enlace.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('No se pudieron descargar tus datos', err);
    }
  });

  document.getElementById('deleteAccountBtn').addEventListener('click', async () => {
    const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);
    const palabra = t('settings.palabraBorrar', 'BORRAR');
    const escrita = window.prompt(t('settings.confirmaBorrar', 'Esto borra tu cuenta, tus datos y tus fotos para siempre. Para confirmar, escribe BORRAR.'));
    if (escrita === null) return;
    if (escrita.trim().toUpperCase() !== palabra.toUpperCase()) {
      window.mostrarAviso(t('err.palabra_incorrecta', 'Escribe la palabra de confirmación tal como se pide'), 'error');
      return;
    }
    try {
      await api.post('./api/account/borrar', { palabra: 'BORRAR' });
    } catch (err) {
      console.error('No se pudo borrar la cuenta', err);
      return;
    }
    window.location.href = './index.html';
  });
});


document.addEventListener('nutriamigo:user-ready', (e) => {
  const aj = e.detail && e.detail.ajustes;
  if (!aj) return;
  try {
    if (aj.tema && !localStorage.getItem('nutriamigo_theme') && window.NutriTema) window.NutriTema.set(aj.tema);
    if (aj.tamanoLetra && !localStorage.getItem('nutriamigo_letra') && window.NutriLetra) window.NutriLetra.set(aj.tamanoLetra);
    if (aj.idioma && !localStorage.getItem('nutriamigo_lang') && window.NutriIdioma) window.NutriIdioma.set(aj.idioma);
  } catch (err) {
    console.error('No se pudieron aplicar tus ajustes guardados', err);
  }
});
