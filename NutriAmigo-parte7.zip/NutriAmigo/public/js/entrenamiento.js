/* Página de Entrenamiento: rutina semanal generada, meta de kilómetros, "Ya lo hice" y "Entrenar ahora". */
let usuarioActual = null;
let biometria = {};
let preferencias = null;
let semanaPlan = null;
let infoSemana = { hoy: null, dia: null, km: 0, semanaNumero: 1 };
let diaActivo = null;
let completionsHoy = [];

const G = window.GeneradorRutinas;

function perfilActual() {
  return perfilDeEntrenamiento(biometria, preferencias, !!usuarioActual.isPremium, infoSemana.semanaNumero, usuarioActual.id);
}

function generar() {
  semanaPlan = G.generarSemana(perfilActual());
}

function diaDeHoyServidor() {
  return infoSemana.dia || diaDeHoy();
}

function textoDias(n) {
  return n === 1 ? trEnt('ent.unDia', '1 día') : trEnt('ent.nDias', '{n} días', { n });
}

function renderResumen() {
  const el = document.getElementById('planSummary');
  if (!biometria.peso) {
    el.innerHTML = `${escapeHtml(trEnt('plan.sinDatos', 'Aún no has completado tus datos.'))} <a href="./onboarding.html" class="enlace-verde">${escapeHtml(trEnt('plan.completarAhora', 'Complétalos ahora'))}</a>`;
    return;
  }
  const genero = biometria.sexo === 'hombre' ? trEnt('plan.hombre', 'hombre') : trEnt('plan.mujer', 'mujer');
  el.innerHTML = `${escapeHtml(trEnt('plan.calculadoPara', 'Plan calculado para:'))} <b>${escapeHtml(genero)}</b>, <b>${escapeHtml(biometria.peso)} kg</b>, <b>${escapeHtml(biometria.estatura)} cm</b>, ${escapeHtml(trEnt('plan.actividad', 'actividad'))} <b>${escapeHtml(labelActividad(biometria.actividad))}</b>.`;
}

function renderObjetivoLabel() {
  document.getElementById('objetivoActualLabel').textContent = labelObjetivo(biometria.objetivo || 'mantener');
}

function renderKcal() {
  const kcal = calcularMetaCalorica(biometria);
  const card = document.getElementById('kcalCard');
  if (kcal) {
    card.style.display = 'block';
    document.getElementById('kcalValue').textContent = `${kcal.toLocaleString('es-CO')} kcal`;
  } else {
    card.style.display = 'none';
  }
}

function renderTuSemana() {
  const r = semanaPlan.resumen;
  const meta = r.kmSemana;
  let km = '';
  if (meta > 0) {
    const pct = Math.min(100, Math.round((infoSemana.km / meta) * 100));
    km = `
      <div class="meta-km">
        <p>${escapeHtml(trEnt('ent.metaKm', 'Meta de la semana: {meta} km', { meta }))} · <b>${escapeHtml(trEnt('ent.kmAvance', '{km} de {meta} km', { km: infoSemana.km, meta }))}</b></p>
        <div class="barra-km" role="progressbar" aria-valuemin="0" aria-valuemax="${meta}" aria-valuenow="${Math.min(infoSemana.km, meta)}" aria-label="${escapeHtml(trEnt('ent.kmAvance', '{km} de {meta} km', { km: infoSemana.km, meta }))}"><span style="width:${pct}%"></span></div>
        ${infoSemana.km >= meta ? `<p class="meta-cumplida">${escapeHtml(trEnt('ent.metaCumplida', '¡Cumpliste la meta de kilómetros de esta semana!'))}</p>` : ''}
      </div>`;
  } else {
    km = `<p class="section-sub">${escapeHtml(trEnt('ent.sinPlanCarrera', 'Sin plan de carrera: elige una distancia en Personalizar.'))}</p>`;
  }
  document.getElementById('weekCard').innerHTML = `
    <h3>${escapeHtml(trEnt('ent.tuSemana', 'Tu semana'))} <span class="etiqueta-semana">${escapeHtml(trEnt('ent.semanaN', 'Semana {n} del plan', { n: semanaPlan.semanaNumero }))}</span></h3>
    <p class="section-sub">${escapeHtml(trEnt('ent.resumenDias', '{e} días de entrenamiento y {d} de descanso activo', { e: r.diasEntrenamiento, d: r.diasDescansoActivo }))}</p>
    ${km}
    ${usuarioActual.isPremium ? '' : `<p class="section-sub">${escapeHtml(trEnt('ent.estandar', 'Rutina estándar: 3 días, cuerpo completo, en casa.'))}</p>`}`;

  const notas = [];
  if (semanaPlan.avisos.includes('semanaDescarga')) notas.push(trEnt('ent.descarga', 'Semana de descarga.'));
  if (semanaPlan.avisos.includes('supervisionMenor')) notas.push(trEnt('ent.supervision', 'Entrena con la supervisión de un adulto.'));
  const caja = document.getElementById('weekNotes');
  caja.textContent = notas.join(' ');
  caja.hidden = notas.length === 0;
}

function renderTabs() {
  const wrap = document.getElementById('weekTabs');
  wrap.innerHTML = semanaPlan.dias.map(d => {
    const activo = d.dia === diaActivo;
    const hoyMarca = d.dia === diaDeHoyServidor() ? ' · ' + escapeHtml(trEnt('ent.hoyEtiqueta', 'Hoy')) : '';
    return `<button type="button" role="tab" aria-selected="${activo}" class="week-tab ${activo ? 'active' : ''}" data-dia="${d.dia}">${escapeHtml(labelDia(d.dia, false))}${hoyMarca}</button>`;
  }).join('');
  wrap.querySelectorAll('.week-tab').forEach(btn => {
    btn.addEventListener('click', () => { diaActivo = btn.dataset.dia; renderTabs(); renderDia(); });
  });
}

function bloqueEjercicios(titulo, items) {
  if (!items.length) return '';
  const filas = items.map(it => {
    const ej = G.ejercicioPorId(it.id);
    const idioma = idiomaActivo();
    const pasos = (ej.pasos[idioma] || ej.pasos.es).map(p => `<li>${escapeHtml(p)}</li>`).join('');
    const errores = (ej.errores[idioma] || ej.errores.es).map(p => `<li>${escapeHtml(p)}</li>`).join('');
    const extra = [];
    if (it.pauta) extra.push(trEnt('ent.pautaIntervalos', '{t} min trote / {c} min caminata', { t: it.pauta.trote, c: it.pauta.caminata }));
    if (it.descansoSeg) extra.push(trEnt('ent.descanso', 'descanso {s} s', { s: it.descansoSeg }));
    if (it.cargaSugeridaPct) extra.push(trEnt('ent.cargaSugerida', '+{p} % de carga sugerida', { p: it.cargaSugeridaPct }));
    return `
      <details class="ejercicio">
        <summary><span class="ejercicio-nombre">${escapeHtml(nombreEjercicio(it.id))}${it.enfoque ? ' ★' : ''}</span><span class="ejercicio-cantidad">${escapeHtml(textoCantidad(it))}</span></summary>
        ${extra.length ? `<p class="ejercicio-extra">${escapeHtml(extra.join(' · '))}</p>` : ''}
        <h5>${escapeHtml(trEnt('ent.pasos', 'Pasos'))}</h5><ol>${pasos}</ol>
        <h5>${escapeHtml(trEnt('ent.errores', 'Errores comunes'))}</h5><ul>${errores}</ul>
      </details>`;
  }).join('');
  return `<div class="bloque-ejercicios"><h5 class="bloque-titulo">${escapeHtml(titulo)}</h5>${filas}</div>`;
}

function renderDia() {
  const dia = semanaPlan.dias.find(d => d.dia === diaActivo) || semanaPlan.dias[0];
  const itemKey = `entrenamiento-${dia.dia}`;
  const esHoy = dia.dia === diaDeHoyServidor();
  const hecho = completionsHoy.includes(itemKey);
  const etiquetaHecho = hecho ? trEnt('plan.hechoHoy', '✓ Hecho hoy') : trEnt('plan.yaLoHice', 'Ya lo hice');

  document.getElementById('daySlots').innerHTML = `
    <div class="slot-card dia-entreno">
      <div class="slot-card-header">
        <h4>${escapeHtml(nombreSesion(dia))} · ${escapeHtml(trEnt('ent.duracion', 'Duración estimada: {min} min', { min: dia.duracionMin }))}</h4>
        <div class="dia-acciones">
          ${esHoy && hecho ? `<button type="button" class="btn btn-ghost" id="reiniciarBtn">${escapeHtml(trEnt('ent.reiniciar', 'Reiniciar'))}</button>` : ''}
          <button type="button" class="done-toggle ${hecho ? 'done' : ''}" id="hechoBtn" ${esHoy ? '' : 'disabled aria-disabled="true"'} title="${esHoy ? '' : escapeHtml(trEnt('ent.soloHoy', 'Solo puedes marcar el día de hoy.'))}">${escapeHtml(etiquetaHecho)}</button>
        </div>
      </div>
      ${esHoy ? '' : `<p class="section-sub">${escapeHtml(trEnt('ent.soloHoy', 'Solo puedes marcar el día de hoy.'))}</p>`}
      ${bloqueEjercicios(trEnt('ent.calentamiento', 'Calentamiento'), dia.calentamiento)}
      ${bloqueEjercicios(trEnt('ent.principal', 'Bloque principal'), dia.principal)}
      ${bloqueEjercicios(trEnt('ent.cardio', 'Cardio'), dia.cardio ? [dia.cardio] : [])}
      ${bloqueEjercicios(trEnt('ent.enfriamiento', 'Enfriamiento'), dia.enfriamiento)}
    </div>`;

  const boton = document.getElementById('hechoBtn');
  if (esHoy) boton.addEventListener('click', () => marcarHoy(itemKey));
  const reiniciar = document.getElementById('reiniciarBtn');
  if (reiniciar) reiniciar.addEventListener('click', reiniciarHoy);
}

async function marcarHoy(itemKey) {
  try {
    const data = await api.post('./api/completions', { itemKey });
    if (data.completado) completionsHoy.push(itemKey);
    else completionsHoy = completionsHoy.filter(k => k !== itemKey);
  } catch (err) {
    console.error('No se pudo registrar como completado', err);
  }
  renderDia();
}

async function reiniciarHoy() {
  try {
    await api.post('./api/completions/reiniciar', { tipo: 'entrenamiento' });
    completionsHoy = completionsHoy.filter(k => !k.startsWith('entrenamiento-'));
    window.mostrarAviso(trEnt('ent.reiniciado', 'Se reiniciaron las marcas de hoy.'), 'exito');
  } catch (err) {
    console.error('No se pudo reiniciar', err);
  }
  renderDia();
}

async function cargarTodo() {
  const [bio, prefs, sem, comp] = await Promise.all([
    api.get('./api/biometrics', { silencioso: true }).catch(() => null),
    api.get('./api/preferences', { silencioso: true }).catch(() => null),
    api.get('./api/entrenamiento/semana', { silencioso: true }).catch(() => null),
    api.get('./api/completions', { silencioso: true }).catch(() => [])
  ]);
  biometria = bio || {};
  preferencias = prefs;
  if (sem) infoSemana = sem;
  completionsHoy = comp || [];
}

function rellenarFormulario() {
  const sel = document.getElementById('frecuenciaSemanal');
  sel.innerHTML = [1, 2, 3, 4, 5, 6, 7].map(n => `<option value="${n}">${escapeHtml(textoDias(n))}</option>`).join('');
  document.getElementById('objetivoSoloLectura').value = labelObjetivo(biometria.objetivo || 'mantener');
  const p = preferencias || {};
  sel.value = String(p.frecuenciaSemanal || 3);
  document.getElementById('distanciaKm').value = p.distanciaKm || '';
  document.getElementById('enfoqueMuscular').value = p.enfoqueMuscular || 'cuerpo_completo';
  document.getElementById('nivelEntreno').value = p.nivel || nivelPorActividad(biometria.actividad);
  document.getElementById('lugarEntreno').value = p.lugar || 'casa';
  document.getElementById('menorNota').hidden = !(biometria.edad >= 15 && biometria.edad < 18);
}

function pintarTodo() {
  generar();
  renderObjetivoLabel();
  renderResumen();
  renderKcal();
  renderTuSemana();
  renderTabs();
  renderDia();
}

function sesionDeHoy() {
  return semanaPlan.dias.find(d => d.dia === diaDeHoyServidor());
}

function iniciarEntrenarAhora() {
  const sesion = sesionDeHoy();
  if (!sesion) return;
  window.EntrenarAhora.abrir({
    sesion,
    peso: biometria.peso,
    fecha: infoSemana.hoy,
    dia: sesion.dia,
    yaMarcado: completionsHoy.includes(`entrenamiento-${sesion.dia}`),
    alTerminar: async () => {
      const itemKey = `entrenamiento-${sesion.dia}`;
      try {
        await api.post('./api/completions', { itemKey, marcar: true }, { silencioso: true });
        if (!completionsHoy.includes(itemKey)) completionsHoy.push(itemKey);
        renderDia();
        return true;
      } catch (err) {
        console.error('No se pudo marcar el día desde "Entrenar ahora"', err);
        return false;
      }
    }
  });
}

document.addEventListener('nutriamigo:user-ready', async (e) => {
  usuarioActual = e.detail;
  await cargarTodo();
  diaActivo = diaDeHoyServidor();
  pintarTodo();
  rellenarFormulario();

  document.addEventListener('nutriamigo:lang-changed', pintarTodo);
  document.getElementById('downloadWorkoutBtn').addEventListener('click', () => {
    document.getElementById('printableBody').innerHTML = construirHtmlEntrenamiento(semanaPlan);
    window.print();
  });
  document.getElementById('trainNowBtn').addEventListener('click', iniciarEntrenarAhora);

  const modal = document.getElementById('personalizeModal');
  document.getElementById('personalizeBtn').addEventListener('click', () => {
    if (!usuarioActual.isPremium) { window.location.href = './premium.html'; return; }
    rellenarFormulario();
    modal.hidden = false;
  });
  document.getElementById('closeModalBtn').addEventListener('click', () => { modal.hidden = true; });

  document.getElementById('personalizeForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const distancia = parseFloat(document.getElementById('distanciaKm').value);
    try {
      await api.post('./api/preferences', {
        frecuenciaSemanal: parseInt(document.getElementById('frecuenciaSemanal').value, 10),
        distanciaKm: Number.isFinite(distancia) ? distancia : 0,
        enfoqueMuscular: document.getElementById('enfoqueMuscular').value,
        nivel: document.getElementById('nivelEntreno').value,
        lugar: document.getElementById('lugarEntreno').value
      });
      modal.hidden = true;
      await cargarTodo();
      pintarTodo();
      window.mostrarAviso(trEnt('ent.guardado', 'Preferencias guardadas.'), 'exito');
    } catch (err) {
      console.error('No se pudieron guardar tus preferencias', err);
    }
  });
});
