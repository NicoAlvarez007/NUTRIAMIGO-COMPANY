/* Recordatorios — nivel básico.
   Funcionan solo mientras esta pestaña sigue abierta. Si el navegador no deja mostrar notificaciones,
   el aviso aparece dentro de la página. Para que lleguen con la pestaña cerrada haría falta la Push API
   real (claves VAPID + service worker + servidor con web-push), que queda para la etapa externa. */

const NUTRIAMIGO_RECORDATORIOS_CHECK_MS = 60 * 1000;       // revisa cada minuto
const NUTRIAMIGO_AGUA_INTERVALO_MS = 2 * 60 * 60 * 1000;   // agua cada 2 horas desde la hora elegida
const NUTRIAMIGO_ENTRENO_HORA = 18;                        // aviso diario de entreno, 6 pm hora local

function nutriamigoAvisar(titulo, cuerpo) {
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(titulo, { body: cuerpo, icon: './assets/logo.png' });
      return true;
    } catch (e) {
      console.error('No se pudo mostrar la notificación', e);
    }
  }
  if (window.mostrarAviso) window.mostrarAviso(`${titulo} ${cuerpo}`, 'info', 9000);
  return false;
}
window.nutriamigoAvisar = nutriamigoAvisar;

function nutriamigoMinutosDelDia(hhmm) {
  const [h, m] = String(hhmm || '').split(':').map(Number);
  return Number.isFinite(h) && Number.isFinite(m) ? h * 60 + m : null;
}

document.addEventListener('nutriamigo:user-ready', (e) => {
  const user = e.detail;
  if (!user) return;
  const t = (clave, es) => (window.NutriIdioma ? window.NutriIdioma.t(clave, es) : es);

  let ultimaAguaTS = Date.now();   // no molestar apenas se abre la pestaña
  const avisadoHoy = { comidas: '', entreno: '' };

  setInterval(() => {
    const actual = window.__nutriamigoUser || user;
    const ajustes = actual.ajustes || {};
    const ahora = new Date();
    const minutos = ahora.getHours() * 60 + ahora.getMinutes();
    const hoy = ahora.toISOString().slice(0, 10);

    if (ajustes.recordarAgua || actual.recordarAgua) {
      const desde = nutriamigoMinutosDelDia(ajustes.horaAgua) ?? 0;
      if (minutos >= desde && Date.now() - ultimaAguaTS >= NUTRIAMIGO_AGUA_INTERVALO_MS) {
        ultimaAguaTS = Date.now();
        nutriamigoAvisar(t('rec.aguaTitulo', 'Hora de tomar agua 💧'), t('rec.aguaCuerpo', 'Toma un vaso de agua y regístralo en tu panel.'));
      }
    }

    if (ajustes.recordarComidas && avisadoHoy.comidas !== hoy) {
      const hora = nutriamigoMinutosDelDia(ajustes.horaComidas);
      if (hora !== null && minutos >= hora && minutos < hora + 30) {
        avisadoHoy.comidas = hoy;
        nutriamigoAvisar(t('rec.comidaTitulo', 'Hora de comer 🍽️'), t('rec.comidaCuerpo', 'Mira tu plan de comidas de hoy en NutriAmigo.'));
      }
    }

    if (actual.recordarEntreno && ahora.getHours() === NUTRIAMIGO_ENTRENO_HORA && avisadoHoy.entreno !== hoy) {
      avisadoHoy.entreno = hoy;
      nutriamigoAvisar(t('rec.entrenoTitulo', '¿Ya entrenaste hoy? 🏋️'), t('rec.entrenoCuerpo', 'No olvides tu rutina de hoy en NutriAmigo.'));
    }
  }, NUTRIAMIGO_RECORDATORIOS_CHECK_MS);
});
