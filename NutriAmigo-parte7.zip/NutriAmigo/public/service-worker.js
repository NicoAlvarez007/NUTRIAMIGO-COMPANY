const CACHE_NAME = 'nutriamigo-v24';
const CORE_ASSETS = [
  './', './index.html', './dashboard.html', './onboarding.html', './alimentacion.html',
  './entrenamiento.html', './comunidad.html', './premium.html', './acceso.html', './google-simulado.html', './suspendida.html',
  './manifest.json',
  './css/styles.css', './css/fonts.css', './css/responsive.css', './css/app.css', './css/chat.css', './css/onboarding.css', './css/acceso.css', './css/entrenar.css', './css/dashboard.css', './css/community.css',
  './js/tema-inicial.js', './js/nav.js', './js/ui.js', './js/i18n.js', './js/avisos.js', './js/api.js',
  './js/script.js', './js/app.js', './js/settings.js', './js/reminders.js', './js/ads.js',
  './js/calorias.js', './js/plan-shared.js', './js/dashboard.js', './js/alimentacion.js',
  './js/entrenamiento.js', './js/comunidad.js', './js/onboarding.js', './js/premium.js', './js/acceso.js', './js/entrenar-ahora.js', './js/graficas.js', './js/generador-rutinas.js', './data/ejercicios.js', './js/google-simulado.js', './js/suspendida.js', './js/index-sesion.js',
  './js/faq-bot.js', './js/pwa.js',
  './data/meals.js', './data/meals.i18n.js',
  './data/faq.js', './data/faq.i18n.js',
  './assets/logo.png', './assets/icon-192.png', './assets/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

/* Red primero con respaldo en caché; solo las navegaciones caen a index.html. */
self.addEventListener('fetch', (event) => {
  const peticion = event.request;
  if (peticion.method !== 'GET') return;
  const url = new URL(peticion.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/auth/') || url.pathname.startsWith('/socket.io/')) return;

  event.respondWith(
    fetch(peticion)
      .then((respuesta) => {
        if (respuesta.ok) {
          const copia = respuesta.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(peticion, copia));
        }
        return respuesta;
      })
      .catch(() => caches.match(peticion).then((cacheada) => {
        if (cacheada) return cacheada;
        if (peticion.mode === 'navigate') return caches.match('./index.html');
        return Response.error();
      }))
  );
});
