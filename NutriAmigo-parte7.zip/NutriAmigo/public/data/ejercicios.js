/* Biblioteca de ejercicios. Cada uno trae nombre y pasos en es/en/de.
   `equipo: []` significa sin equipo; en "casa" solo se piden objetos caseros (silla, mochila, botellas, toalla, escalón).
   `videoUrl` queda en null hasta la etapa externa. Los pasos y errores son orientativos y no reemplazan a un profesional. */
const EJERCICIOS = [
 {
  "id": "sentadilla_libre",
  "nombre": {
   "es": "Sentadilla libre",
   "en": "Bodyweight squat",
   "de": "Kniebeuge ohne Gewicht"
  },
  "musculo": "piernas",
  "patron": "sentadilla",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Pies al ancho de los hombros, pecho arriba.",
    "Baja llevando la cadera atrás, como si te sentaras.",
    "Sube empujando el suelo con todo el pie."
   ],
   "en": [
    "Feet shoulder-width apart, chest up.",
    "Lower your hips back as if sitting down.",
    "Stand up by pushing through your whole foot."
   ],
   "de": [
    "Füße schulterbreit, Brust aufrecht.",
    "Senke die Hüfte nach hinten, als würdest du dich setzen.",
    "Drücke dich mit dem ganzen Fuß nach oben."
   ]
  },
  "errores": {
   "es": [
    "Las rodillas se van hacia adentro.",
    "Los talones se levantan del suelo."
   ],
   "en": [
    "Knees cave inward.",
    "Heels lift off the floor."
   ],
   "de": [
    "Die Knie fallen nach innen.",
    "Die Fersen heben vom Boden ab."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "sentadilla_silla",
  "nombre": {
   "es": "Sentadilla a la silla",
   "en": "Chair squat",
   "de": "Kniebeuge zum Stuhl"
  },
  "musculo": "piernas",
  "patron": "sentadilla",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "silla"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Colócate frente a una silla firme, de espaldas a ella.",
    "Baja hasta rozar el asiento y sube sin dejarte caer.",
    "Mantén la espalda recta."
   ],
   "en": [
    "Stand in front of a sturdy chair, facing away from it.",
    "Lower until you lightly touch the seat, then stand up without dropping.",
    "Keep your back straight."
   ],
   "de": [
    "Stelle dich mit dem Rücken vor einen stabilen Stuhl.",
    "Senke dich, bis du den Sitz leicht berührst, und stehe ohne Fallenlassen auf.",
    "Halte den Rücken gerade."
   ]
  },
  "errores": {
   "es": [
    "Dejarse caer de golpe en la silla.",
    "Inclinar demasiado el tronco hacia delante."
   ],
   "en": [
    "Dropping heavily onto the chair.",
    "Leaning the torso too far forward."
   ],
   "de": [
    "Sich schwer auf den Stuhl fallen lassen.",
    "Den Oberkörper zu weit nach vorn neigen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "sentadilla_mochila",
  "nombre": {
   "es": "Sentadilla con mochila al pecho",
   "en": "Backpack goblet squat",
   "de": "Kniebeuge mit Rucksack vor der Brust"
  },
  "musculo": "piernas",
  "patron": "sentadilla",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "mochila"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Sostén la mochila cargada contra el pecho con ambas manos.",
    "Baja con la espalda recta hasta que los muslos queden paralelos al suelo.",
    "Sube con control."
   ],
   "en": [
    "Hold a loaded backpack against your chest with both hands.",
    "Lower with a straight back until your thighs are parallel to the floor.",
    "Stand up under control."
   ],
   "de": [
    "Halte den beladenen Rucksack mit beiden Händen an die Brust.",
    "Senke dich mit geradem Rücken, bis die Oberschenkel parallel zum Boden sind.",
    "Komm kontrolliert hoch."
   ]
  },
  "errores": {
   "es": [
    "Redondear la espalda al bajar.",
    "Usar una mochila tan pesada que pierdes la técnica."
   ],
   "en": [
    "Rounding the back on the way down.",
    "Using a backpack so heavy that your form breaks."
   ],
   "de": [
    "Den Rücken beim Abwärtsgehen runden.",
    "Einen so schweren Rucksack nehmen, dass die Technik leidet."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "zancada_atras",
  "nombre": {
   "es": "Zancada hacia atrás",
   "en": "Reverse lunge",
   "de": "Ausfallschritt rückwärts"
  },
  "musculo": "piernas",
  "patron": "unilateral",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Da un paso largo hacia atrás con una pierna.",
    "Baja hasta que ambas rodillas formen casi 90°.",
    "Empuja con la pierna de adelante para volver y alterna."
   ],
   "en": [
    "Take a long step back with one leg.",
    "Lower until both knees reach about 90°.",
    "Push through the front leg to return, then switch."
   ],
   "de": [
    "Mache mit einem Bein einen großen Schritt zurück.",
    "Senke dich, bis beide Knie etwa 90° erreichen.",
    "Drücke dich mit dem vorderen Bein zurück und wechsle."
   ]
  },
  "errores": {
   "es": [
    "La rodilla delantera pasa mucho la punta del pie.",
    "Perder el equilibrio por un paso demasiado corto."
   ],
   "en": [
    "The front knee travels far past the toes.",
    "Losing balance with a step that is too short."
   ],
   "de": [
    "Das vordere Knie schiebt weit über die Zehen.",
    "Das Gleichgewicht verlieren, weil der Schritt zu kurz ist."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "zancada_caminando",
  "nombre": {
   "es": "Zancada caminando",
   "en": "Walking lunge",
   "de": "Gehende Ausfallschritte"
  },
  "musculo": "piernas",
  "patron": "unilateral",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Da un paso largo al frente y baja la rodilla de atrás hacia el suelo.",
    "Empuja con la pierna delantera y da el siguiente paso.",
    "Mantén el tronco erguido."
   ],
   "en": [
    "Take a long step forward and lower the back knee toward the floor.",
    "Push off the front leg and step into the next lunge.",
    "Keep your torso upright."
   ],
   "de": [
    "Mache einen großen Schritt nach vorn und senke das hintere Knie zum Boden.",
    "Drücke dich ab und gehe in den nächsten Schritt.",
    "Halte den Oberkörper aufrecht."
   ]
  },
  "errores": {
   "es": [
    "Pasos demasiado cortos.",
    "Golpear la rodilla de atrás contra el suelo."
   ],
   "en": [
    "Steps that are too short.",
    "Banging the back knee on the floor."
   ],
   "de": [
    "Zu kurze Schritte.",
    "Das hintere Knie auf den Boden schlagen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "sentadilla_bulgara",
  "nombre": {
   "es": "Sentadilla búlgara",
   "en": "Bulgarian split squat",
   "de": "Bulgarische Kniebeuge"
  },
  "musculo": "piernas",
  "patron": "unilateral",
  "nivel": "avanzado",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "silla"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Apoya el empeine de un pie sobre una silla firme detrás de ti.",
    "Baja en vertical con la pierna de adelante.",
    "Sube sin rebotar y cambia de pierna al terminar."
   ],
   "en": [
    "Rest the top of one foot on a sturdy chair behind you.",
    "Lower straight down on the front leg.",
    "Rise without bouncing and switch legs when done."
   ],
   "de": [
    "Lege den Fußrücken eines Fußes auf einen stabilen Stuhl hinter dir.",
    "Senke dich senkrecht auf dem vorderen Bein.",
    "Komm ohne Wippen hoch und wechsle danach das Bein."
   ]
  },
  "errores": {
   "es": [
    "Pie delantero demasiado cerca de la silla.",
    "Inclinarse hacia un lado."
   ],
   "en": [
    "Front foot too close to the chair.",
    "Leaning to one side."
   ],
   "de": [
    "Der vordere Fuß steht zu nah am Stuhl.",
    "Zur Seite neigen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "subida_escalon",
  "nombre": {
   "es": "Subida al escalón",
   "en": "Step-up",
   "de": "Step-ups"
  },
  "musculo": "piernas",
  "patron": "unilateral",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "escalon"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Pon todo un pie sobre un escalón estable.",
    "Sube empujando con esa pierna, sin impulsarte con la de abajo.",
    "Baja con control y repite en el otro lado."
   ],
   "en": [
    "Place your whole foot on a stable step.",
    "Rise by pushing with that leg, not by pushing off the lower one.",
    "Step down under control and repeat on the other side."
   ],
   "de": [
    "Stelle den ganzen Fuß auf eine stabile Stufe.",
    "Steige mit diesem Bein hoch, ohne dich mit dem unteren abzustoßen.",
    "Gehe kontrolliert hinunter und wiederhole auf der anderen Seite."
   ]
  },
  "errores": {
   "es": [
    "Escalón resbaloso o inestable.",
    "Dejarse caer al bajar."
   ],
   "en": [
    "Slippery or unstable step.",
    "Dropping down on the way back."
   ],
   "de": [
    "Rutschige oder instabile Stufe.",
    "Sich beim Hinuntergehen fallen lassen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "elevacion_talones",
  "nombre": {
   "es": "Elevación de talones",
   "en": "Calf raise",
   "de": "Wadenheben"
  },
  "musculo": "piernas",
  "patron": "pantorrilla",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "De pie, apóyate suavemente en una pared si lo necesitas.",
    "Sube sobre las puntas de los pies lo más alto que puedas.",
    "Baja despacio hasta que el talón casi toque el suelo."
   ],
   "en": [
    "Stand tall; lightly touch a wall for balance if needed.",
    "Rise onto your toes as high as you can.",
    "Lower slowly until your heels almost touch the floor."
   ],
   "de": [
    "Stehe aufrecht und stütze dich bei Bedarf leicht an einer Wand ab.",
    "Gehe so hoch wie möglich auf die Zehenspitzen.",
    "Senke die Fersen langsam, bis sie fast den Boden berühren."
   ]
  },
  "errores": {
   "es": [
    "Hacerlo muy rápido, con rebote.",
    "Doblar las rodillas para ayudarte."
   ],
   "en": [
    "Doing it too fast, with bounce.",
    "Bending the knees to help."
   ],
   "de": [
    "Zu schnell und mit Wippen ausführen.",
    "Die Knie beugen, um nachzuhelfen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "prensa_piernas",
  "nombre": {
   "es": "Prensa de piernas",
   "en": "Leg press",
   "de": "Beinpresse"
  },
  "musculo": "piernas",
  "patron": "sentadilla",
  "nivel": "principiante",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "maquina"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Siéntate con la espalda y la cadera pegadas al respaldo.",
    "Empuja la plataforma hasta casi estirar las piernas, sin bloquear las rodillas.",
    "Vuelve despacio hasta unos 90° de rodilla."
   ],
   "en": [
    "Sit with your back and hips flat against the pad.",
    "Push the platform until your legs are almost straight, without locking the knees.",
    "Return slowly to about 90° at the knee."
   ],
   "de": [
    "Setze dich mit Rücken und Hüfte fest an die Polsterung.",
    "Drücke die Plattform, bis die Beine fast gestreckt sind, ohne die Knie durchzudrücken.",
    "Gehe langsam bis etwa 90° im Knie zurück."
   ]
  },
  "errores": {
   "es": [
    "Despegar la cadera del asiento.",
    "Bloquear las rodillas al estirar."
   ],
   "en": [
    "Lifting the hips off the seat.",
    "Locking the knees at the top."
   ],
   "de": [
    "Die Hüfte vom Sitz abheben.",
    "Die Knie oben durchdrücken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "sentadilla_barra",
  "nombre": {
   "es": "Sentadilla con barra",
   "en": "Barbell back squat",
   "de": "Kniebeuge mit Langhantel"
  },
  "musculo": "piernas",
  "patron": "sentadilla",
  "nivel": "avanzado",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "barra"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto",
   "esfuerzoMaximo"
  ],
  "pasos": {
   "es": [
    "Coloca la barra sobre la parte alta de la espalda, con agarre firme.",
    "Baja con la espalda neutra hasta que los muslos queden paralelos.",
    "Sube empujando el suelo; pide a alguien que te cuide si subes carga."
   ],
   "en": [
    "Rest the bar on your upper back with a firm grip.",
    "Lower with a neutral spine until your thighs are parallel.",
    "Drive up through the floor; ask a spotter when you add load."
   ],
   "de": [
    "Lege die Stange auf den oberen Rücken und greife fest zu.",
    "Senke dich mit neutralem Rücken, bis die Oberschenkel parallel sind.",
    "Drücke dich nach oben; lass dich bei mehr Gewicht von einer Person sichern."
   ]
  },
  "errores": {
   "es": [
    "Subir más peso del que controlas.",
    "Redondear la zona lumbar."
   ],
   "en": [
    "Loading more weight than you can control.",
    "Rounding the lower back."
   ],
   "de": [
    "Mehr Gewicht nehmen, als du kontrollieren kannst.",
    "Den unteren Rücken runden."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "puente_gluteo",
  "nombre": {
   "es": "Puente de glúteo",
   "en": "Glute bridge",
   "de": "Glute Bridge"
  },
  "musculo": "gluteos",
  "patron": "bisagra",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Acuéstate boca arriba con las rodillas dobladas y los pies apoyados.",
    "Sube la cadera apretando los glúteos hasta formar una línea de hombros a rodillas.",
    "Baja despacio sin dejar caer la cadera."
   ],
   "en": [
    "Lie on your back with knees bent and feet flat.",
    "Lift your hips by squeezing your glutes until shoulders, hips and knees form a line.",
    "Lower slowly without dropping."
   ],
   "de": [
    "Lege dich auf den Rücken, Knie gebeugt, Füße flach.",
    "Hebe die Hüfte und spanne die Gesäßmuskeln an, bis Schultern, Hüfte und Knie eine Linie bilden.",
    "Senke langsam ab, ohne fallen zu lassen."
   ]
  },
  "errores": {
   "es": [
    "Arquear mucho la zona lumbar arriba.",
    "Empujar con los dedos de los pies en vez de con los talones."
   ],
   "en": [
    "Over-arching the lower back at the top.",
    "Pushing through the toes instead of the heels."
   ],
   "de": [
    "Den unteren Rücken oben zu stark überstrecken.",
    "Mit den Zehen statt mit den Fersen drücken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "puente_gluteo_una_pierna",
  "nombre": {
   "es": "Puente de glúteo a una pierna",
   "en": "Single-leg glute bridge",
   "de": "Einbeiniger Glute Bridge"
  },
  "musculo": "gluteos",
  "patron": "bisagra",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Igual que el puente normal, pero estira una pierna al aire.",
    "Sube la cadera con la pierna de apoyo sin que la pelvis gire.",
    "Baja con control y cambia de pierna."
   ],
   "en": [
    "Same as the regular bridge, but extend one leg in the air.",
    "Lift your hips with the support leg without the pelvis rotating.",
    "Lower under control and switch legs."
   ],
   "de": [
    "Wie der normale Bridge, aber ein Bein in die Luft strecken.",
    "Hebe die Hüfte mit dem Standbein, ohne dass sich das Becken dreht.",
    "Senke kontrolliert ab und wechsle das Bein."
   ]
  },
  "errores": {
   "es": [
    "La pelvis cae hacia un lado.",
    "Hacerlo con prisa."
   ],
   "en": [
    "The pelvis drops to one side.",
    "Rushing the movement."
   ],
   "de": [
    "Das Becken kippt zur Seite.",
    "Die Bewegung hastig ausführen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "peso_muerto_rumano_mochila",
  "nombre": {
   "es": "Peso muerto rumano con mochila",
   "en": "Backpack Romanian deadlift",
   "de": "Rumänisches Kreuzheben mit Rucksack"
  },
  "musculo": "gluteos",
  "patron": "bisagra",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "mochila"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Sostén la mochila frente a los muslos, rodillas ligeramente flexionadas.",
    "Lleva la cadera atrás y baja la mochila pegada a las piernas.",
    "Sube apretando los glúteos, con la espalda siempre recta."
   ],
   "en": [
    "Hold the backpack in front of your thighs, knees slightly bent.",
    "Push your hips back and lower the bag close to your legs.",
    "Rise by squeezing your glutes, back straight throughout."
   ],
   "de": [
    "Halte den Rucksack vor den Oberschenkeln, Knie leicht gebeugt.",
    "Schiebe die Hüfte nach hinten und senke den Rucksack nah an den Beinen ab.",
    "Komm hoch, indem du das Gesäß anspannst, der Rücken bleibt gerade."
   ]
  },
  "errores": {
   "es": [
    "Redondear la espalda.",
    "Separar la mochila del cuerpo."
   ],
   "en": [
    "Rounding the back.",
    "Letting the bag drift away from your body."
   ],
   "de": [
    "Den Rücken runden.",
    "Den Rucksack vom Körper weglassen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "peso_muerto_rumano_mancuernas",
  "nombre": {
   "es": "Peso muerto rumano con mancuernas",
   "en": "Dumbbell Romanian deadlift",
   "de": "Rumänisches Kreuzheben mit Kurzhanteln"
  },
  "musculo": "gluteos",
  "patron": "bisagra",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "mancuernas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Sujeta una mancuerna en cada mano frente a los muslos.",
    "Lleva la cadera atrás y baja las mancuernas rozando las piernas.",
    "Sube apretando los glúteos sin redondear la espalda."
   ],
   "en": [
    "Hold a dumbbell in each hand in front of your thighs.",
    "Push your hips back and lower the weights along your legs.",
    "Rise by squeezing your glutes without rounding your back."
   ],
   "de": [
    "Halte in jeder Hand eine Kurzhantel vor den Oberschenkeln.",
    "Schiebe die Hüfte nach hinten und senke die Hanteln an den Beinen entlang.",
    "Komm hoch und spanne das Gesäß an, ohne den Rücken zu runden."
   ]
  },
  "errores": {
   "es": [
    "Doblar demasiado las rodillas y convertirlo en sentadilla.",
    "Mirar hacia arriba y forzar el cuello."
   ],
   "en": [
    "Bending the knees too much and turning it into a squat.",
    "Looking up and straining the neck."
   ],
   "de": [
    "Die Knie zu stark beugen, sodass es eine Kniebeuge wird.",
    "Nach oben schauen und den Nacken überlasten."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "patada_gluteo",
  "nombre": {
   "es": "Patada de glúteo en cuadrupedia",
   "en": "Quadruped glute kickback",
   "de": "Gesäßkick im Vierfüßlerstand"
  },
  "musculo": "gluteos",
  "patron": "extension_cadera",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Apoya manos y rodillas, con la espalda neutra.",
    "Lleva una pierna atrás y arriba, apretando el glúteo.",
    "Baja sin tocar el suelo y repite; luego cambia."
   ],
   "en": [
    "Get on hands and knees with a neutral back.",
    "Extend one leg back and up, squeezing the glute.",
    "Lower without touching the floor and repeat; then switch."
   ],
   "de": [
    "Gehe in den Vierfüßlerstand mit neutralem Rücken.",
    "Strecke ein Bein nach hinten oben und spanne das Gesäß an.",
    "Senke ab, ohne den Boden zu berühren, und wiederhole; dann wechseln."
   ]
  },
  "errores": {
   "es": [
    "Arquear la espalda al subir la pierna.",
    "Balancear la pierna con impulso."
   ],
   "en": [
    "Arching the back as the leg lifts.",
    "Swinging the leg with momentum."
   ],
   "de": [
    "Den Rücken beim Anheben überstrecken.",
    "Das Bein mit Schwung hochwerfen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "hip_thrust_banco",
  "nombre": {
   "es": "Hip thrust en banco",
   "en": "Bench hip thrust",
   "de": "Hip Thrust an der Bank"
  },
  "musculo": "gluteos",
  "patron": "bisagra",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "banco",
   "mancuernas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Apoya la parte alta de la espalda en un banco y sostén una mancuerna sobre la cadera.",
    "Sube la cadera hasta que el tronco quede paralelo al suelo.",
    "Baja despacio y repite."
   ],
   "en": [
    "Rest your upper back on a bench and hold a dumbbell on your hips.",
    "Drive your hips up until your torso is parallel to the floor.",
    "Lower slowly and repeat."
   ],
   "de": [
    "Lege den oberen Rücken auf eine Bank und halte eine Kurzhantel auf der Hüfte.",
    "Drücke die Hüfte hoch, bis der Oberkörper parallel zum Boden ist.",
    "Senke langsam ab und wiederhole."
   ]
  },
  "errores": {
   "es": [
    "Estirar de más la espalda arriba.",
    "Poner los pies demasiado lejos o cerca."
   ],
   "en": [
    "Over-extending the back at the top.",
    "Placing the feet too far or too close."
   ],
   "de": [
    "Den Rücken oben überstrecken.",
    "Die Füße zu weit oder zu nah platzieren."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "abduccion_cadera_lateral",
  "nombre": {
   "es": "Elevación lateral de pierna acostado",
   "en": "Side-lying leg raise",
   "de": "Seitliches Beinheben im Liegen"
  },
  "musculo": "gluteos",
  "patron": "abduccion",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Acuéstate de lado con las piernas estiradas y alineadas.",
    "Sube la pierna de arriba sin girar la cadera.",
    "Baja con control y cambia de lado."
   ],
   "en": [
    "Lie on your side with legs straight and stacked.",
    "Raise the top leg without rolling your hips.",
    "Lower under control and switch sides."
   ],
   "de": [
    "Lege dich seitlich hin, Beine gestreckt und übereinander.",
    "Hebe das obere Bein, ohne die Hüfte zu drehen.",
    "Senke kontrolliert ab und wechsle die Seite."
   ]
  },
  "errores": {
   "es": [
    "Girar la cadera hacia atrás.",
    "Subir la pierna demasiado alto."
   ],
   "en": [
    "Rolling the hips backward.",
    "Lifting the leg too high."
   ],
   "de": [
    "Die Hüfte nach hinten drehen.",
    "Das Bein zu hoch anheben."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "peso_muerto_barra",
  "nombre": {
   "es": "Peso muerto con barra",
   "en": "Barbell deadlift",
   "de": "Kreuzheben mit Langhantel"
  },
  "musculo": "gluteos",
  "patron": "bisagra",
  "nivel": "avanzado",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "barra"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto",
   "esfuerzoMaximo"
  ],
  "pasos": {
   "es": [
    "Barra sobre el medio del pie, agarre justo fuera de las rodillas.",
    "Espalda neutra, pecho arriba; empuja el suelo para subir.",
    "Baja la barra pegada a las piernas y pide ayuda si subes carga."
   ],
   "en": [
    "Bar over mid-foot, grip just outside your knees.",
    "Neutral back, chest up; push the floor away to stand.",
    "Lower the bar close to your legs and ask for a spotter when adding load."
   ],
   "de": [
    "Stange über der Fußmitte, Griff knapp außerhalb der Knie.",
    "Neutraler Rücken, Brust offen; drücke den Boden weg, um aufzustehen.",
    "Senke die Stange nah an den Beinen ab und lass dich bei mehr Gewicht helfen."
   ]
  },
  "errores": {
   "es": [
    "Redondear la espalda al despegar.",
    "Tirar de la barra con los brazos."
   ],
   "en": [
    "Rounding the back off the floor.",
    "Pulling the bar with the arms."
   ],
   "de": [
    "Den Rücken beim Abheben runden.",
    "Die Stange mit den Armen ziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "flexiones_rodillas",
  "nombre": {
   "es": "Flexiones con rodillas apoyadas",
   "en": "Knee push-ups",
   "de": "Liegestütze auf den Knien"
  },
  "musculo": "pecho",
  "patron": "empuje_horizontal",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Manos bajo los hombros y rodillas en el suelo.",
    "Baja el pecho hacia el suelo con el cuerpo en línea.",
    "Empuja hasta estirar los brazos."
   ],
   "en": [
    "Hands under shoulders, knees on the floor.",
    "Lower your chest toward the floor, body in a line.",
    "Press up until your arms are straight."
   ],
   "de": [
    "Hände unter den Schultern, Knie am Boden.",
    "Senke die Brust zum Boden, der Körper bleibt in einer Linie.",
    "Drücke dich hoch, bis die Arme gestreckt sind."
   ]
  },
  "errores": {
   "es": [
    "Dejar caer la cadera.",
    "Abrir mucho los codos."
   ],
   "en": [
    "Letting the hips sag.",
    "Flaring the elbows wide."
   ],
   "de": [
    "Die Hüfte durchhängen lassen.",
    "Die Ellbogen weit abspreizen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "flexiones_inclinadas",
  "nombre": {
   "es": "Flexiones inclinadas (manos en una silla)",
   "en": "Incline push-ups",
   "de": "Schräge Liegestütze (Hände auf Stuhl)"
  },
  "musculo": "pecho",
  "patron": "empuje_horizontal",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "silla"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Apoya las manos en el borde de una silla firme o mesa.",
    "Baja el pecho hacia el borde con el cuerpo recto.",
    "Empuja para volver."
   ],
   "en": [
    "Place your hands on a sturdy chair or table edge.",
    "Lower your chest toward the edge, body straight.",
    "Press back up."
   ],
   "de": [
    "Stütze die Hände auf eine stabile Stuhl- oder Tischkante.",
    "Senke die Brust zur Kante, der Körper bleibt gerade.",
    "Drücke dich zurück nach oben."
   ]
  },
  "errores": {
   "es": [
    "Usar una silla que se mueve.",
    "Encoger los hombros hacia las orejas."
   ],
   "en": [
    "Using a chair that slides.",
    "Shrugging the shoulders to the ears."
   ],
   "de": [
    "Einen rutschenden Stuhl benutzen.",
    "Die Schultern zu den Ohren ziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "flexiones",
  "nombre": {
   "es": "Flexiones de pecho",
   "en": "Push-ups",
   "de": "Liegestütze"
  },
  "musculo": "pecho",
  "patron": "empuje_horizontal",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Manos algo más abiertas que los hombros, cuerpo en tabla.",
    "Baja el pecho a unos centímetros del suelo.",
    "Empuja hasta estirar los brazos sin perder la línea."
   ],
   "en": [
    "Hands slightly wider than shoulders, body like a plank.",
    "Lower your chest to a few centimeters from the floor.",
    "Press up until your arms are straight, keeping the line."
   ],
   "de": [
    "Hände etwas breiter als die Schultern, Körper wie ein Brett.",
    "Senke die Brust bis wenige Zentimeter über den Boden.",
    "Drücke dich hoch, bis die Arme gestreckt sind, ohne die Linie zu verlieren."
   ]
  },
  "errores": {
   "es": [
    "Cadera muy alta o muy baja.",
    "Bajar solo la mitad del recorrido."
   ],
   "en": [
    "Hips too high or too low.",
    "Only going halfway down."
   ],
   "de": [
    "Hüfte zu hoch oder zu tief.",
    "Nur die halbe Strecke absenken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "flexiones_pies_elevados",
  "nombre": {
   "es": "Flexiones con pies elevados",
   "en": "Decline push-ups",
   "de": "Liegestütze mit erhöhten Füßen"
  },
  "musculo": "pecho",
  "patron": "empuje_horizontal",
  "nivel": "avanzado",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "silla"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Pon los pies sobre una silla estable y las manos en el suelo.",
    "Baja el pecho con el cuerpo recto.",
    "Empuja con control."
   ],
   "en": [
    "Put your feet on a stable chair and hands on the floor.",
    "Lower your chest with a straight body.",
    "Press up under control."
   ],
   "de": [
    "Stelle die Füße auf einen stabilen Stuhl, die Hände auf den Boden.",
    "Senke die Brust bei geradem Körper.",
    "Drücke dich kontrolliert hoch."
   ]
  },
  "errores": {
   "es": [
    "Hundir la cadera.",
    "Usar una silla resbalosa."
   ],
   "en": [
    "Letting the hips sink.",
    "Using a slippery chair."
   ],
   "de": [
    "Die Hüfte absinken lassen.",
    "Einen rutschigen Stuhl nutzen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "fondos_silla",
  "nombre": {
   "es": "Fondos de tríceps en silla",
   "en": "Chair dips",
   "de": "Dips am Stuhl"
  },
  "musculo": "pecho",
  "patron": "empuje_vertical",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "silla"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Manos en el borde de una silla firme, piernas al frente.",
    "Baja doblando los codos hacia atrás, a unos 90°.",
    "Empuja hasta estirar los brazos."
   ],
   "en": [
    "Hands on the edge of a sturdy chair, legs in front.",
    "Lower by bending your elbows back to about 90°.",
    "Press up until your arms are straight."
   ],
   "de": [
    "Hände an der Kante eines stabilen Stuhls, Beine nach vorn.",
    "Senke dich, indem du die Ellbogen nach hinten auf etwa 90° beugst.",
    "Drücke dich hoch, bis die Arme gestreckt sind."
   ]
  },
  "errores": {
   "es": [
    "Bajar demasiado y cargar el hombro.",
    "Separar mucho la cadera de la silla."
   ],
   "en": [
    "Dropping too low and stressing the shoulder.",
    "Moving the hips far from the chair."
   ],
   "de": [
    "Zu tief absenken und die Schulter belasten.",
    "Die Hüfte weit vom Stuhl entfernen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "press_pecho_mancuernas",
  "nombre": {
   "es": "Press de pecho con mancuernas",
   "en": "Dumbbell bench press",
   "de": "Brustdrücken mit Kurzhanteln"
  },
  "musculo": "pecho",
  "patron": "empuje_horizontal",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "banco",
   "mancuernas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Acostado en el banco, mancuernas a la altura del pecho.",
    "Empuja hacia arriba hasta estirar los brazos.",
    "Baja despacio hasta sentir estiramiento en el pecho."
   ],
   "en": [
    "Lie on the bench with dumbbells at chest height.",
    "Press up until your arms are straight.",
    "Lower slowly until you feel a chest stretch."
   ],
   "de": [
    "Liege auf der Bank, Hanteln auf Brusthöhe.",
    "Drücke nach oben, bis die Arme gestreckt sind.",
    "Senke langsam ab, bis du die Dehnung in der Brust spürst."
   ]
  },
  "errores": {
   "es": [
    "Chocar las mancuernas arriba.",
    "Despegar la espalda del banco."
   ],
   "en": [
    "Clanging the dumbbells at the top.",
    "Lifting the back off the bench."
   ],
   "de": [
    "Die Hanteln oben aneinanderschlagen.",
    "Den Rücken von der Bank abheben."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "press_pecho_barra",
  "nombre": {
   "es": "Press de banca con barra",
   "en": "Barbell bench press",
   "de": "Bankdrücken mit Langhantel"
  },
  "musculo": "pecho",
  "patron": "empuje_horizontal",
  "nivel": "avanzado",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "banco",
   "barra"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto",
   "esfuerzoMaximo"
  ],
  "pasos": {
   "es": [
    "Acostado, ojos bajo la barra, pies firmes en el suelo.",
    "Baja la barra al pecho con control.",
    "Empuja hasta estirar los brazos; pide a alguien que te cuide."
   ],
   "en": [
    "Lie with eyes under the bar, feet firmly on the floor.",
    "Lower the bar to your chest under control.",
    "Press until arms are straight; use a spotter."
   ],
   "de": [
    "Liege mit den Augen unter der Stange, Füße fest am Boden.",
    "Senke die Stange kontrolliert zur Brust.",
    "Drücke, bis die Arme gestreckt sind; lass dich sichern."
   ]
  },
  "errores": {
   "es": [
    "Rebotar la barra en el pecho.",
    "Entrenar solo con mucha carga."
   ],
   "en": [
    "Bouncing the bar off the chest.",
    "Training alone with heavy load."
   ],
   "de": [
    "Die Stange von der Brust abprallen lassen.",
    "Allein mit viel Gewicht trainieren."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "remo_mochila",
  "nombre": {
   "es": "Remo con mochila inclinado",
   "en": "Backpack bent-over row",
   "de": "Vorgebeugtes Rudern mit Rucksack"
  },
  "musculo": "espalda",
  "patron": "tiron_horizontal",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "mochila"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Inclina el tronco con la espalda recta y la mochila colgando.",
    "Lleva la mochila hacia el abdomen juntando los omóplatos.",
    "Baja despacio."
   ],
   "en": [
    "Hinge forward with a straight back, backpack hanging.",
    "Pull the bag toward your belly, squeezing your shoulder blades.",
    "Lower slowly."
   ],
   "de": [
    "Beuge den Oberkörper mit geradem Rücken, der Rucksack hängt.",
    "Ziehe ihn zum Bauch und drücke die Schulterblätter zusammen.",
    "Senke langsam ab."
   ]
  },
  "errores": {
   "es": [
    "Redondear la espalda.",
    "Tirar con impulso del tronco."
   ],
   "en": [
    "Rounding the back.",
    "Using body swing to pull."
   ],
   "de": [
    "Den Rücken runden.",
    "Mit Körperschwung ziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "remo_mancuerna",
  "nombre": {
   "es": "Remo con mancuerna a una mano",
   "en": "One-arm dumbbell row",
   "de": "Einarmiges Kurzhantelrudern"
  },
  "musculo": "espalda",
  "patron": "tiron_horizontal",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "mancuernas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Apoya una mano y una rodilla en un banco o silla firme.",
    "Tira de la mancuerna hacia la cadera con el codo pegado.",
    "Baja controlado y cambia de lado."
   ],
   "en": [
    "Rest one hand and knee on a bench or sturdy chair.",
    "Pull the dumbbell toward your hip, elbow close.",
    "Lower under control and switch sides."
   ],
   "de": [
    "Stütze eine Hand und ein Knie auf Bank oder stabilen Stuhl.",
    "Ziehe die Hantel zur Hüfte, Ellbogen nah am Körper.",
    "Senke kontrolliert ab und wechsle die Seite."
   ]
  },
  "errores": {
   "es": [
    "Girar el tronco al subir.",
    "Encoger el hombro."
   ],
   "en": [
    "Twisting the torso as you lift.",
    "Shrugging the shoulder."
   ],
   "de": [
    "Den Oberkörper beim Ziehen drehen.",
    "Die Schulter hochziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "superman",
  "nombre": {
   "es": "Superman",
   "en": "Superman",
   "de": "Superman"
  },
  "musculo": "espalda",
  "patron": "extension",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Acuéstate boca abajo con los brazos estirados al frente.",
    "Levanta brazos y piernas unos centímetros del suelo.",
    "Mantén un segundo y baja con control."
   ],
   "en": [
    "Lie face down with arms extended forward.",
    "Lift arms and legs a few centimeters off the floor.",
    "Hold one second and lower under control."
   ],
   "de": [
    "Lege dich auf den Bauch, Arme nach vorn gestreckt.",
    "Hebe Arme und Beine wenige Zentimeter vom Boden.",
    "Halte eine Sekunde und senke kontrolliert ab."
   ]
  },
  "errores": {
   "es": [
    "Levantar la cabeza y forzar el cuello.",
    "Arquear demasiado la zona lumbar."
   ],
   "en": [
    "Craning the neck up.",
    "Over-arching the lower back."
   ],
   "de": [
    "Den Kopf überstrecken.",
    "Den unteren Rücken zu stark überstrecken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "remo_toalla_puerta",
  "nombre": {
   "es": "Remo con toalla en una puerta",
   "en": "Towel door row",
   "de": "Türhandtuch-Rudern"
  },
  "musculo": "espalda",
  "patron": "tiron_horizontal",
  "nivel": "intermedio",
  "lugar": [
   "casa"
  ],
  "equipo": [
   "toalla"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Anuda una toalla en el pomo de una puerta bien cerrada.",
    "Inclínate hacia atrás con los brazos estirados.",
    "Tira del cuerpo hacia la puerta juntando los omóplatos."
   ],
   "en": [
    "Tie a towel around the handle of a firmly closed door.",
    "Lean back with arms straight.",
    "Pull your body toward the door, squeezing your shoulder blades."
   ],
   "de": [
    "Binde ein Handtuch um den Griff einer fest geschlossenen Tür.",
    "Lehne dich mit gestreckten Armen zurück.",
    "Ziehe den Körper zur Tür und drücke die Schulterblätter zusammen."
   ]
  },
  "errores": {
   "es": [
    "Usar una puerta que se abre.",
    "Soltar el cuerpo de golpe."
   ],
   "en": [
    "Using a door that can open.",
    "Letting go of the body suddenly."
   ],
   "de": [
    "Eine Tür benutzen, die aufgehen kann.",
    "Den Körper plötzlich fallen lassen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "jalon_pecho",
  "nombre": {
   "es": "Jalón al pecho",
   "en": "Lat pulldown",
   "de": "Latzug"
  },
  "musculo": "espalda",
  "patron": "tiron_vertical",
  "nivel": "principiante",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "maquina"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Siéntate y agarra la barra un poco más ancho que los hombros.",
    "Tira de la barra hacia la parte alta del pecho.",
    "Sube despacio hasta estirar los brazos."
   ],
   "en": [
    "Sit and grip the bar slightly wider than shoulders.",
    "Pull the bar to your upper chest.",
    "Return slowly until your arms are straight."
   ],
   "de": [
    "Setze dich und greife die Stange etwas breiter als die Schultern.",
    "Ziehe sie zur oberen Brust.",
    "Lass langsam los, bis die Arme gestreckt sind."
   ]
  },
  "errores": {
   "es": [
    "Inclinarse mucho hacia atrás.",
    "Tirar con los brazos en vez de la espalda."
   ],
   "en": [
    "Leaning far back.",
    "Pulling with the arms instead of the back."
   ],
   "de": [
    "Sich weit zurücklehnen.",
    "Mit den Armen statt mit dem Rücken ziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "dominadas_asistidas",
  "nombre": {
   "es": "Dominadas asistidas",
   "en": "Assisted pull-ups",
   "de": "Unterstützte Klimmzüge"
  },
  "musculo": "espalda",
  "patron": "tiron_vertical",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "maquina"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Elige una asistencia que te permita controlar todo el recorrido.",
    "Tira hasta pasar la barbilla de la barra.",
    "Baja despacio hasta estirar los brazos."
   ],
   "en": [
    "Pick an assist level that lets you control the whole range.",
    "Pull until your chin passes the bar.",
    "Lower slowly until your arms are straight."
   ],
   "de": [
    "Wähle eine Unterstützung, mit der du den ganzen Weg kontrollierst.",
    "Ziehe, bis das Kinn über der Stange ist.",
    "Senke langsam, bis die Arme gestreckt sind."
   ]
  },
  "errores": {
   "es": [
    "Balancearse con impulso.",
    "Bajar de golpe."
   ],
   "en": [
    "Swinging for momentum.",
    "Dropping fast."
   ],
   "de": [
    "Mit Schwung arbeiten.",
    "Schnell herunterfallen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "remo_barra",
  "nombre": {
   "es": "Remo con barra",
   "en": "Barbell row",
   "de": "Langhantelrudern"
  },
  "musculo": "espalda",
  "patron": "tiron_horizontal",
  "nivel": "avanzado",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "barra"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto",
   "esfuerzoMaximo"
  ],
  "pasos": {
   "es": [
    "Inclínate con la espalda neutra y la barra colgando.",
    "Tira de la barra hacia el abdomen.",
    "Baja con control sin perder la postura."
   ],
   "en": [
    "Hinge with a neutral back and the bar hanging.",
    "Pull the bar toward your belly.",
    "Lower under control keeping your posture."
   ],
   "de": [
    "Beuge dich mit neutralem Rücken, die Stange hängt.",
    "Ziehe sie zum Bauch.",
    "Senke kontrolliert ab und behalte die Haltung."
   ]
  },
  "errores": {
   "es": [
    "Redondear la zona lumbar.",
    "Usar demasiada carga."
   ],
   "en": [
    "Rounding the lower back.",
    "Using too much weight."
   ],
   "de": [
    "Den unteren Rücken runden.",
    "Zu viel Gewicht nehmen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "press_hombros_botellas",
  "nombre": {
   "es": "Press de hombros con botellas",
   "en": "Bottle overhead press",
   "de": "Schulterdrücken mit Flaschen"
  },
  "musculo": "hombros",
  "patron": "empuje_vertical",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "botellas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "De pie, una botella con agua en cada mano a la altura de los hombros.",
    "Empuja hacia arriba sin arquear la espalda.",
    "Baja despacio."
   ],
   "en": [
    "Stand with a water bottle in each hand at shoulder height.",
    "Press overhead without arching your back.",
    "Lower slowly."
   ],
   "de": [
    "Stehe mit je einer Wasserflasche in der Hand auf Schulterhöhe.",
    "Drücke nach oben, ohne den Rücken zu überstrecken.",
    "Senke langsam ab."
   ]
  },
  "errores": {
   "es": [
    "Arquear la zona lumbar.",
    "Encoger los hombros."
   ],
   "en": [
    "Arching the lower back.",
    "Shrugging the shoulders."
   ],
   "de": [
    "Den unteren Rücken überstrecken.",
    "Die Schultern hochziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "press_hombros_mancuernas",
  "nombre": {
   "es": "Press de hombros con mancuernas",
   "en": "Dumbbell shoulder press",
   "de": "Schulterdrücken mit Kurzhanteln"
  },
  "musculo": "hombros",
  "patron": "empuje_vertical",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "mancuernas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Sentado o de pie, mancuernas a la altura de las orejas.",
    "Empuja hacia arriba hasta casi juntarlas.",
    "Baja con control."
   ],
   "en": [
    "Seated or standing, dumbbells at ear height.",
    "Press up until they almost touch.",
    "Lower under control."
   ],
   "de": [
    "Sitzend oder stehend, Hanteln auf Ohrhöhe.",
    "Drücke nach oben, bis sie sich fast berühren.",
    "Senke kontrolliert ab."
   ]
  },
  "errores": {
   "es": [
    "Arquear la espalda.",
    "Bajar poco recorrido."
   ],
   "en": [
    "Arching the back.",
    "Using a short range."
   ],
   "de": [
    "Den Rücken überstrecken.",
    "Zu kurzen Weg nutzen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "elevaciones_laterales",
  "nombre": {
   "es": "Elevaciones laterales",
   "en": "Lateral raises",
   "de": "Seitheben"
  },
  "musculo": "hombros",
  "patron": "abduccion",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "botellas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "De pie con una botella en cada mano y codos ligeramente flexionados.",
    "Sube los brazos a los lados hasta la altura de los hombros.",
    "Baja despacio."
   ],
   "en": [
    "Stand with a bottle in each hand, elbows slightly bent.",
    "Raise your arms out to the sides to shoulder height.",
    "Lower slowly."
   ],
   "de": [
    "Stehe mit je einer Flasche in der Hand, Ellbogen leicht gebeugt.",
    "Hebe die Arme seitlich bis auf Schulterhöhe.",
    "Senke langsam ab."
   ]
  },
  "errores": {
   "es": [
    "Subir por encima de los hombros.",
    "Balancear el tronco."
   ],
   "en": [
    "Raising above shoulder height.",
    "Swinging the torso."
   ],
   "de": [
    "Über Schulterhöhe heben.",
    "Den Oberkörper schwingen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "pike_flexion",
  "nombre": {
   "es": "Flexión en pica",
   "en": "Pike push-up",
   "de": "Pike-Liegestütz"
  },
  "musculo": "hombros",
  "patron": "empuje_vertical",
  "nivel": "avanzado",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Forma una V invertida con la cadera alta y las manos en el suelo.",
    "Baja la cabeza entre los brazos doblando los codos.",
    "Empuja de vuelta a la V."
   ],
   "en": [
    "Make an inverted V with hips high and hands on the floor.",
    "Lower your head between your arms by bending the elbows.",
    "Press back to the V."
   ],
   "de": [
    "Bilde ein umgekehrtes V mit hoher Hüfte und Händen am Boden.",
    "Senke den Kopf zwischen die Arme, indem du die Ellbogen beugst.",
    "Drücke dich zurück ins V."
   ]
  },
  "errores": {
   "es": [
    "Apoyar la cabeza con fuerza en el suelo.",
    "Perder la forma de V."
   ],
   "en": [
    "Resting heavy weight on the head.",
    "Losing the V shape."
   ],
   "de": [
    "Das Gewicht auf den Kopf legen.",
    "Die V-Form verlieren."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "face_pull_banda",
  "nombre": {
   "es": "Tirón a la cara con banda",
   "en": "Band face pull",
   "de": "Face Pull mit Band"
  },
  "musculo": "hombros",
  "patron": "tiron_horizontal",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "banda"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Sujeta una banda elástica fija a la altura del pecho.",
    "Tira hacia la cara abriendo los codos.",
    "Vuelve despacio."
   ],
   "en": [
    "Hold an elastic band anchored at chest height.",
    "Pull toward your face, elbows wide.",
    "Return slowly."
   ],
   "de": [
    "Halte ein auf Brusthöhe befestigtes Gummiband.",
    "Ziehe es mit weiten Ellbogen zum Gesicht.",
    "Gehe langsam zurück."
   ]
  },
  "errores": {
   "es": [
    "Encoger los hombros.",
    "Inclinar el cuello hacia delante."
   ],
   "en": [
    "Shrugging the shoulders.",
    "Pushing the neck forward."
   ],
   "de": [
    "Die Schultern hochziehen.",
    "Den Nacken nach vorn schieben."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "curl_biceps_mochila",
  "nombre": {
   "es": "Curl de bíceps con mochila",
   "en": "Backpack biceps curl",
   "de": "Bizepscurl mit Rucksack"
  },
  "musculo": "brazos",
  "patron": "flexion_codo",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "mochila"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Sujeta la mochila por las asas con los brazos estirados.",
    "Dobla los codos llevándola hacia el pecho.",
    "Baja despacio sin balancear el cuerpo."
   ],
   "en": [
    "Hold the backpack by its straps with arms straight.",
    "Bend your elbows to bring it toward your chest.",
    "Lower slowly without swinging."
   ],
   "de": [
    "Halte den Rucksack an den Riemen mit gestreckten Armen.",
    "Beuge die Ellbogen und führe ihn zur Brust.",
    "Senke langsam ab, ohne zu schwingen."
   ]
  },
  "errores": {
   "es": [
    "Balancear la espalda.",
    "Separar los codos del cuerpo."
   ],
   "en": [
    "Swaying the back.",
    "Letting elbows drift away."
   ],
   "de": [
    "Den Rücken schwingen.",
    "Die Ellbogen vom Körper lösen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "curl_biceps_mancuernas",
  "nombre": {
   "es": "Curl de bíceps con mancuernas",
   "en": "Dumbbell biceps curl",
   "de": "Bizepscurl mit Kurzhanteln"
  },
  "musculo": "brazos",
  "patron": "flexion_codo",
  "nivel": "principiante",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "mancuernas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "De pie, mancuernas a los lados con las palmas al frente.",
    "Sube doblando los codos sin moverlos del cuerpo.",
    "Baja controlando."
   ],
   "en": [
    "Stand with dumbbells at your sides, palms forward.",
    "Curl up bending the elbows without moving them away.",
    "Lower under control."
   ],
   "de": [
    "Stehe mit Hanteln an den Seiten, Handflächen nach vorn.",
    "Beuge die Ellbogen, ohne sie vom Körper zu lösen.",
    "Senke kontrolliert ab."
   ]
  },
  "errores": {
   "es": [
    "Usar impulso con la cadera.",
    "Bajar muy rápido."
   ],
   "en": [
    "Using hip momentum.",
    "Lowering too fast."
   ],
   "de": [
    "Mit Hüftschwung arbeiten.",
    "Zu schnell absenken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "curl_martillo",
  "nombre": {
   "es": "Curl martillo con botellas",
   "en": "Bottle hammer curl",
   "de": "Hammer-Curl mit Flaschen"
  },
  "musculo": "brazos",
  "patron": "flexion_codo",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "botellas"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "De pie con una botella con agua en cada mano, palmas mirándose.",
    "Sube doblando los codos sin girar las muñecas.",
    "Baja despacio."
   ],
   "en": [
    "Stand with a water bottle in each hand, palms facing each other.",
    "Curl up bending the elbows without rotating the wrists.",
    "Lower slowly."
   ],
   "de": [
    "Stehe mit je einer Wasserflasche in der Hand, Handflächen zueinander.",
    "Beuge die Ellbogen, ohne die Handgelenke zu drehen.",
    "Senke langsam ab."
   ]
  },
  "errores": {
   "es": [
    "Balancear el tronco.",
    "Doblar las muñecas."
   ],
   "en": [
    "Swinging the torso.",
    "Bending the wrists."
   ],
   "de": [
    "Den Oberkörper schwingen.",
    "Die Handgelenke knicken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "extension_triceps",
  "nombre": {
   "es": "Extensión de tríceps con mochila",
   "en": "Backpack overhead triceps extension",
   "de": "Trizepsstrecken mit Rucksack über Kopf"
  },
  "musculo": "brazos",
  "patron": "extension_codo",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [
   "mochila"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Sujeta una mochila cargada con ambas manos sobre la cabeza.",
    "Baja la mochila detrás de la cabeza doblando los codos.",
    "Estira los brazos sin abrir los codos."
   ],
   "en": [
    "Hold a loaded backpack overhead with both hands.",
    "Lower it behind your head by bending the elbows.",
    "Straighten without flaring the elbows."
   ],
   "de": [
    "Halte einen beladenen Rucksack mit beiden Händen über dem Kopf.",
    "Senke ihn hinter den Kopf, indem du die Ellbogen beugst.",
    "Strecke die Arme, ohne die Ellbogen abzuspreizen."
   ]
  },
  "errores": {
   "es": [
    "Abrir los codos.",
    "Arquear la espalda."
   ],
   "en": [
    "Flaring the elbows.",
    "Arching the back."
   ],
   "de": [
    "Die Ellbogen abspreizen.",
    "Den Rücken überstrecken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "flexiones_diamante",
  "nombre": {
   "es": "Flexiones diamante",
   "en": "Diamond push-ups",
   "de": "Diamant-Liegestütze"
  },
  "musculo": "brazos",
  "patron": "extension_codo",
  "nivel": "avanzado",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [
   "compuesto"
  ],
  "pasos": {
   "es": [
    "Junta las manos formando un rombo bajo el pecho.",
    "Baja con los codos cerca del cuerpo.",
    "Empuja hasta estirar los brazos."
   ],
   "en": [
    "Bring your hands together in a diamond under your chest.",
    "Lower with elbows close to your body.",
    "Press until arms are straight."
   ],
   "de": [
    "Bringe die Hände als Raute unter der Brust zusammen.",
    "Senke dich mit den Ellbogen nah am Körper.",
    "Drücke, bis die Arme gestreckt sind."
   ]
  },
  "errores": {
   "es": [
    "Cerrar demasiado los codos y forzar la muñeca.",
    "Hundir la cadera."
   ],
   "en": [
    "Forcing the wrists with narrow elbows.",
    "Sagging hips."
   ],
   "de": [
    "Die Handgelenke durch enge Ellbogen belasten.",
    "Die Hüfte durchhängen lassen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "curl_barra",
  "nombre": {
   "es": "Curl con barra",
   "en": "Barbell curl",
   "de": "Langhantelcurl"
  },
  "musculo": "brazos",
  "patron": "flexion_codo",
  "nivel": "intermedio",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "barra"
  ],
  "tipo": "fuerza",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Agarre al ancho de los hombros, brazos estirados.",
    "Sube la barra doblando los codos pegados al cuerpo.",
    "Baja controlando."
   ],
   "en": [
    "Shoulder-width grip, arms straight.",
    "Curl the bar up with elbows close to your body.",
    "Lower under control."
   ],
   "de": [
    "Griff schulterbreit, Arme gestreckt.",
    "Hebe die Stange mit den Ellbogen nah am Körper.",
    "Senke kontrolliert ab."
   ]
  },
  "errores": {
   "es": [
    "Echar la espalda hacia atrás.",
    "Usar carga excesiva."
   ],
   "en": [
    "Leaning back.",
    "Using excessive load."
   ],
   "de": [
    "Sich nach hinten lehnen.",
    "Zu viel Gewicht nutzen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "plancha",
  "nombre": {
   "es": "Plancha",
   "en": "Plank",
   "de": "Unterarmstütz"
  },
  "musculo": "core",
  "patron": "estabilidad",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "seg",
  "flags": [
   "isometrico"
  ],
  "pasos": {
   "es": [
    "Apoya antebrazos y puntas de los pies en el suelo.",
    "Mantén el cuerpo recto de cabeza a talones.",
    "Respira con calma y aprieta el abdomen."
   ],
   "en": [
    "Rest on forearms and toes.",
    "Keep your body straight from head to heels.",
    "Breathe calmly and brace your abs."
   ],
   "de": [
    "Stütze dich auf Unterarme und Zehen.",
    "Halte den Körper von Kopf bis Fuß gerade.",
    "Atme ruhig und spanne den Bauch an."
   ]
  },
  "errores": {
   "es": [
    "Hundir la cadera.",
    "Subir demasiado la cadera."
   ],
   "en": [
    "Letting the hips sag.",
    "Lifting the hips too high."
   ],
   "de": [
    "Die Hüfte durchhängen lassen.",
    "Die Hüfte zu hoch heben."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "plancha_rodillas",
  "nombre": {
   "es": "Plancha con rodillas apoyadas",
   "en": "Knee plank",
   "de": "Unterarmstütz auf den Knien"
  },
  "musculo": "core",
  "patron": "estabilidad",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "seg",
  "flags": [
   "isometrico"
  ],
  "pasos": {
   "es": [
    "Apoya antebrazos y rodillas en el suelo.",
    "Alinea hombros, cadera y rodillas.",
    "Aprieta el abdomen y respira."
   ],
   "en": [
    "Rest on forearms and knees.",
    "Align shoulders, hips and knees.",
    "Brace your abs and breathe."
   ],
   "de": [
    "Stütze dich auf Unterarme und Knie.",
    "Richte Schultern, Hüfte und Knie aus.",
    "Spanne den Bauch an und atme."
   ]
  },
  "errores": {
   "es": [
    "Dejar caer la cadera.",
    "Aguantar la respiración."
   ],
   "en": [
    "Letting the hips drop.",
    "Holding your breath."
   ],
   "de": [
    "Die Hüfte absinken lassen.",
    "Die Luft anhalten."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "plancha_lateral",
  "nombre": {
   "es": "Plancha lateral",
   "en": "Side plank",
   "de": "Seitstütz"
  },
  "musculo": "core",
  "patron": "estabilidad",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "seg",
  "flags": [
   "isometrico"
  ],
  "pasos": {
   "es": [
    "Apoya un antebrazo en el suelo con el codo bajo el hombro.",
    "Eleva la cadera hasta formar una línea recta.",
    "Mantén y cambia de lado."
   ],
   "en": [
    "Rest on one forearm with the elbow under the shoulder.",
    "Lift your hips into a straight line.",
    "Hold, then switch sides."
   ],
   "de": [
    "Stütze einen Unterarm auf, Ellbogen unter der Schulter.",
    "Hebe die Hüfte in eine gerade Linie.",
    "Halte und wechsle die Seite."
   ]
  },
  "errores": {
   "es": [
    "Dejar caer la cadera.",
    "Girar el pecho hacia el suelo."
   ],
   "en": [
    "Letting the hips drop.",
    "Rolling the chest toward the floor."
   ],
   "de": [
    "Die Hüfte absinken lassen.",
    "Die Brust zum Boden drehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "bicho_muerto",
  "nombre": {
   "es": "Bicho muerto",
   "en": "Dead bug",
   "de": "Dead Bug"
  },
  "musculo": "core",
  "patron": "antiextension",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Boca arriba, brazos al techo y rodillas a 90°.",
    "Baja el brazo contrario a la pierna sin despegar la lumbar del suelo.",
    "Vuelve y alterna."
   ],
   "en": [
    "On your back, arms to the ceiling and knees at 90°.",
    "Lower opposite arm and leg without lifting your lower back.",
    "Return and alternate."
   ],
   "de": [
    "Auf dem Rücken, Arme zur Decke, Knie 90°.",
    "Senke Arm und gegenüberliegendes Bein, ohne den unteren Rücken zu lösen.",
    "Zurück und abwechseln."
   ]
  },
  "errores": {
   "es": [
    "Despegar la lumbar del suelo.",
    "Moverse muy rápido."
   ],
   "en": [
    "Lifting the lower back.",
    "Moving too fast."
   ],
   "de": [
    "Den unteren Rücken abheben.",
    "Zu schnell bewegen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "abdominales_cortos",
  "nombre": {
   "es": "Abdominales cortos",
   "en": "Crunches",
   "de": "Crunches"
  },
  "musculo": "core",
  "patron": "flexion_tronco",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Boca arriba, rodillas dobladas y manos junto a las sienes.",
    "Sube los hombros unos centímetros contrayendo el abdomen.",
    "Baja sin soltar del todo."
   ],
   "en": [
    "On your back, knees bent, hands by your temples.",
    "Lift your shoulders a few centimeters, contracting your abs.",
    "Lower without fully relaxing."
   ],
   "de": [
    "Auf dem Rücken, Knie gebeugt, Hände an den Schläfen.",
    "Hebe die Schultern wenige Zentimeter an und spanne den Bauch an.",
    "Senke ab, ohne ganz zu entspannen."
   ]
  },
  "errores": {
   "es": [
    "Tirar del cuello con las manos.",
    "Subir demasiado el torso."
   ],
   "en": [
    "Pulling on the neck.",
    "Rising too far."
   ],
   "de": [
    "Am Nacken ziehen.",
    "Den Oberkörper zu weit anheben."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "elevacion_piernas",
  "nombre": {
   "es": "Elevación de piernas",
   "en": "Leg raises",
   "de": "Beinheben"
  },
  "musculo": "core",
  "patron": "flexion_cadera",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Boca arriba con las piernas estiradas y la lumbar pegada al suelo.",
    "Sube las piernas hasta la vertical.",
    "Baja despacio sin tocar el suelo."
   ],
   "en": [
    "On your back with legs straight and lower back pressed down.",
    "Raise your legs to vertical.",
    "Lower slowly without touching the floor."
   ],
   "de": [
    "Auf dem Rücken, Beine gestreckt, unterer Rücken am Boden.",
    "Hebe die Beine bis zur Senkrechten.",
    "Senke langsam, ohne den Boden zu berühren."
   ]
  },
  "errores": {
   "es": [
    "Arquear la lumbar al bajar.",
    "Usar impulso."
   ],
   "en": [
    "Arching the lower back on the way down.",
    "Using momentum."
   ],
   "de": [
    "Den unteren Rücken beim Absenken überstrecken.",
    "Mit Schwung arbeiten."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "bird_dog",
  "nombre": {
   "es": "Perro de caza (bird dog)",
   "en": "Bird dog",
   "de": "Bird Dog"
  },
  "musculo": "core",
  "patron": "estabilidad",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "En cuadrupedia con la espalda neutra.",
    "Estira un brazo y la pierna contraria a la vez.",
    "Vuelve y alterna sin girar la cadera."
   ],
   "en": [
    "On hands and knees with a neutral back.",
    "Extend one arm and the opposite leg together.",
    "Return and alternate without twisting the hips."
   ],
   "de": [
    "Im Vierfüßlerstand mit neutralem Rücken.",
    "Strecke einen Arm und das gegenüberliegende Bein gleichzeitig.",
    "Zurück und abwechseln, ohne die Hüfte zu drehen."
   ]
  },
  "errores": {
   "es": [
    "Girar la cadera.",
    "Subir la pierna demasiado alto."
   ],
   "en": [
    "Twisting the hips.",
    "Lifting the leg too high."
   ],
   "de": [
    "Die Hüfte drehen.",
    "Das Bein zu hoch heben."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "bicicleta_abdominal",
  "nombre": {
   "es": "Bicicleta abdominal",
   "en": "Bicycle crunch",
   "de": "Fahrrad-Crunch"
  },
  "musculo": "core",
  "patron": "rotacion",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "core",
  "unidad": "rep",
  "flags": [],
  "pasos": {
   "es": [
    "Boca arriba con manos junto a las sienes.",
    "Lleva un codo hacia la rodilla contraria mientras estiras la otra pierna.",
    "Alterna con ritmo controlado."
   ],
   "en": [
    "On your back with hands by your temples.",
    "Bring one elbow toward the opposite knee while extending the other leg.",
    "Alternate at a controlled pace."
   ],
   "de": [
    "Auf dem Rücken, Hände an den Schläfen.",
    "Führe einen Ellbogen zum gegenüberliegenden Knie und strecke das andere Bein.",
    "Wechsle in kontrolliertem Tempo."
   ]
  },
  "errores": {
   "es": [
    "Tirar del cuello.",
    "Ir demasiado rápido."
   ],
   "en": [
    "Pulling on the neck.",
    "Going too fast."
   ],
   "de": [
    "Am Nacken ziehen.",
    "Zu schnell werden."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "caminata",
  "nombre": {
   "es": "Caminata",
   "en": "Walking",
   "de": "Gehen"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "cardio",
  "unidad": "min",
  "flags": [
   "km"
  ],
  "pasos": {
   "es": [
    "Camina a un ritmo en el que puedas hablar sin ahogarte.",
    "Mantén la espalda erguida y balancea los brazos.",
    "Usa calzado cómodo."
   ],
   "en": [
    "Walk at a pace where you can talk without gasping.",
    "Keep your back upright and swing your arms.",
    "Wear comfortable shoes."
   ],
   "de": [
    "Gehe in einem Tempo, bei dem du sprechen kannst, ohne zu keuchen.",
    "Halte den Rücken aufrecht und schwinge die Arme.",
    "Trage bequeme Schuhe."
   ]
  },
  "errores": {
   "es": [
    "Empezar demasiado rápido.",
    "Mirar al suelo todo el rato."
   ],
   "en": [
    "Starting too fast.",
    "Staring at the ground."
   ],
   "de": [
    "Zu schnell anfangen.",
    "Die ganze Zeit auf den Boden schauen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "trote_suave",
  "nombre": {
   "es": "Trote suave",
   "en": "Easy jog",
   "de": "Lockerer Dauerlauf"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "cardio",
  "unidad": "min",
  "flags": [
   "km"
  ],
  "pasos": {
   "es": [
    "Trota a un ritmo cómodo, con pasos cortos.",
    "Aterriza con el pie bajo tu cuerpo.",
    "Respira de forma regular."
   ],
   "en": [
    "Jog at a comfortable pace with short steps.",
    "Land with your foot under your body.",
    "Breathe steadily."
   ],
   "de": [
    "Laufe locker mit kurzen Schritten.",
    "Setze den Fuß unter dem Körper auf.",
    "Atme gleichmäßig."
   ]
  },
  "errores": {
   "es": [
    "Dar zancadas muy largas.",
    "Aumentar mucho el ritmo de golpe."
   ],
   "en": [
    "Taking very long strides.",
    "Suddenly speeding up."
   ],
   "de": [
    "Zu große Schritte machen.",
    "Das Tempo plötzlich stark steigern."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "intervalos_trote_caminata",
  "nombre": {
   "es": "Intervalos de trote y caminata",
   "en": "Jog-walk intervals",
   "de": "Intervalle aus Joggen und Gehen"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "cardio",
  "unidad": "min",
  "flags": [
   "km",
   "intervalos"
  ],
  "pasos": {
   "es": [
    "Alterna trote suave con caminata, por ejemplo 1 minuto y 2 minutos.",
    "Repite durante el tiempo indicado.",
    "Mantén un ritmo con el que puedas respirar bien."
   ],
   "en": [
    "Alternate easy jogging with walking, for example 1 minute and 2 minutes.",
    "Repeat for the time shown.",
    "Keep a pace that lets you breathe well."
   ],
   "de": [
    "Wechsle lockeres Joggen und Gehen ab, zum Beispiel 1 und 2 Minuten.",
    "Wiederhole die angegebene Zeit.",
    "Halte ein Tempo, bei dem du gut atmen kannst."
   ]
  },
  "errores": {
   "es": [
    "Trotar demasiado rápido al inicio.",
    "Saltarse la caminata de recuperación."
   ],
   "en": [
    "Jogging too fast at the start.",
    "Skipping the walking recovery."
   ],
   "de": [
    "Zu Beginn zu schnell joggen.",
    "Die Geherholung auslassen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "saltos_tijera",
  "nombre": {
   "es": "Saltos de tijera",
   "en": "Jumping jacks",
   "de": "Hampelmann"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "cardio",
  "unidad": "seg",
  "flags": [
   "impacto"
  ],
  "pasos": {
   "es": [
    "Salta abriendo piernas y brazos a la vez.",
    "Vuelve a juntar pies y manos arriba y abajo.",
    "Mantén un ritmo constante."
   ],
   "en": [
    "Jump while spreading your legs and arms together.",
    "Return feet together and arms down.",
    "Keep a steady rhythm."
   ],
   "de": [
    "Springe und öffne Beine und Arme gleichzeitig.",
    "Bringe Füße zusammen und Arme nach unten zurück.",
    "Halte einen gleichmäßigen Rhythmus."
   ]
  },
  "errores": {
   "es": [
    "Aterrizar con las rodillas rígidas.",
    "Encorvar la espalda."
   ],
   "en": [
    "Landing with stiff knees.",
    "Slouching the back."
   ],
   "de": [
    "Mit steifen Knien landen.",
    "Den Rücken krümmen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "escaladores",
  "nombre": {
   "es": "Escaladores",
   "en": "Mountain climbers",
   "de": "Bergsteiger"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "cardio",
  "unidad": "seg",
  "flags": [
   "impacto"
  ],
  "pasos": {
   "es": [
    "Posición de flexión con los brazos estirados.",
    "Lleva una rodilla al pecho y alterna con rapidez.",
    "Mantén la cadera baja."
   ],
   "en": [
    "Start in a push-up position with straight arms.",
    "Drive one knee to your chest and alternate quickly.",
    "Keep your hips low."
   ],
   "de": [
    "Beginne in Liegestützposition mit gestreckten Armen.",
    "Ziehe ein Knie zur Brust und wechsle schnell ab.",
    "Halte die Hüfte tief."
   ]
  },
  "errores": {
   "es": [
    "Subir mucho la cadera.",
    "Apoyar mal las manos."
   ],
   "en": [
    "Hips too high.",
    "Poor hand placement."
   ],
   "de": [
    "Die Hüfte zu hoch halten.",
    "Die Hände schlecht platzieren."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "rodillas_altas",
  "nombre": {
   "es": "Rodillas altas en el sitio",
   "en": "High knees",
   "de": "Kniehebelauf"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "cardio",
  "unidad": "seg",
  "flags": [
   "impacto"
  ],
  "pasos": {
   "es": [
    "Corre en el sitio subiendo las rodillas a la altura de la cadera.",
    "Mueve los brazos al ritmo.",
    "Mantén el tronco erguido."
   ],
   "en": [
    "Run in place raising knees to hip height.",
    "Pump your arms in rhythm.",
    "Keep your torso upright."
   ],
   "de": [
    "Laufe auf der Stelle und hebe die Knie bis auf Hüfthöhe.",
    "Bewege die Arme im Rhythmus.",
    "Halte den Oberkörper aufrecht."
   ]
  },
  "errores": {
   "es": [
    "Inclinarse hacia atrás.",
    "Golpear fuerte el suelo."
   ],
   "en": [
    "Leaning back.",
    "Slamming the feet."
   ],
   "de": [
    "Sich nach hinten lehnen.",
    "Hart auf den Boden stampfen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "bici_estatica",
  "nombre": {
   "es": "Bicicleta estática",
   "en": "Stationary bike",
   "de": "Heimtrainer"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "principiante",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "maquina"
  ],
  "tipo": "cardio",
  "unidad": "min",
  "flags": [],
  "pasos": {
   "es": [
    "Ajusta el asiento para que la rodilla quede casi estirada abajo.",
    "Pedalea a un ritmo constante y cómodo.",
    "Mantén la espalda recta y los hombros relajados."
   ],
   "en": [
    "Adjust the seat so your knee is almost straight at the bottom.",
    "Pedal at a steady, comfortable pace.",
    "Keep your back straight and shoulders relaxed."
   ],
   "de": [
    "Stelle den Sattel so ein, dass das Knie unten fast gestreckt ist.",
    "Trete gleichmäßig und bequem.",
    "Halte den Rücken gerade und die Schultern locker."
   ]
  },
  "errores": {
   "es": [
    "Asiento demasiado bajo.",
    "Agarrar el manillar con tensión."
   ],
   "en": [
    "Seat too low.",
    "Gripping the handlebars tightly."
   ],
   "de": [
    "Sattel zu tief.",
    "Den Lenker verkrampft greifen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "caminadora_inclinada",
  "nombre": {
   "es": "Caminadora con inclinación",
   "en": "Incline treadmill walk",
   "de": "Gehen auf dem Laufband mit Steigung"
  },
  "musculo": "cardio",
  "patron": "cardio",
  "nivel": "principiante",
  "lugar": [
   "gimnasio"
  ],
  "equipo": [
   "maquina"
  ],
  "tipo": "cardio",
  "unidad": "min",
  "flags": [
   "km"
  ],
  "pasos": {
   "es": [
    "Pon una inclinación suave y un ritmo cómodo.",
    "Camina erguido sin agarrarte de las barras.",
    "Aumenta de a poco."
   ],
   "en": [
    "Set a gentle incline and comfortable speed.",
    "Walk upright without holding the rails.",
    "Increase gradually."
   ],
   "de": [
    "Stelle eine leichte Steigung und ein bequemes Tempo ein.",
    "Gehe aufrecht, ohne dich an den Griffen festzuhalten.",
    "Steigere dich langsam."
   ]
  },
  "errores": {
   "es": [
    "Inclinación excesiva.",
    "Agarrarse de las barras todo el tiempo."
   ],
   "en": [
    "Too much incline.",
    "Holding the rails the whole time."
   ],
   "de": [
    "Zu starke Steigung.",
    "Sich die ganze Zeit an den Griffen festhalten."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "circulos_brazos",
  "nombre": {
   "es": "Círculos de brazos",
   "en": "Arm circles",
   "de": "Armkreisen"
  },
  "musculo": "hombros",
  "patron": "calentamiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "Brazos extendidos a los lados.",
    "Haz círculos pequeños y luego más grandes.",
    "Cambia de dirección a la mitad."
   ],
   "en": [
    "Arms extended to the sides.",
    "Make small circles, then larger ones.",
    "Switch direction halfway."
   ],
   "de": [
    "Arme seitlich gestreckt.",
    "Kreise erst klein, dann größer.",
    "Wechsle auf halber Zeit die Richtung."
   ]
  },
  "errores": {
   "es": [
    "Encoger los hombros.",
    "Hacerlo con tensión."
   ],
   "en": [
    "Shrugging the shoulders.",
    "Doing it tensely."
   ],
   "de": [
    "Die Schultern hochziehen.",
    "Verkrampft ausführen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "circulos_cadera",
  "nombre": {
   "es": "Círculos de cadera",
   "en": "Hip circles",
   "de": "Hüftkreisen"
  },
  "musculo": "piernas",
  "patron": "calentamiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "Manos en la cintura y pies al ancho de los hombros.",
    "Dibuja círculos amplios con la cadera.",
    "Cambia de sentido."
   ],
   "en": [
    "Hands on your waist, feet shoulder-width apart.",
    "Draw wide circles with your hips.",
    "Switch direction."
   ],
   "de": [
    "Hände an der Taille, Füße schulterbreit.",
    "Zeichne große Kreise mit der Hüfte.",
    "Wechsle die Richtung."
   ]
  },
  "errores": {
   "es": [
    "Mover las rodillas en vez de la cadera.",
    "Ir muy rápido."
   ],
   "en": [
    "Moving the knees instead of the hips.",
    "Going too fast."
   ],
   "de": [
    "Die Knie statt der Hüfte bewegen.",
    "Zu schnell sein."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "gato_vaca",
  "nombre": {
   "es": "Gato–vaca",
   "en": "Cat–cow",
   "de": "Katze–Kuh"
  },
  "musculo": "espalda",
  "patron": "calentamiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "En cuadrupedia, arquea la espalda hacia arriba exhalando.",
    "Luego hunde la espalda inhalando y mira al frente.",
    "Alterna despacio."
   ],
   "en": [
    "On hands and knees, round your back up as you exhale.",
    "Then dip your back as you inhale and look forward.",
    "Alternate slowly."
   ],
   "de": [
    "Im Vierfüßlerstand den Rücken beim Ausatmen runden.",
    "Beim Einatmen den Rücken senken und nach vorn schauen.",
    "Wechsle langsam."
   ]
  },
  "errores": {
   "es": [
    "Moverse con prisa.",
    "Forzar el cuello."
   ],
   "en": [
    "Rushing.",
    "Straining the neck."
   ],
   "de": [
    "Zu hastig bewegen.",
    "Den Nacken überstrecken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "rotacion_toracica",
  "nombre": {
   "es": "Rotación torácica",
   "en": "Thoracic rotation",
   "de": "Brustwirbelrotation"
  },
  "musculo": "espalda",
  "patron": "calentamiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "En cuadrupedia, pon una mano detrás de la cabeza.",
    "Gira el codo hacia el techo siguiendo con la mirada.",
    "Vuelve y repite; luego cambia de lado."
   ],
   "en": [
    "On hands and knees, put one hand behind your head.",
    "Rotate that elbow to the ceiling, following with your eyes.",
    "Return and repeat; then switch sides."
   ],
   "de": [
    "Im Vierfüßlerstand eine Hand hinter den Kopf legen.",
    "Drehe den Ellbogen zur Decke und folge mit dem Blick.",
    "Zurück und wiederholen; dann Seite wechseln."
   ]
  },
  "errores": {
   "es": [
    "Mover la cadera en vez del torso.",
    "Ir con brusquedad."
   ],
   "en": [
    "Moving the hips instead of the torso.",
    "Jerky movement."
   ],
   "de": [
    "Die Hüfte statt des Oberkörpers bewegen.",
    "Ruckartig bewegen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "sentadilla_pausa",
  "nombre": {
   "es": "Sentadilla profunda con pausa",
   "en": "Deep squat hold",
   "de": "Tiefe Kniebeuge halten"
  },
  "musculo": "piernas",
  "patron": "calentamiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "Baja a una sentadilla cómoda con los codos entre las rodillas.",
    "Mantén el pecho arriba y respira.",
    "Sube despacio."
   ],
   "en": [
    "Sink into a comfortable squat with elbows between your knees.",
    "Keep your chest up and breathe.",
    "Rise slowly."
   ],
   "de": [
    "Gehe in eine bequeme Kniebeuge, Ellbogen zwischen den Knien.",
    "Halte die Brust aufrecht und atme.",
    "Komm langsam hoch."
   ]
  },
  "errores": {
   "es": [
    "Levantar los talones.",
    "Redondear mucho la espalda."
   ],
   "en": [
    "Lifting the heels.",
    "Rounding the back a lot."
   ],
   "de": [
    "Die Fersen anheben.",
    "Den Rücken stark runden."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "marcha_sitio",
  "nombre": {
   "es": "Marcha en el sitio",
   "en": "Marching in place",
   "de": "Marschieren auf der Stelle"
  },
  "musculo": "piernas",
  "patron": "calentamiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "Marcha en el sitio subiendo las rodillas.",
    "Balancea los brazos con naturalidad.",
    "Aumenta el ritmo de a poco."
   ],
   "en": [
    "March in place lifting your knees.",
    "Swing your arms naturally.",
    "Gradually increase the pace."
   ],
   "de": [
    "Marschiere auf der Stelle und hebe die Knie.",
    "Schwinge die Arme natürlich mit.",
    "Steigere das Tempo langsam."
   ]
  },
  "errores": {
   "es": [
    "Encorvarse.",
    "Empezar demasiado fuerte."
   ],
   "en": [
    "Slouching.",
    "Starting too hard."
   ],
   "de": [
    "Sich krümmen.",
    "Zu stark beginnen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "balanceo_piernas",
  "nombre": {
   "es": "Balanceo de piernas",
   "en": "Leg swings",
   "de": "Beinschwingen"
  },
  "musculo": "piernas",
  "patron": "calentamiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "Apóyate en una pared con una mano.",
    "Balancea una pierna adelante y atrás con control.",
    "Cambia de pierna."
   ],
   "en": [
    "Hold a wall with one hand.",
    "Swing one leg forward and back under control.",
    "Switch legs."
   ],
   "de": [
    "Halte dich mit einer Hand an einer Wand fest.",
    "Schwinge ein Bein kontrolliert vor und zurück.",
    "Wechsle das Bein."
   ]
  },
  "errores": {
   "es": [
    "Balancear con fuerza excesiva.",
    "Inclinar el tronco."
   ],
   "en": [
    "Swinging too hard.",
    "Leaning the torso."
   ],
   "de": [
    "Zu kräftig schwingen.",
    "Den Oberkörper neigen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "inchworm",
  "nombre": {
   "es": "Gusano (inchworm)",
   "en": "Inchworm",
   "de": "Inchworm"
  },
  "musculo": "core",
  "patron": "calentamiento",
  "nivel": "intermedio",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "rep",
  "flags": [
   "calentamiento"
  ],
  "pasos": {
   "es": [
    "De pie, inclínate y apoya las manos en el suelo.",
    "Camina con las manos hasta la posición de plancha.",
    "Camina de vuelta y ponte de pie."
   ],
   "en": [
    "Stand, hinge forward and place your hands on the floor.",
    "Walk your hands out to a plank.",
    "Walk back and stand up."
   ],
   "de": [
    "Stehe, beuge dich vor und lege die Hände auf den Boden.",
    "Gehe mit den Händen bis in den Stütz.",
    "Gehe zurück und richte dich auf."
   ]
  },
  "errores": {
   "es": [
    "Doblar mucho las rodillas.",
    "Hundir la cadera en la plancha."
   ],
   "en": [
    "Bending the knees too much.",
    "Sagging in the plank."
   ],
   "de": [
    "Die Knie zu stark beugen.",
    "Im Stütz durchhängen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_cuadriceps",
  "nombre": {
   "es": "Estiramiento de cuádriceps",
   "en": "Quad stretch",
   "de": "Dehnung des Quadrizeps"
  },
  "musculo": "piernas",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "De pie, lleva un talón hacia el glúteo y sujétalo.",
    "Mantén las rodillas juntas y la cadera al frente.",
    "Cambia de pierna."
   ],
   "en": [
    "Standing, bring one heel toward your glute and hold it.",
    "Keep your knees together and hips forward.",
    "Switch legs."
   ],
   "de": [
    "Im Stand ziehe eine Ferse zum Gesäß und halte sie.",
    "Knie zusammen, Hüfte nach vorn.",
    "Wechsle das Bein."
   ]
  },
  "errores": {
   "es": [
    "Arquear la espalda.",
    "Tirar con dolor."
   ],
   "en": [
    "Arching the back.",
    "Pulling into pain."
   ],
   "de": [
    "Den Rücken überstrecken.",
    "Mit Schmerz ziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_isquios",
  "nombre": {
   "es": "Estiramiento de isquiotibiales",
   "en": "Hamstring stretch",
   "de": "Dehnung der Beinrückseite"
  },
  "musculo": "piernas",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "Sentado, estira una pierna y flexiona la otra.",
    "Inclínate hacia el pie con la espalda larga.",
    "Mantén sin rebotar y cambia."
   ],
   "en": [
    "Sit with one leg straight and the other bent.",
    "Lean toward your foot with a long back.",
    "Hold without bouncing, then switch."
   ],
   "de": [
    "Sitze mit einem gestreckten und einem gebeugten Bein.",
    "Neige dich mit langem Rücken zum Fuß.",
    "Halte ohne Wippen und wechsle."
   ]
  },
  "errores": {
   "es": [
    "Rebotar.",
    "Redondear mucho la espalda."
   ],
   "en": [
    "Bouncing.",
    "Rounding the back a lot."
   ],
   "de": [
    "Wippen.",
    "Den Rücken stark runden."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_pecho",
  "nombre": {
   "es": "Estiramiento de pecho en la pared",
   "en": "Wall chest stretch",
   "de": "Brustdehnung an der Wand"
  },
  "musculo": "pecho",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "Apoya el antebrazo en una pared con el codo a 90°.",
    "Gira el cuerpo suavemente hacia el lado contrario.",
    "Mantén y cambia de brazo."
   ],
   "en": [
    "Rest your forearm on a wall with the elbow at 90°.",
    "Gently turn your body away.",
    "Hold, then switch arms."
   ],
   "de": [
    "Lege den Unterarm an eine Wand, Ellbogen 90°.",
    "Drehe den Körper sanft weg.",
    "Halte und wechsle den Arm."
   ]
  },
  "errores": {
   "es": [
    "Girar con demasiada fuerza.",
    "Encoger el hombro."
   ],
   "en": [
    "Turning too forcefully.",
    "Shrugging the shoulder."
   ],
   "de": [
    "Zu kräftig drehen.",
    "Die Schulter hochziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "postura_nino",
  "nombre": {
   "es": "Postura del niño",
   "en": "Child’s pose",
   "de": "Kindhaltung"
  },
  "musculo": "espalda",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "De rodillas, siéntate sobre los talones.",
    "Estira los brazos al frente apoyando la frente.",
    "Respira profundo y relaja la espalda."
   ],
   "en": [
    "Kneel and sit back on your heels.",
    "Stretch your arms forward, forehead down.",
    "Breathe deeply and relax your back."
   ],
   "de": [
    "Knie dich hin und setze dich auf die Fersen.",
    "Strecke die Arme nach vorn, Stirn ablegen.",
    "Atme tief und entspanne den Rücken."
   ]
  },
  "errores": {
   "es": [
    "Forzar si duele la rodilla.",
    "Aguantar la respiración."
   ],
   "en": [
    "Forcing it if the knee hurts.",
    "Holding your breath."
   ],
   "de": [
    "Erzwingen, wenn das Knie schmerzt.",
    "Die Luft anhalten."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_gluteo",
  "nombre": {
   "es": "Estiramiento de glúteo (figura 4)",
   "en": "Figure-4 glute stretch",
   "de": "Gesäßdehnung (Figur 4)"
  },
  "musculo": "gluteos",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "Boca arriba, cruza un tobillo sobre la rodilla contraria.",
    "Jala el muslo de abajo hacia el pecho.",
    "Mantén y cambia de lado."
   ],
   "en": [
    "On your back, cross one ankle over the opposite knee.",
    "Pull the lower thigh toward your chest.",
    "Hold, then switch sides."
   ],
   "de": [
    "Auf dem Rücken, lege einen Knöchel über das gegenüberliegende Knie.",
    "Ziehe den unteren Oberschenkel zur Brust.",
    "Halte und wechsle die Seite."
   ]
  },
  "errores": {
   "es": [
    "Levantar la cabeza con tensión.",
    "Tirar con dolor."
   ],
   "en": [
    "Lifting the head tensely.",
    "Pulling into pain."
   ],
   "de": [
    "Den Kopf angespannt anheben.",
    "Mit Schmerz ziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_hombro",
  "nombre": {
   "es": "Estiramiento de hombro cruzado",
   "en": "Cross-body shoulder stretch",
   "de": "Schulterdehnung quer"
  },
  "musculo": "hombros",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "Lleva un brazo estirado a través del pecho.",
    "Sujétalo con el otro brazo sin girar el torso.",
    "Mantén y cambia."
   ],
   "en": [
    "Bring one straight arm across your chest.",
    "Hold it with the other arm without twisting.",
    "Hold, then switch."
   ],
   "de": [
    "Führe einen gestreckten Arm quer vor die Brust.",
    "Halte ihn mit dem anderen Arm, ohne zu drehen.",
    "Halte und wechsle."
   ]
  },
  "errores": {
   "es": [
    "Subir el hombro.",
    "Tirar con fuerza."
   ],
   "en": [
    "Raising the shoulder.",
    "Pulling hard."
   ],
   "de": [
    "Die Schulter hochziehen.",
    "Kräftig ziehen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_pantorrilla",
  "nombre": {
   "es": "Estiramiento de pantorrilla",
   "en": "Calf stretch",
   "de": "Wadendehnung"
  },
  "musculo": "piernas",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "Apoya las manos en una pared y retrasa una pierna.",
    "Mantén el talón de atrás en el suelo.",
    "Dobla la rodilla de adelante y cambia."
   ],
   "en": [
    "Put your hands on a wall and step one leg back.",
    "Keep the back heel on the floor.",
    "Bend the front knee, then switch."
   ],
   "de": [
    "Stütze die Hände an die Wand und stelle ein Bein zurück.",
    "Die hintere Ferse bleibt am Boden.",
    "Beuge das vordere Knie und wechsle."
   ]
  },
  "errores": {
   "es": [
    "Levantar el talón.",
    "Rebotar."
   ],
   "en": [
    "Lifting the heel.",
    "Bouncing."
   ],
   "de": [
    "Die Ferse anheben.",
    "Wippen."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_triceps",
  "nombre": {
   "es": "Estiramiento de tríceps",
   "en": "Triceps stretch",
   "de": "Trizepsdehnung"
  },
  "musculo": "brazos",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "Lleva un codo hacia arriba y la mano detrás de la cabeza.",
    "Con la otra mano empuja suavemente el codo.",
    "Mantén y cambia de brazo."
   ],
   "en": [
    "Raise one elbow with the hand behind your head.",
    "Gently push the elbow with the other hand.",
    "Hold, then switch arms."
   ],
   "de": [
    "Hebe einen Ellbogen, die Hand liegt hinter dem Kopf.",
    "Drücke den Ellbogen sanft mit der anderen Hand.",
    "Halte und wechsle den Arm."
   ]
  },
  "errores": {
   "es": [
    "Arquear la espalda.",
    "Empujar con brusquedad."
   ],
   "en": [
    "Arching the back.",
    "Pushing abruptly."
   ],
   "de": [
    "Den Rücken überstrecken.",
    "Ruckartig drücken."
   ]
  },
  "videoUrl": null
 },
 {
  "id": "estiramiento_cuello",
  "nombre": {
   "es": "Estiramiento suave de cuello",
   "en": "Gentle neck stretch",
   "de": "Sanfte Nackendehnung"
  },
  "musculo": "core",
  "patron": "estiramiento",
  "nivel": "principiante",
  "lugar": [
   "casa",
   "gimnasio"
  ],
  "equipo": [],
  "tipo": "movilidad",
  "unidad": "seg",
  "flags": [
   "enfriamiento"
  ],
  "pasos": {
   "es": [
    "Sentado o de pie, inclina la oreja hacia el hombro.",
    "Deja que el peso de la cabeza estire suavemente.",
    "Mantén y cambia de lado."
   ],
   "en": [
    "Seated or standing, tilt your ear toward your shoulder.",
    "Let the weight of your head stretch gently.",
    "Hold, then switch sides."
   ],
   "de": [
    "Sitzend oder stehend, neige das Ohr zur Schulter.",
    "Lass das Gewicht des Kopfes sanft dehnen.",
    "Halte und wechsle die Seite."
   ]
  },
  "errores": {
   "es": [
    "Tirar de la cabeza con la mano.",
    "Subir el hombro."
   ],
   "en": [
    "Pulling the head with your hand.",
    "Raising the shoulder."
   ],
   "de": [
    "Den Kopf mit der Hand ziehen.",
    "Die Schulter hochziehen."
   ]
  },
  "videoUrl": null
 }
];

const EQUIPO_CASA = ["silla", "mochila", "botellas", "toalla", "escalon"];

if (typeof window !== 'undefined') {
  window.EJERCICIOS = EJERCICIOS;
  window.EQUIPO_CASA = EQUIPO_CASA;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { EJERCICIOS, EQUIPO_CASA };
}
