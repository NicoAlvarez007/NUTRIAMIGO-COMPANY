const crypto = require('crypto');
const { hoy, ahoraISO } = require('../../lib/fechas');

function crear(db) {
  const ALFABETO_CODIGO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  function codigoAmigoUnico() {
    for (;;) {
      let codigo = '';
      for (let i = 0; i < 8; i += 1) codigo += ALFABETO_CODIGO[crypto.randomInt(ALFABETO_CODIGO.length)];
      if (!db.prepare('SELECT 1 FROM users WHERE friend_code = ?').get(codigo)) return codigo;
    }
  }

  /* Un correo = una cuenta: se busca por id de Google y, si no está, por correo. */
  function findOrCreateUser({ googleId, name, email, avatar }) {
    const correo = email ? String(email).trim().toLowerCase() : null;
    let existente = googleId ? db.prepare('SELECT * FROM users WHERE google_id = ?').get(googleId) : null;
    if (!existente && correo) existente = db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').get(correo);
    if (existente) return existente;

    const info = db.prepare(`INSERT INTO users (google_id, name, email, avatar, auth_provider, friend_code, created_at)
      VALUES (?, ?, ?, ?, 'google', ?, ?)`)
      .run(googleId || `local:${crypto.randomUUID()}`, name, correo, avatar, codigoAmigoUnico(), ahoraISO());

    return db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  }

  function crearUsuarioConContrasena({ email, hash }) {
    const nombre = email.split('@')[0].replace(/[._-]+/g, ' ').trim().slice(0, 40) || 'Usuario';
    const info = db.prepare(`INSERT INTO users (google_id, name, email, password_hash, auth_provider, friend_code, created_at)
      VALUES (?, ?, ?, ?, 'password', ?, ?)`)
      .run(`local:${crypto.randomUUID()}`, nombre.charAt(0).toUpperCase() + nombre.slice(1), email, hash, codigoAmigoUnico(), ahoraISO());
    return db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  }

  function getUserById(id) {
    return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  }

  function touchStreak(userId) {
    const hoyStr = hoy();
    const fila = db.prepare('SELECT * FROM streaks WHERE user_id = ?').get(userId);

    if (!fila) {
      db.prepare('INSERT INTO streaks (user_id, current_streak, last_active_date) VALUES (?, 1, ?)').run(userId, hoyStr);
      return 1;
    }
    if (fila.last_active_date === hoyStr) return fila.current_streak;

    const ayer = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const nueva = fila.last_active_date === ayer ? fila.current_streak + 1 : 1;

    db.prepare('UPDATE streaks SET current_streak = ?, last_active_date = ? WHERE user_id = ?')
      .run(nueva, hoyStr, userId);
    return nueva;
  }

  function getStreak(userId) {
    const fila = db.prepare('SELECT current_streak FROM streaks WHERE user_id = ?').get(userId);
    return fila ? fila.current_streak : 0;
  }

  /* El rango se deriva de la racha actual y del total de acciones marcadas;
     hay que cumplir ambos mínimos para subir. */
  function calcularRango(streak, totalCompletions) {
    if (streak >= 46 && totalCompletions >= 90) return 'platino';
    if (streak >= 21 && totalCompletions >= 40) return 'oro';
    if (streak >= 7 && totalCompletions >= 10) return 'plata';
    return 'bronce';
  }

  function setPremium(userId, value) {
    db.prepare('UPDATE users SET is_premium = ? WHERE id = ?').run(value ? 1 : 0, userId);
  }

  function setAvisarActualizacionPlan(userId, value) {
    db.prepare('UPDATE users SET avisar_actualizacion_plan = ? WHERE id = ?').run(value ? 1 : 0, userId);
  }

  function setRecordatorios(userId, { agua, entreno }) {
    db.prepare('UPDATE users SET recordar_agua = ?, recordar_entreno = ? WHERE id = ?')
      .run(agua ? 1 : 0, entreno ? 1 : 0, userId);
  }

  function setPerfilPublico(userId, value) {
    db.prepare('UPDATE users SET perfil_publico = ? WHERE id = ?').run(value ? 1 : 0, userId);
  }

  const deleteAccount = db.transaction((userId) => {
    db.prepare('DELETE FROM progress WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM streaks WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM biometrics WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM preferences WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM preferencias_proteinas WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM reel_votes WHERE reel_id IN (SELECT id FROM reels WHERE user_id = ?)').run(userId);
    db.prepare('DELETE FROM reel_votes WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM reels WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM friend_messages WHERE friend_id IN (SELECT id FROM friends WHERE user_id = ?)').run(userId);
    db.prepare('DELETE FROM friends WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM daily_logs WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM completions WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM guardian_consents WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM progress_photos WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM wellbeing_logs WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM user_settings WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM sessions WHERE sess LIKE ?').run(`%"user":${userId}}%`);
    db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  });

  return {
    findOrCreateUser, crearUsuarioConContrasena, getUserById, touchStreak, getStreak, calcularRango, setPremium,
    setAvisarActualizacionPlan, setRecordatorios, setPerfilPublico, deleteAccount
  };
}

module.exports = { crear };
