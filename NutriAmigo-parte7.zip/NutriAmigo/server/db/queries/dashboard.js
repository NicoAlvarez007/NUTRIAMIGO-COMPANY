const { diferenciaDias } = require('../../lib/fechas');

const COLUMNAS_AJUSTES = {
  planAutoUpdate: 'plan_auto_update',
  planConfirm: 'plan_confirm',
  recordarAgua: 'recordar_agua',
  recordarComidas: 'recordar_comidas',
  horaAgua: 'hora_agua',
  horaComidas: 'hora_comidas',
  idioma: 'idioma',
  tema: 'tema',
  tamanoLetra: 'tamano_letra'
};

function crear(db) {
  /* ---------- Ajustes por usuario ---------- */
  function getSettings(userId) {
    const f = db.prepare('SELECT * FROM user_settings WHERE user_id = ?').get(userId);
    return {
      planAutoUpdate: !!(f && f.plan_auto_update),
      planConfirm: f ? !!f.plan_confirm : true,
      recordarAgua: !!(f && f.recordar_agua),
      recordarComidas: !!(f && f.recordar_comidas),
      horaAgua: (f && f.hora_agua) || '10:00',
      horaComidas: (f && f.hora_comidas) || '13:00',
      idioma: (f && f.idioma) || null,
      tema: (f && f.tema) || null,
      tamanoLetra: (f && f.tamano_letra) || null,
      fotosConsentimiento: !!(f && f.fotos_consentimiento)
    };
  }

  /* Guarda solo lo recibido; el resto de ajustes se queda como estaba. */
  function saveSettings(userId, datos, ahoraISO) {
    db.prepare('INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)').run(userId);
    const sets = [];
    const valores = [];
    for (const [clave, columna] of Object.entries(COLUMNAS_AJUSTES)) {
      if (datos[clave] === undefined) continue;
      sets.push(`${columna} = ?`);
      valores.push(typeof datos[clave] === 'boolean' ? (datos[clave] ? 1 : 0) : datos[clave]);
    }
    if (datos.fotosConsentimiento === true) {
      sets.push('fotos_consentimiento = COALESCE(fotos_consentimiento, ?)');
      valores.push(ahoraISO);
    }
    if (sets.length) db.prepare(`UPDATE user_settings SET ${sets.join(', ')} WHERE user_id = ?`).run(...valores, userId);
    return getSettings(userId);
  }

  /* ---------- Peso del plan ---------- */
  function actualizarPesoPlan(userId, peso) {
    db.prepare('UPDATE biometrics SET peso = ? WHERE user_id = ?').run(peso, userId);
  }

  function existeRegistroDePeso(userId, peso) {
    return !!db.prepare('SELECT 1 FROM progress WHERE user_id = ? AND ABS(peso - ?) < 0.0001').get(userId, peso);
  }

  function pesoCercano(userId, fecha, ventanaDias = 7) {
    const filas = db.prepare('SELECT fecha, peso FROM progress WHERE user_id = ?').all(userId);
    let mejor = null;
    for (const f of filas) {
      const d = Math.abs(diferenciaDias(f.fecha, fecha));
      if (d <= ventanaDias && (!mejor || d < mejor.d)) mejor = { d, peso: f.peso, fecha: f.fecha };
    }
    return mejor ? { peso: mejor.peso, fecha: mejor.fecha } : null;
  }

  /* ---------- Historial de agua y kilómetros ---------- */
  function listarDailyLogs(userId, desde, hasta) {
    return db.prepare(`SELECT fecha, vasos_agua AS vasos, km_recorridos AS km FROM daily_logs
      WHERE user_id = ? AND fecha BETWEEN ? AND ? ORDER BY fecha`).all(userId, desde, hasta);
  }

  function borrarDailyLog(userId, fecha) {
    return db.prepare('DELETE FROM daily_logs WHERE user_id = ? AND fecha = ?').run(userId, fecha).changes;
  }

  /* ---------- Sueño y ánimo ---------- */
  function guardarBienestar(userId, fecha, horas, animo) {
    db.prepare(`INSERT INTO wellbeing_logs (user_id, fecha, horas_sueno, animo) VALUES (?, ?, ?, ?)
      ON CONFLICT(user_id, fecha) DO UPDATE SET horas_sueno = excluded.horas_sueno, animo = excluded.animo`)
      .run(userId, fecha, horas, animo);
    return getBienestar(userId, fecha);
  }

  function getBienestar(userId, fecha) {
    const f = db.prepare('SELECT fecha, horas_sueno AS horas, animo FROM wellbeing_logs WHERE user_id = ? AND fecha = ?').get(userId, fecha);
    return f || null;
  }

  function listarBienestar(userId, desde, hasta) {
    return db.prepare(`SELECT fecha, horas_sueno AS horas, animo FROM wellbeing_logs
      WHERE user_id = ? AND fecha BETWEEN ? AND ? ORDER BY fecha`).all(userId, desde, hasta);
  }

  function borrarBienestar(userId, fecha) {
    return db.prepare('DELETE FROM wellbeing_logs WHERE user_id = ? AND fecha = ?').run(userId, fecha).changes;
  }

  /* ---------- Fotos de progreso (solo metadatos; el archivo lo maneja almacenFotos) ---------- */
  function listarFotos(userId) {
    return db.prepare('SELECT id, fecha, ref, creado_en FROM progress_photos WHERE user_id = ? ORDER BY fecha ASC, id ASC').all(userId);
  }

  function contarFotos(userId) {
    return db.prepare('SELECT COUNT(*) AS n FROM progress_photos WHERE user_id = ?').get(userId).n;
  }

  function getFoto(userId, id) {
    return db.prepare('SELECT id, fecha, ref, creado_en FROM progress_photos WHERE user_id = ? AND id = ?').get(userId, id) || null;
  }

  function insertarFoto(userId, fecha, ref, creadoEn) {
    const info = db.prepare('INSERT INTO progress_photos (user_id, fecha, ref, creado_en) VALUES (?, ?, ?, ?)').run(userId, fecha, ref, creadoEn);
    return getFoto(userId, Number(info.lastInsertRowid));
  }

  function borrarFilaFoto(userId, id) {
    return db.prepare('DELETE FROM progress_photos WHERE user_id = ? AND id = ?').run(userId, id).changes;
  }

  function borrarFilasFotos(userId) {
    return db.prepare('DELETE FROM progress_photos WHERE user_id = ?').run(userId).changes;
  }

  /* ---------- Descarga de datos ---------- */
  function exportarDatos(userId) {
    const usuario = db.prepare('SELECT id, name, email, auth_provider, is_premium, created_at FROM users WHERE id = ?').get(userId);
    return {
      exportadoEn: new Date().toISOString(),
      perfil: usuario,
      datosBase: db.prepare('SELECT nombre, apellido, correo, peso, estatura, sexo, edad, actividad, objetivo FROM biometrics WHERE user_id = ?').get(userId) || null,
      preferencias: db.prepare('SELECT * FROM preferences WHERE user_id = ?').get(userId) || null,
      ajustes: getSettings(userId),
      progresoPeso: db.prepare('SELECT fecha, peso FROM progress WHERE user_id = ? ORDER BY fecha').all(userId),
      registrosDiarios: db.prepare('SELECT fecha, vasos_agua AS vasos, km_recorridos AS km FROM daily_logs WHERE user_id = ? ORDER BY fecha').all(userId),
      suenoAnimo: db.prepare('SELECT fecha, horas_sueno AS horas, animo FROM wellbeing_logs WHERE user_id = ? ORDER BY fecha').all(userId),
      marcas: db.prepare('SELECT item_key AS clave, fecha FROM completions WHERE user_id = ? ORDER BY fecha').all(userId),
      fotos: db.prepare('SELECT id, fecha, creado_en FROM progress_photos WHERE user_id = ? ORDER BY fecha').all(userId)
    };
  }

  return {
    getSettings, saveSettings, actualizarPesoPlan, existeRegistroDePeso, pesoCercano,
    listarDailyLogs, borrarDailyLog, guardarBienestar, getBienestar, listarBienestar, borrarBienestar,
    listarFotos, contarFotos, getFoto, insertarFoto, borrarFilaFoto, borrarFilasFotos, exportarDatos
  };
}

module.exports = { crear };
