/* Parte 7: ajustes por usuario, fotos de progreso y registros de sueño y ánimo. */
function up(db) {
  db.exec(`
CREATE TABLE IF NOT EXISTS user_settings (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  plan_auto_update INTEGER NOT NULL DEFAULT 0,
  plan_confirm INTEGER NOT NULL DEFAULT 1,
  recordar_agua INTEGER NOT NULL DEFAULT 0,
  recordar_comidas INTEGER NOT NULL DEFAULT 0,
  hora_agua TEXT NOT NULL DEFAULT '10:00',
  hora_comidas TEXT NOT NULL DEFAULT '13:00',
  idioma TEXT,
  tema TEXT,
  tamano_letra TEXT,
  fotos_consentimiento TEXT
);

CREATE TABLE IF NOT EXISTS progress_photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  fecha TEXT NOT NULL,
  ref TEXT NOT NULL UNIQUE,
  creado_en TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_progress_photos_usuario ON progress_photos(user_id, fecha);

CREATE TABLE IF NOT EXISTS wellbeing_logs (
  user_id INTEGER NOT NULL REFERENCES users(id),
  fecha TEXT NOT NULL,
  horas_sueno REAL NOT NULL,
  animo INTEGER NOT NULL,
  PRIMARY KEY (user_id, fecha)
);
`);

  /* Los recordatorios de agua que ya tenía cada persona se conservan. */
  db.exec(`
INSERT OR IGNORE INTO user_settings (user_id, recordar_agua)
SELECT id, recordar_agua FROM users;
`);
}

module.exports = { up };
