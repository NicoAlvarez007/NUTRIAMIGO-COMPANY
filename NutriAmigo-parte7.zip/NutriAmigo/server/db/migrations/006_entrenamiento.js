const COLUMNAS = [
  ['nivel', 'TEXT'],
  ['lugar', 'TEXT'],
  ['plan_inicio', 'TEXT']
];

/* Preferencias de entrenamiento: nivel, lugar y la fecha en que empezó el plan de distancia.
   La numeración 006 es el siguiente número libre en este proyecto. */
function up(db) {
  const existentes = new Set(db.prepare('PRAGMA table_info(preferences)').all().map((c) => c.name));
  for (const [nombre, definicion] of COLUMNAS) {
    if (!existentes.has(nombre)) db.exec(`ALTER TABLE preferences ADD COLUMN ${nombre} ${definicion}`);
  }
}

module.exports = { up };
