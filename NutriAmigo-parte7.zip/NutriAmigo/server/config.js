const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const RUTA_ENV = path.join(__dirname, '.env');
const ENTORNOS = ['development', 'production', 'test'];
const SECRETOS_DE_EJEMPLO = ['', 'cualquier_cadena_larga_y_aleatoria', 'nutriamigo-dev-secret', 'cambia_esto'];
const ADMIN_PASSWORD_POR_DEFECTO = '12345678';
const GOOGLE_DE_EJEMPLO = ['', 'tu_client_id_de_google', 'tu_client_secret_de_google'];

function aBooleano(valor, porDefecto) {
  if (valor === undefined || valor === '') return porDefecto;
  return String(valor).trim().toLowerCase() === 'true';
}

/* Escribe o reemplaza una variable en el archivo .env sin tocar el resto. */
function guardarVariableEnv(rutaEnv, clave, valor) {
  let contenido = fs.existsSync(rutaEnv) ? fs.readFileSync(rutaEnv, 'utf8') : '';
  const linea = `${clave}=${valor}`;
  const patron = new RegExp(`^${clave}=.*$`, 'm');
  if (patron.test(contenido)) {
    contenido = contenido.replace(patron, linea);
  } else {
    if (contenido && !contenido.endsWith('\n')) contenido += '\n';
    contenido += linea + '\n';
  }
  fs.writeFileSync(rutaEnv, contenido, { mode: 0o600 });
}

function cargarConfig(opciones = {}) {
  const rutaEnv = opciones.rutaEnv || RUTA_ENV;
  const env = opciones.env || process.env;
  const entornoBase = env.NODE_ENV || 'development';

  if (!opciones.env && entornoBase !== 'test') {
    require('dotenv').config({ path: rutaEnv });
  }

  const nodeEnv = env.NODE_ENV || 'development';
  if (!ENTORNOS.includes(nodeEnv)) {
    throw new Error(`NODE_ENV inválido: "${nodeEnv}". Usa development, production o test.`);
  }

  const puerto = env.PORT === undefined || env.PORT === '' ? 3000 : Number(env.PORT);
  if (!Number.isInteger(puerto) || puerto < 0 || puerto > 65535) {
    throw new Error(`PORT inválido: "${env.PORT}". Debe ser un número entre 0 y 65535.`);
  }

  let secreto = (env.SESSION_SECRET || '').trim();
  if (SECRETOS_DE_EJEMPLO.includes(secreto)) {
    if (nodeEnv === 'production') {
      throw new Error(
        'Falta SESSION_SECRET. En producción es obligatorio definirlo en server/.env ' +
        '(una cadena larga y aleatoria). El servidor no arrancará sin él.'
      );
    }
    secreto = crypto.randomBytes(48).toString('hex');
    if (nodeEnv === 'development' && opciones.escribirEnv !== false) {
      try {
        guardarVariableEnv(rutaEnv, 'SESSION_SECRET', secreto);
      } catch (err) {
        console.warn('No se pudo guardar SESSION_SECRET en server/.env:', err.message);
      }
    }
  }

  const idGoogle = (env.GOOGLE_CLIENT_ID || '').trim();
  const secretoGoogle = (env.GOOGLE_CLIENT_SECRET || '').trim();
  const googleConfigurado = !GOOGLE_DE_EJEMPLO.includes(idGoogle) && !GOOGLE_DE_EJEMPLO.includes(secretoGoogle);

  return {
    PORT: puerto,
    NODE_ENV: nodeEnv,
    SESSION_SECRET: secreto,
    COOKIE_SECURE: aBooleano(env.COOKIE_SECURE, false),
    GOOGLE_CLIENT_ID: idGoogle,
    GOOGLE_CLIENT_SECRET: secretoGoogle,
    GOOGLE_CALLBACK_URL: (env.GOOGLE_CALLBACK_URL || '').trim() || `http://localhost:${puerto || 3000}/auth/google/callback`,
    GOOGLE_CONFIGURADO: googleConfigurado,
    GOOGLE_SIMULADO: !googleConfigurado && aBooleano(env.GOOGLE_SIMULADO, nodeEnv === 'development'),
    ADMIN_USER: (env.ADMIN_USER || 'administrador').trim(),
    ADMIN_PASSWORD: env.ADMIN_PASSWORD || ADMIN_PASSWORD_POR_DEFECTO,
    ADMIN_CLAVE_POR_DEFECTO: (env.ADMIN_PASSWORD || ADMIN_PASSWORD_POR_DEFECTO) === ADMIN_PASSWORD_POR_DEFECTO,
    CONTACTO: 'nutriamigo@gmail.com',
    TZ_POR_DEFECTO: 'America/Bogota',
    ALLOW_FREE_PREMIUM_SWITCH: aBooleano(env.ALLOW_FREE_PREMIUM_SWITCH, true),
    RUTA_DB: env.NUTRIAMIGO_DB || path.join(__dirname, 'data', 'nutriamigo.db'),
    RUTA_UPLOADS: env.NUTRIAMIGO_UPLOADS || path.join(__dirname, 'uploads')
  };
}

module.exports = { cargarConfig, guardarVariableEnv };
