const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { enviarError, responderCodigo } = require('../middleware/validar');
const { validarBiometria, validarPreferencias, validarConsentimiento } = require('../lib/validadores');
const { hoy } = require('../lib/fechas');

function crearRutasPlan({ q, config, db }) {
  const router = express.Router();
  router.use(requireAuth);

  router.get('/biometrics', (req, res) => {
    res.json(q.getBiometrics(req.user.id));
  });

  const guardarTodo = db.transaction((usuario, datos, consentimiento) => {
    q.saveBiometrics(usuario.id, datos);
    if (consentimiento) q.guardarConsentimiento(usuario.id, consentimiento);
    if (usuario.auth_provider === 'password' && usuario.role !== 'admin') {
      q.actualizarNombre(usuario.id, `${datos.nombre} ${datos.apellido}`.slice(0, 100));
    }
    return q.getBiometrics(usuario.id);
  });

  router.post('/biometrics', (req, res) => {
    const resultado = validarBiometria(req.body, q.getBiometrics(req.user.id));
    if (!resultado.ok) return enviarError(res, resultado);

    const consentimiento = validarConsentimiento(req.body, resultado.valor.edad, !!q.obtenerConsentimiento(req.user.id));
    if (!consentimiento.ok) return enviarError(res, consentimiento);

    const datos = Object.assign({}, resultado.valor, { correo: req.user.email || resultado.valor.correo });
    return res.json(guardarTodo(req.user, datos, consentimiento.valor));
  });

  router.get('/preferences', (req, res) => {
    res.json(q.getPreferences(req.user.id));
  });

  router.post('/preferences', (req, res) => {
    if (!req.user.is_premium) return responderCodigo(res, 403, 'premium_requerido');
    const resultado = validarPreferencias(req.body, q.getBiometrics(req.user.id));
    if (!resultado.ok) return enviarError(res, resultado);

    const datos = resultado.valor;
    if (datos.distanciaKm !== undefined) {
      const actual = q.getPreferences(req.user.id);
      const anterior = actual && actual.distanciaKm ? actual.distanciaKm : 0;
      if (datos.distanciaKm !== anterior) datos.planInicio = hoy(req);
    }
    q.savePreferences(req.user.id, datos);
    return res.json({ ok: true });
  });

  // Se eliminan por completo en la Parte 10, cuando exista la pantalla de pago.
  function soloSiEstaPermitido(req, res, next) {
    if (config.ALLOW_FREE_PREMIUM_SWITCH) return next();
    return responderCodigo(res, 404, 'no_encontrado');
  }

  router.post('/premium/activate', soloSiEstaPermitido, (req, res) => {
    q.setPremium(req.user.id, true);
    res.json({ ok: true });
  });

  router.post('/premium/deactivate', soloSiEstaPermitido, (req, res) => {
    q.setPremium(req.user.id, false);
    res.json({ ok: true });
  });

  return router;
}

module.exports = { crearRutasPlan };
