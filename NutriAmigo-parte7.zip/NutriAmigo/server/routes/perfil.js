const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { validarCuerpo, responderCodigo } = require('../middleware/validar');
const { validarCambioContrasena, validarBorrarCuenta } = require('../lib/validadores');
const { kcalExtra } = require('../lib/plan');
const { hashPassword, verificarPassword } = require('../lib/passwords');
const { hoy } = require('../lib/fechas');
const { esAdmin } = require('../middleware/cuentas');

function crearRutasPerfil({ q, config, almacen }) {
  const router = express.Router();
  router.use(requireAuth);

  router.get('/me', (req, res) => {
    const u = req.user;
    const streak = q.getStreak(u.id);
    const totalCompletions = q.contarCompletionsTotal(u.id);
    const admin = esAdmin(req);
    res.json({
      id: u.id,
      name: u.name,
      email: u.email,
      username: admin ? u.username : undefined,
      avatar: u.avatar,
      role: u.role,
      isPremium: !!u.is_premium,
      createdAt: u.created_at,
      authProvider: u.auth_provider,
      hasPassword: !!u.password_hash,
      hasBiometrics: !!q.getBiometrics(u.id),
      tz: u.tz || config.TZ_POR_DEFECTO,
      simDate: admin && u.sim_date ? u.sim_date : null,
      today: hoy(req),
      suspended: !!u.suspended,
      suspendedReason: u.suspended ? u.suspended_reason : null,
      contactEmail: config.CONTACTO,
      features: q.obtenerFunciones(),
      streak,
      totalCompletions,
      kcalExtraHoy: kcalExtra((q.getDailyLog(u.id, hoy(req)) || {}).km_recorridos, (q.getBiometrics(u.id) || {}).peso),
      ajustes: q.getSettings(u.id),
      rango: q.calcularRango(streak, totalCompletions),
      avisarActualizacionPlan: u.avisar_actualizacion_plan !== 0,
      recordarAgua: !!u.recordar_agua,
      recordarEntreno: !!u.recordar_entreno
    });
  });

  /* Cambiar la contraseña, o crearla si la cuenta vino de Google y no tenía una. */
  router.post('/cuenta/contrasena', validarCuerpo(validarCambioContrasena), async (req, res, next) => {
    try {
      const u = req.user;
      const { actual, nueva } = req.datos;
      if (u.password_hash) {
        const claves = [`pwd:${u.id}`];
        const minutos = q.minutosDeBloqueo(claves);
        if (minutos) return res.status(429).json({ error: 'Demasiados intentos', code: 'cuenta_bloqueada', minutos });
        if (!actual || !(await verificarPassword(actual, u.password_hash))) {
          q.registrarFallo(claves);
          return responderCodigo(res, 403, 'contrasena_actual_incorrecta', 'actual');
        }
        q.limpiarIntentos(claves);
      }
      q.guardarContrasena(u.id, await hashPassword(nueva));
      q.auditar(u.id, 'contrasena_cambiada', null);
      return res.json({ ok: true });
    } catch (err) {
      return next(err);
    }
  });

  router.post('/avisar-actualizacion-plan', (req, res) => {
    q.setAvisarActualizacionPlan(req.user.id, !!(req.body && req.body.valor));
    res.json({ ok: true });
  });

  router.post('/recordatorios', (req, res) => {
    const cuerpo = req.body || {};
    q.setRecordatorios(req.user.id, { agua: !!cuerpo.agua, entreno: !!cuerpo.entreno });
    res.json({ ok: true });
  });

  router.get('/profile-visibility', (req, res) => {
    res.json({ publico: !!req.user.perfil_publico });
  });

  router.post('/profile-visibility', (req, res) => {
    q.setPerfilPublico(req.user.id, !!(req.body && req.body.publico));
    res.json({ ok: true });
  });

  /* Borra la cuenta, sus datos y su carpeta de fotos. */
  function borrarCuenta(req, res, next) {
    if (esAdmin(req)) return responderCodigo(res, 400, 'accion_no_permitida');
    const id = req.user.id;
    q.deleteAccount(id);
    almacen.borrarTodasDeUsuario(id);
    return req.logout((err) => {
      if (err) return next(err);
      return res.json({ ok: true });
    });
  }

  router.delete('/account', borrarCuenta);
  router.post('/account/borrar', validarCuerpo(validarBorrarCuenta), borrarCuenta);

  return router;
}

module.exports = { crearRutasPerfil };
