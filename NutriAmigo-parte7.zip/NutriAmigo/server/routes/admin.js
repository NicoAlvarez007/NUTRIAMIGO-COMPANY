const express = require('express');
const path = require('path');
const requireAuth = require('../middleware/requireAuth');
const { requireAdmin } = require('../middleware/cuentas');
const { responderCodigo, validarCuerpo, validarParametroId } = require('../middleware/validar');
const { validarMotivo, validarFuncion, validarFechaAdmin, FUNCIONES } = require('../lib/validadores');
const { hashPassword, contrasenaTemporal } = require('../lib/passwords');
const { hoy, sumarDias, fechaValida } = require('../lib/fechas');
const { fotosEjemplo } = require('../lib/fotosEjemplo');

function crearRutasAdmin({ q, config, db, almacen }) {
  const router = express.Router();
  router.use('/admin', requireAuth, requireAdmin);

  const rutaId = validarParametroId('id');

  function usuarioObjetivo(req, res) {
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.ids.id);
    if (!u) responderCodigo(res, 404, 'no_encontrado');
    return u || null;
  }

  router.get('/admin/estado', (req, res) => {
    res.json(q.estadoServidor({
      rutaDb: config.RUTA_DB,
      carpetaUploads: path.join(__dirname, '..', 'uploads'),
      version: require('../package.json').version
    }));
  });

  router.get('/admin/usuarios', (req, res) => {
    const texto = typeof req.query.q === 'string' ? req.query.q.slice(0, 80) : '';
    const pagina = Math.max(1, parseInt(req.query.pagina, 10) || 1);
    res.json(q.listarUsuarios({ q: texto, pagina }));
  });

  router.get('/admin/usuarios/:id', rutaId, (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (u) res.json(q.detalleUsuario(u.id));
  });

  router.post('/admin/usuarios/:id/suspender', rutaId, validarCuerpo(validarMotivo), (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (!u) return undefined;
    if (u.role === 'admin') return responderCodigo(res, 400, 'accion_no_permitida');
    q.suspender(u.id, req.datos.motivo);
    q.auditar(req.user.id, 'usuario_suspendido', `id=${u.id}; motivo=${req.datos.motivo}`);
    return res.json({ ok: true });
  });

  router.post('/admin/usuarios/:id/reactivar', rutaId, (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (!u) return;
    q.reactivar(u.id);
    q.auditar(req.user.id, 'usuario_reactivado', `id=${u.id}`);
    res.json({ ok: true });
  });

  router.post('/admin/usuarios/:id/restablecer-contrasena', rutaId, async (req, res, next) => {
    try {
      const u = usuarioObjetivo(req, res);
      if (!u) return undefined;
      if (u.role === 'admin' && u.id !== req.user.id) return responderCodigo(res, 400, 'accion_no_permitida');
      const temporal = contrasenaTemporal();
      q.guardarContrasena(u.id, await hashPassword(temporal));
      q.limpiarIntentos([`cta:${(u.email || u.username || '').toLowerCase()}`, `pwd:${u.id}`]);
      q.auditar(req.user.id, 'contrasena_restablecida', `id=${u.id}`);
      return res.json({ ok: true, temporal });
    } catch (err) {
      return next(err);
    }
  });

  router.delete('/admin/usuarios/:id', rutaId, (req, res) => {
    const u = usuarioObjetivo(req, res);
    if (!u) return undefined;
    if (u.role === 'admin') return responderCodigo(res, 400, 'accion_no_permitida');
    q.deleteAccount(u.id);
    almacen.borrarTodasDeUsuario(u.id);
    q.auditar(req.user.id, 'usuario_eliminado', `id=${u.id}`);
    return res.json({ ok: true });
  });

  router.get('/admin/funciones', (req, res) => {
    res.json(q.obtenerFunciones());
  });

  router.post('/admin/funciones/:clave', validarCuerpo(validarFuncion), (req, res) => {
    const clave = req.params.clave;
    if (!FUNCIONES.includes(clave)) return responderCodigo(res, 404, 'no_encontrado');
    q.cambiarFuncion(clave, req.datos.activo);
    q.auditar(req.user.id, 'funcion_cambiada', `${clave}=${req.datos.activo ? 1 : 0}`);
    return res.json(q.obtenerFunciones());
  });

  router.get('/admin/fecha', (req, res) => {
    res.json({ simulada: req.user.sim_date || null, hoy: hoy(req) });
  });

  router.post('/admin/fecha', validarCuerpo(validarFechaAdmin), (req, res) => {
    const d = req.datos;
    let nueva = null;
    if (d.fecha) nueva = d.fecha;
    else if (d.sumarDias !== undefined) nueva = sumarDias(hoy(req), d.sumarDias);
    if (nueva && !fechaValida(nueva)) return responderCodigo(res, 400, 'fecha_invalida');
    q.fijarFechaSimulada(req.user.id, nueva);
    q.auditar(req.user.id, 'fecha_simulada', nueva || 'quitada');
    return res.json({ simulada: nueva });
  });

  /* ---------- Datos de ejemplo para el propio administrador ---------- */
  function borrarDatosEjemplo(adminId) {
    db.prepare('DELETE FROM progress WHERE user_id = ?').run(adminId);
    db.prepare('DELETE FROM daily_logs WHERE user_id = ?').run(adminId);
    db.prepare('DELETE FROM wellbeing_logs WHERE user_id = ?').run(adminId);
    q.borrarFilasFotos(adminId);
    almacen.borrarTodasDeUsuario(adminId);
  }

  router.post('/admin/datos-ejemplo', (req, res) => {
    const id = req.user.id;
    const fin = hoy(req);
    const insertar = db.transaction(() => {
      borrarDatosEjemplo(id);
      for (let i = 89; i >= 0; i -= 1) {
        if (i % 5 === 4) continue;
        const peso = 78 - (89 - i) * 0.065 + Math.sin(i / 3) * 0.35;
        q.addProgress(id, Math.round(peso * 10) / 10, sumarDias(fin, -i));
      }
      for (let i = 29; i >= 0; i -= 1) {
        q.guardarDailyLog(id, sumarDias(fin, -i), 4 + ((i * 3) % 7), Math.round(((i * 7) % 50) / 10 * 10) / 10);
      }
      for (let i = 13; i >= 0; i -= 1) {
        q.guardarBienestar(id, sumarDias(fin, -i), 5.5 + ((i * 5) % 6) * 0.5, 1 + ((i * 3) % 5));
      }
      q.saveSettings(id, { fotosConsentimiento: true }, new Date().toISOString());
      const fotos = fotosEjemplo();
      [60, 30, 1].forEach((atras, k) => {
        const ref = almacen.guardarFoto(id, fotos[k]);
        q.insertarFoto(id, sumarDias(fin, -atras), ref, new Date().toISOString());
      });
    });
    insertar();
    q.auditar(id, 'datos_ejemplo_cargados', null);
    res.json({ ok: true });
  });

  router.delete('/admin/datos-ejemplo', (req, res) => {
    db.transaction(() => borrarDatosEjemplo(req.user.id))();
    q.auditar(req.user.id, 'datos_ejemplo_borrados', null);
    res.json({ ok: true });
  });

  /* Reinicia el día de hoy del administrador: marcas, agua, km y sueño. */
  router.post('/admin/reiniciar-dia', (req, res) => {
    const fecha = hoy(req);
    const marcas = q.reiniciarCompletions(req.user.id, fecha, null);
    const diario = q.borrarDailyLog(req.user.id, fecha);
    const sueno = q.borrarBienestar(req.user.id, fecha);
    q.auditar(req.user.id, 'dia_reiniciado', fecha);
    res.json({ ok: true, fecha, marcas, diario, sueno });
  });

  return router;
}

module.exports = { crearRutasAdmin };
