const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { hoy, diaDeSemana, diferenciaDias, limitesSemana } = require('../lib/fechas');

function crearRutasEntrenamiento({ q }) {
  const router = express.Router();
  router.use(requireAuth);

  /* Número de semana del plan (1, 2, 3…): cuenta desde que se fijó la distancia o desde el alta de la cuenta. */
  function numeroDeSemana(usuario, preferencias, fechaHoy) {
    const inicio = (preferencias && preferencias.planInicio) || String(usuario.created_at || '').slice(0, 10) || fechaHoy;
    const dias = diferenciaDias(inicio, fechaHoy);
    return Math.max(1, Math.floor(dias / 7) + 1);
  }

  /* Km de la semana local (lunes a domingo) para la barra de progreso de la meta. */
  router.get('/entrenamiento/semana', (req, res) => {
    const fecha = hoy(req);
    const { desde, hasta } = limitesSemana(fecha);
    res.json({
      hoy: fecha,
      dia: diaDeSemana(fecha),
      desde,
      hasta,
      km: q.kmEntre(req.user.id, desde, hasta),
      semanaNumero: numeroDeSemana(req.user, q.getPreferences(req.user.id), fecha)
    });
  });

  return router;
}

module.exports = { crearRutasEntrenamiento };
