const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { noSuspendida } = require('../middleware/cuentas');
const { validarCuerpo, responderCodigo, validarParametroId } = require('../middleware/validar');
const {
  validarAjustes, validarBienestar, validarAceptarCambio, analizarFoto, FOTOS_MAX_POR_PERSONA
} = require('../lib/validadores');
const { hoy, sumarDias } = require('../lib/fechas');
const { kcalExtra, metaAguaVasos, KM_META_SUGERIDA, PESO_UMBRAL_KG } = require('../lib/plan');
const { metaCalorica } = require('../lib/calorias');

/* Plan del día, ajustes, sueño y ánimo, historial de agua/km y fotos de progreso. */
function crearRutasDashboard({ q, almacen }) {
  const router = express.Router();
  router.use(requireAuth);

  /* ---------- Plan del día: calorías base + las cambiadas por entrenamiento, agua y km ---------- */
  router.get('/plan', (req, res) => {
    const bio = q.getBiometrics(req.user.id);
    const log = q.getDailyLog(req.user.id, hoy(req));
    const pesoPlan = bio ? bio.peso : null;
    const base = bio ? metaCalorica(bio) : null;
    const extra = kcalExtra(log.km_recorridos, pesoPlan);
    res.json({
      pesoPlan,
      kcalBase: base,
      kcalExtraHoy: extra,
      kcalMetaHoy: base === null ? null : base + extra,
      aguaMetaVasos: metaAguaVasos(pesoPlan),
      vasosHoy: log.vasos_agua,
      kmHoy: log.km_recorridos,
      kmMetaSugerida: KM_META_SUGERIDA,
      umbralPesoKg: PESO_UMBRAL_KG
    });
  });

  /* Aceptar el cambio de plan que el servidor propuso al registrar un peso. */
  router.post('/plan/aceptar-cambio', validarCuerpo(validarAceptarCambio), (req, res) => {
    const bio = q.getBiometrics(req.user.id);
    const ajustes = q.getSettings(req.user.id);
    const { peso } = req.datos;
    const valido = bio && ajustes.planAutoUpdate
      && Math.abs(peso - bio.peso) + 1e-9 >= PESO_UMBRAL_KG
      && q.existeRegistroDePeso(req.user.id, peso);
    if (!valido) return responderCodigo(res, 400, 'cambio_no_valido', 'peso');
    q.actualizarPesoPlan(req.user.id, peso);
    q.auditar(req.user.id, 'plan_actualizado', `${bio.peso}->${peso}`);
    return res.json({ planActualizado: true, de: bio.peso, a: peso });
  });

  /* ---------- Ajustes ---------- */
  router.get('/settings', (req, res) => {
    res.json(q.getSettings(req.user.id));
  });

  router.post('/settings', validarCuerpo(validarAjustes), (req, res) => {
    res.json(q.saveSettings(req.user.id, req.datos, new Date().toISOString()));
  });

  /* ---------- Historial de agua y km: últimos N días con huecos en cero ---------- */
  router.get('/historial-diario', (req, res) => {
    const dias = Math.min(31, Math.max(1, parseInt(req.query.dias, 10) || 7));
    const fin = hoy(req);
    const inicio = sumarDias(fin, -(dias - 1));
    const porFecha = new Map(q.listarDailyLogs(req.user.id, inicio, fin).map((f) => [f.fecha, f]));
    const lista = [];
    for (let i = 0; i < dias; i += 1) {
      const fecha = sumarDias(inicio, i);
      const f = porFecha.get(fecha);
      lista.push({ fecha, vasos: f ? f.vasos : 0, km: f ? f.km : 0 });
    }
    res.json(lista);
  });

  router.get('/resumen-mensual', (req, res) => {
    const fin = hoy(req);
    const filas = q.listarDailyLogs(req.user.id, sumarDias(fin, -29), fin);
    const mejor = (clave) => filas.reduce((m, f) => (f[clave] > (m ? m[clave] : 0) ? f : m), null);
    const promedio = (clave) => (filas.length ? Math.round((filas.reduce((s, f) => s + f[clave], 0) / filas.length) * 10) / 10 : 0);
    const mejorAgua = mejor('vasos');
    const mejorKm = mejor('km');
    res.json({
      diasConRegistro: filas.length,
      promedioVasos: promedio('vasos'),
      promedioKm: promedio('km'),
      mejorVasos: mejorAgua ? { fecha: mejorAgua.fecha, valor: mejorAgua.vasos } : null,
      mejorKm: mejorKm ? { fecha: mejorKm.fecha, valor: mejorKm.km } : null
    });
  });

  /* ---------- Sueño y ánimo ---------- */
  router.get('/wellbeing', (req, res) => {
    const dias = Math.min(31, Math.max(1, parseInt(req.query.dias, 10) || 14));
    const fin = hoy(req);
    res.json({
      hoy: q.getBienestar(req.user.id, fin),
      registros: q.listarBienestar(req.user.id, sumarDias(fin, -(dias - 1)), fin)
    });
  });

  router.post('/wellbeing', validarCuerpo(validarBienestar), (req, res) => {
    res.json(q.guardarBienestar(req.user.id, hoy(req), req.datos.horas, req.datos.animo));
  });

  /* ---------- Fotos de progreso ---------- */
  const rutaId = validarParametroId('id');


  router.get('/photos', (req, res) => {
    const fotos = q.listarFotos(req.user.id).map((f) => {
      const cercano = q.pesoCercano(req.user.id, f.fecha);
      return { id: f.id, fecha: f.fecha, peso: cercano ? cercano.peso : null, pesoFecha: cercano ? cercano.fecha : null };
    });
    res.json({
      fotos,
      limite: FOTOS_MAX_POR_PERSONA,
      consentimiento: q.getSettings(req.user.id).fotosConsentimiento
    });
  });

  router.post('/photos', noSuspendida, validarCuerpo(analizarFoto), (req, res) => {
    if (!q.getSettings(req.user.id).fotosConsentimiento) return responderCodigo(res, 403, 'fotos_consentimiento_requerido');
    if (q.contarFotos(req.user.id) >= FOTOS_MAX_POR_PERSONA) return responderCodigo(res, 409, 'foto_limite');
    const ref = almacen.guardarFoto(req.user.id, req.datos);
    let fila;
    try {
      fila = q.insertarFoto(req.user.id, hoy(req), ref, new Date().toISOString());
    } catch (err) {
      almacen.borrarFoto(req.user.id, ref);
      throw err;
    }
    const cercano = q.pesoCercano(req.user.id, fila.fecha);
    return res.status(201).json({ id: fila.id, fecha: fila.fecha, peso: cercano ? cercano.peso : null, pesoFecha: cercano ? cercano.fecha : null });
  });

  /* Solo su dueño puede ver la foto; si no existe o es de otra persona, es 404. */
  router.get('/photos/:id/file', rutaId, (req, res) => {
    const fila = q.getFoto(req.user.id, req.ids.id);
    const datos = fila ? almacen.leerFoto(req.user.id, fila.ref) : null;
    if (!datos) return responderCodigo(res, 404, 'no_encontrado');
    res.set({ 'Content-Type': 'image/jpeg', 'Cache-Control': 'private, max-age=3600', 'Content-Length': String(datos.length) });
    return res.end(datos);
  });

  router.delete('/photos/:id', rutaId, (req, res) => {
    const fila = q.getFoto(req.user.id, req.ids.id);
    if (!fila) return responderCodigo(res, 404, 'no_encontrado');
    almacen.borrarFoto(req.user.id, fila.ref);
    q.borrarFilaFoto(req.user.id, fila.id);
    return res.json({ ok: true });
  });

  /* ---------- Descargar mis datos ---------- */
  router.get('/account/export', (req, res) => {
    res.set('Content-Disposition', 'attachment; filename="mis-datos-nutriamigo.json"');
    res.json(q.exportarDatos(req.user.id));
  });

  return router;
}

module.exports = { crearRutasDashboard };
