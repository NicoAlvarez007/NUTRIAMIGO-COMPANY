const express = require('express');
const requireAuth = require('../middleware/requireAuth');
const { validarCuerpo, responderCodigo } = require('../middleware/validar');
const { validarProgreso, validarRegistroDiario, validarCompletion, validarReinicio } = require('../lib/validadores');
const { hoy, diaDeSemana } = require('../lib/fechas');
const { evaluarCambioPlan, kcalExtra } = require('../lib/plan');

function crearRutasProgreso({ q }) {
  const router = express.Router();
  router.use(requireAuth);

  router.get('/progress', (req, res) => {
    res.json(q.getProgress(req.user.id));
  });

  /* Registrar un peso nunca cambia el plan por sí solo: depende de los ajustes y del umbral de 5 kg.
     Responde { progreso, requiereCambioPlan? , planActualizado? }. */
  router.post('/progress', validarCuerpo(validarProgreso), (req, res) => {
    const { peso } = req.datos;
    const bio = q.getBiometrics(req.user.id);
    const ajustes = q.getSettings(req.user.id);
    const decision = evaluarCambioPlan({
      pesoPlan: bio ? bio.peso : null,
      pesoNuevo: peso,
      autoActualizar: ajustes.planAutoUpdate,
      confirmar: ajustes.planConfirm
    });

    const respuesta = { progreso: q.addProgress(req.user.id, peso, hoy(req)) };
    if (decision.accion === 'avisar') {
      respuesta.requiereCambioPlan = { de: decision.de, a: decision.a };
    } else if (decision.accion === 'aplicar') {
      q.actualizarPesoPlan(req.user.id, decision.a);
      q.auditar(req.user.id, 'plan_actualizado', `${decision.de}->${decision.a}`);
      respuesta.planActualizado = true;
      respuesta.de = decision.de;
      respuesta.a = decision.a;
    }
    res.json(respuesta);
  });

  router.delete('/progress', (req, res) => {
    q.clearProgress(req.user.id);
    res.json({ ok: true });
  });

  router.get('/daily-log', (req, res) => {
    res.json(q.getDailyLog(req.user.id, hoy(req)));
  });

  router.post('/daily-log', validarCuerpo(validarRegistroDiario), (req, res) => {
    const fecha = hoy(req);
    const actual = q.getDailyLog(req.user.id, fecha);
    const vasosAgua = req.datos.vasosAgua !== undefined ? req.datos.vasosAgua : actual.vasos_agua;
    const kmRecorridos = req.datos.kmRecorridos !== undefined ? req.datos.kmRecorridos : actual.km_recorridos;
    const log = q.guardarDailyLog(req.user.id, fecha, vasosAgua, kmRecorridos);
    const bio = q.getBiometrics(req.user.id);
    res.json(Object.assign({}, log, { kcalExtraHoy: kcalExtra(log.km_recorridos, bio ? bio.peso : null) }));
  });

  router.get('/completions', (req, res) => {
    res.json(q.getCompletions(req.user.id, hoy(req)));
  });

  /* Los días de entrenamiento solo se marcan el día de hoy (regla "Ya lo hice"). */
  router.post('/completions', validarCuerpo(validarCompletion), (req, res) => {
    const fecha = hoy(req);
    const { itemKey, marcar } = req.datos;
    if (itemKey.startsWith('entrenamiento-') && itemKey !== `entrenamiento-${diaDeSemana(fecha)}`) {
      return responderCodigo(res, 400, 'solo_hoy', 'itemKey');
    }
    return res.json(marcar ? q.marcarCompletion(req.user.id, itemKey, fecha) : q.toggleCompletion(req.user.id, itemKey, fecha));
  });

  /* "Reiniciar": borra las marcas de hoy (todas, o solo las de entrenamiento o alimentación). */
  router.post('/completions/reiniciar', validarCuerpo(validarReinicio), (req, res) => {
    const borradas = q.reiniciarCompletions(req.user.id, hoy(req), req.datos.tipo);
    res.json({ ok: true, borradas });
  });

  return router;
}

module.exports = { crearRutasProgreso };
