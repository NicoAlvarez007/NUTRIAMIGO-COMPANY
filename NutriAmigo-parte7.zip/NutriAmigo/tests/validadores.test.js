const test = require('node:test');
const assert = require('node:assert/strict');
const v = require('../server/lib/validadores');
const k = require('../server/lib/calorias');

const base = { nombre: 'Ana', apellido: 'Ruiz', peso: 70, estatura: 170, sexo: 'mujer', edad: 25, actividad: 'moderado', objetivo: 'mantener' };

test('peso: límites 30 y 250', () => {
  assert.equal(v.validarPeso(30).ok, true);
  assert.equal(v.validarPeso(250).ok, true);
  assert.equal(v.validarPeso(29.9).code, 'peso_invalido');
  assert.equal(v.validarPeso(251).code, 'peso_invalido');
  assert.equal(v.validarPeso('abc').code, 'peso_invalido');
  assert.equal(v.validarPeso(NaN).code, 'peso_invalido');
  assert.equal(v.validarPeso(70.26).valor, 70.3);
});

test('estatura: 120 a 220', () => {
  assert.equal(v.validarEstatura(120).ok, true);
  assert.equal(v.validarEstatura(220).ok, true);
  assert.equal(v.validarEstatura(-5).code, 'estatura_invalida');
  assert.equal(v.validarEstatura(221).code, 'estatura_invalida');
});

test('edad: mínimo 15, máximo 90, entera', () => {
  assert.equal(v.validarEdad(14).code, 'edad_minima');
  assert.equal(v.validarEdad(3).code, 'edad_minima');
  assert.equal(v.validarEdad(15).ok, true);
  assert.equal(v.validarEdad(90).ok, true);
  assert.equal(v.validarEdad(91).code, 'edad_invalida');
  assert.equal(v.validarEdad(20.5).code, 'edad_invalida');
  assert.equal(v.validarEdad('x').code, 'edad_invalida');
});

test('sexo, actividad, objetivo', () => {
  assert.equal(v.validarSexo('zz').code, 'sexo_invalido');
  assert.equal(v.validarSexo('hombre').ok, true);
  assert.equal(v.validarActividad('muy_activo').ok, true);
  assert.equal(v.validarActividad('x').code, 'actividad_invalida');
  assert.equal(v.validarObjetivo('volumen').ok, true);
  assert.equal(v.validarObjetivo('x').code, 'objetivo_invalido');
});

test('nombre sin etiquetas HTML y con largo 1 a 50', () => {
  assert.equal(v.validarNombre('  Ana ').valor, 'Ana');
  assert.equal(v.validarNombre('<b>Ana</b>').code, 'nombre_invalido');
  assert.equal(v.validarNombre('').code, 'nombre_invalido');
  assert.equal(v.validarNombre('a'.repeat(51)).code, 'nombre_invalido');
});

test('correo opcional y con formato', () => {
  assert.equal(v.validarCorreo('').ok, true);
  assert.equal(v.validarCorreo('a@b.co').ok, true);
  assert.equal(v.validarCorreo('no-es-correo').code, 'correo_invalido');
  assert.equal(v.validarCorreo('a@b.co' + 'x'.repeat(120)).code, 'correo_invalido');
});

test('agua y kilómetros', () => {
  assert.equal(v.validarVasos(0).ok, true);
  assert.equal(v.validarVasos(40).ok, true);
  assert.equal(v.validarVasos(41).code, 'vasos_invalidos');
  assert.equal(v.validarVasos('abc').code, 'vasos_invalidos');
  assert.equal(v.validarKm(-3).code, 'km_invalidos');
  assert.equal(v.validarKm(200).ok, true);
  assert.equal(v.validarKm(200.1).code, 'km_invalidos');
});

test('preferencias de entrenamiento y restricciones', () => {
  assert.equal(v.validarFrecuencia(0).code, 'frecuencia_invalida');
  assert.equal(v.validarFrecuencia(7).ok, true);
  assert.equal(v.validarDistancia(100).ok, true);
  assert.equal(v.validarDistancia(101).code, 'distancia_invalida');
  assert.equal(v.validarEnfoque('cuello').code, 'enfoque_invalido');
  assert.equal(v.validarRestricciones('x'.repeat(301)).code, 'restricciones_invalidas');
  assert.equal(v.validarProteinas(['pollo', 'pollo']).valor.length, 1);
  assert.equal(v.validarProteinas(['tofu']).code, 'proteinas_invalidas');
});

test('texto de reel e imagen https', () => {
  assert.equal(v.validarReel({ texto: 'x'.repeat(501) }).code, 'texto_invalido');
  assert.equal(v.validarReel({ texto: 'x'.repeat(500) }).ok, true);
  assert.equal(v.validarReel({ texto: 'hola', imagenUrl: 'http://a.com/x.png' }).code, 'imagen_invalida');
  assert.equal(v.validarReel({ texto: 'hola', imagenUrl: 'javascript:alert(1)' }).code, 'imagen_invalida');
  assert.equal(v.validarReel({ texto: 'hola', imagenUrl: 'https://a.com/x.png' }).ok, true);
});

test('ids e itemKey', () => {
  assert.equal(v.validarId('0').code, 'id_invalido');
  assert.equal(v.validarId('-1').code, 'id_invalido');
  assert.equal(v.validarId('1e3').code, 'id_invalido');
  assert.equal(v.validarId('12').valor, 12);
  assert.equal(v.validarItemKey('alimentacion-lunes-cena').ok, true);
  assert.equal(v.validarItemKey('entrenamiento-domingo').ok, true);
  assert.equal(v.validarItemKey('alimentacion-lunes-brunch').code, 'item_invalido');
  assert.equal(v.validarItemKey('entrenamiento-lunes-cena').code, 'item_invalido');
});

test('biometría: guardado parcial y campos desconocidos ignorados', () => {
  const parcial = v.validarBiometria({ peso: 72, edad: null }, base);
  assert.equal(parcial.ok, true);
  assert.equal(parcial.valor.peso, 72);
  assert.equal(parcial.valor.edad, 25);
  assert.equal(v.validarBiometria({ peso: 72 }, null).code, 'datos_incompletos');
  const conBasura = v.validarBiometria({ ...base, es_admin: true, user_id: 9 }, null);
  assert.equal(conBasura.ok, true);
  assert.equal('es_admin' in conBasura.valor, false);
  assert.equal(v.validarBiometria('texto', null).code, 'cuerpo_invalido');
});

test('menores de 15 a 17: no pueden elegir definir', () => {
  assert.equal(v.validarBiometria({ ...base, edad: 16, objetivo: 'definir' }, null).code, 'objetivo_no_permitido_menor');
  assert.equal(v.validarBiometria({ ...base, edad: 16, objetivo: 'mantener' }, null).ok, true);
  assert.equal(v.validarBiometria({ ...base, edad: 17, objetivo: 'volumen' }, null).ok, true);
  assert.equal(v.validarBiometria({ ...base, edad: 18, objetivo: 'definir' }, null).ok, true);
  assert.equal(v.validarPreferencias({ proteinas: ['pollo'] }, { edad: 16, objetivo: 'definir' }).code, 'objetivo_no_permitido_menor');
});

test('preferencias parciales devuelven solo lo enviado', () => {
  assert.deepEqual(v.validarPreferencias({ proteinas: ['pollo'], restriccionesTexto: 'sin lactosa' }, null).valor,
    { proteinas: ['pollo'], restriccionesTexto: 'sin lactosa' });
  assert.deepEqual(v.validarPreferencias({ frecuenciaSemanal: '3', enfoqueMuscular: 'piernas' }, null).valor,
    { frecuenciaSemanal: 3, enfoqueMuscular: 'piernas' });
});

test('mensajes de sockets', () => {
  assert.equal(v.validarMensajeSala({ room: 'marte', text: 'hola' }).code, 'sala_invalida');
  assert.equal(v.validarMensajeSala({ room: 'global', text: 'x'.repeat(501) }).code, 'texto_invalido');
  assert.equal(v.validarMensajeSala({ room: 'global', text: 'hola', lang: 'fr' }).valor.lang, 'es');
  assert.equal(v.validarMensajeAmigo({ friendId: 'abc', texto: 'hola' }).code, 'id_invalido');
  assert.equal(v.validarMensajeAmigo({ friendId: 3, texto: 'hola' }).valor.friendId, 3);
});

test('todos los códigos de error tienen mensaje en español', () => {
  for (const [codigo, texto] of Object.entries(v.MENSAJES)) {
    assert.ok(texto && texto.length > 3, codigo);
  }
});

test('calorías: piso 1.200 (mujer) y 1.500 (hombre)', () => {
  const mujer = k.metaCalorica({ peso: 40, estatura: 150, sexo: 'mujer', edad: 60, actividad: 'sedentario', objetivo: 'definir' });
  const hombre = k.metaCalorica({ peso: 45, estatura: 150, sexo: 'hombre', edad: 70, actividad: 'sedentario', objetivo: 'definir' });
  assert.equal(mujer, 1200);
  assert.equal(hombre, 1500);
  assert.equal(k.metaCalorica({ peso: 70, estatura: 170, sexo: 'hombre', edad: 25, actividad: 'moderado', objetivo: 'mantener' }), 2550);
  assert.equal(k.metaCalorica({ peso: 70 }), null);
});

test('calorías: reglas de edad', () => {
  assert.equal(k.esMenorDeEdad(14), false);
  assert.equal(k.esMenorDeEdad(15), true);
  assert.equal(k.esMenorDeEdad(17), true);
  assert.equal(k.esMenorDeEdad(18), false);
  assert.equal(k.objetivoPermitido(16, 'definir'), false);
  assert.equal(k.objetivoPermitido(16, 'volumen'), true);
  assert.equal(k.objetivoPermitido(30, 'definir'), true);
});
