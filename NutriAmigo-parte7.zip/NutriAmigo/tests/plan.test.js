const test = require('node:test');
const assert = require('node:assert/strict');
const { kcalExtra, metaAguaVasos, evaluarCambioPlan, PESO_UMBRAL_KG, KCAL_EXTRA_MAX } = require('../server/lib/plan');
const { crearAlmacen } = require('../server/lib/almacenFotos');
const { analizarFoto, validarAjustes, validarBienestar, validarBorrarCuenta, validarAceptarCambio } = require('../server/lib/validadores');
const fs = require('fs');
const os = require('os');
const path = require('path');

const jpegFalso = (extra = 100) => Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(extra, 7)]);
const dataUrl = (buf, tipo = 'image/jpeg') => `data:${tipo};base64,${buf.toString('base64')}`;

test('el umbral del peso es de 5 kg', () => {
  assert.equal(PESO_UMBRAL_KG, 5);
});

test('cambio de plan: los 4 casos (interruptor 1 apagado, encendido con aviso, sin aviso y diferencia menor a 5 kg)', () => {
  const base = { pesoPlan: 70, pesoNuevo: 76 };
  assert.deepEqual(evaluarCambioPlan({ ...base, autoActualizar: false, confirmar: true }), { accion: 'ninguna' });
  assert.deepEqual(evaluarCambioPlan({ ...base, autoActualizar: true, confirmar: true }), { accion: 'avisar', de: 70, a: 76 });
  assert.deepEqual(evaluarCambioPlan({ ...base, autoActualizar: true, confirmar: false }), { accion: 'aplicar', de: 70, a: 76 });
  assert.deepEqual(evaluarCambioPlan({ pesoPlan: 70, pesoNuevo: 74.9, autoActualizar: true, confirmar: true }), { accion: 'ninguna' });
  assert.equal(evaluarCambioPlan({ pesoPlan: 70, pesoNuevo: 75, autoActualizar: true, confirmar: true }).accion, 'avisar', 'justo 5 kg ya cuenta');
  assert.equal(evaluarCambioPlan({ pesoPlan: 70, pesoNuevo: 64, autoActualizar: true, confirmar: true }).accion, 'avisar', 'también al bajar');
  assert.equal(evaluarCambioPlan({ pesoPlan: null, pesoNuevo: 80, autoActualizar: true, confirmar: true }).accion, 'ninguna');
});

test('calorías cambiadas por entrenamiento: km × peso × 0,75 con tope de 800', () => {
  assert.equal(kcalExtra(5, 70), 263);
  assert.equal(kcalExtra(10, 60), 450);
  assert.equal(kcalExtra(30, 90), KCAL_EXTRA_MAX);
  assert.equal(kcalExtra(200, 250), 800);
  assert.equal(kcalExtra(0, 70), 0);
  assert.equal(kcalExtra(-3, 70), 0);
  assert.equal(kcalExtra(5, null), 0);
});

test('meta de agua: 35 ml por kg en vasos de 250 ml', () => {
  assert.equal(metaAguaVasos(70), 10);
  assert.equal(metaAguaVasos(50), 7);
  assert.equal(metaAguaVasos(100), 14);
  assert.equal(metaAguaVasos(null), 8);
});

test('validaciones de sueño, ánimo, ajustes, cambio de plan y borrado de cuenta', () => {
  assert.equal(validarBienestar({ horas: 0, animo: 1 }).ok, true);
  assert.equal(validarBienestar({ horas: 16, animo: 5 }).ok, true);
  assert.equal(validarBienestar({ horas: 16.5, animo: 3 }).code, 'horas_invalidas');
  assert.equal(validarBienestar({ horas: -1, animo: 3 }).code, 'horas_invalidas');
  assert.equal(validarBienestar({ horas: 7.25, animo: 3 }).code, 'horas_invalidas');
  assert.equal(validarBienestar({ horas: 7, animo: 0 }).code, 'animo_invalido');
  assert.equal(validarBienestar({ horas: 7, animo: 3.5 }).code, 'animo_invalido');
  assert.equal(validarBienestar({ horas: 'x', animo: 3 }).code, 'horas_invalidas');

  assert.equal(validarAjustes({ planAutoUpdate: true, tema: 'dark', idioma: 'de', tamanoLetra: 'grande', horaAgua: '09:30' }).ok, true);
  assert.equal(validarAjustes({ planAutoUpdate: 'si' }).code, 'ajuste_invalido');
  assert.equal(validarAjustes({ idioma: 'fr' }).code, 'ajuste_invalido');
  assert.equal(validarAjustes({ horaComidas: '7:5' }).code, 'hora_invalida');
  assert.equal(validarAjustes({ fotosConsentimiento: false }).code, 'ajuste_invalido');

  assert.equal(validarAceptarCambio({ peso: 76 }).ok, true);
  assert.equal(validarAceptarCambio({ peso: 10 }).ok, false);
  assert.equal(validarBorrarCuenta({ palabra: 'BORRAR' }).ok, true);
  assert.equal(validarBorrarCuenta({ palabra: 'borrar' }).ok, false);
});

test('fotos: JPEG válido pasa; PNG, texto disfrazado y mayores de 2 MB se rechazan', () => {
  assert.equal(analizarFoto({ imagen: dataUrl(jpegFalso()) }).ok, true);
  assert.equal(analizarFoto({ imagen: dataUrl(jpegFalso(), 'image/png') }).code, 'foto_formato_invalido');
  assert.equal(analizarFoto({ imagen: dataUrl(Buffer.from('<?php echo 1; ?> esto es texto')) }).code, 'foto_formato_invalido');
  assert.equal(analizarFoto({ imagen: dataUrl(Buffer.from([0x89, 0x50, 0x4E, 0x47, 1, 2, 3, 4])) }).code, 'foto_formato_invalido');
  assert.equal(analizarFoto({ imagen: dataUrl(jpegFalso(2 * 1024 * 1024)) }).code, 'foto_demasiado_grande');
  assert.equal(analizarFoto({ imagen: dataUrl(jpegFalso(2 * 1024 * 1024 - 10)) }).ok, true);
  assert.equal(analizarFoto({ imagen: 123 }).code, 'foto_formato_invalido');
  assert.equal(analizarFoto({ imagen: 'data:image/jpeg;base64,@@@' }).code, 'foto_formato_invalido');
  assert.equal(analizarFoto(null).ok, false);
});

test('almacén de fotos: guarda, lee, borra, rechaza rutas maliciosas y borra la carpeta del usuario', (t) => {
  const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), 'nutriamigo-fotos-'));
  t.after(() => fs.rmSync(carpeta, { recursive: true, force: true }));
  const almacen = crearAlmacen(carpeta);

  const ref = almacen.guardarFoto(7, jpegFalso());
  assert.match(ref, /^[0-9a-f-]{36}\.jpg$/);
  assert.ok(fs.existsSync(path.join(carpeta, '7', ref)));
  assert.deepEqual(almacen.leerFoto(7, ref), jpegFalso());
  assert.equal(almacen.leerFoto(8, ref), null, 'otro usuario no la lee');

  ['../7/' + ref, '..', '../../etc/passwd', ref + '/..', 'a.jpg', '', null, ref.replace('.jpg', '.png')].forEach((malo) => {
    assert.equal(almacen.leerFoto(7, malo), null, String(malo));
    assert.equal(almacen.borrarFoto(7, malo), false, String(malo));
  });
  assert.throws(() => almacen.guardarFoto('../x', jpegFalso()));

  assert.equal(almacen.borrarFoto(7, ref), true);
  assert.equal(almacen.leerFoto(7, ref), null);

  almacen.guardarFoto(7, jpegFalso());
  almacen.guardarFoto(7, jpegFalso());
  almacen.borrarTodasDeUsuario(7);
  assert.equal(fs.existsSync(path.join(carpeta, '7')), false);
  almacen.borrarTodasDeUsuario(7);
});
