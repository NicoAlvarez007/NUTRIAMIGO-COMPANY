const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../public/js/generador-rutinas.js');
const { EJERCICIOS, EQUIPO_CASA } = require('../public/data/ejercicios.js');

const BASE = { objetivo: 'mantener', frecuencia: 3, distanciaKm: null, enfoque: null, nivel: 'intermedio', lugar: 'casa', edad: 30, semanaNumero: 1, semilla: 7 };
const OBJETIVOS = ['definir', 'mantener', 'volumen'];
const NIVELES = ['principiante', 'intermedio', 'avanzado'];
const DIAS_TABLA = { 1: [2], 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 4, 5], 6: [0, 1, 2, 3, 4, 5], 7: [0, 1, 2, 3, 4, 5, 6] };
const RANGOS = {
  definir: { series: [3, 4], reps: [12, 15], descanso: [45, 60] },
  mantener: { series: [3, 3], reps: [8, 12], descanso: [60, 90] },
  volumen: { series: [3, 5], reps: [6, 10], descanso: [90, 120] }
};

function sesionesDeFuerza(semana) {
  return semana.dias.filter((d) => d.principal.length > 0);
}

test('la biblioteca tiene al menos 60 ejercicios, bien formados y en los tres idiomas', () => {
  assert.ok(EJERCICIOS.length >= 60);
  const ids = new Set(EJERCICIOS.map((e) => e.id));
  assert.equal(ids.size, EJERCICIOS.length);
  EJERCICIOS.forEach((e) => {
    ['es', 'en', 'de'].forEach((l) => {
      assert.ok(e.nombre[l] && e.nombre[l].trim(), `${e.id} nombre ${l}`);
      assert.ok(e.pasos[l].length >= 2 && e.pasos[l].length <= 4, `${e.id} pasos ${l}`);
      assert.equal(e.pasos[l].length, e.pasos.es.length, `${e.id} pasos desiguales`);
      assert.ok(e.errores[l].length >= 1, `${e.id} errores ${l}`);
    });
    assert.equal(e.videoUrl, null);
    assert.ok(['fuerza', 'cardio', 'movilidad', 'core'].includes(e.tipo), e.id);
    assert.ok(e.lugar.length > 0, e.id);
  });
  ['piernas', 'pecho', 'espalda', 'hombros', 'brazos', 'core', 'cardio'].forEach((m) => {
    assert.ok(EJERCICIOS.some((e) => e.musculo === m), m);
  });
});

test('1. Para frecuencias 1 a 7 los días de entrenamiento son los de la tabla', () => {
  for (let f = 1; f <= 7; f += 1) {
    const semana = G.generarSemana({ ...BASE, frecuencia: f });
    const dias = semana.dias.filter((d) => d.entrena).map((d) => d.indice);
    assert.deepEqual(dias, DIAS_TABLA[f], `frecuencia ${f}`);
    assert.equal(semana.resumen.diasEntrenamiento, f);
    assert.equal(semana.resumen.diasFuerza, f === 7 ? 6 : f);
    assert.equal(semana.resumen.diasDescansoActivo, 7 - f);
    semana.dias.filter((d) => !d.entrena).forEach((d) => {
      assert.equal(d.principal.length, 0);
      assert.equal(d.cardio.id, 'caminata');
      assert.ok(d.cardio.minutos >= 20 && d.cardio.minutos <= 30);
      assert.equal(d.cardio.cuentaParaKm, true);
    });
  }
  const siete = G.generarSemana({ ...BASE, frecuencia: 7 });
  assert.equal(siete.dias[6].tipoSesion, 'movilidad');
});

test('la estructura de cada frecuencia coincide con la tabla', () => {
  const nombres = (f) => G.generarSemana({ ...BASE, frecuencia: f }).dias.filter((d) => d.entrena).map((d) => d.tipoSesion);
  assert.deepEqual(nombres(1), ['completo_a']);
  assert.deepEqual(nombres(3), ['completo_a', 'completo_b', 'completo_c']);
  assert.deepEqual(nombres(4), ['superior', 'inferior', 'superior', 'inferior']);
  assert.deepEqual(nombres(5), ['empuje', 'piernas', 'tiron', 'completo_ligero', 'cardio_core']);
  assert.deepEqual(nombres(6), ['empuje', 'tiron', 'piernas', 'empuje', 'tiron', 'piernas']);
});

test('2. Series, repeticiones y descansos respetan los rangos de cada objetivo', () => {
  OBJETIVOS.forEach((objetivo) => {
    const r = RANGOS[objetivo];
    NIVELES.forEach((nivel) => {
      for (let n = 1; n <= 8; n += 1) {
        const semana = G.generarSemana({ ...BASE, objetivo, nivel, frecuencia: 4, semanaNumero: n, lugar: 'gimnasio' });
        sesionesDeFuerza(semana).forEach((dia) => {
          assert.ok(dia.principal.length <= 8, 'máximo 8 ejercicios');
          dia.principal.filter((it) => it.tipo === 'fuerza').forEach((it) => {
            const etiqueta = `${objetivo}/${nivel}/semana ${n}/${it.id}`;
            const minSeries = Math.max(2, r.series[0] - 1);
            const maxSeries = r.series[1] + (nivel === 'avanzado' ? 1 : 0);
            assert.ok(it.series >= (semana.descarga ? 2 : minSeries) && it.series <= maxSeries, `series ${etiqueta}: ${it.series}`);
            assert.ok(it.repeticiones >= r.reps[0] && it.repeticiones <= r.reps[1], `reps ${etiqueta}: ${it.repeticiones}`);
            assert.ok(it.descansoSeg >= r.descanso[0] && it.descansoSeg <= r.descanso[1], `descanso ${etiqueta}: ${it.descansoSeg}`);
          });
        });
      }
    });
  });
});

test('2. El nivel ajusta las series y el cardio sigue el objetivo', () => {
  const primera = (nivel) => sesionesDeFuerza(G.generarSemana({ ...BASE, objetivo: 'volumen', nivel, frecuencia: 3 }))[0].principal.find((it) => it.tipo === 'fuerza').series;
  assert.equal(primera('principiante') + 1, primera('intermedio'));
  assert.equal(primera('avanzado') - 1, primera('intermedio'));

  const cardio = (objetivo) => G.generarSemana({ ...BASE, objetivo, frecuencia: 3 }).dias.find((d) => d.principal.length).cardio;
  assert.ok(cardio('definir').minutos >= 10 && cardio('definir').minutos <= 20);
  assert.ok(cardio('mantener').minutos <= cardio('definir').minutos);
  assert.ok(cardio('volumen').minutos < cardio('mantener').minutos, 'volumen lleva poco cardio');
});

test('2. El enfoque muscular agrega un ejercicio por sesión sin pasar de 8', () => {
  ['piernas', 'brazos', 'espalda'].forEach((enfoque) => {
    const sin = G.generarSemana({ ...BASE, frecuencia: 4, lugar: 'gimnasio' });
    const con = G.generarSemana({ ...BASE, frecuencia: 4, lugar: 'gimnasio', enfoque });
    sesionesDeFuerza(sin).forEach((dia, i) => {
      const otra = sesionesDeFuerza(con)[i];
      assert.equal(otra.principal.length, dia.principal.length + 1, `${enfoque} día ${i}`);
      assert.ok(otra.principal.length <= 8);
      assert.ok(otra.principal.some((it) => it.enfoque), 'alguna serie extra marcada como enfoque');
    });
  });
  const parejo = G.generarSemana({ ...BASE, frecuencia: 3, enfoque: 'cuerpo_completo' });
  const base = G.generarSemana({ ...BASE, frecuencia: 3 });
  assert.deepEqual(parejo.dias.map((d) => d.principal.length), base.dias.map((d) => d.principal.length));
});

test('cada sesión trae calentamiento, bloque principal y enfriamiento con duración estimada', () => {
  const semana = G.generarSemana({ ...BASE, frecuencia: 4 });
  sesionesDeFuerza(semana).forEach((dia) => {
    assert.ok(dia.calentamiento.length >= 3 && dia.calentamiento.length <= 4);
    assert.ok(dia.principal.length >= 4);
    assert.ok(dia.enfriamiento.length >= 3 && dia.enfriamiento.length <= 5);
    assert.ok(dia.duracionMin >= 20 && dia.duracionMin <= 90, `duración ${dia.duracionMin}`);
    dia.calentamiento.concat(dia.enfriamiento).forEach((it) => assert.equal(G.ejercicioPorId(it.id).tipo, 'movilidad'));
  });
});

test('3. Plan de distancia: crece cerca de 10 %, cada 4.ª semana baja y nunca pasa la meta', () => {
  NIVELES.forEach((nivel) => {
    [3, 5, 10, 21, 42].forEach((meta) => {
      const plan = G.planDistancia({ distanciaKm: meta, nivel }, 12);
      let ultimaNormal = null;
      plan.forEach((s) => {
        assert.ok(s.km <= meta + 1e-9, `${nivel}/${meta}/semana ${s.semana}: ${s.km}`);
        if (s.descarga) {
          assert.ok(s.km < ultimaNormal, `descarga semana ${s.semana}`);
        } else {
          if (ultimaNormal !== null && s.km < meta) {
            const razon = s.km / ultimaNormal;
            assert.ok(razon > 1.03 && razon < 1.2, `crecimiento ${razon.toFixed(3)} en ${nivel}/${meta}/semana ${s.semana}`);
          }
          ultimaNormal = s.km;
        }
      });
    });
  });
  assert.deepEqual(G.planDistancia({ distanciaKm: null }), []);
  assert.equal(G.planDistancia({ distanciaKm: 5, nivel: 'principiante' })[0].km, 2);
  assert.equal(G.planDistancia({ distanciaKm: 30, nivel: 'intermedio' })[0].km, 3.5);
});

test('3. La distancia cambia el plan: reparte los km en sesiones de cardio de los días elegidos', () => {
  const sin = G.generarSemana({ ...BASE, frecuencia: 4 });
  const con = G.generarSemana({ ...BASE, frecuencia: 4, distanciaKm: 10, nivel: 'principiante', semanaNumero: 3 });
  assert.equal(sin.resumen.kmSemana, 0);
  assert.ok(con.resumen.kmSemana > 0);
  const sesiones = con.dias.filter((d) => d.cardio && d.cardio.km);
  assert.equal(sesiones.length, con.resumen.sesionesCarrera);
  const suma = sesiones.reduce((t, d) => t + d.cardio.km, 0);
  assert.ok(Math.abs(suma - con.resumen.kmSemana) < 0.2, `suma ${suma} vs meta ${con.resumen.kmSemana}`);
  assert.equal(sesiones[0].cardio.id, 'intervalos_trote_caminata');
  assert.deepEqual(sesiones[0].cardio.pauta, { trote: 1, caminata: 2 });
  sesiones.forEach((d) => assert.ok(d.entrena));
});

test('4. Menores de 18: sin repeticiones menores a 8, sin sesiones de más de 60 min y con aviso', () => {
  OBJETIVOS.forEach((objetivo) => {
    NIVELES.forEach((nivel) => {
      [1, 3, 5, 6, 7].forEach((frecuencia) => {
        [null, 5, 40].forEach((distanciaKm) => {
          [1, 4, 6].forEach((semanaNumero) => {
            const semana = G.generarSemana({ ...BASE, edad: 16, objetivo, nivel, frecuencia, distanciaKm, semanaNumero, lugar: 'gimnasio', enfoque: 'piernas' });
            assert.ok(semana.avisos.includes('supervisionMenor'));
            semana.dias.forEach((dia) => {
              assert.ok(dia.duracionMin <= 60, `${objetivo}/${nivel}/f${frecuencia}/km${distanciaKm}/s${semanaNumero}: ${dia.duracionMin} min`);
              dia.principal.filter((it) => it.unidad === 'rep').forEach((it) => assert.ok(it.repeticiones >= 8, `${it.id}: ${it.repeticiones}`));
              dia.principal.forEach((it) => assert.ok(!G.ejercicioPorId(it.id).flags.includes('esfuerzoMaximo'), it.id));
            });
          });
        });
      });
    });
  });
  assert.ok(!G.generarSemana({ ...BASE, edad: 30 }).avisos.includes('supervisionMenor'));
});

test('5. Determinismo por semilla y semana de descarga', () => {
  const a = G.generarSemana({ ...BASE, frecuencia: 5, semilla: 11 });
  const b = G.generarSemana({ ...BASE, frecuencia: 5, semilla: 11 });
  assert.deepEqual(a, b);

  const distintas = [1, 2, 3, 4, 5, 6].map((s) => JSON.stringify(G.generarSemana({ ...BASE, frecuencia: 4, lugar: 'gimnasio', semilla: s }).dias.map((d) => d.principal.map((i) => i.id))));
  assert.ok(new Set(distintas).size > 1, 'la semilla cambia la selección');

  const normal = G.generarSemana({ ...BASE, frecuencia: 4, semanaNumero: 3, objetivo: 'volumen' });
  const descarga = G.generarSemana({ ...BASE, frecuencia: 4, semanaNumero: 4, objetivo: 'volumen' });
  assert.equal(descarga.descarga, true);
  assert.ok(descarga.avisos.includes('semanaDescarga'));
  const volumen = (sem) => sesionesDeFuerza(sem).reduce((t, d) => t + d.principal.reduce((x, it) => x + it.series, 0), 0);
  assert.ok(volumen(descarga) <= volumen(normal) * 0.8, `${volumen(descarga)} vs ${volumen(normal)}`);

  const repsSemana = (n) => sesionesDeFuerza(G.generarSemana({ ...BASE, frecuencia: 3, semanaNumero: n }))[0].principal.find((i) => i.unidad === 'rep').repeticiones;
  assert.equal(repsSemana(2), repsSemana(1) + 1);
  assert.equal(repsSemana(3), repsSemana(2) + 1);
  assert.equal(repsSemana(4), repsSemana(3));
});

test('6. Ningún ejercicio pide equipo que el lugar no ofrece', () => {
  for (let f = 1; f <= 7; f += 1) {
    NIVELES.forEach((nivel) => {
      const semana = G.generarSemana({ ...BASE, frecuencia: f, nivel, lugar: 'casa', enfoque: 'brazos', distanciaKm: 5 });
      semana.dias.forEach((dia) => {
        [].concat(dia.calentamiento, dia.principal, dia.cardio ? [dia.cardio] : [], dia.enfriamiento).forEach((it) => {
          const ej = G.ejercicioPorId(it.id);
          assert.ok(ej.lugar.includes('casa'), `${it.id} no es de casa`);
          ej.equipo.forEach((e) => assert.ok(EQUIPO_CASA.includes(e), `${it.id} pide ${e}`));
        });
      });
    });
  }
  const gym = G.generarSemana({ ...BASE, lugar: 'gimnasio', frecuencia: 4 });
  gym.dias.forEach((dia) => dia.principal.forEach((it) => assert.ok(G.ejercicioPorId(it.id).lugar.includes('gimnasio'), it.id)));
});

test('la calorías estimadas usan MET x peso x horas', () => {
  const sesion = sesionesDeFuerza(G.generarSemana({ ...BASE, frecuencia: 3 }))[0];
  const kcal = G.kcalEstimadas(70, sesion, 3600);
  assert.ok(kcal >= 70 * 3.5 && kcal <= 70 * 6, `kcal ${kcal}`);
  assert.equal(G.kcalEstimadas(0, sesion, 3600), 0);
  assert.equal(G.kcalEstimadas(70, sesion, 0), 0);
});

test('perfil con datos raros se normaliza sin romper', () => {
  const semana = G.generarSemana({ objetivo: 'xx', frecuencia: 99, distanciaKm: -5, enfoque: 'otro', nivel: '??', lugar: '??', edad: 'a', semanaNumero: -3, semilla: 'z' });
  assert.equal(semana.dias.length, 7);
  assert.equal(semana.perfil.frecuencia, 7);
  assert.equal(semana.perfil.lugar, 'casa');
  assert.equal(semana.perfil.distanciaKm, null);
});
