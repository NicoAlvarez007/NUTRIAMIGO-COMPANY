const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { iniciarServidor, iniciarSesion, BIOMETRIA_VALIDA } = require('./ayudas');
const { sumarDias } = require('../server/lib/fechas');

const ENV = { ADMIN_USER: 'administrador', ADMIN_PASSWORD: 'clave-admin-prueba', GOOGLE_SIMULADO: 'true' };
const jpeg = (extra = 200) => Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(extra, 5)]);
const dataUrl = (buf, tipo = 'image/jpeg') => `data:${tipo};base64,${buf.toString('base64')}`;

async function usuario(s, correo) {
  const c = s.cliente();
  const r = await c.post('/auth/registro', { email: correo, password: 'clave-segura-1' });
  assert.equal(r.status, 201);
  assert.equal((await c.post('/api/biometrics', BIOMETRIA_VALIDA)).status, 200);
  return c;
}

async function entrarAdmin(s) {
  const c = s.cliente();
  assert.equal((await c.post('/auth/login', { identificador: 'administrador', password: 'clave-admin-prueba' })).status, 200);
  return c;
}

test('registrar peso: sin interruptores solo guarda en el historial, aunque la diferencia sea grande', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuario(s, 'peso1@prueba.com');
  const r = await c.post('/api/progress', { peso: 80 });
  assert.equal(r.status, 200);
  assert.equal(r.datos.progreso.length, 1);
  assert.equal(r.datos.requiereCambioPlan, undefined);
  assert.equal(r.datos.planActualizado, undefined);
  assert.equal((await c.get('/api/biometrics')).datos.peso, 70, 'el peso del plan no cambió');
});

test('registrar peso: interruptor 1 encendido con aviso, sin aviso y con diferencia menor a 5 kg', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuario(s, 'peso2@prueba.com');

  assert.equal((await c.post('/api/settings', { planAutoUpdate: true, planConfirm: true })).status, 200);
  const chico = await c.post('/api/progress', { peso: 72 });
  assert.equal(chico.datos.requiereCambioPlan, undefined);
  assert.equal(chico.datos.planActualizado, undefined);

  const aviso = await c.post('/api/progress', { peso: 76 });
  assert.deepEqual(aviso.datos.requiereCambioPlan, { de: 70, a: 76 });
  assert.equal((await c.get('/api/biometrics')).datos.peso, 70, 'con aviso no se cambia hasta aceptar');

  assert.equal((await c.post('/api/plan/aceptar-cambio', { peso: 99 })).datos.code, 'cambio_no_valido', 'solo un peso ya registrado');
  const ok = await c.post('/api/plan/aceptar-cambio', { peso: 76 });
  assert.equal(ok.datos.planActualizado, true);
  assert.equal((await c.get('/api/biometrics')).datos.peso, 76);
  assert.equal((await c.post('/api/plan/aceptar-cambio', { peso: 76 })).datos.code, 'cambio_no_valido', 'ya no hay 5 kg de diferencia');

  assert.equal((await c.post('/api/settings', { planConfirm: false })).status, 200);
  const directo = await c.post('/api/progress', { peso: 82 });
  assert.equal(directo.datos.planActualizado, true);
  assert.equal(directo.datos.de, 76);
  assert.equal(directo.datos.a, 82);
  assert.equal((await c.get('/api/biometrics')).datos.peso, 82);
});

test('ajustes: se guardan parcialmente, se validan y viajan en /api/me', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuario(s, 'ajustes@prueba.com');
  assert.equal((await c.get('/api/settings')).datos.planConfirm, true);
  await c.post('/api/settings', { tema: 'dark', tamanoLetra: 'grande', recordarAgua: true, horaAgua: '08:15' });
  await c.post('/api/settings', { idioma: 'de' });
  const a = (await c.get('/api/settings')).datos;
  assert.equal(a.tema, 'dark');
  assert.equal(a.idioma, 'de');
  assert.equal(a.tamanoLetra, 'grande');
  assert.equal(a.recordarAgua, true);
  assert.equal(a.horaAgua, '08:15');
  assert.equal((await c.get('/api/me')).datos.ajustes.tema, 'dark');
  assert.equal((await c.post('/api/settings', { tema: 'rosa' })).status, 400);
  assert.equal((await c.post('/api/settings', { horaAgua: '99:99' })).datos.code, 'hora_invalida');
  assert.equal((await s.cliente().get('/api/settings')).status, 401);
});

test('agua y km: validaciones, plan del día con kcal extra y tope de 800', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuario(s, 'agua@prueba.com');
  assert.equal((await c.post('/api/daily-log', { vasosAgua: 41 })).status, 400);
  assert.equal((await c.post('/api/daily-log', { vasosAgua: 40 })).status, 200);
  assert.equal((await c.post('/api/daily-log', { kmRecorridos: 201 })).status, 400);

  const r = await c.post('/api/daily-log', { vasosAgua: 6, kmRecorridos: 5 });
  assert.equal(r.datos.kcalExtraHoy, 263);
  const plan = (await c.get('/api/plan')).datos;
  assert.equal(plan.pesoPlan, 70);
  assert.equal(plan.aguaMetaVasos, 10);
  assert.equal(plan.kcalExtraHoy, 263);
  assert.equal(plan.kcalMetaHoy, plan.kcalBase + 263);
  assert.equal((await c.get('/api/me')).datos.kcalExtraHoy, 263);

  await c.post('/api/daily-log', { kmRecorridos: 200 });
  assert.equal((await c.get('/api/plan')).datos.kcalExtraHoy, 800);

  const h = (await c.get('/api/historial-diario?dias=7')).datos;
  assert.equal(h.length, 7);
  assert.equal(h[6].vasos, 40);
  assert.equal(h[0].vasos, 0);
  const mes = (await c.get('/api/resumen-mensual')).datos;
  assert.equal(mes.mejorVasos.valor, 40);
});

test('sueño y ánimo: una vez por día, validado, y con historial', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuario(s, 'sueno@prueba.com');
  assert.equal((await c.post('/api/wellbeing', { horas: 17, animo: 3 })).status, 400);
  assert.equal((await c.post('/api/wellbeing', { horas: 7, animo: 9 })).status, 400);
  assert.equal((await c.post('/api/wellbeing', { horas: 6.5, animo: 3 })).status, 200);
  assert.equal((await c.post('/api/wellbeing', { horas: 8, animo: 5 })).status, 200);
  const r = (await c.get('/api/wellbeing?dias=14')).datos;
  assert.equal(r.registros.length, 1);
  assert.equal(r.hoy.horas, 8);
  assert.equal(r.hoy.animo, 5);
});

test('fotos: consentimiento, subida, validaciones, privacidad, límite de 60 y borrado', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const ana = await usuario(s, 'fotos1@prueba.com');
  const beto = await usuario(s, 'fotos2@prueba.com');
  const id = (await ana.get('/api/me')).datos.id;

  assert.equal((await ana.post('/api/photos', { imagen: dataUrl(jpeg()) })).datos.code, 'fotos_consentimiento_requerido');
  assert.equal((await ana.get('/api/photos')).datos.consentimiento, false);
  await ana.post('/api/settings', { fotosConsentimiento: true });
  assert.equal((await ana.get('/api/photos')).datos.consentimiento, true);

  assert.equal((await ana.post('/api/photos', { imagen: dataUrl(jpeg(), 'image/png') })).status, 400);
  assert.equal((await ana.post('/api/photos', { imagen: dataUrl(Buffer.from('texto disfrazado de foto')) })).status, 400);
  assert.equal((await ana.post('/api/photos', { imagen: dataUrl(jpeg(2 * 1024 * 1024 + 50)) })).status, 400);

  await ana.post('/api/progress', { peso: 71.5 });
  const subida = await ana.post('/api/photos', { imagen: dataUrl(jpeg()) });
  assert.equal(subida.status, 201);
  assert.equal(subida.datos.peso, 71.5, 'peso registrado cerca de la fecha');
  const carpeta = path.join(s.rutaUploads, String(id));
  assert.equal(fs.readdirSync(carpeta).length, 1);
  assert.match(fs.readdirSync(carpeta)[0], /^[0-9a-f-]{36}\.jpg$/);

  const archivo = await ana.get(`/api/photos/${subida.datos.id}/file`);
  assert.equal(archivo.status, 200);
  assert.equal(archivo.cabeceras.get('content-type'), 'image/jpeg');
  assert.match(archivo.cabeceras.get('cache-control'), /private/);
  assert.equal((await beto.get(`/api/photos/${subida.datos.id}/file`)).status, 404, 'otra persona no la ve');
  assert.equal((await beto.delete(`/api/photos/${subida.datos.id}`)).status, 404);
  assert.equal((await s.cliente().get(`/api/photos/${subida.datos.id}/file`)).status, 401);
  assert.equal((await ana.get('/uploads/' + id + '/x.jpg')).status, 404, 'uploads no se sirve como estático');
  assert.equal((await ana.get('/server/uploads/')).status, 404);

  assert.equal((await ana.delete(`/api/photos/${subida.datos.id}`)).status, 200);
  assert.equal(fs.readdirSync(carpeta).length, 0, 'se borró el archivo');
  assert.equal((await ana.get('/api/photos')).datos.fotos.length, 0);

  const buffer = jpeg();
  for (let i = 0; i < 60; i += 1) {
    const ref = require('crypto').randomUUID() + '.jpg';
    fs.writeFileSync(path.join(carpeta, ref), buffer);
    s.servidor.db.prepare('INSERT INTO progress_photos (user_id, fecha, ref, creado_en) VALUES (?, ?, ?, ?)').run(id, '2026-01-01', ref, 'x');
  }
  const limite = await ana.post('/api/photos', { imagen: dataUrl(jpeg()) });
  assert.equal(limite.status, 409);
  assert.equal(limite.datos.code, 'foto_limite');
});

test('descargar mis datos y borrar la cuenta (con palabra) elimina filas y carpeta de fotos', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuario(s, 'borrar@prueba.com');
  const id = (await c.get('/api/me')).datos.id;
  await c.post('/api/progress', { peso: 70 });
  await c.post('/api/wellbeing', { horas: 7, animo: 4 });
  await c.post('/api/settings', { fotosConsentimiento: true });
  await c.post('/api/photos', { imagen: dataUrl(jpeg()) });

  const datos = await c.get('/api/account/export');
  assert.equal(datos.status, 200);
  assert.match(datos.cabeceras.get('content-disposition'), /attachment/);
  assert.equal(datos.datos.datosBase.peso, 70);
  assert.equal(datos.datos.progresoPeso.length, 1);
  assert.equal(datos.datos.suenoAnimo.length, 1);
  assert.equal(datos.datos.fotos.length, 1);
  assert.ok(!JSON.stringify(datos.datos).includes('password'));
  assert.ok(!JSON.stringify(datos.datos).includes('.jpg'), 'no expone nombres internos de archivos');

  assert.equal((await c.post('/api/account/borrar', { palabra: 'borrar' })).status, 400);
  assert.equal((await c.get('/api/me')).status, 200);
  assert.equal((await c.post('/api/account/borrar', { palabra: 'BORRAR' })).status, 200);
  assert.equal((await c.get('/api/me')).status, 401);
  assert.equal(fs.existsSync(path.join(s.rutaUploads, String(id))), false);
  const db = s.servidor.db;
  ['progress', 'wellbeing_logs', 'progress_photos', 'user_settings'].forEach((tabla) => {
    assert.equal(db.prepare(`SELECT COUNT(*) AS n FROM ${tabla} WHERE user_id = ?`).get(id).n, 0, tabla);
  });
});

test('administrador: datos de ejemplo, borrarlos y reiniciar el día', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const admin = await entrarAdmin(s);
  const c = await usuario(s, 'normal@prueba.com');
  assert.equal((await c.post('/api/admin/datos-ejemplo', {})).status, 403);

  assert.equal((await admin.post('/api/admin/datos-ejemplo', {})).status, 200);
  const hoy = (await admin.get('/api/me')).datos.today;
  const progreso = (await admin.get('/api/progress')).datos.progreso || (await admin.get('/api/progress')).datos;
  assert.ok(progreso.length >= 60, `pesos: ${progreso.length}`);
  assert.equal((await admin.get('/api/historial-diario?dias=31')).datos.filter((d) => d.vasos > 0).length >= 29, true);
  assert.equal((await admin.get('/api/wellbeing?dias=14')).datos.registros.length, 14);
  const fotos = (await admin.get('/api/photos')).datos.fotos;
  assert.equal(fotos.length, 3);
  assert.equal((await admin.get(`/api/photos/${fotos[0].id}/file`)).status, 200);

  await admin.post('/api/completions', { itemKey: `alimentacion-lunes-cena` });
  const r = await admin.post('/api/admin/reiniciar-dia', {});
  assert.equal(r.status, 200);
  assert.equal(r.datos.fecha, hoy);
  assert.equal((await admin.get('/api/wellbeing')).datos.hoy, null, 'sueño de hoy borrado');
  assert.equal((await admin.get('/api/daily-log')).datos.vasos_agua, 0, 'agua de hoy borrada');
  assert.deepEqual((await admin.get('/api/completions')).datos, []);

  assert.equal((await admin.delete('/api/admin/datos-ejemplo')).status, 200);
  assert.equal((await admin.get('/api/photos')).datos.fotos.length, 0);
  assert.equal((await admin.get('/api/wellbeing?dias=14')).datos.registros.length, 0);
  const idAdmin = (await admin.get('/api/me')).datos.id;
  assert.equal(fs.existsSync(path.join(s.rutaUploads, String(idAdmin))), false);
});

test('admin: al eliminar un usuario también se borran sus fotos', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuario(s, 'adios@prueba.com');
  const id = (await c.get('/api/me')).datos.id;
  await c.post('/api/settings', { fotosConsentimiento: true });
  await c.post('/api/photos', { imagen: dataUrl(jpeg()) });
  assert.equal(fs.existsSync(path.join(s.rutaUploads, String(id))), true);
  const admin = await entrarAdmin(s);
  assert.equal((await admin.delete(`/api/admin/usuarios/${id}`)).status, 200);
  assert.equal(fs.existsSync(path.join(s.rutaUploads, String(id))), false);
});

test('fecha simulada del admin mueve las fotos, el sueño y el historial a ese día', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const admin = await entrarAdmin(s);
  await admin.post('/api/admin/fecha', { fecha: '2030-05-20' });
  await admin.post('/api/wellbeing', { horas: 7, animo: 3 });
  await admin.post('/api/daily-log', { vasosAgua: 3 });
  assert.equal((await admin.get('/api/wellbeing')).datos.hoy.fecha, '2030-05-20');
  const h = (await admin.get('/api/historial-diario?dias=3')).datos;
  assert.deepEqual(h.map((d) => d.fecha), [sumarDias('2030-05-20', -2), sumarDias('2030-05-20', -1), '2030-05-20']);
  assert.equal(h[2].vasos, 3);
});
