const test = require('node:test');
const assert = require('node:assert/strict');
const { iniciarServidor } = require('./ayudas');
const { diaDeSemana, sumarDias, limitesSemana } = require('../server/lib/fechas');

const ENV = { ADMIN_USER: 'administrador', ADMIN_PASSWORD: 'clave-admin-prueba', GOOGLE_SIMULADO: 'true' };
const DATOS = { nombre: 'Ana', apellido: 'Pérez', peso: 60, estatura: 165, sexo: 'mujer', edad: 30, actividad: 'ligero', objetivo: 'mantener' };

async function usuarioConDatos(s, correo) {
  const c = s.cliente();
  await c.post('/auth/registro', { email: correo, password: 'clave-segura-1' });
  await c.post('/api/biometrics', DATOS);
  return c;
}

async function entrarAdmin(s) {
  const c = s.cliente();
  const r = await c.post('/auth/login', { identificador: 'administrador', password: 'clave-admin-prueba' });
  assert.equal(r.status, 200);
  return c;
}

test('solo se puede marcar el entrenamiento del día de hoy, y "marcar" no desmarca', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuarioConDatos(s, 'hoy@prueba.com');
  const hoy = (await c.get('/api/me')).datos.today;
  const dia = diaDeSemana(hoy);
  const otro = diaDeSemana(sumarDias(hoy, 1));

  const ayer = await c.post('/api/completions', { itemKey: `entrenamiento-${otro}` });
  assert.equal(ayer.status, 400);
  assert.equal(ayer.datos.code, 'solo_hoy');

  assert.equal((await c.post('/api/completions', { itemKey: `entrenamiento-${dia}`, marcar: true })).datos.completado, true);
  assert.equal((await c.post('/api/completions', { itemKey: `entrenamiento-${dia}`, marcar: true })).datos.completado, true);
  assert.deepEqual((await c.get('/api/completions')).datos, [`entrenamiento-${dia}`]);

  assert.equal((await c.post('/api/completions', { itemKey: `entrenamiento-${dia}` })).datos.completado, false);
  assert.equal((await c.post('/api/completions', { itemKey: `entrenamiento-${dia}`, marcar: 'si' })).status, 400);
});

test('"Reiniciar" borra solo las marcas de hoy del tipo pedido', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuarioConDatos(s, 'reinicio@prueba.com');
  const hoy = (await c.get('/api/me')).datos.today;
  const dia = diaDeSemana(hoy);

  await c.post('/api/completions', { itemKey: `entrenamiento-${dia}` });
  await c.post('/api/completions', { itemKey: `alimentacion-${dia}-desayuno` });
  const r = await c.post('/api/completions/reiniciar', { tipo: 'entrenamiento' });
  assert.equal(r.datos.borradas, 1);
  assert.deepEqual((await c.get('/api/completions')).datos, [`alimentacion-${dia}-desayuno`]);
  assert.equal((await c.post('/api/completions/reiniciar', { tipo: 'otra' })).status, 400);
  assert.equal((await c.post('/api/completions/reiniciar', {})).datos.borradas, 1);
  assert.deepEqual((await c.get('/api/completions')).datos, []);
});

test('GET /api/entrenamiento/semana suma los km de la semana local y usa la fecha simulada del admin', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuarioConDatos(s, 'km@prueba.com');
  await c.post('/api/daily-log', { kmRecorridos: 3.2 });

  const semana = (await c.get('/api/entrenamiento/semana')).datos;
  const hoy = (await c.get('/api/me')).datos.today;
  assert.equal(semana.hoy, hoy);
  assert.equal(semana.dia, diaDeSemana(hoy));
  assert.equal(semana.desde, limitesSemana(hoy).desde);
  assert.equal(semana.hasta, limitesSemana(hoy).hasta);
  assert.equal(semana.km, 3.2);
  assert.equal(semana.semanaNumero, 1);
  assert.equal((await s.cliente().get('/api/entrenamiento/semana')).status, 401);

  const admin = await entrarAdmin(s);
  await admin.post('/api/admin/fecha', { fecha: '2030-05-20' });
  const sim = (await admin.get('/api/entrenamiento/semana')).datos;
  assert.equal(sim.hoy, '2030-05-20');
  assert.equal(sim.km, 0);
  assert.ok(sim.semanaNumero > 1, 'la semana del plan avanza con la fecha simulada');
});

test('preferencias de entrenamiento: solo Premium, validadas, guardado parcial y reinicio del plan de distancia', async (t) => {
  const s = await iniciarServidor({ env: ENV });
  t.after(() => s.detener());
  const c = await usuarioConDatos(s, 'prefs@prueba.com');
  const id = (await c.get('/api/me')).datos.id;

  assert.equal((await c.post('/api/preferences', { frecuenciaSemanal: 4 })).status, 403);
  s.servidor.db.prepare('UPDATE users SET is_premium = 1 WHERE id = ?').run(id);

  assert.equal((await c.post('/api/preferences', { frecuenciaSemanal: 8 })).status, 400);
  assert.equal((await c.post('/api/preferences', { distanciaKm: 101 })).status, 400);
  assert.equal((await c.post('/api/preferences', { nivel: 'experto' })).datos.code, 'nivel_invalido');
  assert.equal((await c.post('/api/preferences', { lugar: 'playa' })).datos.code, 'lugar_invalido');

  assert.equal((await c.post('/api/preferences', { frecuenciaSemanal: 5, nivel: 'intermedio', lugar: 'gimnasio', enfoqueMuscular: 'brazos' })).status, 200);
  assert.equal((await c.post('/api/preferences', { distanciaKm: 5 })).status, 200);
  const prefs = (await c.get('/api/preferences')).datos;
  assert.equal(prefs.frecuenciaSemanal, 5);
  assert.equal(prefs.nivel, 'intermedio');
  assert.equal(prefs.lugar, 'gimnasio');
  assert.equal(prefs.enfoqueMuscular, 'brazos');
  assert.equal(prefs.distanciaKm, 5);
  assert.equal(prefs.planInicio, (await c.get('/api/me')).datos.today);

  assert.equal((await c.post('/api/preferences', { frecuenciaSemanal: 3 })).status, 200);
  const despues = (await c.get('/api/preferences')).datos;
  assert.equal(despues.frecuenciaSemanal, 3);
  assert.equal(despues.distanciaKm, 5);
  assert.equal(despues.nivel, 'intermedio');
});
