const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');

const RAIZ = path.join(__dirname, '..', 'public');
const PAGINAS = ['index', 'onboarding', 'dashboard', 'alimentacion', 'entrenamiento', 'comunidad', 'premium'];
const leer = (f) => fs.readFileSync(path.join(RAIZ, f), 'utf8');

test('todas las páginas declaran viewport móvil y color de tema', () => {
  PAGINAS.forEach(p => {
    const html = leer(`${p}.html`);
    assert.match(html, /viewport-fit=cover/, p);
    assert.match(html, /name="theme-color" content="#3ecf8e"/, p);
  });
});

test('ninguna página depende de CDN ni de Google Fonts', () => {
  PAGINAS.forEach(p => {
    const html = leer(`${p}.html`);
    assert.doesNotMatch(html, /fonts\.googleapis|fonts\.gstatic|cdnjs\.cloudflare/, p);
  });
});

test('el tema por defecto es claro (sin cambio automático por hora)', () => {
  PAGINAS.forEach(p => assert.doesNotMatch(leer(`${p}.html`), /getHours/, p));
  assert.doesNotMatch(leer('js/ui.js'), /getHours/);
});

test('las páginas internas usan nav.js y cargan responsive.css', () => {
  ['dashboard', 'alimentacion', 'entrenamiento', 'comunidad', 'premium'].forEach(p => {
    const html = leer(`${p}.html`);
    assert.match(html, /id="appHeader"/, p);
    assert.match(html, /js\/nav\.js/, p);
  });
  PAGINAS.forEach(p => assert.match(leer(`${p}.html`), /css\/responsive\.css/, p));
});

test('las claves nuevas existen en inglés y alemán', () => {
  const src = leer('js/i18n.js');
  const claves = ['nav.principal', 'nav.perfil', 'nav.abrirMenu', 'bnav.inicio', 'bnav.alimentacion', 'bnav.entrenamiento',
    'bnav.comunidad', 'bnav.mas', 'appnav.logros', 'tema.auto', 'com.volverAmigos', 'dash.graficaPeso', 'dash.graficaImc',
    'ob.err.nombre', 'ob.err.medidas', 'ob.err.perfil', 'ob.err.objetivo', 'ob.err.guardar'];
  claves.forEach(c => assert.strictEqual(src.split(`'${c}'`).length - 1, 2, `${c} debe estar en en y de`));
});

test('los canvas del dashboard no tienen ancho fijo', () => {
  assert.doesNotMatch(leer('dashboard.html'), /<canvas[^>]*width="/);
});

test('el manifest incluye íconos maskable y los archivos existen', () => {
  const m = JSON.parse(leer('manifest.json'));
  assert.ok(m.icons.some(i => i.purpose === 'maskable'));
  m.icons.forEach(i => assert.ok(fs.existsSync(path.join(RAIZ, i.src)), i.src));
});

test('las páginas de cuentas existen, cargan i18n y api, y no dependen de enlaces legales inexistentes', () => {
  ['acceso', 'google-simulado', 'suspendida', 'admin'].forEach((p) => {
    const html = leer(`${p}.html`);
    assert.match(html, /js\/i18n\.js/, p);
    assert.match(html, /js\/api\.js/, p);
    assert.match(html, /css\/responsive\.css/, p);
  });
  assert.doesNotMatch(leer('acceso.html'), /terminos\.html|privacidad\.html/);
});

test('ninguna página ni script usa el modo demo ni el atajo de cuenta compartida', () => {
  PAGINAS.forEach((p) => assert.doesNotMatch(leer(`${p}.html`), /demo-mode|auth\/google/, p));
  assert.equal(fs.existsSync(path.join(RAIZ, 'js', 'demo-mode.js')), false);
});

test('Parte 6: Entrenamiento carga la biblioteca, el generador y "Entrenar ahora" sin scripts en línea', () => {
  const html = leer('entrenamiento.html');
  ['data/ejercicios.js', 'js/generador-rutinas.js', 'js/entrenar-ahora.js', 'js/entrenamiento.js', 'css/entrenar.css'].forEach((ruta) => {
    assert.match(html, new RegExp(ruta.replace(/[./]/g, '\\$&')), ruta);
  });
  assert.doesNotMatch(html, /workouts/);
  assert.doesNotMatch(html, /<script>[^<]/);
  const orden = (a, b) => assert.ok(html.indexOf(a) < html.indexOf(b), `${a} antes de ${b}`);
  orden('data/ejercicios.js', 'js/generador-rutinas.js');
  orden('js/generador-rutinas.js', 'js/entrenamiento.js');
  orden('js/plan-shared.js', 'js/entrenamiento.js');
  ['trainNowBtn', 'entrenarAhora', 'eaHecho', 'eaAnillo', 'eaSonido', 'weekCard'].forEach((id) => assert.match(html, new RegExp(`id="${id}"`), id));
});

test('Parte 6: el dashboard y el panel de administrador también cargan el generador', () => {
  ['dashboard.html', 'admin.html'].forEach((p) => {
    const html = leer(p);
    assert.match(html, /data\/ejercicios\.js/, p);
    assert.match(html, /js\/generador-rutinas\.js/, p);
    assert.doesNotMatch(html, /workouts/, p);
  });
});

test('Parte 7: el dashboard tiene una sola gráfica de progreso, las tarjetas nuevas y no usa librerías externas', () => {
  const html = leer('dashboard.html');
  ['progressChart', 'modoTabs', 'hoyCard', 'waterChart', 'kmChart', 'sleepChart', 'moodGroup', 'fotosCard', 'fotoArchivo', 'kmInput'].forEach((id) => {
    assert.match(html, new RegExp(`id="${id}"`), id);
  });
  assert.doesNotMatch(html, /imcChart/, 'la gráfica de IMC separada ya no existe');
  assert.doesNotMatch(html, /https?:\/\/(cdn|unpkg|cdnjs)/i);
  assert.match(html, /css\/dashboard\.css/);
  assert.ok(html.indexOf('js/graficas.js') < html.indexOf('js/dashboard.js'));
  assert.doesNotMatch(html, /<script>[^<]/);
});

test('Parte 7: Configuración incluye el plan automático, comidas, tamaño de letra y los pies de privacidad', () => {
  const js = leer('js/settings.js');
  ['planAutoToggle', 'planConfirmToggle', 'recordarComidasToggle', 'letraGroup', 'cfgSexo', 'exportDataBtn', 'deleteAccountBtn'].forEach((id) => {
    assert.match(js, new RegExp(id), id);
  });
  assert.match(js, /api\/account\/borrar/);
  assert.match(js, /api\/account\/export/);
});

test('Parte 7: el tamaño de letra se aplica antes de pintar y existen las tres escalas', () => {
  assert.match(leer('js/tema-inicial.js'), /data-letra/);
  const css = leer('css/dashboard.css');
  assert.match(css, /data-letra="grande"/);
  assert.match(css, /data-letra="muy_grande"/);
});

test('Parte 7: la política de seguridad no permite scripts ni imágenes externas', () => {
  const seg = fs.readFileSync(path.join(__dirname, '..', 'server', 'middleware', 'seguridad.js'), 'utf8');
  assert.doesNotMatch(seg, /unsafe-eval/);
  assert.match(seg, /img-src/);
});

test('Parte 7: ninguna foto se sirve como archivo estático (uploads vive en server/)', () => {
  assert.equal(fs.existsSync(path.join(RAIZ, 'uploads')), false);
  assert.equal(fs.existsSync(path.join(RAIZ, 'data', 'uploads')), false);
});
